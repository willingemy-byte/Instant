#!/usr/bin/env bash
set -u

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
cd "$ROOT"

# Idempotent: do nothing if the demo server is already running.
if pgrep -f "python3 -m http.server 8000" >/dev/null 2>&1; then
  exit 0
fi

nohup python3 -m http.server 8000 --bind 0.0.0.0 > /tmp/aiv-demo.log 2>&1 &
