# Demo-AIV

Démonstrateur visuel du projet **All In Visible**. Cette version montre la logique d’exécution et de gouvernance de l’infrastructure sans reproduire tout le backend final.

## Mémoire d’architecture

La mémoire conceptuelle canonique de l’architecture AIV est conservée dans :

- `docs/aiv-architecture-memory.md`

Ce document fixe notamment les invariants autour des identités cryptographiques par entité, du pedigree causal, de `AIV_API_K`, de Kubernetes comme porte d’entrée, de Main, DNPC, Watcher, du journal à visibilité contrôlée et du rollback causal.

## Version actuelle

La démo comprend quatre vues :

- **Architecture** — appareil, identités cryptographiques, moteur local, MAIN, WATCHER, journal local, journal central, alertes et accès utilisateur.
- **Journal central** — historique détaillé des interactions, analyse WATCHER et réponse MAIN.
- **Anomalie & restauration** — comparaison avant/après, décision MAIN, rollback et ligne du temps.
- **Faisabilité** — distinction entre les éléments directement réalisables et ceux qui exigent une intégration système forte.

Le design est **responsive** : sur grand écran, les blocs forment une vue globale horizontale; sur mobile, les mêmes blocs s’empilent verticalement dans un ordre logique.

## Prévisualisation avec Codespaces

On conserve la même méthode de prévisualisation avec **GitHub Codespaces**. Le dépôt contient une configuration `.devcontainer` qui démarre le serveur web sur le port **8000** et expose la démo depuis le Codespace.

Les fichiers principaux sont :

- `index.html`
- `styles.css`
- `app.js`
