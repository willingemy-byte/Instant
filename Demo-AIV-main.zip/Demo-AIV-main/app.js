const tabs = [...document.querySelectorAll('.tab')];
const views = [...document.querySelectorAll('.view')];

function activateTab(id) {
  tabs.forEach(tab => tab.classList.toggle('is-active', tab.dataset.tab === id));
  views.forEach(view => view.classList.toggle('is-active', view.id === id));
  history.replaceState(null, '', `#${id}`);
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

tabs.forEach(tab => {
  tab.addEventListener('click', () => activateTab(tab.dataset.tab));
});

const hash = location.hash.replace('#', '');
if (views.some(view => view.id === hash)) {
  tabs.forEach(tab => tab.classList.toggle('is-active', tab.dataset.tab === hash));
  views.forEach(view => view.classList.toggle('is-active', view.id === hash));
}

const journalRows = [...document.querySelectorAll('#journal-table tbody tr')];
const watcherSummary = document.querySelector('.analysis-summary');

journalRows.forEach(row => {
  row.addEventListener('click', () => {
    journalRows.forEach(item => item.classList.remove('is-selected'));
    row.classList.add('is-selected');

    const detail = row.dataset.detail;
    if (!detail || !watcherSummary) return;

    let selected = watcherSummary.querySelector('.selected-event');
    if (!selected) {
      selected = document.createElement('div');
      selected.className = 'selected-event';
      selected.style.marginTop = '10px';
      selected.style.padding = '9px';
      selected.style.border = '1px solid #4b3560';
      selected.style.borderRadius = '8px';
      selected.style.fontSize = '.72rem';
      selected.style.lineHeight = '1.45';
      selected.style.color = '#d5c5df';
      watcherSummary.appendChild(selected);
    }
    selected.innerHTML = `<strong style="color:#c47cff">Interaction sélectionnée</strong><br>${detail}`;
  });
});

const exportButton = document.querySelector('.ghost-button');
if (exportButton) {
  exportButton.addEventListener('click', () => {
    const rows = [...document.querySelectorAll('#journal-table tr')].map(row =>
      [...row.children].map(cell => `"${cell.innerText.replaceAll('"', '""')}"`).join(',')
    );
    const blob = new Blob([rows.join('\n')], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'aiv-journal-demo.csv';
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  });
}
