import unittest
from datetime import datetime, timezone

from scripts.inactivity_watchdog import Activity, parse_dt


class InactivityWatchdogTests(unittest.TestCase):
    def test_parse_dt_utc(self):
        value = parse_dt("2026-09-01T16:00:00Z")
        self.assertEqual(value, datetime(2026, 9, 1, 16, 0, tzinfo=timezone.utc))

    def test_last_activity_uses_newest_signal(self):
        commit = datetime(2026, 9, 1, 16, 0, tzinfo=timezone.utc)
        workflow = datetime(2026, 9, 1, 16, 5, tzinfo=timezone.utc)
        activity = Activity(commit, workflow, 0)
        self.assertEqual(activity.last_activity, workflow)

    def test_last_activity_handles_no_workflows(self):
        commit = datetime(2026, 9, 1, 16, 0, tzinfo=timezone.utc)
        activity = Activity(commit, None, 0)
        self.assertEqual(activity.last_activity, commit)

    def test_active_workflow_count_is_preserved(self):
        activity = Activity(None, None, 2)
        self.assertEqual(activity.active_workflow_count, 2)


if __name__ == "__main__":
    unittest.main()
