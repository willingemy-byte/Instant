import unittest

from scripts.inactivity_relauncher import (
    RELAUNCH_MARKER,
    build_relaunch_body,
    find_open_relaunch_issue,
)


class InactivityRelauncherTests(unittest.TestCase):
    def test_relaunch_body_locks_visual_demo_priority(self):
        body = build_relaunch_body(18, "2026-09-01T17:00:00+00:00")
        self.assertIn(RELAUNCH_MARKER, body)
        self.assertIn("PRIORITÉ ABSOLUE", body)
        self.assertIn("démo Web All In Visible", body)
        self.assertIn("real-time anomaly investigation and traceability", body)

    def test_find_open_relaunch_issue(self):
        issues = [
            {"number": 4, "state": "closed", "body": RELAUNCH_MARKER},
            {"number": 5, "state": "open", "body": "autre tâche"},
            {"number": 6, "state": "open", "body": RELAUNCH_MARKER},
        ]
        self.assertEqual(find_open_relaunch_issue(issues)["number"], 6)

    def test_pull_requests_are_ignored(self):
        items = [
            {"number": 7, "state": "open", "body": RELAUNCH_MARKER, "pull_request": {"url": "x"}},
        ]
        self.assertIsNone(find_open_relaunch_issue(items))


if __name__ == "__main__":
    unittest.main()
