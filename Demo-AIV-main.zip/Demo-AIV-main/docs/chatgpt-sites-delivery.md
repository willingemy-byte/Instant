# Contrat de livraison — All In Visible ↔ ChatGPT Site

## Séparation des responsabilités

Le projet **All In Visible (AIV)** est la source de vérité du design, du contenu et du comportement de la démo.

AIV **n’est pas responsable** de créer, publier, maintenir ou synchroniser directement le ChatGPT Site. Cette responsabilité appartient à une conversation ChatGPT distincte chargée de la couche Site.

La branche réservée à cette couche est :

- `site/aiv-demo-sync-v1`

AIV ne doit pas modifier cette branche sauf instruction explicite de l’utilisateur.

## Responsabilité d’AIV

Quand l’utilisateur demande un changement visible ou comportemental de la démo, AIV modifie normalement la version source canonique dans son workflow GitHub.

Les fichiers principaux sont :

- `index.html`
- `styles.css`
- `app.js`

Le projet doit maintenir ces fichiers comme une démo Web autonome, portable et exécutable sans dépendre de Codespaces.

Les images/storyboard fournies par l’utilisateur dans les Sources du projet ChatGPT restent la référence principale du design et du parcours de démonstration.

## Manifest de publication

AIV maintient également :

- `site-source/manifest.json`

Ce manifest décrit au minimum :

- la version de la démo ;
- les dates de génération et de mise à jour ;
- le commit source ;
- l’entrypoint ;
- la liste des fichiers requis ;
- les checksums ;
- les éventuels assets ;
- les contraintes de runtime pertinentes.

À chaque changement validé du design ou du comportement, les fichiers source et le manifest doivent être mis à jour et laissés dans un état Git propre et traçable.

## Responsabilité de la conversation Site

La conversation Site distincte prend en charge :

- la branche GitHub dédiée au Site ;
- l’intégration GitHub → ChatGPT Site ;
- la publication ;
- la stabilité de l’URL ;
- la synchronisation des modifications ;
- l’adaptation technique nécessaire au runtime Sites.

Elle récupère la version canonique produite par AIV et décide comment cette version est transportée vers le Site.

## Contraintes

AIV ne doit pas :

- gérer directement ChatGPT Sites ;
- créer une autre branche Site ;
- modifier `site/aiv-demo-sync-v1` sans instruction explicite ;
- obliger l’utilisateur à ouvrir VS Code ou Codespaces pour consulter la démo ;
- stocker des secrets côté navigateur.

Codespaces peut servir au développement ou aux tests, mais ne fait pas partie des dépendances nécessaires au fonctionnement de la démo livrable.

## Critère de réussite côté AIV

Le travail AIV est prêt pour synchronisation lorsque :

- `main` représente exactement la version de la démo que l’utilisateur veut voir ;
- le design et le comportement correspondent aux décisions validées ;
- `index.html`, `styles.css` et `app.js` restent autonomes et transportables ;
- `site-source/manifest.json` décrit correctement la version canonique ;
- aucun secret navigateur n’est requis ;
- la branche `site/aiv-demo-sync-v1` n’a pas été modifiée par AIV.

En résumé : **AIV décide ce que la démo doit montrer. GitHub conserve la version source. La conversation Site décide comment cette version arrive sur ChatGPT Sites.**
