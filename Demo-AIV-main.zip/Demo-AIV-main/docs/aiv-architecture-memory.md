# AIV — Mémoire d’architecture canonique

> État conceptuel issu des brainstormings du 2 septembre 2026. Ce document sert de mémoire de conception. Il décrit l’intention architecturale de référence; il ne prétend pas que chaque mécanisme est déjà implémenté.

## 1. Principe fondamental

AIV doit éliminer autant que possible l’attribution par interprétation. Toute entité capable d’interagir avec le système doit posséder une identité cryptographique AIV distincte et traçable.

L’identité d’un utilisateur n’est pas celle de son téléphone. L’identité d’un téléphone n’est pas celle d’une application. L’identité d’une application n’est pas celle de ses agents, workers ou composants. Chaque acteur qui peut produire une action doit être identifiable séparément afin de pouvoir reconstruire la cause exacte d’un incident.

La règle de base est : **pas d’identité AIV reconnue, pas d’accès à Main — même en lecture.**

## 2. Chaîne d’identité et pedigree

AIV maintient un pedigree causal complet depuis la naissance d’une entité.

Exemple conceptuel :

`identité usine du téléphone -> première activation -> identité utilisateur -> installation ChatGPT -> identité de cette instance ChatGPT -> worker créé -> action -> objet modifié`

Le téléphone reçoit déjà une identité cryptographique au moment de sa fabrication/enrôlement. Lors de la première activation et de la prise de possession, l’utilisateur possède une identité distincte qui est reliée au téléphone sans être confondue avec lui.

Quand une application AIV-compatible est téléchargée, son code contient le mécanisme d’appel AIV. Au premier enrôlement, le système crée une nouvelle identité pour **cette installation précise**, reliée notamment à l’utilisateur, à l’appareil, à l’application, à sa version et à son histoire d’évolution.

Deux utilisateurs peuvent donc télécharger exactement le même binaire et la même version d’une application tout en créant deux entités AIV distinctes, car leurs pedigrees sont différents.

Les mises à jour, changements de paramètres, changements de permissions, création de workers, interactions et autres transformations importantes enrichissent ensuite ce pedigree.

## 3. `AIV_API_K` : appel universel, pas secret universel

Le code des applications peut utiliser une interface commune, conceptuellement nommée :

`AIV_API_K`

Cette interface est la porte d’appel standard vers l’infrastructure AIV. Toutes les applications peuvent contenir le même appel. Ce n’est pas une API key traditionnelle transportant le secret ou l’identité de l’application.

Lorsqu’une entité utilise `AIV_API_K`, la demande est dirigée vers Kubernetes. Le système résout alors, à l’intérieur de l’infrastructure AIV, quelle entité et quel pedigree sont liés à cette requête.

L’application n’a pas besoin de connaître son identité cryptographique interne ni le mécanisme qui permet au système de la reconnaître.

## 4. Kubernetes est la porte d’entrée

Dans l’architecture voulue, **Kubernetes est la porte réseau devant Main**.

Flux conceptuel :

`entité -> AIV_API_K -> Kubernetes -> validation/reconnaissance AIV -> Main`

Une requête qui n’est pas reliée à une identité cryptographique AIV reconnue ne doit pas atteindre Main. Elle est rejetée à la porte.

Kubernetes possède l’accès nécessaire au registre d’identité, au journal et aux services internes qui permettent de résoudre la demande. Les mécanismes ou valeurs internes permettant cette résolution ne doivent pas être divulgués aux applications clientes.

Les références et mécanismes d’accès peuvent être renouvelés fréquemment par l’infrastructure afin de réduire la valeur d’une information capturée ou devenue obsolète.

## 5. Main

Main demeure l’autorité centrale du système.

Pendant la phase de conception, le cerveau IA principal (par exemple un grand modèle de type DeepSeek/MoE) peut servir d’architecte pour comprendre AIV, proposer l’infrastructure, écrire et tester les règles de Main et organiser les composants autour de lui.

En production, Main est conçu comme un moteur Python dont le code est contrôlé. Une fois la version jugée solide et mise en production, les IA n’ont plus le droit de modifier directement ce code. Elles peuvent analyser et proposer des changements, mais l’exécution d’une modification de Main reste réservée au propriétaire autorisé.

L’objectif est de séparer :

- la capacité de réfléchir et de proposer;
- la capacité de prendre une décision selon les règles de Main;
- la capacité souveraine de modifier ces règles.

## 6. DNPC / cerveau d’orchestration

Le grand modèle demeure le cerveau cognitif et d’orchestration de l’écosystème : compréhension globale, analyse, conception, suggestions, création de workers spécialisés et amélioration de l’infrastructure.

Il ne devient toutefois pas l’unique détenteur de l’état. La continuité importante doit être enregistrée dans les sources persistantes AIV : journal, mémoire canonique, versions, décisions, états et artifacts.

Les workers temporaires peuvent être créés et détruits. Leur contexte et leurs résultats doivent revenir vers l’architecture persistante afin qu’aucun travail important ne disparaisse avec le worker.

## 7. Watcher

Watcher observe en permanence les actions, relations et anomalies.

Son rôle n’est pas seulement de chercher une permission manquante. Il compare aussi le comportement d’une entité avec son pedigree et sa fonction attendue.

Exemple : si une identité liée à un composant « caméra » commence à créer des réunions de calendrier ou à envoyer des emails à l’insu de l’utilisateur, l’écart comportemental doit être immédiatement visible dans le graphe causal et dans le journal.

Watcher doit pouvoir remonter jusqu’au premier événement anormal, identifier les descendants et objets touchés et remettre à Main une reconstruction exploitable de l’incident.

## 8. Journal cryptographique causal

Le journal AIV est conçu comme un historique causal, pas seulement comme une suite de logs techniques.

Chaque événement doit permettre de relier au minimum :

- l’identité AIV de l’acteur;
- l’identité de la cible;
- la relation parent/enfant ou l’origine de délégation;
- l’action demandée;
- l’action réellement exécutée;
- l’état pertinent avant l’action;
- l’état pertinent après l’action;
- le moment de l’événement;
- les objets ou entités touchés;
- les dépendances et interactions qui en découlent.

`AIV_API_K` peut servir de référence universelle dans le journal afin de demander au système d’afficher les événements reliés à une identité. La valeur inscrite dans le journal ne doit pas être un secret permettant d’usurper l’entité; elle sert à résoudre une relation dans AIV.

Les secrets ou éléments cryptographiques permettant l’usurpation ne doivent pas être écrits en clair dans le journal.

## 9. Visibilité du journal : globale pour AIV, locale pour chaque utilisateur

AIV peut conserver une traçabilité globale tout en donnant à chaque utilisateur uniquement la vue correspondant à son propre périmètre.

Si un utilisateur consulte les événements reliés à son instance de ChatGPT, il peut voir les interactions qui concernent son téléphone, son application et les composants qui lui sont rattachés.

Si cette même entité sort de ce périmètre et interagit avec une infrastructure sans lien avec cet utilisateur, AIV peut conserver la continuité causale pour ses fonctions de sécurité, mais l’utilisateur n’a pas automatiquement le droit de voir cette portion du pedigree.

Le principe est : **le pedigree peut être global sans que sa visibilité soit globale.**

La résolution d’une même référence `AIV_API_K` peut donc produire des vues différentes selon l’identité et les droits de la personne ou du composant qui effectue la demande.

## 10. Attribution des incidents

L’objectif majeur est de pouvoir distinguer rapidement :

- une action volontaire de l’utilisateur;
- une défaillance de l’appareil;
- une anomalie d’une application;
- une action d’un worker ou agent descendant;
- une modification introduite par une mise à jour;
- un comportement extérieur au domaine de l’utilisateur.

Le simple fait qu’une application ait été initialement reliée à un utilisateur ne signifie pas que toutes ses actions ultérieures doivent être attribuées à cet utilisateur. Le journal causal doit permettre de montrer précisément où et comment une chaîne d’actions s’est séparée du comportement attendu.

## 11. Restauration causale

Lorsqu’une anomalie est confirmée, AIV doit pouvoir reconstruire la chaîne depuis le premier événement fautif et déterminer exactement quels objets ont été touchés directement ou indirectement.

Le rollback recherché est causal : restaurer les éléments concernés à leur état valide précédent, révoquer ou isoler les identités compromises et traiter les descendants de l’incident sans détruire inutilement les états sans rapport avec lui.

Les actions irréversibles vers l’extérieur doivent idéalement être bloquées ou fortement contrôlées avant leur exécution, car certains effets externes ne peuvent pas être annulés après coup.

## 12. Applications et sites AIV

Le même principe d’identité peut être appliqué aux applications, services et sites.

Une application AIV-compatible possède le mécanisme `AIV_API_K` et fait enrôler chaque nouvelle installation dans son pedigree.

Un site protégé par AIV peut placer Kubernetes/AIV devant son backend. Selon la politique choisie par le propriétaire du site, l’accès peut exiger une identité AIV reconnue avant qu’une requête puisse atteindre l’application protégée.

## 13. Principe de minimisation

Un objectif transversal d’AIV est de réduire la quantité d’information sensible qui doit circuler.

Lorsqu’une information peut rester dans le composant chargé de la vérifier, elle ne doit pas être distribuée inutilement ailleurs. Les applications n’ont pas besoin de connaître les secrets internes de leur identité. Le journal n’a pas besoin de contenir les secrets de reconnaissance. Les consommateurs n’obtiennent que la vue nécessaire à leur rôle.

Moins de secrets copiés, transmis et stockés signifie moins de surfaces à protéger et moins de couches ajoutées uniquement pour protéger d’autres couches.

## 14. Invariants à conserver

1. Toute entité capable d’interaction possède une identité AIV distincte.
2. L’identité de l’utilisateur, de l’appareil, de l’application et des workers ne doit jamais être confondue.
3. Pas d’identité reconnue -> pas d’accès à Main.
4. Kubernetes est la porte d’entrée devant Main.
5. `AIV_API_K` est une interface universelle d’appel; ce n’est pas le secret d’identité de l’entité.
6. Chaque installation crée une nouvelle lignée/pedigree AIV.
7. Les mises à jour et transformations enrichissent le pedigree plutôt que de l’effacer.
8. Toute interaction importante est journalisée causalement.
9. Les secrets d’authentification ne sont pas exposés dans le journal.
10. La visibilité du journal est limitée au domaine autorisé de l’identité qui consulte.
11. Watcher recherche continuellement les ruptures de comportement et les chaînes causales anormales.
12. Main demeure l’autorité décisionnelle; sa modification en production exige l’autorité cryptographique du propriétaire.
13. Les IA peuvent proposer des changements sans pouvoir les appliquer souverainement à Main.
14. Le rollback vise la chaîne causale exacte et évite autant que possible les dommages collatéraux.
15. La minimisation des informations en circulation est un principe de sécurité central.

## 15. Pourquoi ces brainstormings doivent être conservés

Ces séances servent à pousser l’architecture plus loin avant de figer le système. Les nouvelles idées qui modifient réellement les invariants, le modèle d’identité, Main, Watcher, Kubernetes, le journal ou le rollback doivent être intégrées à cette mémoire afin que les futurs agents et développeurs ne reconstruisent pas AIV à partir de suppositions ou de modèles de sécurité conventionnels incompatibles avec l’intention du projet.
