#!/usr/bin/env python3
"""Handle AIV inactivity dispatches and relaunch useful development work."""
from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.request
from typing import Any

RELAUNCH_MARKER = "<!-- AIV_AUTONOMOUS_RELAUNCH -->"
COPILOT_LOGIN = "copilot-swe-agent[bot]"


def request_json(
    method: str,
    url: str,
    token: str,
    payload: dict[str, Any] | None = None,
    *,
    user_agent: str = "Demo-AIV-Inactivity-Relauncher",
) -> Any:
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {token}",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": user_agent,
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            raw = response.read()
            return json.loads(raw) if raw else None
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"GitHub API {method} {url} -> HTTP {exc.code}: {body[:1500]}") from exc


def load_event_payload(path: str | None) -> dict[str, Any]:
    if not path:
        return {}
    try:
        with open(path, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        return payload if isinstance(payload, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def build_relaunch_body(idle_minutes: int | None, last_activity: str | None) -> str:
    idle_text = str(idle_minutes) if idle_minutes is not None else "unknown"
    activity_text = last_activity or "unknown"
    return f"""{RELAUNCH_MARKER}
## Relance autonome AIV

Le watchdog a détecté une stagnation du dépôt.

- Inactivité signalée : **{idle_text} minutes**
- Dernière activité utile : `{activity_text}`

### PRIORITÉ ABSOLUE
Faire avancer la **démo Web All In Visible** vers une reproduction fidèle du storyboard visuel fourni par l'utilisateur dans les Sources du projet.

Le livrable prioritaire est une page Web stable et consultable, construite principalement avec `index.html`, `styles.css` et `app.js`, qui montre clairement le fonctionnement futur de All In Visible sans construire tout le backend final.

### À NE PAS REPRENDRE COMME DIRECTION PRINCIPALE
- l'ancienne piste « real-time anomaly investigation and traceability » ;
- une console générique d'agents ;
- un backend complet ;
- la cryptographie réelle ;
- des travaux d'infrastructure sans impact direct sur la démo visible.

### Travail attendu lors de cette relance
1. Examiner `main` et choisir le plus petit changement utile qui rapproche visuellement la démo des références.
2. Conserver la démo statique, légère et portable.
3. Vérifier que la page reste fonctionnelle et responsive.
4. Ne pas fusionner automatiquement : proposer les changements via le flux normal de revue de l'agent.
"""


def find_open_relaunch_issue(items: list[dict[str, Any]]) -> dict[str, Any] | None:
    for item in items:
        if item.get("pull_request"):
            continue
        if str(item.get("state") or "") != "open":
            continue
        if RELAUNCH_MARKER in str(item.get("body") or ""):
            return item
    return None


def get_or_create_relaunch_issue(
    api: str,
    repo: str,
    github_token: str,
    idle_minutes: int | None,
    last_activity: str | None,
) -> int:
    items = request_json("GET", f"{api}/repos/{repo}/issues?state=open&per_page=100", github_token) or []
    existing = find_open_relaunch_issue(items if isinstance(items, list) else [])
    if existing:
        number = int(existing["number"])
        request_json(
            "POST",
            f"{api}/repos/{repo}/issues/{number}/comments",
            github_token,
            {"body": "🔁 Nouveau signal `aiv_inactivity` reçu. La relance autonome est réémise sur cette tâche."},
        )
        return number

    created = request_json(
        "POST",
        f"{api}/repos/{repo}/issues",
        github_token,
        {
            "title": "AIV — relance autonome de la démo visuelle",
            "body": build_relaunch_body(idle_minutes, last_activity),
        },
    )
    return int(created["number"])


def assign_copilot(api: str, repo: str, issue_number: int, copilot_token: str) -> None:
    request_json(
        "POST",
        f"{api}/repos/{repo}/issues/{issue_number}/assignees",
        copilot_token,
        {
            "assignees": [COPILOT_LOGIN],
            "agent_assignment": {
                "target_repo": repo,
                "base_branch": "main",
                "custom_instructions": (
                    "Prioritize the visible All In Visible web demo. Match the project's visual reference storyboard. "
                    "Do not revive the old real-time anomaly infrastructure direction unless directly required by the visible demo. "
                    "Make one concrete, reviewable increment and keep the static demo lightweight."
                ),
                "custom_agent": "",
                "model": "",
            },
        },
    )


def post_webhook(url: str, payload: dict[str, Any]) -> None:
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        method="POST",
        headers={"Content-Type": "application/json", "User-Agent": "Demo-AIV-Inactivity-Relauncher"},
    )
    with urllib.request.urlopen(req, timeout=30) as response:
        response.read()


def comment_watchdog_issue(api: str, repo: str, token: str, text: str) -> None:
    issue = int(os.environ.get("WATCHDOG_ISSUE", "2"))
    request_json("POST", f"{api}/repos/{repo}/issues/{issue}/comments", token, {"body": text})


def main() -> int:
    repo = os.environ["GITHUB_REPOSITORY"]
    github_token = os.environ["GITHUB_TOKEN"]
    api = os.environ.get("GITHUB_API_URL", "https://api.github.com")
    copilot_token = os.environ.get("AIV_COPILOT_TOKEN", "").strip()
    webhook = os.environ.get("ORCHESTRATOR_WEBHOOK_URL", "").strip()

    event = load_event_payload(os.environ.get("GITHUB_EVENT_PATH"))
    client = event.get("client_payload") if isinstance(event.get("client_payload"), dict) else {}
    try:
        idle_minutes = int(client.get("idle_minutes")) if client.get("idle_minutes") is not None else None
    except (TypeError, ValueError):
        idle_minutes = None
    last_activity = str(client.get("last_activity")) if client.get("last_activity") else None

    if copilot_token:
        issue_number = get_or_create_relaunch_issue(api, repo, github_token, idle_minutes, last_activity)
        assign_copilot(api, repo, issue_number, copilot_token)
        comment_watchdog_issue(
            api,
            repo,
            github_token,
            f"🤖 **Relance reçue et transmise à Copilot coding agent** via l'issue #{issue_number}. Priorité : démo Web fidèle aux références visuelles.",
        )
        print(f"RELAUNCHER: Copilot assigned to issue #{issue_number}.")
        return 0

    if webhook:
        post_webhook(
            webhook,
            {
                "event": "aiv_inactivity_relaunch",
                "repository": repo,
                "idle_minutes": idle_minutes,
                "last_activity": last_activity,
                "priority": "visual-demo-reference-fidelity",
                "branch": "main",
            },
        )
        comment_watchdog_issue(
            api,
            repo,
            github_token,
            "🔁 **Relance reçue et transmise à l'orchestrateur externe.** Priorité transmise : démo Web fidèle aux références visuelles.",
        )
        print("RELAUNCHER: external orchestrator webhook notified.")
        return 0

    comment_watchdog_issue(
        api,
        repo,
        github_token,
        "⚠️ **Le listener de relance a bien reçu `aiv_inactivity`, mais aucun moteur de travail n'est branché.** "
        "Configurer `AIV_COPILOT_TOKEN` (préféré) ou `ORCHESTRATOR_WEBHOOK_URL` dans les secrets GitHub pour transformer l'alerte en vraie reprise autonome.",
    )
    print("RELAUNCHER: dispatch received, but no Copilot token or external orchestrator webhook is configured.")
    return 2


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"RELAUNCHER ERROR: {exc}", file=sys.stderr)
        raise
