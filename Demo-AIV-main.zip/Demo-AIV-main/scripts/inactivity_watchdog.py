#!/usr/bin/env python3
"""Inactivity watchdog for Demo-AIV / All In Visible development."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

WATCHDOG_MARKER = "<!-- AIV_IDLE_WATCHDOG -->"
WATCHDOG_WORKFLOW_NAME = "AIV-INACTIVITY-WATCHDOG"


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def parse_dt(value: str | None) -> datetime | None:
    if not value:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def github_request(method: str, url: str, token: str, payload: dict[str, Any] | None = None) -> Any:
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {token}",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "Demo-AIV-Inactivity-Watchdog",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as response:
            raw = response.read()
            return json.loads(raw) if raw else None
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"GitHub API {method} {url} -> HTTP {exc.code}: {body[:1000]}") from exc


def newest_commit_time() -> datetime | None:
    try:
        raw = subprocess.check_output(
            ["git", "log", "--all", "-1", "--format=%cI"],
            text=True,
            stderr=subprocess.STDOUT,
        ).strip()
    except subprocess.CalledProcessError:
        return None
    return parse_dt(raw)


@dataclass(frozen=True)
class Activity:
    last_commit: datetime | None
    last_workflow: datetime | None
    active_workflow_count: int

    @property
    def last_activity(self) -> datetime | None:
        points = [x for x in (self.last_commit, self.last_workflow) if x is not None]
        return max(points) if points else None


def inspect_actions(api: str, repo: str, token: str) -> tuple[datetime | None, int]:
    payload = github_request("GET", f"{api}/repos/{repo}/actions/runs?per_page=50", token)
    latest: datetime | None = None
    active = 0
    for run in payload.get("workflow_runs", []):
        if run.get("name") == WATCHDOG_WORKFLOW_NAME:
            continue
        status = str(run.get("status") or "")
        if status in {"queued", "in_progress", "waiting", "requested", "pending"}:
            active += 1
        dt = parse_dt(run.get("updated_at") or run.get("created_at"))
        if dt is not None and (latest is None or dt > latest):
            latest = dt
    return latest, active


def recent_alert_exists(api: str, repo: str, issue: int, token: str, cooldown: timedelta, now: datetime) -> bool:
    comments = github_request("GET", f"{api}/repos/{repo}/issues/{issue}/comments?per_page=100", token)
    for comment in reversed(comments):
        body = str(comment.get("body") or "")
        if WATCHDOG_MARKER not in body:
            continue
        created = parse_dt(comment.get("created_at"))
        return created is not None and now - created < cooldown
    return False


def post_alert(api: str, repo: str, issue: int, token: str, idle_minutes: int, last_activity: datetime | None) -> None:
    last_text = last_activity.isoformat() if last_activity else "unknown"
    body = (
        f"{WATCHDOG_MARKER}\n"
        f"🚨 **AIV semble stagnant.**\n\n"
        f"Aucune activité utile détectée depuis au moins **{idle_minutes} minutes** "
        f"(dernier signal: `{last_text}`). Le watchdog émet `aiv_inactivity`; "
        "le listener de relance choisira ensuite le moteur de reprise configuré.\n\n"
        "Aucun merge produit automatique n'est déclenché par le watchdog lui-même."
    )
    github_request("POST", f"{api}/repos/{repo}/issues/{issue}/comments", token, {"body": body})


def emit_dispatch(api: str, repo: str, token: str, idle_minutes: int, last_activity: datetime | None) -> None:
    github_request(
        "POST",
        f"{api}/repos/{repo}/dispatches",
        token,
        {
            "event_type": "aiv_inactivity",
            "client_payload": {
                "idle_minutes": idle_minutes,
                "last_activity": last_activity.isoformat() if last_activity else None,
                "source": "aiv-inactivity-watchdog",
            },
        },
    )


def main() -> int:
    repo = os.environ["GITHUB_REPOSITORY"]
    token = os.environ["GITHUB_TOKEN"]
    api = os.environ.get("GITHUB_API_URL", "https://api.github.com")
    issue = int(os.environ.get("WATCHDOG_ISSUE", "2"))
    threshold = timedelta(minutes=int(os.environ.get("IDLE_MINUTES", "15")))
    cooldown = timedelta(minutes=int(os.environ.get("ALERT_COOLDOWN_MINUTES", "30")))
    dry_run = os.environ.get("WATCHDOG_DRY_RUN", "0").strip().lower() in {"1", "true", "yes"}
    now = utcnow()

    last_workflow, active_count = inspect_actions(api, repo, token)
    activity = Activity(newest_commit_time(), last_workflow, active_count)
    last_activity = activity.last_activity
    idle_for = (now - last_activity) if last_activity is not None else threshold + timedelta(seconds=1)

    print(json.dumps({
        "priority": "AIV repository progress",
        "now": now.isoformat(),
        "last_commit": activity.last_commit.isoformat() if activity.last_commit else None,
        "last_non_watchdog_workflow": activity.last_workflow.isoformat() if activity.last_workflow else None,
        "active_non_watchdog_workflows": active_count,
        "idle_seconds": int(idle_for.total_seconds()),
        "threshold_seconds": int(threshold.total_seconds()),
        "dry_run": dry_run,
    }, indent=2, sort_keys=True))

    if active_count > 0:
        print("WATCHDOG: useful workflow activity is running; no relaunch.")
        return 0
    if idle_for < threshold:
        print("WATCHDOG: repository is active; no relaunch.")
        return 0

    idle_minutes = max(int(idle_for.total_seconds() // 60), int(threshold.total_seconds() // 60))
    if dry_run:
        print(f"WATCHDOG: DRY-RUN — idle for {idle_minutes} minutes; would alert issue #{issue} and dispatch aiv_inactivity.")
        return 0
    if recent_alert_exists(api, repo, issue, token, cooldown, now):
        print("WATCHDOG: idle, but equivalent alert is inside cooldown.")
        return 0

    post_alert(api, repo, issue, token, idle_minutes, last_activity)
    emit_dispatch(api, repo, token, idle_minutes, last_activity)

    print("WATCHDOG: AIV inactivity signal emitted for the relaunch listener.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"WATCHDOG ERROR: {exc}", file=sys.stderr)
        raise
