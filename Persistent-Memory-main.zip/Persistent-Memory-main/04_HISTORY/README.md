# 04_HISTORY

Contexte historique personnel et professionnel utile pour comprendre les décisions, préférences de travail, expériences passées et patterns récurrents de l’utilisateur. Ne conserver que ce qui améliore réellement la continuité ou la compréhension.
