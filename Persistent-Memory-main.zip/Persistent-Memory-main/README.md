# Persistent Memory

Ce dépôt est la mémoire canonique contrôlée par l’utilisateur pour ses projets, recherches, modèles, décisions et règles de collaboration avec ChatGPT.

## Principe directeur

- GitHub est la source de vérité durable.
- La mémoire dynamique de ChatGPT peut servir de contexte opportuniste, mais ne remplace pas ce dépôt.
- Les conclusions déjà validées ne doivent pas être réécrites silencieusement.
- Toute modification importante doit être explicite, traçable par Git et reliée à une nouvelle décision, une nouvelle preuve ou une correction identifiée.
- Quand une conversation importante est terminée, ChatGPT peut en produire une synthèse canonique et la pousser ici sur instruction de l’utilisateur.

## Structure

- `00_PERSONA/` — rôle attendu de ChatGPT, méthode de travail et relation de collaboration.
- `01_PROJECTS/` — continuité et état canonique des projets actifs.
- `02_RESEARCH/` — enquêtes, débats et recherches déjà approfondis.
- `03_MODELS/` — modèles conceptuels, architectures et hypothèses structurées.
- `04_HISTORY/` — contexte historique personnel/professionnel utile à la continuité.

## Règle de modification

Une synthèse canonique peut être enrichie ou corrigée, mais elle ne doit pas être remplacée par une nouvelle interprétation automatique sans signaler clairement ce qui change et pourquoi.
