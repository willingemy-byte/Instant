# 03_MODELS

Modèles conceptuels, architectures, hypothèses structurées et systèmes de pensée. Chaque document doit distinguer clairement les principes canoniques, les composants, les relations entre composants et les points encore ouverts.
