# CALL-LUNA

`CALL-LUNA` is the generic dispatch bridge between GitHub and the stored OpenAI Platform prompt used by Luna.

## Architecture

Luna is the orchestrator, not the long-running worker.

- **GitHub MCP**: inspect repositories, issues, pull requests and Actions state.
- **Browser MCP (Browserbase hosted MCP)**: inspect browser-based interfaces that do not expose a suitable API/MCP. Default mode is `observe`, so no clicks, typing, authentication, publication or external mutation is permitted.
- **GitHub Actions runners**: perform coding, tests, data processing and heavy computation.
- **Persistent-Memory**: durable source for Luna's orchestration rules, priorities and context.

The preferred flow is:

```text
conversation / durable mandate
        ↓
       Luna
   ↙           ↘
GitHub MCP    Browser MCP
   ↓              ↓
state/code     web interfaces
   ↓
Actions runners
   ↓
artifacts/tests/results
   ↓
       Luna verifies
```

## Fast path

Open an issue whose title begins with:

```text
[LUNA]
```

The issue body is treated as Luna's mandate. The workflow calls the stored prompt and posts Luna's final report back to the same issue.

This makes a GitHub issue a durable mandate envelope: it has an author, timestamp, complete request, Actions run, and result thread.

## Manual path

Run the `CALL-LUNA` workflow from GitHub Actions and provide a mandate plus reasoning effort.

## Required secrets

The repository must contain:

```text
OPENAI_API_KEY
```

Optional MCP credentials:

```text
GITHUB_MCP_TOKEN
BROWSERBASE_API_KEY
```

`GITHUB_MCP_TOKEN` is useful when Luna must inspect repositories beyond the repository-scoped `GITHUB_TOKEN` supplied by Actions.

`BROWSERBASE_API_KEY` enables Browserbase's hosted MCP at `https://mcp.browserbase.com/mcp`. If it is absent, Luna continues normally with Browser MCP disabled.

Never put an OpenAI key, GitHub PAT, Browserbase key, MCP bearer token, cookies, passwords or other credentials in an issue, prompt body, committed file, workflow input, result bundle or log.

## Browser safety modes

The dispatcher supports:

```text
LUNA_BROWSER_MCP_MODE=observe
LUNA_BROWSER_MCP_MODE=interactive
```

Default: `observe`.

`observe` exposes only the Browserbase MCP tools required to start a session, navigate, observe and extract. It deliberately excludes `act`.

`interactive` may expose Browserbase's `act` tool and must only be enabled when the current mandate explicitly authorizes browser-side changes. Authentication state must be established without putting account credentials into GitHub.

## Stored prompt

The workflow currently references:

```text
pmpt_6a97c8d99b2c819399b7a22344c8d14c0452c62e37df99d2
```

The stored prompt remains Luna's durable persona/tool configuration. `CALL-LUNA` adds the current mandate and a small execution contract.

## Operational boundary

Long-running or compute-heavy work belongs on runners. Luna should inspect, decide, delegate, verify and continue.

When an external interface has no suitable API, Browser MCP is the fallback interaction layer. It should not replace a stable API or GitHub-native operation when one exists.
