# Persistent Memory — politique d’ingestion

## Principe

Les exports bruts de ChatGPT servent de matière première. Ils ne sont jamais considérés comme mémoire canonique.

Le pipeline doit distinguer trois niveaux :

1. **SOURCE RAW** — archive originale, temporaire, non committée dans l’historique Git.
2. **CANDIDATE** — synthèses générées automatiquement à partir des conversations.
3. **CANONICAL** — documents validés comme contexte durable.

## Règles non négociables

- Ne jamais écraser silencieusement un document `CANONICAL`.
- Toute nouvelle information qui modifie une conclusion existante doit apparaître comme proposition/diff explicite.
- Préserver les contradictions réelles au lieu de choisir arbitrairement une version.
- Séparer clairement : faits vérifiés, interprétations, conclusions de travail de l’utilisateur, décisions, questions ouvertes et contre-arguments examinés.
- Ne pas transformer une hypothèse personnelle en fait externe établi.
- Ne pas perdre les détails uniques en dédoublonnant plusieurs conversations.
- Conserver la provenance : conversation(s) source(s), dates, identifiants et hash de l’archive.

## Organisation cible

- `00_PERSONA/` — relation de travail, méthode de raisonnement et comportement attendu de l’assistant.
- `01_PROJECTS/` — Auto Trading, All Invisible et autres projets.
- `02_RESEARCH/` — enquêtes et débats approfondis (ex. système bancaire/Fed/Titanic, recherches GitHub/MCP/multi-agent).
- `03_MODELS/` — modèles conceptuels et architectures.
- `04_HISTORY/` — parcours et contexte historique utile.
- `05_IMPORTS/` — inventaires et rapports d’ingestion; jamais l’archive brute.
- `CANDIDATES/` — propositions générées automatiquement en attente de validation.

## Documentation opérationnelle des projets

La mémoire canonique doit conserver **les règles durables de fonctionnement**, pas les états ponctuels de runs, commits, artifacts ou chiffres temporaires.

Pour les projets techniques complexes :

- chaque branche active doit contenir dans son propre dépôt un artefact lisible décrivant son rôle, ses entrées/sorties, ses dépendances, ses garde-fous et où chercher les données;
- le `main` du projet peut contenir une carte globale qui relie les branches entre elles;
- ces cartes doivent utiliser des schémas visuels simples (par exemple Mermaid avec flèches) quand cela facilite la compréhension;
- Persistent Memory retient seulement **qu’une telle documentation doit exister et être tenue à jour**;
- les détails opérationnels et l’état courant restent dans le dépôt qui en est la source de vérité.

## Archive brute

Un export ChatGPT peut contenir des données privées ou d’anciens secrets. Il ne doit pas être ajouté au Git normal, même temporairement. Pour un runner GitHub, le transport recommandé est un **asset de Release privée temporaire** ou un mécanisme équivalent hors historique Git. Une fois l’ingestion validée, l’asset peut être supprimé.

## Validation

Le pipeline automatique peut classifier, dédupliquer et proposer des synthèses. La promotion d’une conclusion importante vers `CANONICAL` doit rester explicite et traçable.
