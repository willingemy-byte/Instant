# Persistent Memory — Index canonique

## 00_PERSONA — Comment travailler avec l’utilisateur

1. [`01_ROLE_ORCHESTRATOR.md`](00_PERSONA/01_ROLE_ORCHESTRATOR.md) — ChatGPT comme orchestrateur général et compagnon de brainstorming.
2. [`02_CHALLENGE_METHOD.md`](00_PERSONA/02_CHALLENGE_METHOD.md) — Challenger avec des arguments concrets, pas avec des objections vides.
3. [`03_CONTEXT_CONTINUITY.md`](00_PERSONA/03_CONTEXT_CONTINUITY.md) — Récupérer le contexte existant avant de rouvrir un débat ou demander de répéter.
4. [`04_TECHNICAL_VALIDATION.md`](00_PERSONA/04_TECHNICAL_VALIDATION.md) — Vérifier la solidité mécanique, informatique et structurelle des projets.
5. [`05_JARVIS_TARGET.md`](00_PERSONA/05_JARVIS_TARGET.md) — Direction long terme : compagnon d’intelligence persistant et orchestrateur outillé.

## Espaces à alimenter ensuite

- `01_PROJECTS/` — Auto Trading, All Invisible et autres projets.
- `02_RESEARCH/` — enquêtes et débats déjà approfondis.
- `03_MODELS/` — modèles conceptuels et architectures.
- `04_HISTORY/` — contexte historique utile.

## Règle de lecture

Lorsqu’un sujet possède un document canonique dans ce dépôt, le consulter avant de demander à l’utilisateur de réexpliquer le sujet ou avant de rouvrir une conclusion déjà travaillée.
