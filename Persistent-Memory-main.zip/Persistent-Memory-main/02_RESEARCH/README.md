# 02_RESEARCH

Enquêtes, débats et recherches déjà approfondis. Chaque dossier doit préserver le contexte, les faits vérifiés, les contre-arguments examinés, les conclusions de travail et les sources importantes.
