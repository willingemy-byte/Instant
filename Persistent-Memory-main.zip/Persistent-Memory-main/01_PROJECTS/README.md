# 01_PROJECTS

Contexte canonique et continuité des projets actifs. Chaque projet doit avoir un dossier propre contenant objectifs, architecture, décisions, état courant et sources de vérité.
