#!/usr/bin/env python3
"""Normalize and classify a ChatGPT data export without committing raw chat text.

Outputs an import manifest and catalog. Raw normalized conversations are written to a
working directory for the summarization stage and are expected to remain ephemeral.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_text_part(part: Any) -> str:
    if isinstance(part, str):
        return part
    if isinstance(part, dict):
        # Preserve useful textual payloads, ignore binary/file references.
        for key in ("text", "content", "caption"):
            value = part.get(key)
            if isinstance(value, str):
                return value
    return ""


def conversation_messages(conv: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for node in (conv.get("mapping") or {}).values():
        msg = node.get("message")
        if not msg:
            continue
        role = ((msg.get("author") or {}).get("role") or "unknown").lower()
        if role not in {"user", "assistant"}:
            continue
        parts = (msg.get("content") or {}).get("parts") or []
        text = "\n".join(filter(None, (safe_text_part(p) for p in parts))).strip()
        if not text:
            continue
        rows.append({
            "role": role,
            "create_time": msg.get("create_time"),
            "text": text,
        })
    rows.sort(key=lambda x: (x["create_time"] is None, x["create_time"] or 0))
    return rows


def iso_time(value: Any) -> str | None:
    if not isinstance(value, (int, float)):
        return None
    return datetime.fromtimestamp(value, tz=timezone.utc).isoformat()


def classify(title: str, messages: list[dict[str, Any]], taxonomy: dict[str, Any]) -> list[dict[str, Any]]:
    # Candidate routing only. AI stage may refine or add labels.
    sample = (title + "\n" + "\n".join(m["text"] for m in messages)).lower()
    scored = []
    for bucket in taxonomy.get("buckets", []):
        matches = []
        for kw in bucket.get("keywords", []):
            n = len(re.findall(re.escape(kw.lower()), sample))
            if n:
                matches.append({"keyword": kw, "count": n})
        score = sum(x["count"] for x in matches)
        if score:
            scored.append({
                "id": bucket["id"],
                "target": bucket["target"],
                "score": score,
                "matches": matches[:12],
            })
    scored.sort(key=lambda x: (-x["score"], x["id"]))
    return scored[:6]


def slug(value: str) -> str:
    value = value.lower().strip()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-")[:64] or "conversation"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("archive", type=Path)
    ap.add_argument("--taxonomy", type=Path, default=Path("config/taxonomy.json"))
    ap.add_argument("--work-dir", type=Path, default=Path(".memory-work"))
    ap.add_argument("--report-dir", type=Path, default=Path("05_IMPORTS/latest"))
    args = ap.parse_args()

    taxonomy = json.loads(args.taxonomy.read_text(encoding="utf-8"))
    args.work_dir.mkdir(parents=True, exist_ok=True)
    normalized_dir = args.work_dir / "normalized"
    normalized_dir.mkdir(parents=True, exist_ok=True)
    args.report_dir.mkdir(parents=True, exist_ok=True)

    archive_hash = sha256_file(args.archive)
    conversations: list[dict[str, Any]] = []
    with zipfile.ZipFile(args.archive) as zf:
        bad = zf.testzip()
        if bad:
            raise SystemExit(f"Corrupt ZIP member: {bad}")
        names = sorted(n for n in zf.namelist() if re.fullmatch(r"conversations-\d+\.json", Path(n).name))
        if not names:
            raise SystemExit("No conversations-*.json found")
        for name in names:
            payload = json.loads(zf.read(name))
            if not isinstance(payload, list):
                raise SystemExit(f"Unexpected payload in {name}")
            conversations.extend(payload)

    catalog = []
    seen_ids = set()
    for idx, conv in enumerate(conversations):
        cid = conv.get("id") or f"unknown-{idx}"
        if cid in seen_ids:
            continue
        seen_ids.add(cid)
        title = (conv.get("title") or "Untitled").strip()
        messages = conversation_messages(conv)
        if not messages:
            continue
        labels = classify(title, messages, taxonomy)
        record = {
            "conversation_id": cid,
            "title": title,
            "created_at": iso_time(conv.get("create_time")),
            "updated_at": iso_time(conv.get("update_time")),
            "message_count": len(messages),
            "user_message_count": sum(m["role"] == "user" for m in messages),
            "assistant_message_count": sum(m["role"] == "assistant" for m in messages),
            "character_count": sum(len(m["text"]) for m in messages),
            "candidate_routes": labels,
            "source_archive_sha256": archive_hash,
        }
        catalog.append(record)

        # Ephemeral text used by the AI stage. Never git-add .memory-work/.
        out = normalized_dir / f"{idx:04d}-{slug(title)}-{str(cid)[:8]}.json"
        out.write_text(json.dumps({**record, "messages": messages}, ensure_ascii=False, indent=2), encoding="utf-8")

    catalog.sort(key=lambda x: (x.get("created_at") or "", x["title"]))
    (args.report_dir / "catalog.json").write_text(json.dumps(catalog, ensure_ascii=False, indent=2), encoding="utf-8")

    counts: dict[str, int] = {}
    for item in catalog:
        for route in item["candidate_routes"]:
            counts[route["id"]] = counts.get(route["id"], 0) + 1
    manifest = {
        "schema": "persistent-memory-import-v1",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "archive_sha256": archive_hash,
        "conversation_count": len(catalog),
        "route_counts": dict(sorted(counts.items())),
        "raw_archive_committed": False,
        "normalized_work_dir_committed": False,
    }
    (args.report_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    lines = ["# Inventaire d’ingestion", "", f"- Conversations: **{len(catalog)}**", f"- Archive SHA-256: `{archive_hash}`", "", "## Routage candidat", ""]
    for key, value in sorted(counts.items(), key=lambda kv: (-kv[1], kv[0])):
        lines.append(f"- `{key}`: {value}")
    lines += ["", "## Conversations", ""]
    for item in catalog:
        routes = ", ".join(r["id"] for r in item["candidate_routes"][:3]) or "unclassified"
        lines.append(f"- **{item['title']}** — {item['message_count']} messages — {routes}")
    (args.report_dir / "catalog.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(json.dumps(manifest, ensure_ascii=False))


if __name__ == "__main__":
    main()
