#!/usr/bin/env python3
"""Summarize normalized ChatGPT conversations into reviewable memory candidates.

Requires OPENAI_API_KEY. Uses the Responses API and, when configured,
a stored OpenAI Platform prompt. Nothing is promoted to CANONICAL.
"""
from __future__ import annotations

import argparse
import json
import os
import re
from collections import defaultdict
from pathlib import Path
from typing import Any

from openai import OpenAI

MODEL = os.getenv("MEMORY_MODEL", "gpt-5.6-luna")
PROMPT_ID = os.getenv("MEMORY_PROMPT_ID", "").strip()
PROMPT_VERSION = os.getenv("MEMORY_PROMPT_VERSION", "").strip()
MAX_CHARS = int(os.getenv("MEMORY_CHUNK_CHARS", "180000"))

# Safe fallback used only when MEMORY_PROMPT_ID is not configured.
SYSTEM = """You are building a persistent, user-controlled memory from historical ChatGPT conversations.
Your job is faithful reconstruction, not persuasion and not fact-check theater.
Separate clearly:
- documented/verified facts stated or researched in the conversation;
- the user's own working conclusions or interpretations;
- decisions and project requirements;
- counterarguments actually examined;
- unresolved questions or contradictions.
Never turn a user's interpretation into an externally established fact.
Never erase a unique detail merely because it is repeated elsewhere.
Prefer concrete names, dates, paths, repositories, technical constraints and decisions when present.
For conversations involving age-restricted or dangerous subjects, gambling, self-harm, weapons, drugs, or dangerous activities, preserve only high-level non-actionable context needed for continuity. Do not preserve instructions, strategies, access methods, concealment methods, graphic details, or operational guidance.
Return valid JSON only, with no markdown fence."""


def prompt_reference() -> dict[str, str] | None:
    if not PROMPT_ID:
        return None
    ref = {"id": PROMPT_ID}
    if PROMPT_VERSION:
        ref["version"] = PROMPT_VERSION
    return ref


def call_json(client: OpenAI, task: str, effort: str = "low") -> dict[str, Any]:
    """Run one structured memory-analysis task.

    When a stored prompt is configured, it supplies the durable Luna persona and
    policy. The per-call task remains dynamic. Tools saved on the prompt are not
    needed for archive synthesis, so tool use is disabled for these calls; the
    GitHub Actions workflow remains the only writer during an import run.
    """
    kwargs: dict[str, Any] = {
        "model": MODEL,
        "reasoning": {"effort": effort},
        "tools": [],
        "tool_choice": "none",
    }
    stored_prompt = prompt_reference()
    if stored_prompt:
        kwargs["prompt"] = stored_prompt
        kwargs["input"] = [{"role": "user", "content": task}]
    else:
        kwargs["input"] = [
            {"role": "system", "content": SYSTEM},
            {"role": "user", "content": task},
        ]

    response = client.responses.create(**kwargs)
    text = response.output_text.strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.I | re.S).strip()
    return json.loads(text)


def message_text(messages: list[dict[str, Any]]) -> str:
    return "\n\n".join(f"[{m['role'].upper()}]\n{m['text']}" for m in messages)


def chunk_messages(messages: list[dict[str, Any]], limit: int = MAX_CHARS) -> list[list[dict[str, Any]]]:
    chunks: list[list[dict[str, Any]]] = []
    current: list[dict[str, Any]] = []
    size = 0
    for message in messages:
        n = len(message.get("text", "")) + 32
        if current and size + n > limit:
            chunks.append(current)
            current = []
            size = 0
        current.append(message)
        size += n
    if current:
        chunks.append(current)
    return chunks


def chunk_prompt(meta: dict[str, Any], chunk: list[dict[str, Any]], index: int, total: int) -> str:
    routes = [r["id"] for r in meta.get("candidate_routes", [])]
    return f"""Analyze chunk {index}/{total} of this historical conversation.
Title: {meta['title']}
Conversation ID: {meta['conversation_id']}
Candidate routes from deterministic indexing: {routes}

Extract a compact but information-dense JSON object with exactly these keys:
summary, key_facts, user_working_conclusions, decisions_requirements, counterarguments_examined,
open_questions, contradictions, entities_terms, project_state, source_clues, candidate_routes.
All list-valued keys must be arrays of strings. summary and project_state are strings.
Do not invent information absent from the text.

CONVERSATION CHUNK:
{message_text(chunk)}"""


def conversation_prompt(meta: dict[str, Any], chunk_summaries: list[dict[str, Any]]) -> str:
    return f"""Synthesize one historical conversation from its chunk analyses.
Title: {meta['title']}
Conversation ID: {meta['conversation_id']}
Created: {meta.get('created_at')}
Updated: {meta.get('updated_at')}

Produce JSON with exactly these keys:
canonical_title, executive_summary, themes, key_facts, user_working_conclusions,
decisions_requirements, counterarguments_examined, open_questions, contradictions,
entities_terms, project_state, recommended_routes, continuity_notes, importance.

Rules:
- arrays for every key except canonical_title, executive_summary, project_state, continuity_notes, importance;
- importance must be one of low, medium, high, foundational;
- merge duplicates but preserve every materially unique safe detail;
- if chunks disagree, record the disagreement under contradictions rather than choosing silently;
- recommended_routes should use repository-style identifiers such as project.auto-trading or research.banking-fed-titanic;
- continuity_notes should explain what a future assistant must know before reopening this subject.

CHUNK ANALYSES:
{json.dumps(chunk_summaries, ensure_ascii=False)}"""


def topic_prompt(route: str, summaries: list[dict[str, Any]]) -> str:
    compact = [{
        "conversation_id": s["conversation_id"],
        "title": s["title"],
        "created_at": s.get("created_at"),
        "analysis": s["analysis"],
    } for s in summaries]
    return f"""Build a cross-conversation memory candidate for route: {route}.

Produce JSON with exactly these keys:
title, scope, chronological_development, consolidated_facts, user_working_conclusions,
decisions_requirements, counterarguments_examined, contradictions, open_questions,
current_state, continuity_instructions, source_conversations.

Requirements:
- This is a CANDIDATE, not an automatic declaration of external truth.
- Deduplicate repetition across conversations without deleting unique safe details.
- Preserve changes of mind and evolution chronologically.
- Distinguish researched facts from the user's interpretations/conclusions.
- For an investigation, retain the strongest counterarguments actually examined and what happened when they were investigated.
- For a project, retain architecture decisions, blockers, branch/repo/path names and the latest known state.
- source_conversations must list conversation IDs used.

CONVERSATION SUMMARIES:
{json.dumps(compact, ensure_ascii=False)}"""


def write_md(path: Path, payload: dict[str, Any], provenance: dict[str, Any]) -> None:
    prompt_label = PROMPT_ID or "embedded-fallback"
    if PROMPT_VERSION:
        prompt_label = f"{prompt_label}@{PROMPT_VERSION}"
    lines = [
        f"# {payload.get('title') or payload.get('canonical_title') or 'Memory candidate'}",
        "",
        "**Status: CANDIDATE — review required before canonical promotion.**",
        "",
        f"Source archive SHA-256: `{provenance['archive_sha256']}`",
        f"Model: `{MODEL}`",
        f"Stored prompt: `{prompt_label}`",
        "",
    ]
    for key, value in payload.items():
        if key in {"title", "canonical_title"}:
            continue
        heading = key.replace("_", " ").title()
        lines += [f"## {heading}", ""]
        if isinstance(value, list):
            lines += [f"- {item}" for item in value] or ["- _None recorded._"]
        elif isinstance(value, dict):
            lines += ["```json", json.dumps(value, ensure_ascii=False, indent=2), "```"]
        else:
            lines.append(str(value or "_None recorded._"))
        lines.append("")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def route_slug(route: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", route.lower()).strip("-")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--work-dir", type=Path, default=Path(".memory-work"))
    ap.add_argument("--report-dir", type=Path, default=Path("05_IMPORTS/latest"))
    ap.add_argument("--candidate-dir", type=Path, default=Path("CANDIDATES"))
    ap.add_argument("--limit", type=int, default=0, help="Debug: max conversations; 0 = all")
    args = ap.parse_args()

    if not os.getenv("OPENAI_API_KEY"):
        raise SystemExit("OPENAI_API_KEY is required")
    client = OpenAI()
    manifest = json.loads((args.report_dir / "manifest.json").read_text(encoding="utf-8"))
    files = sorted((args.work_dir / "normalized").glob("*.json"))
    if args.limit:
        files = files[: args.limit]

    mode = f"stored prompt {PROMPT_ID}" if PROMPT_ID else "embedded fallback prompt"
    print(f"Memory worker: model={MODEL}; instruction_source={mode}", flush=True)

    summaries = []
    conversation_dir = args.candidate_dir / "conversations"
    for pos, path in enumerate(files, 1):
        source = json.loads(path.read_text(encoding="utf-8"))
        messages = source.pop("messages")
        chunks = chunk_messages(messages)
        chunk_analyses = []
        print(f"[{pos}/{len(files)}] {source['title']} — {len(chunks)} chunk(s)", flush=True)
        for idx, chunk in enumerate(chunks, 1):
            chunk_analyses.append(call_json(client, chunk_prompt(source, chunk, idx, len(chunks)), effort="low"))
        analysis = call_json(client, conversation_prompt(source, chunk_analyses), effort="medium")
        record = {**source, "analysis": analysis}
        summaries.append(record)
        out_json = conversation_dir / f"{source['conversation_id']}.json"
        out_json.parent.mkdir(parents=True, exist_ok=True)
        out_json.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")

    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for record in summaries:
        routes = {r["id"] for r in record.get("candidate_routes", [])}
        routes.update(record["analysis"].get("recommended_routes", []))
        for route in sorted(r for r in routes if isinstance(r, str) and r.strip()):
            grouped[route].append(record)

    topic_index = []
    topic_dir = args.candidate_dir / "topics"
    for route, records in sorted(grouped.items()):
        print(f"[topic] {route} — {len(records)} conversations", flush=True)
        payload = call_json(client, topic_prompt(route, records), effort="medium")
        payload.setdefault("title", route)
        jpath = topic_dir / f"{route_slug(route)}.json"
        mpath = topic_dir / f"{route_slug(route)}.md"
        jpath.parent.mkdir(parents=True, exist_ok=True)
        jpath.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        write_md(mpath, payload, manifest)
        topic_index.append({"route": route, "conversation_count": len(records), "json": str(jpath), "markdown": str(mpath)})

    (args.report_dir / "topic-index.json").write_text(json.dumps(topic_index, ensure_ascii=False, indent=2), encoding="utf-8")
    manifest["summarization"] = {
        "model": MODEL,
        "prompt_id": PROMPT_ID or None,
        "prompt_version": PROMPT_VERSION or None,
        "instruction_source": "stored_prompt" if PROMPT_ID else "embedded_fallback",
        "conversation_summaries": len(summaries),
        "topic_candidates": len(topic_index),
        "canonical_documents_modified": False,
    }
    (args.report_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest["summarization"], ensure_ascii=False))


if __name__ == "__main__":
    main()
