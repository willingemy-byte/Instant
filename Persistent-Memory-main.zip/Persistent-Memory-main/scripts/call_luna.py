#!/usr/bin/env python3
"""Dispatch one mandate to Luna through the Responses API.

Luna keeps the stored OpenAI Platform prompt for durable persona/tool configuration,
then receives a repository-versioned developer prompt for the current execution
policy. GitHub MCP can be read-only or writable according to explicit dispatcher
environment settings. Heavy execution stays on runners. Secrets are never written
to the result bundle.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
from typing import Any
from urllib.parse import quote

from openai import OpenAI

PROMPT_ID = os.getenv("MEMORY_PROMPT_ID", "").strip()
PROMPT_VERSION = os.getenv("MEMORY_PROMPT_VERSION", "").strip()
MODEL = os.getenv("LUNA_MODEL", "gpt-5.6-luna").strip()
DEFAULT_EFFORT = os.getenv("LUNA_REASONING_EFFORT", "medium").strip()
DEVELOPER_PROMPT_FILE = Path(
    os.getenv(
        "LUNA_DEVELOPER_PROMPT_FILE",
        "00_PERSONA/06_LUNA_EXECUTION_ORCHESTRATOR.md",
    ).strip()
)

GITHUB_MCP_ENABLED = os.getenv("LUNA_GITHUB_MCP_ENABLED", "true").strip().lower() not in {"0", "false", "no", "off"}
GITHUB_MCP_URL = os.getenv("GITHUB_MCP_URL", "https://api.githubcopilot.com/mcp/").strip()
GITHUB_MCP_TOOLSETS = os.getenv(
    "GITHUB_MCP_TOOLSETS",
    "context,repos,issues,pull_requests,actions",
).strip()
GITHUB_MCP_READONLY = os.getenv("LUNA_GITHUB_MCP_READONLY", "true").strip().lower() not in {"0", "false", "no", "off"}
GITHUB_MCP_REQUIRE_APPROVAL = os.getenv(
    "LUNA_GITHUB_MCP_REQUIRE_APPROVAL",
    "never" if GITHUB_MCP_READONLY else "always",
).strip().lower()

BROWSER_MCP_ENABLED = os.getenv("LUNA_BROWSER_MCP_ENABLED", "true").strip().lower() not in {"0", "false", "no", "off"}
BROWSER_MCP_MODE = os.getenv("LUNA_BROWSER_MCP_MODE", "observe").strip().lower()
BROWSERBASE_MCP_BASE_URL = os.getenv("BROWSERBASE_MCP_URL", "https://mcp.browserbase.com/mcp").strip()


def prompt_reference() -> dict[str, str]:
    if not PROMPT_ID:
        raise SystemExit("MEMORY_PROMPT_ID is required")
    ref = {"id": PROMPT_ID}
    if PROMPT_VERSION:
        ref["version"] = PROMPT_VERSION
    return ref


def item_type(item: Any) -> str:
    if isinstance(item, dict):
        return str(item.get("type", "unknown"))
    return str(getattr(item, "type", "unknown"))


def load_developer_prompt() -> str:
    if not DEVELOPER_PROMPT_FILE.exists():
        raise SystemExit(f"Luna developer prompt not found: {DEVELOPER_PROMPT_FILE}")
    text = DEVELOPER_PROMPT_FILE.read_text(encoding="utf-8").strip()
    if not text:
        raise SystemExit(f"Luna developer prompt is empty: {DEVELOPER_PROMPT_FILE}")
    return text


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def github_mcp_token() -> str:
    """Prefer a dedicated multi-repo token; fall back to current-repo Actions token."""
    return (os.getenv("GITHUB_MCP_TOKEN") or os.getenv("GITHUB_TOKEN") or "").strip()


def build_github_mcp_tool() -> dict[str, Any] | None:
    if not GITHUB_MCP_ENABLED:
        return None

    token = github_mcp_token()
    if not token:
        return None

    if GITHUB_MCP_REQUIRE_APPROVAL not in {"never", "always"}:
        raise SystemExit("LUNA_GITHUB_MCP_REQUIRE_APPROVAL must be 'never' or 'always'")

    headers = {
        "Authorization": f"Bearer {token}",
        "X-MCP-Toolsets": GITHUB_MCP_TOOLSETS,
    }
    if GITHUB_MCP_READONLY:
        headers["X-MCP-Readonly"] = "true"

    tool: dict[str, Any] = {
        "type": "mcp",
        "server_label": "github",
        "server_description": (
            "Official GitHub MCP server for repository orchestration. Inspect repositories, "
            "branches, issues, pull requests and Actions; when writable mode is explicitly "
            "enabled, perform only the writes authorized by the developer execution prompt. "
            "Delegate heavy computation to GitHub Actions runners."
        ),
        "server_url": GITHUB_MCP_URL,
        "headers": headers,
        "require_approval": "never" if GITHUB_MCP_READONLY else GITHUB_MCP_REQUIRE_APPROVAL,
    }
    if GITHUB_MCP_READONLY:
        tool["allowed_tools"] = {"read_only": True}
    return tool


def browserbase_api_key() -> str:
    return os.getenv("BROWSERBASE_API_KEY", "").strip()


def build_browser_mcp_tool() -> dict[str, Any] | None:
    if not BROWSER_MCP_ENABLED:
        return None

    key = browserbase_api_key()
    if not key:
        return None

    if BROWSER_MCP_MODE not in {"observe", "interactive"}:
        raise SystemExit("LUNA_BROWSER_MCP_MODE must be 'observe' or 'interactive'")

    separator = "&" if "?" in BROWSERBASE_MCP_BASE_URL else "?"
    server_url = f"{BROWSERBASE_MCP_BASE_URL}{separator}browserbaseApiKey={quote(key, safe='')}"
    allowed = ["start", "navigate", "observe", "extract"]
    if BROWSER_MCP_MODE == "interactive":
        allowed = ["start", "end", "navigate", "act", "observe", "extract"]

    return {
        "type": "mcp",
        "server_label": "browser",
        "server_description": (
            "Browserbase hosted MCP. In observe mode, inspect only; do not click, type, "
            "authenticate, publish, purchase, change settings or perform external writes."
        ),
        "server_url": server_url,
        "allowed_tools": allowed,
        "require_approval": "never",
    }


def build_tools() -> tuple[list[dict[str, Any]], bool, bool]:
    tools: list[dict[str, Any]] = []
    github_tool = build_github_mcp_tool()
    browser_tool = build_browser_mcp_tool()
    if github_tool:
        tools.append(github_tool)
    if browser_tool:
        tools.append(browser_tool)
    return tools, bool(github_tool), bool(browser_tool)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mandate-file", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=Path("luna-result.md"))
    parser.add_argument("--json-output", type=Path, default=Path("luna-result.json"))
    parser.add_argument("--effort", choices=["low", "medium", "high", "xhigh"], default=DEFAULT_EFFORT)
    args = parser.parse_args()

    if not os.getenv("OPENAI_API_KEY"):
        raise SystemExit("OPENAI_API_KEY is required")

    mandate = args.mandate_file.read_text(encoding="utf-8").strip()
    if not mandate:
        raise SystemExit("Mandate is empty")
    developer_prompt = load_developer_prompt()
    developer_prompt_sha = sha256_text(developer_prompt)

    tools, github_enabled, browser_enabled = build_tools()
    client = OpenAI()
    response = client.responses.create(
        model=MODEL,
        prompt=prompt_reference(),
        input=[
            {"role": "developer", "content": developer_prompt},
            {"role": "user", "content": mandate},
        ],
        reasoning={"effort": args.effort},
        tools=tools,
        tool_choice="auto" if tools else "none",
        max_tool_calls=60,
        metadata={
            "source": "persistent-memory-call-luna",
            "repository": "willingemy-byte/Persistent-Memory",
            "developer_prompt_sha256": developer_prompt_sha,
            "github_mcp": "enabled" if github_enabled else "disabled",
            "github_mcp_readonly": str(GITHUB_MCP_READONLY).lower(),
            "browser_mcp": "enabled" if browser_enabled else "disabled",
            "browser_mcp_mode": BROWSER_MCP_MODE if browser_enabled else "disabled",
        },
        store=True,
    )

    output_types = [item_type(item) for item in (response.output or [])]
    approval_pending = any(t == "mcp_approval_request" for t in output_types)
    text = (response.output_text or "").strip()

    approval_note = ""
    if approval_pending:
        approval_note = (
            "\n\n> Luna requested MCP approval despite the dispatcher policy. "
            "The action was not represented as completed; inspect the tool configuration."
        )

    if not text:
        text = "Luna returned no final text output."

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        "# Luna result\n\n"
        f"Response ID: `{response.id}`  \n"
        f"Status: `{response.status}`  \n"
        f"Model: `{response.model}`  \n"
        f"Stored prompt: `{PROMPT_ID}`  \n"
        f"Developer prompt: `{DEVELOPER_PROMPT_FILE}`  \n"
        f"Developer prompt SHA256: `{developer_prompt_sha}`  \n"
        f"GitHub MCP: `{'enabled' if github_enabled else 'disabled'}`  \n"
        f"GitHub MCP read-only: `{GITHUB_MCP_READONLY}`  \n"
        f"GitHub MCP approval: `{('never' if GITHUB_MCP_READONLY else GITHUB_MCP_REQUIRE_APPROVAL)}`  \n"
        f"Browser MCP: `{'enabled' if browser_enabled else 'disabled'}`  \n"
        f"Browser MCP mode: `{BROWSER_MCP_MODE if browser_enabled else 'disabled'}`  \n"
        f"Output item types: `{', '.join(output_types) or 'none'}`\n\n"
        f"{text}{approval_note}\n",
        encoding="utf-8",
    )

    safe_record = {
        "response_id": response.id,
        "status": response.status,
        "model": response.model,
        "prompt_id": PROMPT_ID,
        "prompt_version": PROMPT_VERSION or None,
        "developer_prompt_file": str(DEVELOPER_PROMPT_FILE),
        "developer_prompt_sha256": developer_prompt_sha,
        "reasoning_effort": args.effort,
        "github_mcp_enabled": github_enabled,
        "github_mcp_readonly": GITHUB_MCP_READONLY,
        "github_mcp_require_approval": "never" if GITHUB_MCP_READONLY else GITHUB_MCP_REQUIRE_APPROVAL,
        "github_mcp_toolsets": GITHUB_MCP_TOOLSETS if github_enabled else None,
        "browser_mcp_enabled": browser_enabled,
        "browser_mcp_mode": BROWSER_MCP_MODE if browser_enabled else None,
        "browserbase_secret_configured": bool(browserbase_api_key()),
        "output_item_types": output_types,
        "mcp_approval_pending": approval_pending,
        "output_text": text,
    }
    args.json_output.write_text(json.dumps(safe_record, ensure_ascii=False, indent=2), encoding="utf-8")

    print(json.dumps({k: safe_record[k] for k in (
        "response_id",
        "status",
        "model",
        "developer_prompt_sha256",
        "github_mcp_enabled",
        "github_mcp_readonly",
        "github_mcp_require_approval",
        "mcp_approval_pending",
    )}, ensure_ascii=False))


if __name__ == "__main__":
    main()
