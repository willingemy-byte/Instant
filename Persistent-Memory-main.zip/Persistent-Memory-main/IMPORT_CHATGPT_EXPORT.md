# Importer un export ChatGPT

Le pipeline `IMPORT-CHATGPT-EXPORT` est conçu pour traiter un export complet sans ajouter l’archive brute à l’historique Git.

## Pourquoi l’archive ne va pas dans Git

L’export peut être volumineux et contenir des données privées. Un fichier ajouté puis supprimé d’une branche peut rester dans l’historique Git. Le pipeline utilise donc un **asset de Release privée temporaire** comme boîte d’entrée.

## Flux

1. Créer une Release privée temporaire dans ce dépôt, recommandée : `chatgpt-export-inbox`.
2. Y joindre le ZIP original comme asset.
3. Dans **Actions → IMPORT-CHATGPT-EXPORT → Run workflow**, conserver le tag proposé ou indiquer le tag utilisé.
4. Le runner :
   - télécharge le ZIP;
   - vérifie son intégrité et son SHA-256;
   - extrait les conversations dans un espace de travail éphémère;
   - construit l’inventaire déterministe;
   - utilise `gpt-5.6-luna` pour résumer chaque conversation en plusieurs passes si nécessaire;
   - regroupe ensuite les conversations par projet, enquête et modèle;
   - produit uniquement des documents `CANDIDATE`;
   - crée une branche d’import et une pull request pour revue;
   - peut supprimer l’asset ZIP temporaire une fois le traitement réussi.

## Secret requis

Le workflow attend `OPENAI_API_KEY` dans **Settings → Secrets and variables → Actions** du dépôt. Ne jamais écrire la clé dans un fichier, une issue, un prompt ou un commit.

## Sorties

- `05_IMPORTS/latest/manifest.json` — provenance et statistiques de l’import.
- `05_IMPORTS/latest/catalog.json` / `catalog.md` — inventaire et routage candidat.
- `CANDIDATES/conversations/` — synthèse de chaque conversation.
- `CANDIDATES/topics/` — consolidation transversale par sujet.

Aucun fichier dans `CANDIDATES/` ne devient automatiquement canonique.

## Taxonomie initiale

Le pipeline possède déjà des routes pour : Auto Trading, All Invisible, Persistent Memory/Jarvis, système bancaire/Fed/Titanic, GitHub/MCP/Codex/multi-agent, modèles métaphysiques/conscience, IA/quantique/conscience et contexte personnel/professionnel. Le modèle peut proposer des routes supplémentaires lorsqu’un ensemble important n’entre pas proprement dans ces catégories.
