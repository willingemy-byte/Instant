# Luna ↔ GitHub MCP contract

Luna uses GitHub's official remote MCP server as an orchestration interface. Runners remain responsible for heavy execution.

## Endpoint

`https://api.githubcopilot.com/mcp/`

## Default toolsets

- `context`
- `repos`
- `issues`
- `pull_requests`
- `actions`

## Authentication

`GITHUB_MCP_TOKEN` is preferred when Luna needs access across multiple repositories. When it is absent, the dispatcher may use the current workflow `GITHUB_TOKEN`; that token is repository-scoped and therefore only provides the permissions granted to the current Actions job.

Never store a token in this file, a prompt, an issue, or an artifact.

## Safety modes

Default mode is read-only. It is enforced server-side with `X-MCP-Readonly: true` and by filtering allowed tools to read-only annotations when supported.

Write mode must be enabled explicitly with `LUNA_GITHUB_MCP_READONLY=false`, and the token used must itself have only the minimum repository permissions needed. GitHub Actions/runners remain the preferred way to perform long-running computation.

## Responsibilities

Luna may use MCP to inspect repositories, code, issues, pull requests, Actions runs, failures, and artifacts; decide the next orchestration step; and report blockers.

Luna should delegate expensive or long-running execution to GitHub Actions runners rather than attempting to perform that work in its own model context.
