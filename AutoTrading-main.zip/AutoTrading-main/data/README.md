# Données locales

Les données de marché téléchargées sont volontairement exclues de GitHub. Elles peuvent être volumineuses et soumises à une licence du fournisseur.

- `raw/` : export original du fournisseur et métadonnées de requête;
- `normalized/` : chandelles validées et agrégées pour le backtest.

Seuls de minuscules fixtures synthétiques destinés aux tests peuvent être ajoutés au dépôt.
