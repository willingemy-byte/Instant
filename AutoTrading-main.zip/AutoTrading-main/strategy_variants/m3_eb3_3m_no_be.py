import yfinance as yf
import pandas as pd
from backtesting import Strategy, Backtest


class Eb3Persistent3mStrategy(Strategy):
    rsi_length = 21
    rsi_ma_length = 50
    price_ma_length = 50
    risk_reward_ratio = 3.0

    def init(self):
        def calculate_rsi(close_prices, rsi_length):
            delta = pd.Series(close_prices).diff()
            gain = delta.mask(delta < 0, 0)
            loss = -delta.mask(delta > 0, 0)
            avg_gain = gain.ewm(com=rsi_length - 1, adjust=False).mean()
            avg_loss = loss.ewm(com=rsi_length - 1, adjust=False).mean()
            rs = avg_gain / avg_loss
            return pd.Series([
                100 - (100 / (1 + val)) if val != 0 and not pd.isna(val)
                else (100 if pd.isna(val) else 0)
                for val in rs
            ])

        self.rsi = self.I(calculate_rsi, self.data.Close, self.rsi_length, name="RSI")
        self.rsi_ma = self.I(
            lambda x: pd.Series(x).rolling(self.rsi_ma_length).mean(),
            self.rsi,
            name="RSI_MA",
        )
        self.price_ma = self.I(
            lambda x: pd.Series(x).rolling(self.price_ma_length).mean(),
            self.data.Close,
            name="Price_MA",
        )

        self.bullish_block_armed = False
        self.bearish_block_armed = False
        self.bullish_block_body_top = None
        self.bearish_block_body_bottom = None

    def _detect_eb3(self):
        if len(self.data.Open) < 4:
            return False, False

        current_open = self.data.Open[-1]
        current_close = self.data.Close[-1]
        current_body_low = min(current_open, current_close)
        current_body_high = max(current_open, current_close)

        previous_body_lows = [
            min(self.data.Open[-i], self.data.Close[-i])
            for i in (2, 3, 4)
        ]
        previous_body_highs = [
            max(self.data.Open[-i], self.data.Close[-i])
            for i in (2, 3, 4)
        ]

        engulfs_three_bodies = (
            current_body_low <= min(previous_body_lows)
            and current_body_high >= max(previous_body_highs)
        )

        bullish = current_close > current_open and engulfs_three_bodies
        bearish = current_close < current_open and engulfs_three_bodies
        return bullish, bearish

    def next(self):
        bullish_eb3, bearish_eb3 = self._detect_eb3()
        current_close = self.data.Close[-1]

        if (
            self.bullish_block_armed
            and not bullish_eb3
            and self.bullish_block_body_top is not None
            and current_close <= self.bullish_block_body_top
        ):
            self.bullish_block_armed = False
            self.bullish_block_body_top = None

        if (
            self.bearish_block_armed
            and not bearish_eb3
            and self.bearish_block_body_bottom is not None
            and current_close >= self.bearish_block_body_bottom
        ):
            self.bearish_block_armed = False
            self.bearish_block_body_bottom = None

        if bullish_eb3:
            self.bullish_block_armed = True
            self.bullish_block_body_top = max(self.data.Open[-1], self.data.Close[-1])

        if bearish_eb3:
            self.bearish_block_armed = True
            self.bearish_block_body_bottom = min(self.data.Open[-1], self.data.Close[-1])

        if pd.isna(self.rsi[-1]) or pd.isna(self.rsi_ma[-1]) or pd.isna(self.price_ma[-1]):
            return

        if self.position:
            return

        long_confirmation = (
            current_close > self.price_ma[-1]
            and self.rsi[-1] > self.rsi_ma[-1]
        )
        short_confirmation = (
            current_close < self.price_ma[-1]
            and self.rsi[-1] < self.rsi_ma[-1]
        )

        if self.bullish_block_armed and long_confirmation:
            entry_price = current_close
            stop_loss = self.data.Low[-2]

            if stop_loss >= entry_price - (entry_price * 0.001):
                stop_loss = entry_price * 0.99

            risk = entry_price - stop_loss
            if risk > 0:
                take_profit = entry_price + (risk * self.risk_reward_ratio)
                self.buy(sl=stop_loss, tp=take_profit)
                self.bullish_block_armed = False
                self.bullish_block_body_top = None

        elif self.bearish_block_armed and short_confirmation:
            entry_price = current_close
            stop_loss = self.data.High[-2]

            if stop_loss <= entry_price + (entry_price * 0.001):
                stop_loss = entry_price * 1.01

            risk = stop_loss - entry_price
            if risk > 0:
                take_profit = entry_price - (risk * self.risk_reward_ratio)
                self.sell(sl=stop_loss, tp=take_profit)
                self.bearish_block_armed = False
                self.bearish_block_body_bottom = None


def download_one_minute():
    last_error = None
    for period in ("30d", "7d"):
        try:
            df = yf.download("GLD", period=period, interval="1m", progress=False)
            if df is not None and not df.empty:
                return df, period
        except Exception as exc:
            last_error = exc
    raise RuntimeError(f"Unable to download GLD 1m data: {last_error}")


raw_1m, requested_period = download_one_minute()

if isinstance(raw_1m.columns, pd.MultiIndex):
    raw_1m.columns = raw_1m.columns.droplevel(1)

raw_1m = raw_1m[["Open", "High", "Low", "Close", "Volume"]].dropna()

# Build true 3-minute OHLCV candles from 1-minute Yahoo bars.
data = raw_1m.resample("3min", label="left", closed="left").agg({
    "Open": "first",
    "High": "max",
    "Low": "min",
    "Close": "last",
    "Volume": "sum",
}).dropna()

print("=== DATASET 3M ===")
print(f"Yahoo source interval: 1m")
print(f"Requested Yahoo period: {requested_period}")
print(f"Raw 1m rows: {len(raw_1m)}")
print(f"3m rows: {len(data)}")
print(f"3m start: {data.index.min()}")
print(f"3m end: {data.index.max()}")
print()

bt = Backtest(
    data,
    Eb3Persistent3mStrategy,
    cash=100000,
    commission=0.002,
    exclusive_orders=True,
)

stats = bt.run()
print(stats)
