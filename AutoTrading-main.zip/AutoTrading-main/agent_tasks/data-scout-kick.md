# DATA-SCOUT KICK

Mission source: issue #12.

## Priority mission

Research only. Find **historical tick-by-tick Gold futures data**, priority **GC**, then **MGC**, covering the same broad historical period as the existing 1-minute Price Action source.

### Canonical date window

Use the existing 1-minute source window only as the target date span:

- start: approximately `2023-01-02T23:00:00Z`
- end: `2026-03-23T23:59:00Z`

This date alignment is only to ensure both research branches examine the same market era. **Do not attempt to make tick bars match 1-minute candles, do not rebuild 1-minute OHLCV, and do not compare bar-for-bar against the minute dataset.** A time candle contains a variable number of trade events, which is precisely why the tick branch is scientifically distinct.

The objective is not to build the longest possible history and not to search back to 2010 or earlier. Older availability may be noted only as provider metadata; it has no priority.

Prefer candidates that cover the entire canonical date window. If no single source does, identify the smallest reproducible combination of compatible sources that can cover it, documenting gaps and contract/rollover differences.

## Native tick research objective

The tick dataset must preserve event sequencing and permit deterministic construction of **tick-count bars**, not time bars.

Required tick-count granularities:

- 50 ticks
- 75 ticks
- 100 ticks
- 125 ticks
- continue in increments of 25 ticks
- through 1,000 ticks inclusive
- plus 2,000 ticks as a larger structural unit

Thus the standard family is `50, 75, 100, ... 975, 1000, 2000` ticks.

Each tick-count bar closes after the specified number of qualifying trade ticks/events, regardless of elapsed clock time. Preserve start/end timestamps so elapsed duration and activity rate can later be studied as properties of each bar rather than as aggregation boundaries.

Do not silently equate a trade tick with an order-book event. For each source, determine exactly what one record represents:

- executed trade/event;
- quote or bid/ask update;
- MBP-1 book update;
- MBO/order event.

The first research target is trade-tick bars. If richer MBP/MBO data are available, catalogue them separately because they may support additional microstructure research later.

## Scientific intent

The purpose of native tick bars is to expose market structure based on activity rather than clock time. The future Price Action tick branch should be able to run the same structural concepts across the tick-count family without contaminating or replacing the existing minute-based branch.

The minute and tick branches therefore share:

- approximately the same historical dates;
- the same underlying Gold futures market context where instrument compatibility permits;
- comparable structural concepts.

They do **not** share candle boundaries or equal numbers of events per bar.

## Required discovery order

1. Query SkillDB / available MCP skill databases first for skills related to market-data discovery, dataset search, GitHub research, CME/COMEX, futures, tick data, Databento, Rithmic/NinjaTrader exports, Parquet/CSV and data provenance.
2. Search GitHub repositories and dataset hosts for actual GC/MGC tick files or reproducible acquisition pipelines covering the canonical date window.
3. Search official/provider catalogues specifically for availability over `2023-01-02` through `2026-03-23` and exact schema/access terms.
4. Distinguish actual downloadable data from code-only repositories, wrappers, samples and documentation.

## Strong leads to verify, not blindly adopt

- Databento CME Globex `GLBX.MDP3`: verify GC/MGC trade-tick coverage specifically for `2023-01-02` → `2026-03-23`, contract semantics and access constraints.
- `GhostFinancialLLC/goldmicrostructure`: determine whether raw GC tick data covering our canonical window are actually accessible or only the pipeline/documentation is public.
- Existing `GC_TRADES_2026.parquet`: retain as a known partial source and native trade-tick dataset; do not convert it to 1-minute bars as part of this mission.
- Rithmic/NinjaTrader exporters, CME DataMine, Sierra Chart, Kibot, PortaraCQG and Tick Data LLC: evaluate only insofar as they can supply the canonical window reproducibly.

## For every candidate record

Record:

- provider/repository and exact URL;
- GC or MGC and individual-contract vs continuous semantics;
- whether it covers the full canonical date window;
- exact earliest usable timestamp within our window;
- exact latest usable timestamp within our window;
- explicit gaps inside the window;
- what one row/event actually represents;
- trade schema versus quote/L1/MBP-1/MBO;
- timestamp resolution and timezone;
- fields such as price, size, side/aggressor if available, bid, ask, contract;
- actual downloadable files vs API/account requirement vs code-only;
- approximate rows/bytes for the canonical window if available;
- licensing/redistribution constraints;
- rollover/continuous-series method;
- reproducibility/provenance quality;
- suitability for deterministic 50→1000-by-25 tick-count bars plus 2000-tick bars;
- compatibility issues between GC and the current MGC minute research context.

## Ranking rule

Rank candidates primarily by:

1. complete coverage of `2023-01-02` → `2026-03-23`;
2. true trade-event/tick granularity with preserved ordering;
3. correct instrument/contract semantics;
4. reproducible access;
5. timestamp and schema quality;
6. provenance and licensing;
7. suitability for native tick-count Price Action analysis.

Do not award extra priority because a source starts years earlier than 2023.

## Classification

Classify candidates as:

- `FULL_WINDOW_READY` — accessible true tick data covering the complete canonical date window;
- `PARTIAL_WINDOW_READY` — accessible true tick data covering only part of it;
- `ACCESS_PATH` — provider/API/export path likely able to cover it but requiring acquisition;
- `REFERENCE_ONLY` — suitable data are documented but not currently reproducibly accessible;
- `REJECTED` — wrong instrument, fake tick granularity, incompatible contract semantics, unclear provenance, unusable licensing, or irrelevant coverage.

Do not modify strategy code, the existing Price Action minute scientific rules, or the Site branch. This mission is tick-data discovery and evidence only. Preserve all raw search evidence and journal the result.
