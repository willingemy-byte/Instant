import unittest
from scripts.fetch_gc_yahoo import normalize


class FetchGcYahooTests(unittest.TestCase):
    def test_normalize_accepts_valid_bars_and_reports_metadata(self):
        timestamps = list(range(1_700_000_000, 1_700_000_000 + 1001 * 300, 300))
        payload = {
            "chart": {
                "error": None,
                "result": [{
                    "meta": {
                        "symbol": "GC=F",
                        "exchangeName": "CMX",
                        "exchangeTimezoneName": "America/New_York",
                        "currency": "USD",
                        "instrumentType": "FUTURE",
                    },
                    "timestamp": timestamps,
                    "indicators": {"quote": [{
                        "open": [2000.0] * len(timestamps),
                        "high": [2001.0] * len(timestamps),
                        "low": [1999.0] * len(timestamps),
                        "close": [2000.5] * len(timestamps),
                        "volume": [10] * len(timestamps),
                    }]},
                }],
            }
        }
        rows, report = normalize(payload)
        self.assertEqual(len(rows), 1001)
        self.assertEqual(report["symbol_returned"], "GC=F")
        self.assertEqual(report["interval"], "5m")

    def test_normalize_rejects_bad_ohlc(self):
        n = 1001
        payload = {
            "chart": {
                "error": None,
                "result": [{
                    "meta": {"symbol": "GC=F"},
                    "timestamp": list(range(1_700_000_000, 1_700_000_000 + n * 300, 300)),
                    "indicators": {"quote": [{
                        "open": [2000.0] * n,
                        "high": [1990.0] * n,
                        "low": [1980.0] * n,
                        "close": [2000.5] * n,
                        "volume": [10] * n,
                    }]},
                }],
            }
        }
        with self.assertRaises(RuntimeError):
            normalize(payload)

    def test_normalize_rejects_empty_intraday_result(self):
        with self.assertRaises(RuntimeError):
            normalize({"chart": {"error": None, "result": []}})


if __name__ == "__main__":
    unittest.main()
