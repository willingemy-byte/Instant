import unittest
from datetime import datetime, timedelta, timezone

from scripts.price_action_watchdog import (
    IntegrityReport,
    WorkflowRun,
    classify_state,
    compare_manifests,
    event_type,
    timeframe_progress,
)

UTC = timezone.utc
NOW = datetime(2026, 9, 1, 19, 0, tzinfo=UTC)


def integrity(*, current=False, site=False, missing=(), mismatches=()):
    expected = ("1W", "1D", "4H", "2H", "1H", "15m", "5m", "3m", "1m", "tick")
    completed = tuple(tf for tf in expected if tf not in missing)
    return IntegrityReport(
        current_exists=current,
        site_exists=site,
        manifests=("results/price-action-v1/current/manifest.json",) if current else (),
        checksum_files=("results/price-action-v1/current/checksums.sha256",) if current else (),
        checkpoints=("results/price-action-v1/current/checkpoints/state.json",) if current else (),
        completed_timeframes=completed if current else (),
        missing_timeframes=tuple(missing) if current else expected,
        mismatches=tuple(mismatches),
        scientific_generated_at=None,
        site_generated_at=None,
    )


def run(status="in_progress", conclusion=None, age=5):
    created = NOW - timedelta(minutes=age)
    return WorkflowRun(
        123,
        "PRICE ACTION V1 Historical Campaign",
        ".github/workflows/price-action-v1-campaign.yml",
        status,
        conclusion,
        created,
        created,
        "abc",
        "https://example/run",
    )


class PriceActionWatchdogTests(unittest.TestCase):
    def test_timeframe_tokens_do_not_confuse_1m_with_15m(self):
        paths = [
            "results/price-action-v1/current/15m/part.parquet",
            "results/price-action-v1/current/timeframe=1m/part.parquet",
            "results/price-action-v1/current/tick/part.parquet",
        ]
        complete, missing = timeframe_progress(paths, ("15m", "5m", "1m", "tick"))
        self.assertEqual(complete, ("15m", "1m", "tick"))
        self.assertEqual(missing, ("5m",))

    def test_manifest_mismatch_detected(self):
        mismatches = compare_manifests(
            {"dataset_id": "A", "schema_version": 1, "generated_at": "2026-09-01T18:00:00Z"},
            {"dataset_id": "B", "schema_version": 1, "generated_at": "2026-09-01T17:00:00Z"},
        )
        self.assertTrue(any("dataset_id mismatch" in item for item in mismatches))
        self.assertTrue(any("older" in item for item in mismatches))

    def test_successful_run_with_complete_integrity_is_complete(self):
        state = classify_state(
            run("completed", "success"),
            workflow_seen=True,
            integrity=integrity(current=True, site=True),
            branch_sha="abc",
            branch_updated_at=NOW,
            now=NOW,
            idle_threshold=timedelta(minutes=15),
            queue_stall=timedelta(minutes=30),
            run_timeout=timedelta(minutes=360),
        )
        self.assertEqual(state.code, "COMPLETE")
        self.assertEqual(event_type(state.code), "price_action_complete")

    def test_successful_run_with_missing_timeframe_is_integrity_error(self):
        state = classify_state(
            run("completed", "success"),
            workflow_seen=True,
            integrity=integrity(current=True, site=True, missing=("tick",)),
            branch_sha="abc",
            branch_updated_at=NOW,
            now=NOW,
            idle_threshold=timedelta(minutes=15),
            queue_stall=timedelta(minutes=30),
            run_timeout=timedelta(minutes=360),
        )
        self.assertEqual(state.code, "INTEGRITY_ERROR")
        self.assertEqual(event_type(state.code), "price_action_integrity_error")

    def test_branch_without_workflow_becomes_stalled_after_idle_threshold(self):
        state = classify_state(
            None,
            workflow_seen=False,
            integrity=integrity(),
            branch_sha="abc",
            branch_updated_at=NOW - timedelta(minutes=16),
            now=NOW,
            idle_threshold=timedelta(minutes=15),
            queue_stall=timedelta(minutes=30),
            run_timeout=timedelta(minutes=360),
        )
        self.assertEqual(state.code, "STALLED_NO_WORKFLOW")
        self.assertTrue(state.actionable)

    def test_running_work_is_not_actionable_before_timeout(self):
        state = classify_state(
            run("in_progress", age=45),
            workflow_seen=True,
            integrity=integrity(),
            branch_sha="abc",
            branch_updated_at=NOW,
            now=NOW,
            idle_threshold=timedelta(minutes=15),
            queue_stall=timedelta(minutes=30),
            run_timeout=timedelta(minutes=360),
        )
        self.assertEqual(state.code, "RUNNING")
        self.assertFalse(state.actionable)


if __name__ == "__main__":
    unittest.main()
