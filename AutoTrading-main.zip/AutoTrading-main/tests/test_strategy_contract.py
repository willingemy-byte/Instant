from pathlib import Path
import unittest


ROOT = Path(__file__).parents[1]
BASELINE = (ROOT / "strategies" / "manus_v1_executable.pine").read_text(
    encoding="utf-8"
)
NO_TIME = (ROOT / "strategies" / "manus_v1_no_time_filter.pine").read_text(
    encoding="utf-8"
)


class StrategyContractTests(unittest.TestCase):
    def test_both_variants_keep_recovered_signal_parameters(self):
        for source in (BASELINE, NO_TIME):
            with self.subTest(source=source.splitlines()[1]):
                self.assertIn('input.int(21, "RSI")', source)
                self.assertIn('input.int(50, "MM RSI")', source)
                self.assertIn('input.int(50, "MM Prix")', source)
                self.assertIn('input.float(3.0, "Ratio R:R")', source)
                self.assertIn('input.int(5, "Recherche Englobante")', source)
                self.assertIn("default_qty_type=strategy.fixed", source)
                self.assertIn("default_qty_value=1", source)

    def test_stops_and_targets_match_recovered_baseline(self):
        for source in (BASELINE, NO_TIME):
            self.assertIn(
                "sl = low[1] < close * 0.999 ? low[1] : close * 0.99", source
            )
            self.assertIn(
                "sl = high[1] > close * 1.001 ? high[1] : close * 1.01", source
            )
            self.assertIn("tp = close + (close - sl) * rr", source)
            self.assertIn("tp = close - (sl - close) * rr", source)

    def test_only_baseline_requires_new_york_window(self):
        self.assertIn('hour(time, "America/New_York") >= 8', BASELINE)
        self.assertIn("bull_found and trade_window", BASELINE)
        self.assertNotIn("trade_window", NO_TIME)

    def test_both_variants_prevent_overlapping_entries(self):
        for source in (BASELINE, NO_TIME):
            self.assertEqual(source.count("strategy.position_size == 0"), 2)


if __name__ == "__main__":
    unittest.main()
