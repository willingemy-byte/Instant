import importlib.util
import unittest
from pathlib import Path

SPEC = importlib.util.spec_from_file_location(
    "price_action_watchdog_v2", Path("scripts/price_action_watchdog_v2.py")
)
mod = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(mod)


class PriceActionWatchdogV2Tests(unittest.TestCase):
    def test_dispatch_payload_respects_github_limit(self):
        cfg = {
            "name": "PRICE ACTION V1",
            "branch": "research/price-action-v1",
            "workflow": "price-action-v1-campaign.yml",
            "issue": 116,
            "current_root": "results/price-action-v1/current",
            "site_root": "results/price-action-v1/current/site",
            "guardrails": {"resume_from_checkpoint": True},
        }
        report = {
            "completed_timeframes": ["1D", "1m"],
            "unavailable_timeframes": ["tick"],
            "missing_timeframes": [],
            "errors": [],
        }
        payload = mod.dispatch_payload("COMPLETE", cfg, "abc", None, report)
        self.assertLessEqual(len(payload), 10)
        self.assertIn("context", payload)
        self.assertEqual(payload["context"]["unavailable_timeframes"], ["tick"])

    def test_explicit_unavailable_timeframe_is_accounted(self):
        paths = (
            "results/price-action-v1/current/timeframe=1m/structural-ledger.parquet",
            "results/price-action-v1/current/timeframe-status/tick.json",
        )
        complete, unavailable, missing = mod.accounted_timeframes(
            paths, "results/price-action-v1/current", ["1m", "tick"]
        )
        self.assertEqual(complete, ["1m"])
        self.assertEqual(unavailable, ["tick"])
        self.assertEqual(missing, [])


if __name__ == "__main__":
    unittest.main()
