import unittest
from pathlib import Path
from unittest.mock import patch

import scripts.entry_path_recovery_agent as recovery


class EntryPathRecoveryAgentTests(unittest.TestCase):
    def test_safe_path_allows_entry_path_code(self):
        path = recovery.safe_path("entry_path/core.py")
        self.assertEqual(path, (recovery.ROOT / "entry_path/core.py").resolve())

    def test_safe_path_allows_campaign_workflow(self):
        path = recovery.safe_path(".github/workflows/entry-path-v1-campaign.yml")
        self.assertEqual(path, (recovery.ROOT / ".github/workflows/entry-path-v1-campaign.yml").resolve())

    def test_safe_path_blocks_main_or_unrelated_lab(self):
        for candidate in (
            ".github/workflows/agent-lab.yml",
            "backtest/lab/engine.py",
            "scripts/inactivity_watchdog.py",
            "strategies/manus_v1_executable.pine",
        ):
            with self.subTest(candidate=candidate):
                with self.assertRaises(ValueError):
                    recovery.safe_path(candidate)

    def test_safe_path_blocks_parent_escape(self):
        with self.assertRaises((ValueError, Exception)):
            recovery.safe_path("entry_path/../../README.md")

    def test_event_context_defaults_to_empty_json(self):
        with patch.object(recovery, "EVENT_FILE", Path("/definitely/missing/entry-path-event.json")):
            self.assertEqual(recovery.event_context(), "{}")


if __name__ == "__main__":
    unittest.main()
