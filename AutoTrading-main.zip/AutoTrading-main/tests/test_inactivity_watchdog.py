import unittest
from datetime import datetime, timedelta, timezone

from scripts.inactivity_watchdog import PriorityRun, classify_priority_state, parse_dt, state_event_type


UTC = timezone.utc
NOW = datetime(2026, 9, 1, 16, 50, tzinfo=UTC)


def run(status="in_progress", conclusion=None, age_minutes=5, run_id=123):
    created = NOW - timedelta(minutes=age_minutes)
    return PriorityRun(
        run_id=run_id,
        status=status,
        conclusion=conclusion,
        created_at=created,
        updated_at=created,
        head_sha="abc123",
        html_url="https://github.com/example/run/123",
    )


def classify(priority_run, report_exists=False, branch_age_minutes=5):
    return classify_priority_state(
        priority_run,
        report_exists=report_exists,
        branch_updated_at=NOW - timedelta(minutes=branch_age_minutes),
        now=NOW,
        idle_threshold=timedelta(minutes=15),
        queue_stall=timedelta(minutes=30),
        run_timeout=timedelta(minutes=360),
    )


class InactivityWatchdogTests(unittest.TestCase):
    def test_parse_dt_utc(self):
        value = parse_dt("2026-08-31T03:40:00Z")
        self.assertEqual(value, datetime(2026, 8, 31, 3, 40, tzinfo=UTC))

    def test_current_campaign_running_is_not_actionable(self):
        state = classify(run("in_progress", age_minutes=45))
        self.assertEqual(state.code, "RUNNING")
        self.assertFalse(state.actionable)

    def test_failed_campaign_is_immediately_actionable(self):
        state = classify(run("completed", "failure", age_minutes=1))
        self.assertEqual(state.code, "FAILED")
        self.assertTrue(state.actionable)
        self.assertEqual(state_event_type(state.code), "entry_path_failure")

    def test_success_requires_persisted_report(self):
        state = classify(run("completed", "success"), report_exists=False)
        self.assertEqual(state.code, "OUTPUT_MISSING")
        self.assertEqual(state_event_type(state.code), "entry_path_output_missing")

    def test_success_with_report_is_complete(self):
        state = classify(run("completed", "success"), report_exists=True)
        self.assertEqual(state.code, "COMPLETE")
        self.assertEqual(state_event_type(state.code), "entry_path_complete")

    def test_long_running_campaign_gets_timeout_guard_only_at_six_hours(self):
        state = classify(run("in_progress", age_minutes=361))
        self.assertEqual(state.code, "STALLED_RUN")
        self.assertEqual(state_event_type(state.code), "entry_path_stalled")

    def test_queue_stall_has_30_minute_guard(self):
        state = classify(run("queued", age_minutes=31))
        self.assertEqual(state.code, "STALLED_QUEUE")

    def test_no_run_waits_for_priority_branch_idle_threshold(self):
        self.assertEqual(classify(None, branch_age_minutes=5).code, "WAITING_FOR_RUN")
        self.assertEqual(classify(None, branch_age_minutes=16).code, "STALLED_NO_RUN")

    def test_existing_report_without_run_is_complete(self):
        state = classify(None, report_exists=True, branch_age_minutes=100)
        self.assertEqual(state.code, "COMPLETE")


if __name__ == "__main__":
    unittest.main()
