import json
import tempfile
import unittest
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path

from scripts import worklog


class WorklogTests(unittest.TestCase):
    def test_record_appends_json_and_rebuilds_status(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            output = StringIO()
            arguments = [
                "checkpoint",
                "--run-id",
                "test-run",
                "--step",
                "Étape test",
                "--payoff",
                "Un journal vérifiable",
                "--summary",
                "Le script a écrit un événement.",
                "--action",
                "Écriture JSONL",
                "--result",
                "Une ligne valide",
                "--file",
                "example.txt",
                "--test",
                "unittest: OK",
                "--next",
                "Lire le statut.",
            ]

            with redirect_stdout(output):
                code = worklog.main(arguments, root=root)

            self.assertEqual(code, 0)
            events = (root / "WORKLOG.jsonl").read_text(encoding="utf-8").splitlines()
            self.assertEqual(len(events), 1)
            event = json.loads(events[0])
            self.assertEqual(event["run_id"], "test-run")
            self.assertEqual(event["event"], "checkpoint")

            status = (root / "STATUS.md").read_text(encoding="utf-8")
            self.assertIn("Étape test", status)
            self.assertIn("Lire le statut.", status)
            self.assertIn("unittest: OK", status)
            self.assertIn("checkpoint=test-run", output.getvalue().replace("checkpoint=checkpoint run_id=", "checkpoint="))

    def test_dry_run_does_not_write_files(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            arguments = [
                "start",
                "--run-id",
                "dry-run",
                "--step",
                "Inspection",
                "--summary",
                "Aucun changement.",
                "--next",
                "Commencer.",
                "--dry-run",
            ]
            with redirect_stdout(StringIO()):
                code = worklog.main(arguments, root=root)

            self.assertEqual(code, 0)
            self.assertFalse((root / "WORKLOG.jsonl").exists())
            self.assertFalse((root / "STATUS.md").exists())

    def test_stage_path_cannot_escape_repository(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with self.assertRaises(ValueError):
                worklog.safe_repo_path(root, "../outside.txt")


if __name__ == "__main__":
    unittest.main()
