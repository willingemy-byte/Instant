from __future__ import annotations

import argparse
import importlib.util
import sys
import tempfile
import unittest
from datetime import date
from decimal import Decimal
from pathlib import Path


SCRIPT = Path(__file__).parents[1] / "scripts" / "fetch_gc_databento.py"
SPEC = importlib.util.spec_from_file_location("fetch_gc_databento", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class FakeStore:
    def to_csv(self, path, **kwargs):
        self.kwargs = kwargs
        Path(path).write_text(
            "ts_event,open,high,low,close,volume,instrument_id,symbol\n"
            "2026-08-01T00:00:00Z,3300,3301,3299,3300.5,12,1,GCZ6\n",
            encoding="utf-8",
        )


class FakeMetadata:
    def __init__(self, cost):
        self.cost = cost
        self.requests = []

    def get_cost(self, **request):
        self.requests.append(request)
        return self.cost


class FakeTimeseries:
    def __init__(self):
        self.requests = []

    def get_range(self, **request):
        self.requests.append(request)
        return FakeStore()


class FakeClient:
    def __init__(self, cost="1.25"):
        self.metadata = FakeMetadata(cost)
        self.timeseries = FakeTimeseries()


def args(**overrides):
    values = {
        "start": date(2026, 7, 1),
        "end": date(2026, 8, 30),
        "download": False,
        "max_cost_usd": None,
        "output": Path("unused.csv"),
        "overwrite": False,
    }
    values.update(overrides)
    return argparse.Namespace(**values)


class FetchGcDatabentoTests(unittest.TestCase):
    def test_default_range_is_exactly_sixty_days(self):
        value = MODULE.default_range(date(2026, 8, 30))
        self.assertEqual(value.days, 60)
        self.assertEqual(value.start.isoformat(), "2026-07-01")

    def test_estimate_mode_never_downloads(self):
        client = FakeClient()
        result = MODULE.execute(args(), client)
        self.assertEqual(result["estimated_cost_usd"], "1.25")
        self.assertFalse(result["downloaded"])
        self.assertEqual(client.timeseries.requests, [])
        self.assertEqual(client.metadata.requests[0]["symbols"], "GC.v.0")
        self.assertEqual(client.metadata.requests[0]["schema"], "ohlcv-1m")

    def test_download_requires_explicit_cost_cap(self):
        with self.assertRaisesRegex(MODULE.UserError, "requires --max-cost-usd"):
            MODULE.execute(args(download=True), FakeClient())

    def test_download_stops_when_estimate_exceeds_cap(self):
        client = FakeClient(cost="5.01")
        with self.assertRaisesRegex(MODULE.UserError, "exceeds"):
            MODULE.execute(
                args(download=True, max_cost_usd=Decimal("5.00")), client
            )
        self.assertEqual(client.timeseries.requests, [])

    def test_accepted_download_is_atomic_and_writes_metadata(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "gc.csv"
            client = FakeClient(cost="0.75")
            result = MODULE.execute(
                args(
                    download=True,
                    max_cost_usd=Decimal("1.00"),
                    output=output,
                ),
                client,
            )
            self.assertTrue(result["downloaded"])
            self.assertTrue(output.exists())
            self.assertTrue(MODULE.metadata_path(output).exists())
            self.assertFalse(output.with_suffix(".csv.part").exists())
            self.assertEqual(len(client.timeseries.requests), 1)


if __name__ == "__main__":
    unittest.main()
