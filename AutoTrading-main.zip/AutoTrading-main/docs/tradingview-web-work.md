# TradingView Web dans Work — chemin sans ordinateur

Date : 2026-08-30  
État : mis en pause — non requis pour le backtest actuel

## Décision

L'absence d'ordinateur empêche d'exécuter le serveur local TVControl/CDP, mais elle n'empêche pas un premier flux AutoTrading. Le navigateur cloud de Work ouvre directement TradingView Web et son Pine Editor.

Mise au point : ce chemin est conservé pour une validation Pine ultérieure. La target active est d'abord un backtest hors ligne sur données GC; aucune connexion TradingView n'est nécessaire pour cette étape.

Ce chemin est distinct de TVControl :

- aucun serveur Node local ni port 9222;
- aucune installation TradingView Desktop;
- contrôle par l'interface Web plutôt que par les 109 outils MCP de TVControl;
- session de connexion conservée tant que le navigateur Work la maintient, avec réauthentification possible si TradingView ou Google expire la session.

## Preuves obtenues

- `https://www.tradingview.com/chart/` s'ouvre dans le navigateur Work.
- Le graphique AAPL invité est rendu.
- Le bouton Pine ouvre le Pine Editor.
- Un script vierge Pine v6 est visible dans l'éditeur.
- TradingView propose Google, Facebook, Twitter, Yahoo, Apple, LinkedIn et Email pour la connexion.
- La tentative Google s'est arrêtée sur le message visible `Too many failed attempts`; aucune nouvelle tentative automatique n'a été faite.

## Garde-fous AutoTrading

1. Terminer la connexion TradingView dans le navigateur Work.
2. Vérifier un signal positif du compte connecté sur une nouvelle page TradingView.
3. Créer ou ouvrir uniquement `AutoTrading-Sandbox`.
4. Lire et sauvegarder la source existante dans GitHub avant toute modification.
5. Ne jamais remplacer un script de production sans copie et autorisation explicite.
6. Injecter le Pine dans le sandbox, relire le contenu, puis compiler.
7. Lire les erreurs et le Strategy Tester avant toute optimisation.
8. Commencer les variations de paramètres une à la fois; le sweep MCP parallèle n'existe pas dans ce chemin Web tant qu'il n'est pas réimplémenté et testé.

## Payoffs d'acceptation

- Compte TradingView connecté.
- Script `AutoTrading-Sandbox` séparé du script de production.
- Source sauvegardée dans le dépôt.
- Écriture et relecture identiques.
- Compilation réussie ou erreurs récupérées.
- Résultats Strategy Tester lisibles.

## Prochaine action exacte

Obtenir les chandelles GC 5 minutes sur environ 60 jours et terminer le backtest hors ligne avant de reprendre une connexion TradingView.
