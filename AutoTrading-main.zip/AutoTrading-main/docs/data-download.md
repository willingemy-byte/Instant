# Télécharger les données GC sans dépense implicite

> **Outil dormant : aucune action requise maintenant.** Le test initial de 60 jours utilise les données déjà accessibles. Ne pas créer de compte et ne pas acheter de données pour cette étape.

## Sécurité du processus

Le script commence toujours par une estimation. Il ne télécharge rien sans `--download`, et ce mode exige aussi un plafond `--max-cost-usd`. La clé Databento doit rester dans le secret d'environnement `DATABENTO_API_KEY`; elle ne doit jamais être collée dans un message ou commise dans GitHub.

## 1. Installer le client

```bash
python -m pip install -r requirements-data.txt
```

## 2. Estimer 60 jours

```bash
python scripts/fetch_gc_databento.py
```

Par défaut, la fin est la date UTC courante, exclusive, et le début est 60 jours plus tôt. Pour une expérience parfaitement reproductible, fixer les dates :

```bash
python scripts/fetch_gc_databento.py \
  --start 2026-07-01 \
  --end 2026-08-30
```

## 3. Télécharger seulement si le prix convient

Exemple avec un refus automatique au-dessus de 5 USD :

```bash
python scripts/fetch_gc_databento.py \
  --start 2026-07-01 \
  --end 2026-08-30 \
  --download \
  --max-cost-usd 5.00
```

La sortie brute va dans `data/raw/gc_1m.csv`. Un fichier voisin `gc_1m.csv.metadata.json` conserve la requête, l'estimation et l'heure du téléchargement. Les deux sont ignorés par Git pour éviter de republier des données sous licence.

## Requête fixe

- dataset : `GLBX.MDP3`;
- symbole : `GC.v.0`;
- symbologie : `continuous`;
- schéma : `ohlcv-1m`;
- timestamps : UTC.

L'agrégation en 5 minutes et la validation des trous feront l'objet de l'étape suivante.
