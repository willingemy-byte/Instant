# ENTRY-PATH V1 Orchestrator

Chain: watchdog -> repository_dispatch -> ENTRY-PATH V1 ORCHESTRATOR -> bounded recovery.

The orchestrator listens on the default branch for:
- `entry_path_failure`
- `entry_path_stalled`
- `entry_path_output_missing`
- `entry_path_complete`

Recovery rules:
- COMPLETE: record handoff only.
- STALLED: cancel/re-run the stale campaign when a run id exists; otherwise request a workflow dispatch on `research/entry-path-v1`.
- FAILURE / OUTPUT_MISSING: collect the watchdog payload and run logs, run targeted ENTRY-PATH tests, launch a bounded local Qwen recovery worker, re-run targeted tests, and merge only green technical fixes into `research/entry-path-v1`.
- If no code change is justified and tests are green, re-run the affected campaign run.
- If recovery is not green, do not merge.

Guardrails:
- never merge recovery changes into `main`;
- never touch UNIVERSAL RANGE;
- never load/use/analyze the blind holdout starting 2026-04-01;
- never add broker/live-order connectivity;
- never alter trading semantics merely to make tests pass;
- technical failures remain separate from trading inference.
