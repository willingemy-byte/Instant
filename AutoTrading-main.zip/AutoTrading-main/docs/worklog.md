# Journal de travail durable

## But

Le journal empêche qu'une longue session se termine sans point de reprise. Il conserve une trace factuelle et append-only de ce qui a été tenté, obtenu, modifié et vérifié.

Il enregistre :

- l'objectif et le payoff de l'étape;
- les actions importantes;
- les résultats et preuves observables;
- les décisions explicites;
- les fichiers touchés;
- les tests et leurs résultats;
- les erreurs ou blocages;
- la prochaine action exacte.

Il n'enregistre pas les tokens privés de raisonnement d'un modèle. Ceux-ci ne sont pas fournis au script. Le remplacement utile est un résumé opérationnel écrit avant et après chaque action matérielle.

## Fichiers

- `WORKLOG.jsonl` : historique append-only, une ligne JSON par événement.
- `STATUS.md` : dernier point de reprise, lisible sans outil spécial.
- `AGENTS.md` : règles obligatoires pour les prochaines sessions Codex.
- `scripts/worklog.py` : écrivain du journal, générateur de statut et créateur de checkpoint Git.

## Types d'événements

- `start` : objectif et payoff fixés avant le travail;
- `checkpoint` : progression durable;
- `decision` : choix et preuves ayant mené au choix;
- `test` : commande de validation et résultat;
- `block` : blocage, état conservé et intervention nécessaire;
- `finish` : payoff terminé et prochaine étape identifiée.

## Commande minimale

```bash
python scripts/worklog.py start \
  --run-id nom-du-run \
  --step "Étape active" \
  --payoff "Résultat vérifiable" \
  --summary "Point de départ connu" \
  --next "Première action exacte"
```

Pour sauvegarder immédiatement sur GitHub, ajouter `--commit --push`. Les chemins fournis avec `--file` sont inclus dans le commit avec `WORKLOG.jsonl` et `STATUS.md`.

## Reprise après une coupure

```bash
git pull --ff-only
git log -1 --oneline
tail -n 20 WORKLOG.jsonl
```

Lire ensuite `STATUS.md` et exécuter seulement sa section « Prochaine action exacte ».

## Limite importante

Un script hébergé dans GitHub ne peut pas intercepter l'interface ChatGPT Work ni son raisonnement privé. Pour qu'un événement soit durable, l'agent doit exécuter le script ou écrire le checkpoint au dépôt. C'est pourquoi `AGENTS.md` impose un checkpoint fréquent, avant les opérations longues et après chaque résultat matériel.
