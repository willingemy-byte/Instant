# M1 — EB3 persistant

Cette variante part de M0 sans filtre horaire et modifie la logique de setup selon les règles utilisateur du 2026-08-30.

## Données et indicateurs conservés
- Instrument de test actuel: GLD via Yahoo Finance.
- Intervalle: 5 minutes.
- Fenêtre: 59 derniers jours disponibles au moment du run.
- RSI: 21.
- SMA du RSI: 50.
- SMA du prix: 50.
- R:R: 1:3.
- Une seule position à la fois.
- Pas de filtre horaire dans cette variante.

## Engulfing block EB3
Un EB3 est une bougie dont le CORPS englobe entièrement les CORPS des trois bougies immédiatement précédentes.

### Bullish EB3
- Bougie actuelle haussière: Close > Open.
- Bas du corps actuel <= plus bas des corps des 3 bougies précédentes.
- Haut du corps actuel >= plus haut des corps des 3 bougies précédentes.

### Bearish EB3
- Bougie actuelle baissière: Close < Open.
- Bas du corps actuel <= plus bas des corps des 3 bougies précédentes.
- Haut du corps actuel >= plus haut des corps des 3 bougies précédentes.

Les mèches ne servent pas à déterminer l'englobante.

## Persistance et validité du bloc
- Aucun timeout n'est appliqué.
- Un bullish EB3 reste armé aussi longtemps que les clôtures suivantes restent au-dessus du haut du corps de ce bloc.
- Si une clôture revient dans ou sous le corps bullish, le setup long est invalidé.
- Un bearish EB3 reste armé aussi longtemps que les clôtures suivantes restent sous le bas du corps de ce bloc.
- Si une clôture revient dans ou au-dessus du corps bearish, le setup short est invalidé.
- Le bloc correspondant est consommé lorsqu'une entrée est envoyée.

## Confirmation d'entrée
### Long
Entrer lorsqu'un bullish EB3 valide est armé ET qu'une bougie clôture avec:
- Close > SMA50 du prix;
- RSI21 > SMA50 du RSI.

### Short
Entrer lorsqu'un bearish EB3 valide est armé ET qu'une bougie clôture avec:
- Close < SMA50 du prix;
- RSI21 < SMA50 du RSI.

Le signal peut se produire sur la bougie EB3 elle-même ou n'importe combien de bougies plus tard, tant que le bloc demeure valide.

## Stop et take profit
### Long
- Stop basé sur le Low, mèche incluse, de la bougie immédiatement précédente à la bougie de signal d'entrée.
- Le fallback Manus V1 est conservé: si ce stop est à moins de 0,1% du prix de référence, utiliser 1% sous ce prix.
- TP = 3 x le risque au-dessus du prix de référence.

### Short
- Stop basé sur le High, mèche incluse, de la bougie immédiatement précédente à la bougie de signal d'entrée.
- Le fallback Manus V1 est conservé: si ce stop est à moins de 0,1% du prix de référence, utiliser 1% au-dessus de ce prix.
- TP = 3 x le risque sous le prix de référence.

## Ce qui n'est PAS encore changé
- La source GLD/Yahoo n'est pas encore remplacée par GC futures.
- La fenêtre de données n'est pas encore figée dans un CSV commun.
- Le sizing n'est pas encore converti en risque fixe de 1% par trade.
- Le comportement d'exécution de Backtesting.py n'est pas encore changé en `trade_on_close=True`.
