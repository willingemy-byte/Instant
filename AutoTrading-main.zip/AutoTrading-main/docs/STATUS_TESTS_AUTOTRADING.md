# AutoTrading — État des tests

**Snapshot : 31 août 2026, fin d’après-midi (ET)**  
**Dépôt :** `willingemy-byte/AutoTrading`  
**But de ce document :** distinguer ce qui est réellement validé/exécuté de ce qui est seulement construit ou encore bloqué.

## Résumé exécutif

Le projet a beaucoup avancé aujourd’hui. Le LAB modulaire est construit et plusieurs couches ont passé leurs CI. La campagne universelle RANGE a aussi réellement commencé à calculer.

**État actuel de la campagne universelle :**

- Campagne prévue : **15 variantes de stratégie × 3 fenêtres (3m/6m/1y) × 3 vues RANGE (1m/3m/5m) × 3 875 configurations**.
- Total théorique du screening : **523 125 cellules RANGE**.
- Premier lancement complet : GitHub Actions run **#33415715238**.
- **24 shards sur 45 ont terminé avec succès et ont produit leurs artifacts.**
- Chaque shard validé contient **11 625 cellules** (3 vues × 3 875 configs).
- Donc **279 000 cellules RANGE ont réellement été calculées et sauvegardées**, soit **53,3 %** du screening universel prévu.
- Le run complet s’est terminé en **failure**, donc l’agrégation globale, la re-simulation exacte massive et le leaderboard final n’ont pas encore été exécutés.

### Stratégies dont les 3 fenêtres ont produit leurs shards

- `m10_fixed` — 3m / 6m / 1y ✅
- `m10_trailing` — 3m / 6m / 1y ✅
- `m13` — 3m / 6m / 1y ✅
- `m14` — 3m / 6m / 1y ✅
- `m15` — 3m / 6m / 1y ✅
- `m16` — 3m / 6m / 1y ✅
- `m17` — 3m / 6m / 1y ✅
- `m32` — 3m / 6m / 1y ✅

Ces 24 artifacts existent réellement dans GitHub Actions et sont conservés 30 jours à partir du 31 août 2026.

### Blocage actuel

Les familles `m24` à `m30` n’ont pas produit leurs shards dans ce premier lancement.

L’erreur ouverte dans le job `m24 / 3m` est technique :

```text
AttributeError: 'tuple' object has no attribute 'copy'
```

Elle apparaît dans `scripts/run_universal_range_screen.py` pendant l’adaptation de la sortie historique de M24. Ce n’est donc **pas un résultat négatif de trading** : le moteur universel attend un objet de type DataFrame alors que certains moteurs historiques M24–M30 retournent une structure différente.

**Prochaine priorité technique :** normaliser les sorties des adaptateurs M24–M30, relancer les 21 shards manquants, puis laisser l’étape d’agrégation démarrer.

---

## Baseline M17 — validation exacte réussie

Le guard historique du LAB a passé son workflow `LAB-M17-BASELINE` avec succès.

Fenêtre testée : **1 an**, du 23 mars 2025 au 23 mars 2026.  
Risque : **300 $ par R**.

Résultat réellement reproduit par le LAB :

| Métrique | Résultat |
|---|---:|
| Trades | 657 |
| Gagnants | 138 |
| Perdants | 385 |
| Breakeven | 134 |
| Win rate tous trades | 21,00 % |
| Win rate hors breakeven | **26,386 %** |
| Sum R | **142,183 R** |
| Avg R | **0,2164 R** |
| Profit fixe à 300 $/R | **42 654,78 $** |
| Drawdown closed-equity max | **-6 450,87 $** |
| Topstep MLL | **Survécu ✅** |
| Headroom MLL minimum | **2 319,08 $** |

C’est maintenant la **référence de fidélité** : si une modification du LAB change le nombre de trades, l’expectancy ou la survie MLL hors tolérance, le guard doit échouer avant une campagne de recherche.

Run : https://github.com/willingemy-byte/AutoTrading/actions/runs/33354474797

---

## LAB V1 — infrastructure validée

Les éléments suivants ont été construits et ont passé leurs validations ciblées :

### CORE / recettes

- Schéma déterministe avec hash, seed et provenance.
- Registres séparés SIGNAL / STOP / TP-MANAGEMENT / TIME-EVENTS / DATA_VIEW.
- Génération de **1 500 recettes uniques déterministes**.

### DataProvider

- Vues temporelles **1m / 3m / 5m**.
- Contrat pour barres basées sur un nombre fixe de trades.
- Capability gate : refuse proprement une vue tick si aucune source tick qualifiée n’est disponible.

### Batch / Resume

- Checkpoint après chaque recette.
- Reprise après interruption sans recalculer les succès déjà enregistrés.
- Erreurs techniques marquées retryables.

### Ranking

- Métriques RAW séparées des métriques ACCOUNT / MLL.
- Fenêtres officielles **3m / 6m / 1y**.
- Stress 3,22 ans conservé séparément.
- Classement **survie MLL avant profit**.

### RANGE-GATE

- Devenu un plugin SIGNAL orthogonal plutôt qu’une stratégie parallèle.
- Première étape : 5 signaux de base + 225 variantes gated = 230 options.
- Après intégration M24/M25 : 7 bases + 315 variantes RANGE = 322 options.
- Les smoke tests de **1 500 recettes / 1 500 hashes uniques** ont continué de passer après les extensions.

### NEWS-BLACKOUT

- Plugin TIME/EVENT séparé.
- V1 : nouvelles entrées bloquées autour des événements, fenêtre T-10 / T+15.
- Calendrier historique vérifié requis.
- Registre TIME : **4 règles de base + 4 variantes NEWS = 8 options**.
- Dernier checkpoint de wiring : **32 tests PASS** + smoke 1 500/1 500 PASS.

### Provenance M-series

La récupération atomique des règles historiques a progressé au moins jusqu’à M27 :

- M24/M25 : filtres de tendance récupérés et testés.
- M26 : stack SMA 5/8/13/20/200 récupéré puis câblé.
- M27 : signal direct MA-stack récupéré, câblage registre effectué, stop historique opposé au wick récupéré séparément.

Une partie de cette chaîne est encore dans des PR empilées et n’est pas entièrement fusionnée sur `main`.

---

## Couche de risque — construite et tests unitaires verts

PR #109 / #110 ajoutent cinq politiques de risque post-ledger :

1. Fixe **300 $/R**.
2. M19 : **20 % du headroom**.
3. M20 : **20 % capé à 900 $**.
4. M23 historique : **20 → 15 → 10 → 5 %**.
5. Nouvelle politique : **20 → 15 → 10 % → 100 $ jusqu’au reset complet du headroom**.

Le workflow `LAB-UNIVERSAL-EXACT-UNIT` a terminé en **SUCCESS** : tests Account/RANGE et compilation des scripts de campagne réussis.

Important : cela valide la couche logicielle, **pas encore le classement massif des cinq politiques sur tous les candidats RANGE**, puisque le full run a été bloqué avant l’agrégation.

---

## Campagne UNIVERSAL RANGE — pipeline actuel

Le workflow complet est conçu pour :

1. exécuter 45 shards de screening ;
2. vérifier **11 625 cellules** par shard ;
3. agréger **523 125 cellules** ;
4. sélectionner les candidats stables ;
5. refaire une **re-simulation exacte sur 12 moteurs compatibles** ;
6. appliquer les **5 politiques de risque** ;
7. classer les survivants ;
8. produire un dashboard et un leaderboard consolidés.

### État de chaque étape

| Étape | État |
|---|---|
| Pipeline et workflows | ✅ Construits |
| Tests unitaires exact/RISK | ✅ PASS |
| Screening universel | 🟡 24/45 shards, 279 000/523 125 cellules |
| Adaptateurs M24–M30 | 🔴 Bug de compatibilité à corriger |
| Agrégation 523 125 | ⏸️ Non démarrée, dépend des 45 shards |
| Exact re-simulation massive | ⏸️ Non démarrée |
| 5 politiques RISK sur candidats | ⏸️ Non démarrée |
| Leaderboard final | ⏸️ Non généré |
| Dashboard universel final | ⏸️ Données finales non générées |

Workflow complet : https://github.com/willingemy-byte/AutoTrading/actions/runs/33415715238

PR d’intégration : https://github.com/willingemy-byte/AutoTrading/pull/110

---

## Dashboard

Le dashboard mobile-first a été construit dans la PR #107 et cette PR est **fusionnée**.

Fonctions prévues :

- tri et filtres ;
- partitions `strategy × data-view × window` chargées à la demande ;
- leaderboard global ;
- ingestion CSV incrémentale ;
- publication par GitHub Actions.

Le dashboard universel consolidé ne peut toutefois pas afficher le classement final tant que l’agrégation et les re-simulations exactes du full run ne sont pas terminées.

PR #107 : https://github.com/willingemy-byte/AutoTrading/pull/107

---

## Données tick / FOX-TICK

Une vraie source trade-level GC 2026 a passé la validation machine :

- fichier : `GC_TRADES_2026.parquet` ;
- **14 622 660 trades** ;
- période : 1er janvier 2026 au 30 juillet 2026 ;
- timestamps UTC ;
- 0 timestamp nul ;
- 0 transition temporelle vers l’arrière ;
- ~1,98 M timestamps dupliqués, compatibles avec plusieurs trades au même timestamp ;
- prix et tailles présents ;
- validation machine : **PASS**.

Mais la **provenance/licence d’utilisation reste à qualifier** avant de considérer cette source comme donnée officielle de production/recherche durable.

La campagne universelle actuelle n’a donc utilisé que les vues temporelles RANGE **1m/3m/5m**. Les **39 vues trade-count (50 à 1 000 trades par pas de 25)** sont spécifiées dans le manifest, mais restent en attente de qualification finale de la source tick.

---

## Situation Git / orchestration

Point important : une grande partie du LAB récent vit dans une **chaîne de PR empilées** (`#79` jusqu’à `#110`) plutôt que sur `main`.

- `main` contient les recherches historiques fusionnées et certains composants, mais pas toute la pointe du LAB universel.
- La PR #110 est actuellement la branche d’intégration la plus avancée : `lab/universal-execution-v1`.
- Il ne faut pas confondre « code présent dans une PR avec CI verte » et « code fusionné sur main ».

Le watchdog d’inactivité existe dans la PR #84, mais il ne devient réellement autonome sur horaire qu’une fois fusionné sur la branche par défaut.

---

## Prochaine séquence recommandée

1. **Corriger l’interface d’adaptation M24–M30** (`tuple` → structure normalisée attendue par le screener).
2. Ajouter un test de contrat commun pour empêcher qu’un moteur historique retourne silencieusement un type incompatible.
3. **Relancer seulement les 21 shards manquants** si possible, plutôt que gaspiller les 279 000 cellules déjà calculées.
4. Agréger les 45 shards en **523 125 cellules**.
5. Lancer la sélection de stabilité puis les **12 re-simulations exactes**.
6. Appliquer les **5 politiques de risque** uniquement aux résultats exacts.
7. Produire le leaderboard survival-first et le dashboard final.
8. En parallèle, terminer la qualification provenance/licence de la source GC trade-level avant d’ouvrir la campagne des 39 trade-count views.

## Liens principaux

- Dépôt : https://github.com/willingemy-byte/AutoTrading
- Issue orchestration LAB : https://github.com/willingemy-byte/AutoTrading/issues/74
- PR intégration universelle : https://github.com/willingemy-byte/AutoTrading/pull/110
- Full RANGE run : https://github.com/willingemy-byte/AutoTrading/actions/runs/33415715238
- M17 baseline guard : https://github.com/willingemy-byte/AutoTrading/actions/runs/33354474797
- Dashboard PR : https://github.com/willingemy-byte/AutoTrading/pull/107

---

**Lecture du statut :** ✅ validé / 🟡 partiel / 🔴 blocage technique / ⏸️ dépendance non encore satisfaite.
