# Décision de source — GC 5 minutes

Date : 2026-08-30

> **Statut actuel : reporté.** Cette comparaison ne fait plus partie du chemin actif. Le peaufinage initial utilisera environ 60 jours de données déjà accessibles, sans achat ni création de compte fournisseur. Databento reste seulement une option future de validation indépendante.

## Besoin

- instrument : futures Gold `GC` de COMEX/CME;
- période : environ 60 jours;
- granularité finale : 5 minutes;
- usage : recherche et backtest hors ligne, sans exécution d'ordres.

## Sources vérifiées

### Databento — source proposée

- Dataset officiel utilisé pour CME Globex : `GLBX.MDP3`.
- Symbole continu avant basé sur le volume : `GC.v.0`, avec `stype_in="continuous"`.
- Schéma disponible : `ohlcv-1m`; Databento documente aussi sa conversion en barres de 5 minutes.
- Les prix continus ne sont pas rétroajustés. Un changement de contrat peut donc créer un saut réel dans la série et devra être identifié dans les résultats.
- `metadata.get_cost` permet de connaître le prix exact avant le téléchargement.
- Un nouveau compte reçoit actuellement 125 USD de crédits historiques, valides six mois.

Conclusion : c'est la meilleure combinaison de provenance, continuité de contrat, granularité et contrôle du coût. La sélection demeure **provisoire** jusqu'au test réel de l'API.

### CME DataMine — référence officielle / solution de secours

- Source directe de CME, donc excellente provenance.
- Le nom de l'ancien échantillon `xcec-tick-gc-fut-...` correspond à la convention COMEX (`XCEC`) de DataMine.
- L'achat, les licences et la transformation des ticks rendent toutefois le premier test plus lourd qu'une requête OHLCV Databento.

Conclusion : conserver comme source de référence ou de validation si Databento ne passe pas le test.

### Polygon — non retenu pour l'instant

La documentation publique trouvée ne démontre pas encore qu'un forfait gratuit donne précisément 60 jours de barres intrajournalières GC. Il ne faut pas confondre les avantages du forfait gratuit **actions** avec les droits sur les **futures**.

### Yahoo/yfinance — écarté pour ce test

Un incident actuel documente que `GC=F` peut retourner une série intrajournalière vide. Cette piste n'offre donc pas la fiabilité requise pour établir la rentabilité de la stratégie.

### FirstRateData — solution commerciale de secours

Le jeu GC 5 minutes/continu peut convenir, mais il est moins directement vérifiable et automatisable ici que l'API proposée.

## Requête cible

```python
client.metadata.get_cost(
    dataset="GLBX.MDP3",
    symbols="GC.v.0",
    stype_in="continuous",
    schema="ohlcv-1m",
    start=START_UTC,
    end=END_UTC,
)
```

Après confirmation du coût, les données seront téléchargées puis agrégées en 5 minutes avec des fenêtres alignées en UTC. Le fichier normalisé conservera aussi l'identifiant du contrat sous-jacent afin de rendre les rollovers auditables.

## Critères d'acceptation de l'étape 2

1. coût affiché avant toute dépense;
2. au moins un petit échantillon réel reçu;
3. ordre chronologique strict, aucun doublon de timestamp;
4. OHLC cohérent et volume non négatif;
5. trous et changement de contrat rapportés, pas masqués;
6. sortie CSV 5 minutes reproductible.

## Sources primaires

- <https://databento.com/docs/examples/symbology/continuous>
- <https://databento.com/docs/schemas-and-data-formats/ohlcv>
- <https://databento.com/docs/examples/basics-historical/ohlcv-resampling>
- <https://databento.com/docs/api-reference-historical/metadata/metadata-get-cost>
- <https://databento.com/pricing>
- <https://www.cmegroup.com/datamine.html>
- <https://www.cmegroup.com/datamine/datamine-list-api.html>
- <https://github.com/ranaroussi/yfinance/discussions/2762>
