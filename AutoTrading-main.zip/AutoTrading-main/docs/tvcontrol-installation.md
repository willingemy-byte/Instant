# TVControl — Protocole d'installation et d'acceptation

Date : 2026-08-30  
Candidat retenu : [`FerroxLabs/tvcontrol`](https://github.com/FerroxLabs/tvcontrol)  
Révision auditée : `0ee585f034e75f945924fff67e6310346b976539`

## But

Relier un agent MCP à TradingView Desktop pour éditer et tester le Pine Script AutoTrading, sans exposer le port de débogage et sans risquer d'écraser un script existant.

## Conditions obligatoires

- Un ordinateur Windows, macOS ou Linux; un téléphone seul ne suffit pas.
- TradingView Desktop installé et connecté au bon compte.
- Node.js 18 ou plus récent et Git.
- Aucun travail Pine non sauvegardé avant le premier lancement CDP.
- Port 9222 accessible uniquement depuis la boucle locale.

Arrêter immédiatement si le port écoute sur `0.0.0.0`, `::`, une adresse LAN ou une adresse publique.

## Phase 1 — Installer une révision reproductible

```bash
git clone https://github.com/FerroxLabs/tvcontrol.git
cd tvcontrol
git checkout --detach 0ee585f034e75f945924fff67e6310346b976539
npm ci
npm test
```

Résultat attendu : installation déterministe à la révision auditée. Sur Windows, cette révision a trois échecs de tests connus liés à CRLF, `npm`/`npm.cmd` et aux séparateurs de chemins. Ils doivent correspondre exactement au diagnostic dans `docs/tradingview-control-audit.md`; tout autre échec est un arrêt.

Ne pas utiliser `tv_update` et ne pas revenir sur `main` pendant l'acceptation. Une mise à jour future exige un nouvel audit.

## Phase 2 — Configurer MCP en lecture seule

Configurer le client MCP avec le chemin absolu réel :

```json
{
  "mcpServers": {
    "tvcontrol": {
      "command": "node",
      "args": ["/chemin/absolu/tvcontrol/src/server.js"],
      "env": {
        "TV_MCP_READONLY": "1",
        "TV_CDP_HOST": "127.0.0.1",
        "TV_CDP_PORT": "9222"
      }
    }
  }
}
```

Redémarrer le client MCP après la modification. Dans ce mode, les mutations Pine, alertes, dessins, restaurations, sweeps, `pine_check` et `tv_launch` ne doivent pas être enregistrés.

## Phase 3 — Lancer TradingView sans état non sauvegardé

1. Sauvegarder tout script, layout et dialogue ouvert.
2. Fermer TradingView normalement.
3. Démarrer TradingView avec CDP sur le port 9222.

`tv_launch` ne tue pas une instance par défaut et retourne immédiatement si un endpoint CDP sain existe déjà. Sur Windows Store/MSIX, son fallback peut toutefois copier le paquet sous `%LOCALAPPDATA%\\tvcontrol\\desktop-cache` et fermer l'instance qui n'a pas réussi à ouvrir CDP.

Les scripts `launch_tv_debug.*` ferment les instances de force; ne pas les utiliser tant qu'un état non sauvegardé est possible.

## Phase 4 — Prouver que le port est local

### Windows PowerShell

```powershell
Get-NetTCPConnection -LocalPort 9222 -State Listen |
  Select-Object LocalAddress, LocalPort, OwningProcess
```

### macOS

```bash
lsof -nP -iTCP:9222 -sTCP:LISTEN
```

### Linux

```bash
ss -ltnp 'sport = :9222'
```

Résultat accepté : `127.0.0.1` ou `::1` seulement. Fermer TradingView et corriger le lancement avant de continuer si une autre adresse apparaît.

## Phase 5 — Test de lecture seule

1. Appeler `tv_health_check`.
2. Appeler `chart_get_state` et vérifier qu'il décrit le graphique visible.
3. Appeler `pine_get_source` seulement si le contenu du script ouvert peut être lu par l'agent.
4. Confirmer que `pine_set_source`, `pine_save`, `pine_compile`, `strategy_sweep` et `tv_launch` sont absents.

Payoff : l'agent voit la bonne session TradingView sans pouvoir la modifier.

## Phase 6 — Test Pine contrôlé

Cette phase exige de redémarrer le serveur MCP sans `TV_MCP_READONLY=1`.

1. Dans TradingView, créer manuellement un nouveau script stratégie nommé `AutoTrading-Sandbox`; `pine_new` ne crée pas un nouveau script sauvegardé.
2. Ouvrir ce script avec `pine_open`.
3. Lire la source avec `pine_get_source` et en conserver une copie dans le dépôt avant toute mutation.
4. Exécuter `pine_analyze` sur la nouvelle source. Utiliser `pine_check` seulement si l'envoi de cette source au service de compilation TradingView en mode Guest est accepté.
5. Appeler `pine_set_source`; `confirm_overwrite:true` n'est permis qu'après la copie et uniquement dans `AutoTrading-Sandbox`.
6. Relire la source et confirmer le nombre de caractères et de lignes.
7. Appeler `pine_compile`, en sachant que cette commande sauvegarde d'abord le script lié.
8. Lire `pine_get_errors`, `pine_get_console` et les résultats du Strategy Tester.

Payoff : un cycle écriture → relecture → compilation → erreurs → résultats, sans toucher au script de production.

## Phase 7 — Premier sweep

- Utiliser le sandbox.
- Commencer avec 2 à 4 combinaisons.
- Fixer `parallelism: 1`, `restore_start_state: true` et `use_cache: false`.
- Capturer l'état avant et après; vérifier symbole, intervalle, inputs et onglets.
- Ne tester le parallélisme qu'après réussite du sweep séquentiel.

Le pool parallèle complet n'est pas couvert par les tests hors ligne amont; il doit donc être accepté séparément sur la session réelle.

## Critères de réussite

- Révision amont exacte et enregistrée.
- Port 9222 limité à loopback.
- `tv_health_check` réussi.
- Catalogue lecture seule sans outils de mutation.
- Script sandbox sauvegardé séparément du script de production.
- Source injectée relue à l'identique.
- Compilation et erreurs lisibles.
- Strategy Tester lisible.
- État du graphique restauré après sweep.

## Retour arrière

Arrêter le serveur MCP, fermer TradingView, puis le relancer normalement sans port de débogage. Ne supprimer le clone ou le cache MSIX qu'après avoir confirmé qu'aucun processus ne les utilise.

## Prochaine action exacte

Identifier le système de l'ordinateur hôte, puis exécuter les phases 1 à 5. Ne déverrouiller les mutations qu'après validation du test en lecture seule.
