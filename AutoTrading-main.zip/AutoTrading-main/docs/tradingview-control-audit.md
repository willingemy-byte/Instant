# Audit des solutions de contrôle TradingView

Date : 2026-08-30  
État : terminé — candidat retenu, installation réelle en attente

## Question

Quel projet peut permettre à Codex de modifier, compiler, corriger, sauvegarder et tester le Pine Script AutoTrading dans TradingView, avec le moins d'interventions manuelles possible?

## Critères d'acceptation

1. Contrôle réel du Pine Editor.
2. Injection du code et compilation.
3. Lecture structurée des erreurs.
4. Sauvegarde sans écrasement silencieux.
5. Lecture du Strategy Tester ou balayage de paramètres.
6. Installation réalisable et point de connexion clair.
7. Tests, garde-fous et licence identifiables.

## Inventaire vérifié

| Dépôt | Fonction réelle | État vérifié | Décision actuelle |
|---|---|---|---|
| [`FerroxLabs/tvcontrol`](https://github.com/FerroxLabs/tvcontrol) | Contrôle complet de TradingView Desktop par MCP/CDP, outils Pine, vision, replay, snapshots et sweeps | Actif; dernier push 2026-08-27; 37 étoiles; 14 forks; version `package.json` 2.4.1 | Candidat principal provisoire |
| [`tradesdontlie/tradingview-mcp`](https://github.com/tradesdontlie/tradingview-mcp) | Projet d'origine du pont MCP/CDP, contrôle du Pine Editor et du graphique | 5 916 étoiles; 2 588 forks; dernier push 2026-07-28 | Référence de base |
| [`srinivasbe-07/tv-mcp`](https://github.com/srinivasbe-07/tv-mcp) | Contrôle CDP personnalisé avec Pine, alertes, moniteurs et interface locale | Version 0.1.0; système fortement spécialisé; aucun README racine | À conserver seulement comme comparaison ciblée |
| [`smitkunpara/tv-mcp`](https://github.com/smitkunpara/tv-mcp) | Collecte de données, indicateurs et nouvelles par FastMCP | Python, MIT; aucun contrôle du Pine Editor | Exclu |
| [`xabbai/tv-mcp`](https://github.com/xabbai/tv-mcp) | Screener utilisant des champs TradingView | Un seul usage de filtrage | Exclu |
| [`JayNorthDev/tv-mcp`](https://github.com/JayNorthDev/tv-mcp) | Fork de `tradesdontlie/tradingview-mcp` | Aucun avantage distinct établi | Exclu au profit de la source |

Les étoiles servent seulement à mesurer l'adoption visible; elles ne prouvent ni la sécurité ni la fiabilité.

## Architecture confirmée

```text
Agent compatible MCP
    ↕ stdio
Serveur TradingView local
    ↕ Chrome DevTools Protocol, localhost:9222
TradingView Desktop
```

Exigences communes aux deux candidats principaux :

- TradingView Desktop installé et lancé avec `--remote-debugging-port=9222`;
- Node.js 18 ou plus récent;
- serveur MCP installé sur le même ordinateur ou capable de joindre ce port local;
- abonnement TradingView valide selon les fonctions et données utilisées;
- acceptation du risque que les interfaces internes non documentées changent après une mise à jour TradingView.

## Incohérences trouvées

### `FerroxLabs/tvcontrol`

- README : 109 outils MCP.
- Description de `package.json` : 105 outils MCP.
- Description de l'API GitHub : 88 outils MCP.
- `src/server.js` calcule maintenant le catalogue et le nombre réellement enregistré au démarrage.
- Mesure directe des appels `server.tool(...)` : 110 outils définis, 109 enregistrés par défaut et un seul outil avancé (`ui_evaluate`) caché par défaut.

Conclusion : le README à 109 correspond au catalogue normal actuel. Les descriptions à 105 et 88 sont périmées. Le test `tools/list` après installation devra tout de même confirmer 109 dans l'environnement installé.

### `tradesdontlie/tradingview-mcp`

- README : 78 outils MCP.
- Instructions intégrées à `src/server.js` : 84 outils.
- `package.json` : version 1.0.0.
- `src/server.js` : version annoncée 2.0.0.

Conclusion : la source originale fonctionne comme référence architecturale, mais sa documentation et ses constantes ont dérivé.

## Capacités déjà confirmées dans les sources

Les deux candidats principaux déclarent et enregistrent des fonctions pour :

- injecter le code Pine;
- compiler le code;
- récupérer les erreurs et la console;
- sauvegarder et rouvrir les scripts;
- lire l'état du graphique et le Strategy Tester;
- capturer une image du graphique ou du Strategy Tester;
- lancer TradingView Desktop avec CDP sur Windows, macOS et Linux.

TVControl ajoute notamment :

- snapshots et restauration d'état;
- `strategy_sweep` avec cache et combinaisons de paramètres;
- `chart_vision_read`;
- mode lecture seule qui retire les outils de mutation du catalogue;
- tests hors ligne et scripts de vérification plus étendus;
- garde annoncée contre l'écrasement d'un buffer Pine non vide.

## Audit des garde-fous Pine

Le code actuel confirme :

- `pine_set_source` exige `confirm_overwrite:true` lorsqu'un buffer contient du vrai code;
- `pine_new` ne prétend plus créer un nouveau script : il annonce qu'il remplace le buffer par un modèle;
- si le buffer ne peut pas être lu, l'opération est refusée;
- après `setValue`, le buffer est relu et comparé à la source demandée;
- `pine_save` déduit son succès de l'état Save/Saved relu dans l'éditeur et lance une erreur si l'état demeure non sauvegardé;
- `pine_compile` et `pine_smart_compile` sauvegardent dans le nuage avant la compilation; ce comportement est annoncé dans la description de l'outil;
- des tests distincts couvrent l'écrasement, la sauvegarde, la recherche du bon éditeur Monaco, le comptage des outils et le mode lecture seule.

Le mode `TV_MCP_READONLY=1` fonctionne par liste blanche : les mutations Pine, alertes, dessins, restauration d'état et actions UI ne sont pas enregistrées dans MCP. Un nouvel outil futur est donc refusé par défaut jusqu'à classification explicite.

## État de la CI amont

Dernier commit audité : `0ee585f034e75f945924fff67e6310346b976539`, daté du 2026-08-27.

| Plateforme | Node | Résultat |
|---|---:|---|
| Ubuntu | 18 | Succès complet |
| Ubuntu | 22 | Succès complet |
| macOS | 18 | Succès complet |
| macOS | 22 | Succès complet |
| Windows | 18 | Échec pendant les tests hors ligne |
| Windows | 22 | Échec pendant les tests hors ligne |

Sur les quatre jobs réussis, l'installation, le lint, les tests hors ligne, l'audit des dépendances et le paquetage à blanc passent.

Les deux jobs Windows exécutent 772 tests : 769 passent et les mêmes trois échouent sous Node 18 et Node 22.

| Test en échec | Cause observée | Portée de la preuve |
|---|---|---|
| Shebang du binaire | Le checkout CRLF laisse un `\r` dans la première ligne comparée strictement | Test non portable; ne démontre pas une panne du shim `.cmd` Windows |
| Handshake du paquet installé | `spawnSync("npm")` retourne `ENOENT`; Windows attend normalement `npm.cmd` | Harnais non portable; le handshake réel reste à exécuter |
| Garde hermétique CDP | Les chemins `src\\connection.js` ne correspondent pas à la normalisation `/` du test | Faux positifs de classification sur Windows; pas une connexion réseau réellement effectuée |

Conclusion : la CI rouge provient de trois hypothèses Unix dans les tests. Ce n'est pas une preuve que TVControl ne fonctionne pas sous Windows, mais l'absence d'un job vert interdit encore de le déclarer validé sur cette plateforme.

## Contrat de `strategy_sweep`

| Élément | Comportement vérifié |
|---|---|
| Taille | 100 combinaisons par défaut; plafond absolu de 500 |
| Temps | Timeout par combinaison de 30 s par défaut; cooldown normal de 1 500 ms et raccourci à 200 ms si symbole et intervalle ne changent pas |
| Reprise | Écriture partielle toutes les 10 combinaisons; reprise à partir d'un `run_id` dont le format est validé contre la traversée de chemins |
| Cache | Local dans `~/.tv-mcp/sweep-cache`; durée 24 h par défaut; maximum de 5 000 fichiers; clé incluant stratégie, symbole, intervalle et inputs |
| Restauration | Snapshot avant le sweep, restauration dans un `finally` même après `on_error=abort`, puis suppression du snapshot temporaire |
| Parallélisme | 1 à 6 onglets travailleurs selon le schéma de l'outil |

Les tests hors ligne couvrent la limite, les checkpoints, la reprise, le cache, la restauration après exception, le nettoyage et le timeout. Ils déclarent aussi que le pool parallèle complet nécessite une vraie session CDP; ce chemin n'est donc pas validé de bout en bout par la suite hors ligne.

## Surface de sécurité CDP

- Hôte par défaut : `127.0.0.1`.
- Port par défaut : `9222`.
- L'hôte et le port peuvent être remplacés par `TV_CDP_HOST`/`TV_CDP_PORT` ou `CDP_HOST`/`CDP_PORT`.
- La politique de sécurité amont demande explicitement de garder le port 9222 sur localhost et de ne jamais l'exposer au réseau ou à Internet.
- Le port donne accès à une application TradingView déjà authentifiée; il faut donc le traiter comme une interface de contrôle sensible.

Il reste à vérifier le code du lanceur afin de confirmer ses arguments exacts, puis à limiter l'installation recommandée à l'adresse locale.

### Lanceurs fournis

Les scripts Windows, macOS et Linux :

1. ferment les instances TradingView existantes de force;
2. relancent l'exécutable avec `--remote-debugging-port=<port>`;
3. interrogent ensuite `/json/version` sur `127.0.0.1` ou `localhost`.

Ils ne passent pas `--remote-debugging-address=127.0.0.1`. Le client TVControl se connecte bien à `127.0.0.1` par défaut, mais cela ne constitue pas une preuve que TradingView écoute exclusivement sur loopback. L'acceptation locale devra donc vérifier le socket avec `Get-NetTCPConnection`/`netstat`/`ss` selon le système, et arrêter l'installation si l'adresse locale est `0.0.0.0`, `::` ou une adresse LAN.

Le `taskkill /F`/`pkill` des scripts crée aussi un risque de perte d'un buffer non sauvegardé. Ils ne doivent être lancés qu'après sauvegarde et fermeture contrôlée de TradingView.

## Appels réseau Pine

| Outil | Destination et données | Conséquence |
|---|---|---|
| `pine_check` | Envoie la source fournie à `pine-facade.tradingview.com` comme utilisateur Guest | Fonctionne sans CDP; peut échouer avec des dépendances privées; source transmise à TradingView |
| `pine_open` | Interroge la bibliothèque puis récupère une source via le Pine facade avec la session TradingView | Accès authentifié aux scripts sauvegardés; dépend d'une session valide |
| `pine_list_scripts` | Liste la bibliothèque via le Pine facade avec la session TradingView | Résultats filtrés/paginés; une session expirée est traitée comme erreur |

Le mode `TV_MCP_READONLY=1` retire `pine_check` de la liste blanche afin d'éviter l'envoi involontaire d'une source privée. Le mode lecture seule est donc le bon premier démarrage.

### Comportement exact de `tv_launch`

- `kill_existing` est faux par défaut et le schéma avertit qu'une fermeture forcée peut perdre l'état TradingView.
- Un endpoint CDP déjà sain provoque un retour immédiat, sans nouveau processus.
- Le processus détaché reçoit uniquement `--remote-debugging-port=<port>`.
- Le fallback Windows Store/MSIX copie le paquet protégé dans `%LOCALAPPDATA%\\tvcontrol\\desktop-cache` lorsqu'il ne peut pas publier CDP, ferme alors l'instance en échec et lance la copie locale.
- La réponse de succès inclut l'URL CDP calculée avec `CDP_HOST`, le PID et l'identité du navigateur.

Ce comportement réduit le risque de fermeture accidentelle par rapport aux scripts autonomes, sans supprimer la nécessité de sauvegarder/fermer normalement TradingView et de vérifier l'adresse d'écoute au premier démarrage.

## Décision

Retenir `FerroxLabs/tvcontrol` à la révision `0ee585f034e75f945924fff67e6310346b976539` pour l'essai AutoTrading. Ne pas retenir les dépôts `tv-mcp` de données/screener, et conserver `tradesdontlie/tradingview-mcp` seulement comme référence amont.

La recommandation est conditionnelle à une acceptation locale : port loopback seulement, premier démarrage en lecture seule, puis test sur un script `AutoTrading-Sandbox`. Les commandes et critères sont définis dans `docs/tvcontrol-installation.md`.

## Limite d'environnement actuelle

L'audit du code est possible depuis cette session. Le test réel contre TradingView ne l'est pas encore, car il faut un ordinateur local où TradingView Desktop tourne sur le port 9222. L'installation ne doit pas être déclarée réussie avant `tv_health_check`, `tools/list` et un cycle Pine contrôlé.

## Prochaine vérification

Identifier le système de l'ordinateur hôte et exécuter les phases 1 à 5 de `docs/tvcontrol-installation.md`.
