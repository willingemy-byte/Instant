# Baseline retrouvé — GC 5 minutes

Date de récupération : 2026-08-30

## Ce qui est confirmé

- Instrument de test : `GC1!` dans TradingView, graphique 5 minutes.
- Capital affiché : 10 000 USD.
- Baseline Manus V1 : RSI 21, moyenne simple du RSI 50, moyenne simple du prix 50, ratio rendement/risque 3:1, recherche d'englobante sur 5 barres.
- Fenêtre du baseline original : 08:00 à 12:00, heure de New York.
- Englobante originale : le corps de la chandelle courante englobe le corps de la chandelle précédente.
- Long : RSI au-dessus de sa moyenne, clôture au-dessus de SMA50, englobante haussière observée dans les 5 dernières barres et fenêtre horaire active.
- Short : miroir du long.
- Stop long : `low[1]` s'il est sous `close * 0.999`, sinon `close * 0.99`.
- Stop short : `high[1]` s'il est au-dessus de `close * 1.001`, sinon `close * 1.01`.
- Take profit : trois fois la distance entre l'entrée et le stop.
- Une seule position à la fois : `strategy.position_size == 0`.

## Ajustement mécanique confirmé

Le sizing original à 100 % de l'equity a produit zéro trade avec un compte de 10 000 USD sur GC. Un contrat fixe a ensuite été accepté uniquement pour rendre les entrées exécutables et comparer le win rate; ce n'était pas une modification du signal.

## Résultats historiques retrouvés

| Variante | Trades | Gagnants | Perdants | Win rate | Note |
|---|---:|---:|---:|---:|---|
| EB3 | 16 | 4 | 12 | 25,0 % | +60,9 % affiché et 147,1 % de drawdown; seuls les signaux/win rate étaient jugés interprétables |
| Manus V1 recalculé | non récupéré | non récupéré | non récupéré | 21,1 % | Test décrit comme GC réel dans TradingView |
| Englobante fraîche | non récupéré | non récupéré | non récupéré | 36,4 % | Même RSI/SMA, fenêtre 08:00–12:00 et cible 3R |

La prédiction Manus d'environ 57 % n'a donc pas été reproduite dans les tests retrouvés.

## Variante rejetée

L'exigence que toute la chandelle soit au-dessus ou au-dessous de SMA50 a empiré les résultats et a été rejetée. Elle ne doit pas réapparaître silencieusement dans le baseline.

## Données réellement disponibles

Aucun CSV GC 5 minutes de 60 jours n'a été retrouvé dans le dépôt ou dans les comptes rendus précédents. Les chiffres ci-dessus venaient du Strategy Tester de TradingView sur `GC1!`. Le prochain test doit donc rapporter explicitement la première et la dernière barre réellement couvertes par TradingView au lieu d'affirmer « 60 jours » sans preuve.

## Discipline d'itération

1. Reproduire le baseline exécutable à un contrat.
2. Noter la plage de dates et le nombre de trades.
3. Modifier une seule règle.
4. Comparer win rate, profit factor, résultat net, drawdown et espérance.

## Fichiers exécutables reconstruits

- `strategies/manus_v1_executable.pine` : baseline 08:00–12:00 à un contrat;
- `strategies/manus_v1_no_time_filter.pine` : même code, seule la fenêtre horaire est retirée.

Des tests statiques protègent les paramètres, les stops, les cibles et la différence horaire entre les deux fichiers.

## Limite observée en mode visiteur

Le 2026-08-30, TradingView a laissé voir le graphique et le Pine Editor, mais a affiché une fenêtre « Join for free » qui bloque l'ajout de la stratégie au graphique. Le mode visiteur ne suffit donc pas, dans cette session, pour produire un nouveau résultat du Strategy Tester. Un compte TradingView gratuit existant suffit normalement; aucune donnée payante n'est requise.
