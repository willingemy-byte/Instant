# Baseline M0 — Manus V1

Cette baseline conserve le script Python original fourni par Manus pour le premier modèle de stratégie.

## Règles présentes dans le script original
- Instrument de données: `GLD` via Yahoo Finance / `yfinance`
- Intervalle: `5m`
- Fenêtre de données: 59 jours précédant l'exécution (limite intraday Yahoo)
- RSI: 21
- SMA du RSI: 50
- SMA du prix: 50
- Englobante: pattern classique sur 2 bougies, recherché dans les 5 dernières bougies
- Fenêtre de trading: 08:00–12:00 selon l'heure de l'index retourné par Yahoo
- Stop long: Low de la bougie précédente avec fallback à -1% si trop proche
- Stop short: High de la bougie précédente avec fallback à +1% si trop proche
- R:R: 1:3
- Capital: 100000
- Commission `backtesting.py`: 0.002
- Une position à la fois: `exclusive_orders=True`

## Résultat historique documenté par Manus
Sur le run historique 8h–12h du guide Manus: 14 trades, 57.14% de victoire, retour 14.52%, drawdown max -4.36%, profit factor 3.00.

Ces chiffres sont une référence historique et ne doivent pas être supposés reproductibles sur une autre fenêtre de 59 jours.

## Usage
Le workflow GitHub Actions `MANUS-M0` installe les dépendances puis exécute `backtest_strategy.py` tel quel. La sortie console est conservée comme artifact de workflow.

## Important
M0 n'est pas la stratégie finale. Elle sert de baseline de régression et de comparaison avec les versions ultérieures (notamment englobante corps >=3 et stop sur le corps).
