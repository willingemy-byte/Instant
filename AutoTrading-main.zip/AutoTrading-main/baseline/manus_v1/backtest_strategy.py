import yfinance as yf
import pandas as pd
from backtesting import Strategy, Backtest
from backtesting.lib import crossover
from datetime import datetime, timedelta

class RsiMaEngulfingStrategy(Strategy):
    rsi_length = 21
    rsi_ma_length = 50
    price_ma_length = 50
    risk_reward_ratio = 3.0
    engulfing_lookback = 5
    
    # Paramètres du filtre horaire pour le backtest
    trade_start_hour = 8
    trade_start_minute = 0
    trade_end_hour = 12
    trade_end_minute = 0

    def init(self):
        # Implémentation correcte du RSI pour la librairie backtesting
        def calculate_rsi(close_prices, rsi_length):
            delta = pd.Series(close_prices).diff()
            gain = delta.mask(delta < 0, 0)
            loss = -delta.mask(delta > 0, 0)
            avg_gain = gain.ewm(com=rsi_length - 1, adjust=False).mean()
            avg_loss = loss.ewm(com=rsi_length - 1, adjust=False).mean()
            rs = avg_gain / avg_loss
            # Gérer la division par zéro et les NaN initiaux
            rsi = pd.Series([100 - (100 / (1 + val)) if val != 0 and not pd.isna(val) else (100 if pd.isna(val) else 0) for val in rs])
            return rsi

        self.rsi = self.I(calculate_rsi, self.data.Close, self.rsi_length, name='RSI')
        self.rsi_ma = self.I(lambda x: pd.Series(x).rolling(self.rsi_ma_length).mean(), self.rsi, name='RSI_MA')
        self.price_ma = self.I(lambda x: pd.Series(x).rolling(self.price_ma_length).mean(), self.data.Close, name='Price_MA')

    def next(self):
        # Vérifier le filtre horaire
        current_time = self.data.index[-1].time()
        start_trade = datetime.strptime(f'{self.trade_start_hour}:{self.trade_start_minute}', '%H:%M').time()
        end_trade = datetime.strptime(f'{self.trade_end_hour}:{self.trade_end_minute}', '%H:%M').time()

        in_allowed_time_range = False
        if start_trade < end_trade:
            in_allowed_time_range = start_trade <= current_time < end_trade
        else: # Gérer le cas où la plage chevauche minuit (non applicable ici)
            in_allowed_time_range = start_trade <= current_time or current_time < end_trade

        if not in_allowed_time_range:
            return # Ne pas trader en dehors de cette période

        # Conditions de base
        base_long_condition = self.rsi[-1] > self.rsi_ma[-1] and self.data.Close[-1] > self.price_ma[-1]
        base_short_condition = self.rsi[-1] < self.rsi_ma[-1] and self.data.Close[-1] < self.price_ma[-1]

        # Détection d'englobement
        bullish_engulfing_found = False
        bearish_engulfing_found = False

        # Assurez-vous qu'il y a suffisamment de bougies pour la détection
        if len(self.data.Open) > self.engulfing_lookback + 1:
            for i in range(1, self.engulfing_lookback + 1):
                # Bullish Engulfing: Bougie actuelle haussière englobe la précédente baissière
                if (self.data.Open[-i] < self.data.Close[-i] and  # Bougie actuelle haussière
                    self.data.Open[-(i+1)] > self.data.Close[-(i+1)] and  # Bougie précédente baissière
                    self.data.Open[-i] < self.data.Close[-(i+1)] and  # Open actuel sous close précédent
                    self.data.Close[-i] > self.data.Open[-(i+1)]):  # Close actuel au-dessus open précédent
                    bullish_engulfing_found = True
                    break

                # Bearish Engulfing: Bougie actuelle baissière englobe la précédente haussière
                if (self.data.Open[-i] > self.data.Close[-i] and  # Bougie actuelle baissière
                    self.data.Open[-(i+1)] < self.data.Close[-(i+1)] and  # Bougie précédente haussière
                    self.data.Open[-i] > self.data.Close[-(i+1)] and  # Open actuel au-dessus close précédent
                    self.data.Close[-i] < self.data.Open[-(i+1)]):  # Close actuel sous open précédent
                    bearish_engulfing_found = True
                    break

        long_condition_final = base_long_condition and bullish_engulfing_found
        short_condition_final = base_short_condition and bearish_engulfing_found

        if long_condition_final:
            if not self.position:
                entry_price = self.data.Close[-1]
                stop_loss_price_long = self.data.Low[-2] # Low of previous candle

                if stop_loss_price_long >= entry_price - (entry_price * 0.001):
                    stop_loss_price_long = entry_price * 0.99

                risk = entry_price - stop_loss_price_long
                take_profit_price_long = entry_price + (risk * self.risk_reward_ratio)

                self.buy(sl=stop_loss_price_long, tp=take_profit_price_long)

        elif short_condition_final:
            if not self.position:
                entry_price = self.data.Close[-1]
                stop_loss_price_short = self.data.High[-2] # High of previous candle

                if stop_loss_price_short <= entry_price + (entry_price * 0.001):
                    stop_loss_price_short = entry_price * 1.01

                risk = stop_loss_price_short - entry_price
                take_profit_price_short = entry_price - (risk * self.risk_reward_ratio)

                self.sell(sl=stop_loss_price_short, tp=take_profit_price_short)


# Téléchargement des données pour GLD (ETF Or) en 5 minutes
# yfinance a des limitations sur les données intraday historiques étendues (max 60 jours pour 5m).
end_date = datetime.now()
start_date = end_date - timedelta(days=59) # Max 60 days

data = yf.download("GLD", start=start_date, end=end_date, interval="5m")

# Aplatir les colonnes MultiIndex si elles existent (yfinance peut les retourner pour les intervalles intraday)
if isinstance(data.columns, pd.MultiIndex):
    data.columns = data.columns.droplevel(1) # Supprime le niveau du ticker (ex: GLD)

# Renommer les colonnes pour correspondre aux attentes de backtesting
data.rename(columns={
    'Open': 'Open',
    'High': 'High',
    'Low': 'Low',
    'Close': 'Close',
    'Volume': 'Volume'
}, inplace=True)

# Nettoyage des données (supprimer les lignes avec des valeurs NaN)
data.dropna(inplace=True)

# Exécution du backtest
bt = Backtest(data, RsiMaEngulfingStrategy,
              cash=100000, commission=0.002, exclusive_orders=True)

stats = bt.run()

print(stats)

# bt.plot() # Décommenter pour visualiser le backtest (nécessite un environnement graphique)
