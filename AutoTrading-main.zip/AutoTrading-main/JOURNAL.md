# AutoTrading — Journal de travail lisible

Ce fichier est la chronologie humaine du projet. `WORKLOG.jsonl` demeure la source append-only détaillée et `STATUS.md` demeure le dernier point de reprise.

## 2026-08-30 — Correction zéro achat de données

### Target

Peaufiner les règles GC sur environ 60 jours de barres 5 minutes déjà accessibles.

### Décision

Aucun historique de 5, 10 ou 20 ans n'est nécessaire pour cette étape. Aucun achat et aucun compte Databento ne seront demandés. Le travail Databento déjà produit est conservé comme option future, mais retiré du chemin actif. Les validations de 3, 6 et 12 mois viendront seulement après le peaufinage initial et pourront profiter de l'infrastructure TradingView/Alibaba prévue.

### Payoff suivant

Récupérer le Pine complet, confirmer la profondeur réellement disponible, puis produire les premières métriques sur la fenêtre accessible.

### Contexte historique récupéré

Le test EB3 avait été exécuté directement dans TradingView sur `GC1!`: 16 trades, 4 gagnants, 12 perdants, soit 25 %. Un recalcul ultérieur avait donné 21,1 % au Manus V1 et 36,4 % à la variante englobante fraîche. Le filtre exigeant une chandelle entièrement au-dessus ou au-dessous de SMA50 avait empiré les résultats et avait été rejeté. Aucun CSV de 60 jours réellement téléchargé n'a été retrouvé.

### Baselines reconstruits et blocage vérifié

Les fichiers Pine du Manus V1 exécutable et de la variante sans filtre horaire ont été reconstruits. Douze tests locaux sur douze réussissent. Dans la session TradingView invitée, le graphique et le Pine Editor sont visibles, mais « Join for free » bloque l'ajout de la stratégie; aucun nouveau chiffre de backtest n'a donc été inventé. La continuation gratuite requiert une session TradingView ou un vrai CSV gratuit.

---

## Portée stricte

Le journal contient uniquement le travail directement lié à AutoTrading : objectifs, recherches, actions techniques, résultats, décisions, fichiers, tests, commits et prochaine action.

Il ne contient pas :

- les conversations sans rapport avec AutoTrading;
- les opinions ou digressions personnelles;
- les mots de passe, jetons, cookies ou autres secrets;
- le raisonnement interne privé d'un modèle.

---

## 2026-08-30 — Source retenue pour le backtest GC

### Target

Choisir une source reproductible pour environ 60 jours de futures Gold `GC` en 5 minutes, sans dépendre de TradingView.

### Payoff attendu

Une requête exacte, une méthode de contrôle du coût et des critères permettant d'accepter ou de refuser les données avant de coder le backtest.

### Résultats et décision

Databento est retenu provisoirement avec `GLBX.MDP3`, `GC.v.0`, `stype_in="continuous"` et `ohlcv-1m`, à agréger localement en 5 minutes. Son endpoint `metadata.get_cost` doit être exécuté avant tout téléchargement. CME DataMine reste la référence de secours. Yahoo/yfinance est écarté à cause du risque actuel de série intrajournalière GC vide; Polygon n'est pas retenu sans preuve des droits futures intrajournaliers du forfait visé.

### Fichiers

- `WORKPLAN.md`
- `docs/data-source-decision.md`
- `JOURNAL.md`
- `STATUS.md`
- `WORKLOG.jsonl`

### Tests

- Documentation primaire Databento : symbole continu, OHLCV 1 minute, agrégation 5 minutes et estimation préalable du coût confirmés.
- Aucun téléchargement ni crédit consommé.

### Prochaine action exacte

Créer le téléchargeur Databento en mode estimation par défaut, avec validation d'environnement et zéro dépense implicite.

---

## 2026-08-30 — Téléchargeur GC avec garde de coût

### Target

Préparer la requête réelle sans qu'une simple exécution puisse consommer des crédits par erreur.

### Payoff attendu

Un outil testable qui estime d'abord le coût, bloque tout téléchargement implicite et conserve les métadonnées de l'expérience.

### Actions et résultats

- Ajout de `scripts/fetch_gc_databento.py` pour `GLBX.MDP3 / GC.v.0 / ohlcv-1m`.
- Le mode par défaut appelle seulement `metadata.get_cost`.
- Le téléchargement exige à la fois `--download` et `--max-cost-usd`; il est refusé si l'estimation dépasse le plafond.
- L'écriture CSV est atomique et produit un fichier JSON de métadonnées.
- Les données brutes et normalisées sont exclues de GitHub afin de respecter leur licence.
- Le premier lancement des tests a révélé un défaut du chargeur dynamique de test; il a été corrigé avant publication.

### Tests

- `python -m unittest discover -s tests -v` : **OK, 8/8**.
- `python -m py_compile scripts/fetch_gc_databento.py scripts/worklog.py` : **OK**.
- `python scripts/fetch_gc_databento.py --help` : **OK**.

### Prochaine action exacte

Créer ou ouvrir l'accès Databento, enregistrer la clé comme secret `DATABENTO_API_KEY`, puis exécuter seulement l'estimation de 60 jours.

## Format obligatoire d'une entrée

Chaque entrée doit indiquer :

1. la target;
2. le payoff attendu;
3. les actions effectuées;
4. les résultats et preuves;
5. la conclusion;
6. les fichiers touchés;
7. les tests;
8. le commit;
9. la prochaine action exacte.

---

## 2026-08-30 — Installation du système de reprise

### Target

Empêcher qu'une session longue se termine sans résultat durable ni point de reprise.

### Payoff attendu

Un journal append-only, un statut lisible, des règles Codex et un mécanisme de commit/push fréquent.

### Actions effectuées

- Création de `scripts/worklog.py`.
- Création de `WORKLOG.jsonl` et `STATUS.md`.
- Création de `AGENTS.md` avec la règle de checkpoint.
- Création de la documentation et des tests.

### Résultats et preuves

- Trois tests sur trois réussis.
- Le script ajoute un événement JSONL et régénère `STATUS.md`.
- Les chemins qui sortent du dépôt sont refusés.
- Le commit d'installation a été relu depuis GitHub.

### Conclusion

Le projet possède maintenant un point de reprise durable. Un checkpoint doit être enregistré au maximum après cinq minutes ou trois opérations matérielles, avant une opération longue et après chaque décision, test, erreur ou blocage.

### Fichiers

- `scripts/worklog.py`
- `tests/test_worklog.py`
- `WORKLOG.jsonl`
- `STATUS.md`
- `AGENTS.md`
- `docs/worklog.md`

### Tests

- `python -m unittest discover -s tests -v` : **OK, 3/3**.
- `python -m py_compile scripts/worklog.py` : **OK**.

### Commits

- Installation : `9c6cbfec12c3595ef05acd87cef64a31713ce223`.
- Point de reprise final : `a397fac1624b68afd5fa7a0d7ae77be47c79a8d8`.

### Prochaine action exacte

Créer ce journal lisible, puis reprendre l'audit des solutions de contrôle TradingView.

---

## 2026-08-30 — Reprise de la recherche TVControl

### Target

Trouver une méthode permettant à Codex de modifier, compiler, tester et corriger un script Pine dans TradingView sans obliger l'utilisateur à faire continuellement du copier-coller sur son téléphone.

### Point de départ fourni

- Recherche exacte : <https://github.com/search?q=Tvcontrol&type=repositories>.
- Le nom dont l'utilisateur se souvenait ressemblait à « TVControl »; le dernier candidat retenu auparavant n'était possiblement pas nommé exactement `tvcontrol`, mais contenait encore `tv`.
- Le fichier Pine doit rester versionné dans le dépôt AutoTrading.

### Faits récupérables de la recherche précédente

- Dans la configuration mobile précédente, Codex ne pouvait pas éditer directement le Pine Editor de TradingView.
- Deux pistes avaient été distinguées : contrôler une session TradingView par navigateur/application, ou garder GitHub comme source principale du fichier `.pine`.
- Les noms suivants avaient été observés et doivent maintenant être revérifiés dans leur source :
  - `FerroxLabs/tvcontrol`;
  - `tradesdontlie/tradingview-mcp`;
  - des dépôts dont le nom ressemble à `tv-mcp`;
  - `tvdatafeed`, qui semblait viser les données plutôt que le contrôle du Pine Editor.
- Une piste technique provisoire utilisait MCP et le Chrome DevTools Protocol sur un port local, possiblement avec TradingView Desktop. Les commandes exactes, le port, les capacités et les systèmes supportés doivent être confirmés dans le code actuel avant toute sélection.

### Ce qui n'est pas récupérable avec certitude

- Le nom exact du dernier dépôt choisi dans l'ancienne session.
- Le nombre exact d'outils exposés par chaque dépôt.
- La preuve que l'installation fonctionne dans l'environnement actuel.

Ces éléments ne seront pas inventés; ils seront reconstruits à partir des dépôts GitHub actuels.

### Recherche GitHub vérifiée — checkpoint 1

La recherche exacte et deux recherches complémentaires ont été rejouées le 2026-08-30.

- `FerroxLabs/tvcontrol` est le seul résultat `Tvcontrol` directement lié à TradingView.
- La famille `tv-mcp` existe réellement, mais ses dépôts ont des fonctions différentes :
  - `smitkunpara/tv-mcp` récupère des données, indicateurs et nouvelles; il ne contrôle pas le Pine Editor;
  - `xabbai/tv-mcp` expose un screener d'actions;
  - `JayNorthDev/tv-mcp` est un fork de `tradesdontlie/tradingview-mcp`;
  - `srinivasbe-07/tv-mcp` contrôle TradingView Desktop par CDP, mais il s'agit d'un système spécialisé et personnalisé, sans README à la racine.
- `tradesdontlie/tradingview-mcp` est l'origine reconnue de la méthode CDP/MCP reprise par TVControl.
- L'architecture confirmée est : agent MCP → serveur local → CDP sur `localhost:9222` → TradingView Desktop.
- Cette architecture exige donc un ordinateur local avec TradingView Desktop et un client MCP; le téléphone seul ne peut pas joindre le port local de cet ordinateur.

Une incohérence documentaire doit être résolue par un test d'exécution :

- le README de `FerroxLabs/tvcontrol` annonce 109 outils;
- la description de `package.json` en annonce 105;
- la description de l'API GitHub en annonce 88;
- le serveur actuel calcule son nombre d'outils au démarrage au lieu d'utiliser une constante.

Le nombre réel sera donc celui retourné par `tools/list` après installation, pas celui d'un texte promotionnel.

### Audit du code — checkpoint 2

Le catalogue actuel a été mesuré directement dans tous les fichiers `src/tools/*.js` :

- 110 outils définis;
- 109 outils enregistrés par défaut;
- `ui_evaluate` est le seul outil avancé retiré par défaut;
- aucun nom dupliqué;
- 12 outils Pine sont présents.

Les garde-fous suivants sont présents dans le code et couverts par des tests dédiés :

- `pine_set_source` et `pine_new` refusent d'écraser un buffer non trivial sans `confirm_overwrite:true`;
- un buffer illisible provoque un refus fermé;
- la source est relue après injection et sa longueur ainsi que son nombre de lignes sont comparés;
- `pine_save` ne retourne pas un succès si TradingView indique encore des changements non sauvegardés;
- `pine_compile` et `pine_smart_compile` avertissent explicitement qu'ils sauvegardent avant de compiler;
- le mode `TV_MCP_READONLY=1` retire structurellement les outils de mutation au lieu de demander simplement au modèle de ne pas les utiliser.

État de la CI au dernier commit amont `0ee585f034e75f945924fff67e6310346b976539` :

- Linux Node 18 et 22 : succès;
- macOS Node 18 et 22 : succès;
- Windows Node 18 et 22 : échec pendant les tests hors ligne.

Le projet ne sera donc pas décrit comme entièrement vert sur Windows avant lecture du journal d'erreur et reproduction locale.

### Diagnostic Windows — checkpoint 3

Les journaux complets des jobs Node 18 et Node 22 ont été lus. Les deux produisent exactement le même bilan : **772 tests, 769 réussis, 3 échoués**.

Les trois échecs sont des incompatibilités du banc de tests avec un checkout Windows :

1. le test du shebang compare `#!/usr/bin/env node` avec une première ligne terminée par `\r` après conversion CRLF;
2. le test d'installation tente de lancer `npm` avec `spawnSync`, ce qui retourne `ENOENT` sous Windows où le lanceur attendu est généralement `npm.cmd`;
3. le test hermétique compare des chemins normalisés avec `/`, mais reçoit des chemins `src\\connection.js` et classe alors trois occurrences autorisées comme non gardées.

Ces résultats ne prouvent pas que les fonctions TradingView échouent sous Windows : ils montrent que la suite de tests n'est pas portable telle quelle. Ils empêchent néanmoins de qualifier la branche actuelle de entièrement verte. La vérification décisive demeure un `npm test` corrigé ou un test d'installation et de handshake réel sur l'ordinateur Windows cible.

### Sweep et endpoint CDP — checkpoint 4

Le code de `strategy_sweep` et ses tests confirment :

- 100 combinaisons au maximum par défaut et un plafond absolu de 500;
- un délai par combinaison de 30 secondes par défaut;
- un checkpoint partiel toutes les 10 combinaisons et une reprise par `run_id` validé;
- un cache local de 24 heures par défaut, plafonné à 5 000 fichiers et isolé par identifiant de stratégie, symbole, intervalle et inputs;
- la restauration de l'état de départ dans un `finally`, y compris quand `on_error=abort` provoque une exception;
- la suppression du snapshot temporaire après la restauration;
- de vrais tests de cache, reprise, limite, restauration et nettoyage.

La limite est explicite dans les tests amont : le pool parallèle complet ouvre de vrais onglets et exige une session CDP. Les tests hors ligne couvrent son coupe-circuit de timeout et l'utilisation de l'endpoint partagé, pas un sweep parallèle réel de bout en bout.

Pour la connexion, `CDP_HOST` vaut `127.0.0.1` par défaut et le port vaut `9222`. L'hôte peut être changé par variable d'environnement; la politique de sécurité amont exige donc de ne jamais exposer ce port au réseau ou à Internet. Le prochain contrôle doit confirmer que le lanceur local n'ajoute aucune option qui élargit l'écoute.

### Lanceurs et appels Pine — checkpoint 5

Les lanceurs Windows, macOS et Linux ont été lus :

- ils ferment d'abord les instances TradingView existantes (`taskkill /F` ou `pkill`), ce qui impose de sauvegarder tout travail ouvert avant lancement;
- ils ajoutent `--remote-debugging-port=9222`, mais pas `--remote-debugging-address=127.0.0.1`;
- ils vérifient ensuite l'endpoint avec `127.0.0.1` ou `localhost`, mais cette vérification ne démontre pas à elle seule que l'application n'écoute sur aucune interface réseau;
- le protocole AutoTrading devra donc vérifier l'adresse d'écoute avec l'outil système de l'ordinateur et refuser toute écoute sur `0.0.0.0`, `::` ou une adresse LAN.

Les appels réseau Pine sont maintenant distingués :

- `pine_check` envoie explicitement la source fournie au service `pine-facade.tradingview.com` en mode `Guest`, avec un timeout de 15 secondes; il peut fonctionner sans TradingView ouvert, mais les dépendances privées/premium peuvent échouer et la requête est limitée par IP;
- `pine_open` et `pine_list_scripts` utilisent le même service interne depuis la page TradingView avec les identifiants de la session courante;
- le mode lecture seule retire `pine_check`, précisément parce qu'il peut envoyer une source privée au service de compilation.

Conclusion de sécurité : il ne s'agit pas d'un outil « sans appel cloud ». Les appels sont vers TradingView, mais toute utilisation d'un script confidentiel doit éviter `pine_check` ou accepter explicitement cet envoi.

L'outil MCP `tv_launch` est plus prudent que les scripts autonomes :

- `kill_existing` vaut faux par défaut;
- si CDP répond déjà, il retourne l'instance existante au lieu d'en démarrer une seconde;
- il lance seulement avec `--remote-debugging-port=<port>`;
- sur Windows Store/MSIX, si le paquet protégé ne publie pas CDP, il copie le paquet sous `%LOCALAPPDATA%\\tvcontrol\\desktop-cache`, ferme l'instance ayant échoué et lance la copie;
- le premier branchement exige donc toujours une sauvegarde et une fermeture normales de TradingView, suivies d'une vérification système du socket.

### Décision finale

La direction MCP est confirmée et le candidat retenu est `FerroxLabs/tvcontrol`, épinglé pour l'acceptation à la révision auditée `0ee585f034e75f945924fff67e6310346b976539`.

Le projet est retenu parce qu'il combine le contrôle réel du Pine Editor, une relecture après injection, une protection contre l'écrasement, une sauvegarde vérifiée, un mode lecture seule structurel, des sweeps reprenables et une base de tests nettement plus complète que les autres candidats trouvés.

Cette décision ne signifie pas que TradingView est déjà connecté à la présente session. Le serveur doit être installé sur l'ordinateur qui exécute TradingView Desktop. L'acceptation commence en lecture seule et se termine par un cycle Pine sur un script sandbox; le protocole complet est dans `docs/tvcontrol-installation.md`.

### Fichiers

- `JOURNAL.md`
- `docs/tradingview-control-audit.md`
- `docs/tvcontrol-installation.md`
- `STATUS.md`
- `WORKLOG.jsonl`

### Tests

- Catalogue analysé statiquement : **110 définis, 109 par défaut, aucun doublon**.
- Tests amont Linux/macOS : **succès**.
- Tests amont Windows : **769/772; trois incompatibilités de tests identifiées**.
- Aucun test d'intégration contre une session TradingView locale exécuté à ce point.

### Commit

- Journal lisible initial : `6078daf1fd100439eb53d2217e2ba9bb431a726b`.
- Audit inventaire : `796e26ba0b520b1681dc2c9601d0084f024eaa7a`.
- Audit du code Pine : `4599311c0eb5337836354b1e2084add2ff07b967`.

### Prochaine action exacte

Identifier le système de l'ordinateur qui hébergera TradingView, puis exécuter les phases 1 à 5 de `docs/tvcontrol-installation.md` en lecture seule.

---

## 2026-08-30 — Validation du chemin TradingView sans ordinateur

### Target

Déterminer si AutoTrading peut avancer depuis le téléphone en utilisant directement TradingView Web dans le navigateur Work, sans ordinateur personnel ni serveur TVControl local.

### Payoff attendu

Une preuve visuelle que le graphique et le Pine Editor sont contrôlables, suivie d'une connexion sécurisée au compte TradingView.

### Actions effectuées

- Lecture de `agents.md` pour distinguer le fichier d'instructions de l'environnement d'exécution.
- Ouverture de TradingView Web dans le navigateur cloud Work.
- Ouverture du panneau Pine et inspection de l'éditeur.
- Démarrage de la connexion TradingView par le mécanisme sécurisé du navigateur.

### Résultats et preuves

- `AGENTS.md` est un format Markdown d'instructions pour agents; il ne fournit ni ordinateur, ni navigateur, ni serveur TradingView.
- TradingView Web charge correctement un graphique AAPL.
- Le Pine Editor s'ouvre et affiche un script vierge Pine v6.
- Le chemin sans ordinateur est donc techniquement réel pour l'édition par interface Web.
- Google a affiché `Too many failed attempts` après la méthode choisie; les tentatives automatiques ont été arrêtées immédiatement.

### Conclusion

TVControl demeure impossible sans machine hôte, mais il n'est pas requis pour le premier cycle AutoTrading. Le navigateur Work peut piloter TradingView Web après authentification. Cette voie est moins structurée que les 109 outils MCP et doit être validée progressivement sur `AutoTrading-Sandbox`.

### Fichiers

- `JOURNAL.md`
- `docs/tradingview-web-work.md`
- `STATUS.md`
- `WORKLOG.jsonl`

### Tests

- Chargement du graphique TradingView Web : **OK**.
- Ouverture visuelle du Pine Editor : **OK**.
- Authentification Google : **bloquée par `Too many failed attempts`**.
- Aucune source de production modifiée.

### Prochaine action exacte

Terminer manuellement la connexion dans l'onglet TradingView Work, vérifier un signal positif du compte, puis ouvrir ou créer `AutoTrading-Sandbox` avant toute écriture.

---

## 2026-08-30 — Retour à la target données et backtest

### Correction de portée

La connexion TradingView n'est pas la target actuelle. Elle servira plus tard à la validation Pine ou au déploiement continu, lequel dépendra aussi de l'infrastructure d'entreprise Alibaba Cloud. Les essais de connexion ont été arrêtés et les onglets d'authentification fermés.

### Target

Mesurer hors ligne la rentabilité des règles AutoTrading sur environ 60 jours de Gold futures GC, en chandelles de 5 minutes, avant toute exploitation réelle.

### Paramètres récupérés

- Instrument : Gold futures `GC`, COMEX/CME, continu ou front-month compatible Topstep.
- Résolution : 5 minutes.
- Fenêtre : environ 60 jours, 24 heures sur 24.
- Règles de départ récupérables : chandelle entièrement au-dessus de la SMA 50, bloc englobant après croisement, RSI 21 au-dessus de sa moyenne 50, ratio risque-rendement 1:3.
- Référence à vérifier : Manus avait annoncé environ 57 % de réussite, alors qu'un essai ultérieur avait produit environ 25 %.

### Données retrouvées

- Exemple déjà fourni : `xcec-tick-gc-fut-20220823-part-00058.c000-sample.csv.gz.csv`.
- Sources comparées auparavant : CME DataMine, CME Metals Market Profile et FirstRateData.
- La piste gratuite `yfinance` correspond à la limite de 60 jours en intraday, mais une discussion amont d'avril 2026 signale que `GC=F` peut retourner zéro ligne même en 5 minutes. Elle ne sera pas adoptée sans test réel réussi.
- TradingView visiteur pouvait afficher de l'intraday, mais ne fournissait pas l'export CSV requis et son historique était limité.

### Payoffs

1. Un fichier GC 5 minutes d'environ 60 jours, avec provenance et contrôle qualité.
2. Un moteur de backtest reproductible dans le dépôt.
3. Win rate, nombre de trades, profit net, profit factor, drawdown maximal et résultat avec coûts/slippage.
4. Comparaison directe avec les résultats de 57 % et 25 %.

### Prochaine action exacte

Identifier et tester la meilleure source de données GC réellement accessible, puis publier un échantillon normalisé avant de coder le moteur de backtest.
