from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

import run_m10_trailing_initial_risk as b
import run_m14_topstep_150k_risk300 as m14
import run_m17_eb3_noentry_10_17ct as m17
import run_m20_m17_dynamic20_capped900 as m20
import run_m21_m20_full_mgc_history as m21
import run_m28_fib_358_mtf_exit as m28
import run_m29_fib_358_trailing10_tp7 as m29

OUT = Path("artifacts/m31_tp_ladder_matrix")
OUT.mkdir(parents=True, exist_ok=True)
EPS = 1e-9
ONE_NS = pd.Timedelta(nanoseconds=1)

VARIANTS = {
    "A_ladder_only": {
        "initial_stop_R": -1.0,
        "trail_mode": "none",
        "be_at_3R": False,
    },
    "B_trail_from_entry": {
        "initial_stop_R": -1.5,
        "trail_mode": "from_entry",
        "be_at_3R": False,
    },
    "C_be_at_3R": {
        "initial_stop_R": -1.0,
        "trail_mode": "none",
        "be_at_3R": True,
    },
    "D_be_and_trail_at_3R": {
        "initial_stop_R": -1.0,
        "trail_mode": "after_3R",
        "be_at_3R": True,
    },
    "E_trail_after_TP1": {
        "initial_stop_R": -1.0,
        "trail_mode": "after_1R",
        "be_at_3R": False,
    },
}


def _price_at_r(pos: dict, r_mult: float) -> float:
    return float(pos["entry"]) + int(pos["side"]) * float(pos["risk"]) * float(r_mult)


def _move_r(pos: dict, price: float) -> float:
    return ((float(price) - float(pos["entry"])) / float(pos["risk"])) * int(pos["side"])


def _finish(pos: dict, price: float, ts: pd.Timestamp, reason: str) -> dict:
    remaining = float(pos["remaining_frac"])
    total_r = float(pos["realized_R"]) + remaining * _move_r(pos, price)
    return {
        **pos,
        "exit": float(price),
        "exit_time": ts,
        "reason": reason,
        "R": float(total_r),
        "remaining_frac_at_exit": remaining,
    }


def _stop_price(pos: dict) -> float:
    return _price_at_r(pos, float(pos["active_stop_R"]))


def _stop_touched(side: int, o: float, h: float, l: float, stop: float) -> tuple[bool, float, bool]:
    if side == 1:
        if o <= stop:
            return True, o, True
        if l <= stop:
            return True, stop, False
    else:
        if o >= stop:
            return True, o, True
        if h >= stop:
            return True, stop, False
    return False, np.nan, False


def _favorable_reached(side: int, o: float, h: float, l: float, level: float) -> bool:
    if side == 1:
        return o >= level or h >= level
    return o <= level or l <= level


def _update_best_and_stop(pos: dict, bar: pd.Series, cfg: dict) -> None:
    side = int(pos["side"])
    entry = float(pos["entry"])
    risk = float(pos["risk"])
    if side == 1:
        best = max(float(pos["best_price"]), float(bar.High))
        best_r = (best - entry) / risk
    else:
        best = min(float(pos["best_price"]), float(bar.Low))
        best_r = (entry - best) / risk
    pos["best_price"] = best
    pos["best_R"] = max(float(pos["best_R"]), float(best_r))

    trail_mode = cfg["trail_mode"]
    trail_active = (
        trail_mode == "from_entry"
        or (trail_mode == "after_1R" and bool(pos["hit_tp1"]))
        or (trail_mode == "after_3R" and bool(pos["hit_tp2"]))
    )
    if trail_active:
        trail_stop_r = float(pos["best_R"]) - 1.5
        pos["active_stop_R"] = max(float(pos["active_stop_R"]), trail_stop_r)

    if cfg["be_at_3R"] and bool(pos["hit_tp2"]):
        pos["active_stop_R"] = max(float(pos["active_stop_R"]), 0.0)


def process_minutes(pos: dict | None, mins: pd.DataFrame, cfg: dict) -> tuple[dict | None, dict | None]:
    if pos is None or mins.empty:
        return pos, None

    side = int(pos["side"])
    for ts, bar in mins.iterrows():
        o = float(bar.Open)
        h = float(bar.High)
        l = float(bar.Low)

        if m14.force_flat_now(ts):
            return None, _finish(pos, o, ts, "topstep_1510_flat")

        # Conservative ordering: the stop known BEFORE this 1m bar gets priority.
        stop = _stop_price(pos)
        touched, stop_fill, gap = _stop_touched(side, o, h, l, stop)
        if touched:
            return None, _finish(pos, stop_fill, ts, "gap_stop" if gap else "stop")

        # TP1 at +1R: sell 50% of ORIGINAL position.
        if not pos["hit_tp1"]:
            lvl1 = _price_at_r(pos, 1.0)
            if _favorable_reached(side, o, h, l, lvl1):
                pos["hit_tp1"] = True
                pos["realized_R"] += 0.50 * 1.0
                pos["remaining_frac"] -= 0.50

        # TP2 at +3R: sell half of what remains = 25% ORIGINAL.
        if pos["hit_tp1"] and not pos["hit_tp2"]:
            lvl2 = _price_at_r(pos, 3.0)
            if _favorable_reached(side, o, h, l, lvl2):
                pos["hit_tp2"] = True
                pos["realized_R"] += 0.25 * 3.0
                pos["remaining_frac"] -= 0.25

        # TP3 at +7R: sell the final 25% ORIGINAL; completed trade = +3R total.
        if pos["hit_tp2"] and not pos["hit_tp3"]:
            lvl3 = _price_at_r(pos, 7.0)
            if _favorable_reached(side, o, h, l, lvl3):
                pos["hit_tp3"] = True
                pos["realized_R"] += float(pos["remaining_frac"]) * 7.0
                pos["remaining_frac"] = 0.0
                return None, _finish(pos, lvl3, ts, "tp3_7R")

        # Ratchet management from this completed 1m bar for FUTURE minutes only.
        _update_best_and_stop(pos, bar, cfg)

    return pos, None


def simulate_variant(d1: pd.DataFrame, d5: pd.DataFrame, variant: str, cfg: dict) -> tuple[pd.DataFrame, dict]:
    h1 = m28.completed_h1_fib_mas(d1)
    m5 = m28.five_minute_fib_mas(d5)
    low10 = d5["Low"].rolling(10, min_periods=10).min()
    high10 = d5["High"].rolling(10, min_periods=10).max()

    idx5 = d5.index
    pos = None
    rec: list[dict] = []
    prev_eligible_long = False
    prev_eligible_short = False
    long_armed = False
    short_armed = False
    counters = {
        "long_setups_formed": 0,
        "short_setups_formed": 0,
        "accepted_long_entries": 0,
        "accepted_short_entries": 0,
        "blocked_by_entry_hours": 0,
        "invalid_risk_unit": 0,
    }

    for i in range(len(d5)):
        close_time = idx5[i] + pd.Timedelta(minutes=5)
        prev_close = idx5[i] if i == 0 else idx5[i - 1] + pd.Timedelta(minutes=5)

        if pos is not None:
            pos, done = process_minutes(pos, d1.loc[prev_close:close_time - ONE_NS], cfg)
            if done is not None:
                rec.append(done)

        row5 = m5.iloc[i]
        vals5 = [row5.get(f"sma{n}_5m", np.nan) for n in (3, 5, 8)]
        valid5 = all(pd.notna(v) and np.isfinite(float(v)) for v in vals5)
        if not valid5:
            prev_eligible_long = prev_eligible_short = False
            long_armed = short_armed = False
            continue
        sma3_5, sma5_5, sma8_5 = map(float, vals5)

        hist = h1.loc[:close_time]
        if hist.empty:
            continue
        hr = hist.iloc[-1]
        close_h1 = float(hr["close_h1"])
        sma3_h1 = float(hr["sma3_h1"])
        sma5_h1 = float(hr["sma5_h1"])
        sma8_h1 = float(hr["sma8_h1"])
        sma200_h1 = float(hr["sma200_h1"])

        long_regime = close_h1 > sma200_h1 and sma3_h1 > sma5_h1 > sma8_h1 > sma200_h1
        short_regime = close_h1 < sma200_h1 and sma3_h1 < sma5_h1 < sma8_h1 < sma200_h1
        eligible_long = long_regime and sma3_5 > sma5_5 and sma3_5 > sma8_5
        eligible_short = short_regime and sma3_5 < sma5_5 and sma3_5 < sma8_5

        if eligible_long and not prev_eligible_long:
            long_armed = True
            counters["long_setups_formed"] += 1
        elif not eligible_long:
            long_armed = False
        if eligible_short and not prev_eligible_short:
            short_armed = True
            counters["short_setups_formed"] += 1
        elif not eligible_short:
            short_armed = False
        prev_eligible_long = eligible_long
        prev_eligible_short = eligible_short

        if pos is not None:
            continue
        if not m17.entry_allowed_m17(close_time):
            if long_armed or short_armed:
                counters["blocked_by_entry_hours"] += 1
            continue
        if pd.isna(low10.iloc[i]) or pd.isna(high10.iloc[i]):
            continue

        entry = float(d5.Close.iloc[i])
        side = 0
        initial_extreme = np.nan
        if long_armed and eligible_long:
            side = 1
            initial_extreme = float(low10.iloc[i])
        elif short_armed and eligible_short:
            side = -1
            initial_extreme = float(high10.iloc[i])
        if side == 0:
            continue

        risk = (entry - initial_extreme) if side == 1 else (initial_extreme - entry)
        if risk <= 0 or not np.isfinite(risk):
            counters["invalid_risk_unit"] += 1
            continue

        pos = {
            "variant": variant,
            "side": side,
            "entry": entry,
            "entry_time": close_time,
            "risk": float(risk),
            "risk_reference_10bar": float(initial_extreme),
            "active_stop_R": float(cfg["initial_stop_R"]),
            "best_price": entry,
            "best_R": 0.0,
            "remaining_frac": 1.0,
            "realized_R": 0.0,
            "hit_tp1": False,
            "hit_tp2": False,
            "hit_tp3": False,
            "sma3_5m": sma3_5,
            "sma5_5m": sma5_5,
            "sma8_5m": sma8_5,
            "close_h1": close_h1,
            "sma3_h1": sma3_h1,
            "sma5_h1": sma5_h1,
            "sma8_h1": sma8_h1,
            "sma200_h1": sma200_h1,
        }
        if side == 1:
            long_armed = False
            counters["accepted_long_entries"] += 1
        else:
            short_armed = False
            counters["accepted_short_entries"] += 1

    if pos is not None:
        end_ts = idx5[-1] + pd.Timedelta(minutes=5)
        rec.append(_finish(pos, float(d5.Close.iloc[-1]), end_ts, "data_end"))

    return pd.DataFrame(rec), counters


def summarize_raw(trades: pd.DataFrame) -> dict:
    if trades.empty:
        return {}
    r = trades["R"].astype(float)
    wins = int((r > EPS).sum())
    losses = int((r < -EPS).sum())
    be = int((r.abs() <= EPS).sum())
    return {
        "trades": int(len(trades)),
        "wins": wins,
        "losses": losses,
        "breakeven": be,
        "win_rate_ex_be_pct": float(100 * wins / (wins + losses)) if wins + losses else 0.0,
        "avg_R": float(r.mean()),
        "sum_R": float(r.sum()),
        "longest_loss_streak": int(m21.longest_loss_streak(r)),
        "tp1_count": int(trades["hit_tp1"].astype(bool).sum()),
        "tp2_count": int(trades["hit_tp2"].astype(bool).sum()),
        "tp3_count": int(trades["hit_tp3"].astype(bool).sum()),
        "tp1_pct": float(100 * trades["hit_tp1"].astype(bool).mean()),
        "tp2_pct": float(100 * trades["hit_tp2"].astype(bool).mean()),
        "tp3_pct": float(100 * trades["hit_tp3"].astype(bool).mean()),
        "realized_partial_R_total": float(trades["realized_R"].astype(float).sum()),
    }


def annual_stats(trades: pd.DataFrame) -> list[dict]:
    return m29.raw_period_stats(trades, "year") if not trades.empty else []


def main() -> None:
    d1 = m21.load_full_1m()
    d5 = b.make_5m(d1)
    all_payload = {
        "method": "offline research simulation only",
        "data_start": str(d1.index.min()),
        "data_end": str(d1.index.max()),
        "entry_logic": "M30 Fibonacci 3/5/8 entry logic unchanged",
        "risk_unit": "entry-to-rolling10 wick distance used only as 1R normalization",
        "tp_ladder": {"TP1": "+1R close 50% original", "TP2": "+3R close 25% original", "TP3": "+7R close final 25%"},
        "full_target_total_R": 3.0,
        "variants": {},
    }
    comparison_rows = []

    for name, cfg in VARIANTS.items():
        trades, counters = simulate_variant(d1, d5, name, cfg)
        trades.to_csv(OUT / f"{name}_trades.csv", index=False)
        raw = summarize_raw(trades)
        ev = m20.evaluate_dynamic20_capped900(trades, d1)
        dyn = m20.summarize(trades, ev)
        annual = annual_stats(trades)
        exits = trades["reason"].value_counts().to_dict() if not trades.empty else {}
        result = {
            "config": cfg,
            "counters": counters,
            "raw": raw,
            "dynamic": dyn,
            "annual_raw": annual,
            "exit_reasons": exits,
        }
        all_payload["variants"][name] = result
        comparison_rows.append({
            "variant": name,
            **raw,
            "dynamic_net_profit": dyn.get("net_profit"),
            "dynamic_final_balance": dyn.get("final_balance"),
            "minimum_mll_headroom": dyn.get("minimum_mll_headroom"),
            "topstep_survived": dyn.get("topstep_survived"),
        })

    comp = pd.DataFrame(comparison_rows)
    comp.to_csv(OUT / "m31_comparison.csv", index=False)
    (OUT / "m31_results.json").write_text(json.dumps(all_payload, indent=2), encoding="utf-8")

    lines = [
        "# M31 — TP ladder 1R / 3R / 7R — five management variants",
        "",
        "TP ladder: 50% original at +1R, 25% original at +3R, final 25% at +7R.",
        "If all three targets are reached, total trade result = +3R.",
        "",
        "| Variant | Trades | WR ex-BE | AvgR | SumR | TP1 % | TP2 % | TP3 % | Loss streak | Dynamic net $ | Survived MLL |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|",
    ]
    for row in comparison_rows:
        lines.append(
            f"| {row['variant']} | {row['trades']} | {row['win_rate_ex_be_pct']:.2f}% | {row['avg_R']:.3f} | {row['sum_R']:.1f} | "
            f"{row['tp1_pct']:.2f}% | {row['tp2_pct']:.2f}% | {row['tp3_pct']:.2f}% | {row['longest_loss_streak']} | "
            f"{row['dynamic_net_profit']:.0f} | {row['topstep_survived']} |"
        )
    lines.append("")
    for name in VARIANTS:
        lines.append(f"## {name}")
        lines.append("")
        result = all_payload["variants"][name]
        for r in result["annual_raw"]:
            lines.append(
                f"- {r['period']}: {r['trades']} trades, WR {r['win_rate_ex_be_pct']:.2f}%, AvgR {r['avg_R']:.3f}, SumR {r['sum_R']:.1f}"
            )
        lines.append("")
    report = "\n".join(lines) + "\n"
    (OUT / "m31_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
