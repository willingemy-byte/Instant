from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

import run_m10_trailing_initial_risk as b
import run_m14_topstep_150k_risk300 as m14
import run_m17_eb3_noentry_10_17ct as m17

OUT = Path("artifacts")
OUT.mkdir(parents=True, exist_ok=True)

START_BALANCE = m14.START_BALANCE
MLL_DISTANCE = m14.MLL_DISTANCE
RISK_FRACTION = 0.20
RISK_CAP = 900.0


def closed_drawdown_dynamic(pnls: pd.Series) -> float:
    if pnls.empty:
        return 0.0
    eq = START_BALANCE + pnls.cumsum()
    peak = eq.cummax()
    return float((eq - peak).min())


def evaluate_dynamic20_capped900(trades: pd.DataFrame, d1: pd.DataFrame) -> dict:
    if trades.empty:
        return {"survived": True, "trades": 0, "ledger": pd.DataFrame()}
    t = trades.sort_values("entry_time").reset_index(drop=True).copy()
    t["session"] = t["entry_time"].map(m14.session_label)
    balance = START_BALANCE
    mll = START_BALANCE - MLL_DISTANCE
    min_headroom = float("inf")
    min_headroom_time = None
    breach = None
    rows = []
    current_session = None

    for j, tr in t.iterrows():
        sess = tr["session"]
        if current_session is not None and sess != current_session:
            mll = min(START_BALANCE, max(mll, balance - MLL_DISTANCE))
        current_session = sess

        available = balance - mll
        if available <= 0:
            breach = {"trade_index": int(j), "time": str(tr["entry_time"]), "equity": balance, "mll": mll, "headroom": available, "entry_time": str(tr["entry_time"]), "reason": "no_headroom_at_entry"}
            break

        risk_dollars = min(RISK_CAP, RISK_FRACTION * available)
        entry = float(tr["entry"])
        risk_points = float(tr["risk"])
        side = int(tr["side"])
        et = pd.Timestamp(tr["entry_time"])
        xt = pd.Timestamp(tr["exit_time"])
        dollars_per_price = risk_dollars / risk_points
        mins = d1.loc[et:xt]
        local_min_headroom = float("inf")
        local_min_time = et

        for ts, bar in mins.iterrows():
            reason = str(tr["reason"])
            if ts == xt and reason in {"stop", "gap_stop", "both_stop_first", "topstep_1510_flat"}:
                worst_pnl = float(tr["R"]) * risk_dollars
            else:
                if side == 1:
                    worst_pnl = (float(bar.Low) - entry) * dollars_per_price
                else:
                    worst_pnl = (entry - float(bar.High)) * dollars_per_price
                if ts == xt:
                    worst_pnl = min(worst_pnl, float(tr["R"]) * risk_dollars)
            equity_worst = balance + worst_pnl
            headroom = equity_worst - mll
            if headroom < local_min_headroom:
                local_min_headroom = headroom; local_min_time = ts
            if headroom < min_headroom:
                min_headroom = headroom; min_headroom_time = ts
            if equity_worst <= mll and breach is None:
                breach = {"trade_index": int(j), "time": str(ts), "equity": float(equity_worst), "mll": float(mll), "headroom": float(headroom), "entry_time": str(et), "risk_dollars": float(risk_dollars), "R_at_exit": float(tr["R"])}
                break

        pnl = float(tr["R"]) * risk_dollars
        balance_before = balance
        if breach is None:
            balance += pnl
        rows.append({"trade": int(j + 1), "entry_time": str(et), "exit_time": str(xt), "session": sess, "R": float(tr["R"]), "balance_before": float(balance_before), "mll_before_trade": float(mll), "available_headroom_before": float(available), "risk_fraction": RISK_FRACTION, "risk_cap": RISK_CAP, "risk_dollars": float(risk_dollars), "pnl_dollars": float(pnl), "balance_after": float(balance), "min_headroom_trade": float(local_min_headroom), "min_headroom_time": str(local_min_time), "reason": str(tr["reason"])})
        if breach is not None:
            break

    if breach is None and current_session is not None:
        mll = min(START_BALANCE, max(mll, balance - MLL_DISTANCE))

    ledger = pd.DataFrame(rows)
    risk_series = ledger["risk_dollars"] if not ledger.empty else pd.Series(dtype=float)
    pnl_series = ledger["pnl_dollars"] if not ledger.empty else pd.Series(dtype=float)
    cap_hits = int((risk_series >= RISK_CAP - 1e-9).sum()) if len(risk_series) else 0
    return {"survived": breach is None, "trades": int(len(t)), "trades_processed": int(len(ledger)), "final_balance": float(balance), "net_profit": float(balance - START_BALANCE), "ending_mll": float(mll), "minimum_headroom": float(min_headroom), "minimum_headroom_time": str(min_headroom_time), "breach": breach, "first_risk_dollars": float(risk_series.iloc[0]) if len(risk_series) else 0.0, "average_risk_dollars": float(risk_series.mean()) if len(risk_series) else 0.0, "median_risk_dollars": float(risk_series.median()) if len(risk_series) else 0.0, "minimum_risk_dollars": float(risk_series.min()) if len(risk_series) else 0.0, "maximum_risk_dollars": float(risk_series.max()) if len(risk_series) else 0.0, "cap_hit_trades": cap_hits, "closed_equity_max_drawdown": closed_drawdown_dynamic(pnl_series), "ledger": ledger}


def summarize(trades: pd.DataFrame, ev: dict) -> dict:
    eps = 1e-9
    r = trades.R.astype(float)
    wins = int((r > eps).sum()); losses = int((r < -eps).sum()); be = int((r.abs() <= eps).sum())
    return {"trades": int(len(trades)), "wins": wins, "losses": losses, "breakeven": be, "win_rate_ex_be_pct": float(100 * wins / (wins + losses)) if wins + losses else 0.0, "avg_R": float(r.mean()) if len(r) else 0.0, "topstep_survived": bool(ev["survived"]), "net_profit": float(ev["net_profit"]), "final_balance": float(ev["final_balance"]), "minimum_mll_headroom": float(ev["minimum_headroom"]), "closed_equity_max_drawdown": float(ev["closed_equity_max_drawdown"]), "first_risk_dollars": float(ev["first_risk_dollars"]), "average_risk_dollars": float(ev["average_risk_dollars"]), "median_risk_dollars": float(ev["median_risk_dollars"]), "minimum_risk_dollars": float(ev["minimum_risk_dollars"]), "maximum_risk_dollars": float(ev["maximum_risk_dollars"]), "cap_hit_trades": int(ev["cap_hit_trades"]), "breach": ev["breach"]}


def main():
    d1 = b.load_1m(); d5 = b.make_5m(d1)
    results = []
    for label, start in b.STARTS.items():
        x1 = d1.loc[start:]; x5 = d5.loc[start:]
        trades = m17.simulate_m17(x1, x5)
        trades.to_csv(OUT / f"m20_{label}_trades.csv", index=False)
        ev = evaluate_dynamic20_capped900(trades, x1)
        ev["ledger"].to_csv(OUT / f"m20_{label}_ledger.csv", index=False)
        s = summarize(trades, ev); s["window"] = label; results.append(s)

    payload = {"method": "offline research simulation only", "strategy": "M17 unchanged", "only_change": "dynamic sizing: 1R dollars = min($900, 20% of realized balance minus current MLL)", "starting_balance": START_BALANCE, "starting_mll": START_BALANCE - MLL_DISTANCE, "starting_headroom": MLL_DISTANCE, "risk_fraction_of_headroom": RISK_FRACTION, "risk_cap_dollars": RISK_CAP, "starting_risk_dollars": min(RISK_CAP, RISK_FRACTION * MLL_DISTANCE), "mll_model": "real-time unrealized equity breach; EOD/session-transition MLL=max(previous, balance-4500), capped/locked at 150000", "sizing_caveat": "continuous normalized sizing; integer contract granularity, commissions and slippage not modeled", "results": results}
    (OUT / "m20_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = ["# M20 — M17 with 20% current MLL headroom risk, capped at $900", "", "At each entry: 1R dollars = min($900, 20% × (realized balance - current MLL)).", "Risk decreases after drawdown and can recover after gains, but can never exceed $900.", "", "| Window | Trades | W | L | BE | WR ex-BE | Avg R | Net $ | Final balance | Avg risk $ | Min risk $ | Max risk $ | Trades at $900 cap | Min MLL headroom $ | Survived |", "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|"]
    for r in results:
        lines.append(f"| {r['window']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['breakeven']} | {r['win_rate_ex_be_pct']:.2f}% | {r['avg_R']:.3f} | {r['net_profit']:.0f} | {r['final_balance']:.0f} | {r['average_risk_dollars']:.0f} | {r['minimum_risk_dollars']:.0f} | {r['maximum_risk_dollars']:.0f} | {r['cap_hit_trades']} | {r['minimum_mll_headroom']:.0f} | {r['topstep_survived']} |")
    report = "\n".join(lines) + "\n"
    (OUT / "m20_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
