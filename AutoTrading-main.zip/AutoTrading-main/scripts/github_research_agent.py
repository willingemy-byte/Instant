#!/usr/bin/env python3
"""Role-aware wrapper around the bounded AutoTrading coding worker.

Modes:
- lab: build deterministic parameter-search/backtest laboratory infrastructure.
- param: build provenance-preserving M-series parameter extraction infrastructure.

This remains research/backtesting only. It cannot add broker connectivity or live orders.
"""
from __future__ import annotations

import json
import os

import github_engine_agent as base

MODE = os.environ.get("AGENT_MODE", "lab").strip().lower()

# Give the research worker a little more direct context about the strongest/recent
# experiments without flooding the local model with every historical file.
for relative in (
    "scripts/run_m17_eb3_noentry_10_17ct.py",
    "scripts/run_m20_m17_dynamic20_capped900.py",
    "scripts/run_m21_m20_full_mgc_history.py",
    "scripts/run_m31_tp_ladder_matrix.py",
    "scripts/run_m32_m17_tp_ladder_full_history.py",
):
    if relative not in base.CONTEXT_FILES:
        base.CONTEXT_FILES.append(relative)


def role_system_prompt() -> str:
    common = (
        "You are a bounded coding worker inside the AutoTrading repository. "
        "This is OFFLINE research/backtesting only: never add brokerage connectivity, live order execution, "
        "credential handling, or autonomous real-money trading. Follow AGENTS.md and the GitHub issue literally. "
        "Preserve recovered historical baselines and make changes deterministic/reproducible. "
        "Return ONLY a JSON object with keys summary and files. files maps repository-relative paths to COMPLETE "
        "UTF-8 contents. You may modify only backtest/, tests/, docs/, or requirements.txt. "
        "Prefer the Python standard library unless a dependency is truly necessary. "
        "Explicitly document/test ambiguous intrabar stop/target behavior. "
    )
    if MODE == "lab":
        return common + (
            "Your mission IS to build parameter-exploration infrastructure. Parameter combinations and recipe generation "
            "are required, but do not silently promote an optimized recipe into a production baseline. Separate strategy "
            "RAW metrics from ACCOUNT/MLL metrics, rank survival before profit, and make 3m/6m/1y the official windows. "
            "Implement a practical V1 in this run: registry/config model, deterministic seeded recipe generation, batches/resume, "
            "scoring/reporting interfaces, cache/precompute interfaces, plugin/data-provider boundaries, and tests. "
            "If a full historical adapter cannot be completed safely in one bounded run, build the adapter contract plus baseline "
            "guard and fixture tests rather than faking results. Never fabricate a backtest result."
        )
    if MODE == "param":
        return common + (
            "Your mission is parameter archaeology, NOT optimization. Build a deterministic scanner/miner that reads the existing "
            "repository M-series scripts at runtime, extracts atomic configurable rules/constants and their provenance, deduplicates "
            "equivalent values conservatively, and emits machine-readable registry/recipe seeds. Never invent missing historical rules. "
            "Mark today's new hypotheses separately from legacy-derived values. Add tests using representative source snippets/fixtures."
        )
    raise RuntimeError(f"Unsupported AGENT_MODE: {MODE}")


def model_call(task: str, context: str, prior_tests: str, round_no: int) -> dict:
    system = role_system_prompt()
    user = (
        f"TASK (GitHub issue #{base.ISSUE_NUMBER}):\n{task}\n\n"
        f"ROLE: {MODE}\n"
        f"ROUND: {round_no}/{base.MAX_ROUNDS}\n"
        f"CURRENT REPOSITORY CONTEXT:\n{context}\n\n"
        f"LATEST TEST OUTPUT:\n{prior_tests or 'No new test output yet.'}\n\n"
        "Produce the smallest COMPLETE coherent file set that materially advances the issue and keeps the full test suite green."
    )
    messages = [{"role": "system", "content": system}, {"role": "user", "content": user}]

    if base.MODEL_PROVIDER == "ollama":
        payload = {
            "model": base.MODEL,
            "messages": messages,
            "stream": False,
            "format": "json",
            "options": {"temperature": 0.1, "num_ctx": 32768, "num_predict": 12000},
        }
        response = base.local_json(base.OLLAMA_URL, payload)
        content = response["message"]["content"]
    elif base.MODEL_PROVIDER == "github":
        payload = {
            "model": base.MODEL,
            "messages": messages,
            "temperature": 0.1,
            "max_tokens": 14000,
            "response_format": {"type": "json_object"},
        }
        response = base.http_json(base.GITHUB_MODEL_URL, method="POST", payload=payload)
        content = response["choices"][0]["message"]["content"]
    else:
        raise RuntimeError(f"Unsupported MODEL_PROVIDER: {base.MODEL_PROVIDER}")

    try:
        result = json.loads(content)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Model did not return valid JSON: {content[:2000]}") from exc
    if not isinstance(result.get("files"), dict):
        raise RuntimeError("Model response missing files object")
    return result


base.model_call = model_call

if __name__ == "__main__":
    raise SystemExit(base.main())
