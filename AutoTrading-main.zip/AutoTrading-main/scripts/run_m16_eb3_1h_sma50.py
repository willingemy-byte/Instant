from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

import run_m10_trailing_initial_risk as b
import run_m14_topstep_150k_risk300 as m14
import run_m15_topstep_1h_sma50 as m15

OUT = Path("artifacts")
OUT.mkdir(parents=True, exist_ok=True)


def eb3_signal(d5: pd.DataFrame, i: int) -> int:
    """Return +1 bullish EB3, -1 bearish EB3, 0 otherwise.

    M16 definition:
    - current 5m candle BODY must engulf the BODIES of each of the previous 3 candles;
    - bullish EB3 requires Close > Open;
    - bearish EB3 requires Close < Open;
    - wicks are ignored for engulf qualification.
    """
    if i < 3:
        return 0

    cur_o = float(d5.Open.iloc[i])
    cur_c = float(d5.Close.iloc[i])
    cur_lo = min(cur_o, cur_c)
    cur_hi = max(cur_o, cur_c)

    prev_lows = []
    prev_highs = []
    for j in range(i - 3, i):
        o = float(d5.Open.iloc[j])
        c = float(d5.Close.iloc[j])
        prev_lows.append(min(o, c))
        prev_highs.append(max(o, c))

    engulfs_three_bodies = cur_lo <= min(prev_lows) and cur_hi >= max(prev_highs)
    if not engulfs_three_bodies:
        return 0
    if cur_c > cur_o:
        return 1
    if cur_c < cur_o:
        return -1
    return 0


def simulate_m16(d1: pd.DataFrame, d5: pd.DataFrame) -> pd.DataFrame:
    h1_sma = m15.completed_h1_sma50(d1)
    if h1_sma.empty:
        return pd.DataFrame()

    pos = None
    rec = []
    idx5 = d5.index
    one_ns = pd.Timedelta(nanoseconds=1)

    for i in range(len(d5)):
        close_time = idx5[i] + pd.Timedelta(minutes=5)
        prev_close = idx5[i] if i == 0 else idx5[i - 1] + pd.Timedelta(minutes=5)

        if pos is not None:
            pos, done = m14.process_minutes_topstep(pos, d1.loc[prev_close:close_time - one_ns])
            if done is not None:
                rec.append(done)

        if pos is not None or not m14.entry_allowed(close_time):
            continue

        sig = eb3_signal(d5, i)
        if sig == 0:
            continue

        hist = h1_sma.loc[:close_time]
        if hist.empty:
            continue
        sma50 = float(hist.iloc[-1])

        entry = float(d5.Close.iloc[i])
        if sig == 1:
            if entry <= sma50:
                continue
            sl = float(d5.Low.iloc[i])
            risk = entry - sl
            if risk <= 0:
                continue
            pos = {
                "side": 1,
                "entry": entry,
                "entry_time": close_time,
                "risk": risk,
                "initial_stop": sl,
                "active_stop": sl,
                "tp": entry + 7.0 * risk,
                "best_price": entry,
                "phase2": False,
                "sma50_h1": sma50,
                "eb3_time": idx5[i],
                "eb3_open": float(d5.Open.iloc[i]),
                "eb3_high": float(d5.High.iloc[i]),
                "eb3_low": float(d5.Low.iloc[i]),
                "eb3_close": entry,
            }
        else:
            if entry >= sma50:
                continue
            sl = float(d5.High.iloc[i])
            risk = sl - entry
            if risk <= 0:
                continue
            pos = {
                "side": -1,
                "entry": entry,
                "entry_time": close_time,
                "risk": risk,
                "initial_stop": sl,
                "active_stop": sl,
                "tp": entry - 7.0 * risk,
                "best_price": entry,
                "phase2": False,
                "sma50_h1": sma50,
                "eb3_time": idx5[i],
                "eb3_open": float(d5.Open.iloc[i]),
                "eb3_high": float(d5.High.iloc[i]),
                "eb3_low": float(d5.Low.iloc[i]),
                "eb3_close": entry,
            }

    if pos is not None:
        pos, done = m14.process_minutes_topstep(pos, d1.loc[idx5[-1] + pd.Timedelta(minutes=5):])
        if done is not None:
            rec.append(done)

    return pd.DataFrame(rec)


def main():
    d1 = b.load_1m()
    d5 = b.make_5m(d1)

    results = []
    for label, start in b.STARTS.items():
        x1 = d1.loc[start:]
        x5 = d5.loc[start:]
        t = simulate_m16(x1, x5)
        t.to_csv(OUT / f"m16_topstep_{label}_trades.csv", index=False)
        risk_eval = m14.evaluate_mll(t, x1)
        risk_eval["ledger"].to_csv(OUT / f"m16_topstep_{label}_ledger.csv", index=False)
        s = m14.summarize(t, risk_eval)
        s["window"] = label
        results.append(s)

    payload = {
        "method": "offline research only",
        "baseline_management": "M13/M15: TP 7R; 1.5R trail to break-even, then 3R trailing with BE floor",
        "entry": {
            "timeframe": "5m",
            "bullish": "bullish candle body engulfs bodies of previous 3 candles; enter at EB3 close",
            "bearish": "bearish candle body engulfs bodies of previous 3 candles; enter at EB3 close",
            "long_stop": "low wick of EB3 candle",
            "short_stop": "high wick of EB3 candle",
        },
        "trend_filter": {
            "long": "entry close > latest completed 1h SMA50",
            "short": "entry close < latest completed 1h SMA50",
            "lookahead": "forbidden; completed 1h bars only",
        },
        "removed_entry_logic": "M15 five-wave/W-M exhaustion entry is not used in M16",
        "starting_balance": m14.START_BALANCE,
        "risk_dollars_per_trade": m14.RISK_DOLLARS,
        "mll_distance": m14.MLL_DISTANCE,
        "results": results,
    }
    (OUT / "m16_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = [
        "# M16 — EB3 direct entry + completed 1h SMA50 + M13 management",
        "",
        "Entry: current 5m BODY engulfs the BODIES of the previous 3 candles.",
        "Long only above latest completed 1h SMA50; short only below.",
        "Stop = EB3 wick extreme. TP = 7R. Trail = 1.5R to BE, then 3R with BE floor.",
        "M15 five-wave/W-M entry is removed for this test.",
        "",
        "| Window | Trades | W | L | BE | WR all | WR ex-BE | Avg R | Net $ | Final balance | Closed DD $ | Min MLL headroom $ | Survived |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|",
    ]
    for r in results:
        lines.append(
            f"| {r['window']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['breakeven']} | "
            f"{r['win_rate_all_pct']:.2f}% | {r['win_rate_ex_be_pct']:.2f}% | {r['avg_R']:.3f} | "
            f"{r['fixed_risk_net_profit']:.0f} | {r['final_balance']:.0f} | {r['closed_equity_max_drawdown']:.0f} | "
            f"{r['minimum_mll_headroom']:.0f} | {r['topstep_survived']} |"
        )
    report = "\n".join(lines) + "\n"
    (OUT / "m16_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
