import contextlib
import hashlib
import io
import runpy
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd
import yfinance as yf


M1_PATH = "strategy_variants/m1_eb3_persistent.py"
M2_PATH = "strategy_variants/m2_eb3_persistent_be1r.py"


def summarize(label, stats):
    trades = stats["_trades"].copy()
    pnl = trades["PnL"] if "PnL" in trades.columns else pd.Series(dtype=float)
    wins = int((pnl > 0).sum())
    losses = int((pnl < 0).sum())
    breakeven = int((pnl == 0).sum())

    print(f"\n=== {label} ===")
    print(f"Trades: {len(trades)}")
    print(f"Winning trades: {wins}")
    print(f"Losing trades: {losses}")
    print(f"Breakeven trades: {breakeven}")
    print(f"Win rate [%]: {stats['Win Rate [%]']}")
    print(f"Return [%]: {stats['Return [%]']}")
    print(f"Max. Drawdown [%]: {stats['Max. Drawdown [%]']}")
    print(f"Profit Factor: {stats['Profit Factor']}")
    return trades


def run_strategy(path, fixed_snapshot):
    original_download = yf.download

    def fixed_download(*args, **kwargs):
        return fixed_snapshot.copy(deep=True)

    yf.download = fixed_download
    captured = io.StringIO()
    try:
        with contextlib.redirect_stdout(captured):
            namespace = runpy.run_path(path, run_name="__fixed_snapshot_backtest__")
    finally:
        yf.download = original_download

    return namespace["stats"]


def entry_times(trades):
    if "EntryTime" not in trades.columns:
        return []
    return [pd.Timestamp(value) for value in trades["EntryTime"].tolist()]


def main():
    artifacts = Path("artifacts")
    artifacts.mkdir(exist_ok=True)

    # One and only one Yahoo download for both strategies.
    end_date = datetime.now()
    start_date = end_date - timedelta(days=59)
    snapshot = yf.download("GLD", start=start_date, end=end_date, interval="5m")
    snapshot = snapshot.dropna().copy()

    if snapshot.empty:
        raise RuntimeError("Yahoo returned an empty GLD 5-minute snapshot")

    snapshot_path = artifacts / "gld_5m_fixed_snapshot.csv"
    snapshot.to_csv(snapshot_path)
    sha256 = hashlib.sha256(snapshot_path.read_bytes()).hexdigest()

    print("=== FIXED DATASET ===")
    print(f"Rows: {len(snapshot)}")
    print(f"Start: {snapshot.index.min()}")
    print(f"End: {snapshot.index.max()}")
    print(f"CSV SHA256: {sha256}")

    m1_stats = run_strategy(M1_PATH, snapshot)
    m2_stats = run_strategy(M2_PATH, snapshot)

    m1_trades = summarize("M1 — no break-even", m1_stats)
    m2_trades = summarize("M2 — break-even at +1R", m2_stats)

    m1_entries = entry_times(m1_trades)
    m2_entries = entry_times(m2_trades)
    m1_set = set(m1_entries)
    m2_set = set(m2_entries)

    common = sorted(m1_set & m2_set)
    only_m1 = sorted(m1_set - m2_set)
    only_m2 = sorted(m2_set - m1_set)

    print("\n=== ENTRY PATH COMPARISON ===")
    print(f"Common entry timestamps: {len(common)}")
    print(f"M1-only entry timestamps: {len(only_m1)}")
    print(f"M2-only entry timestamps: {len(only_m2)}")

    if only_m1:
        print(f"First M1-only entry: {only_m1[0]}")
    if only_m2:
        print(f"First M2-only entry: {only_m2[0]}")

    # Find the first positional divergence as an easy debugging marker.
    first_positional_divergence = None
    for index, (m1_entry, m2_entry) in enumerate(zip(m1_entries, m2_entries), start=1):
        if m1_entry != m2_entry:
            first_positional_divergence = (index, m1_entry, m2_entry)
            break

    if first_positional_divergence:
        index, m1_entry, m2_entry = first_positional_divergence
        print(
            f"First positional divergence: trade #{index} | "
            f"M1={m1_entry} | M2={m2_entry}"
        )
    elif len(m1_entries) != len(m2_entries):
        print(
            "Entry sequences are identical through the shorter list; "
            "the trade-count difference starts afterward."
        )
    else:
        print("Entry timestamp sequences are identical.")


if __name__ == "__main__":
    main()
