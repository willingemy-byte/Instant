from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

import run_m10_trailing_initial_risk as b
import run_m17_eb3_noentry_10_17ct as m17
import run_m20_m17_dynamic20_capped900 as m20

OUT = Path("artifacts")
OUT.mkdir(parents=True, exist_ok=True)
SRC = Path("external/mgc-src/data")


def load_full_1m() -> pd.DataFrame:
    """Load every pinned daily MGC CSV available; unlike b.load_1m, no 1y cutoff."""
    frames = []
    for p in sorted(SRC.glob("ohlcv_MGC_*.csv")):
        x = pd.read_csv(p)
        if "timestamp" not in x.columns:
            continue
        x["timestamp"] = pd.to_datetime(x["timestamp"], utc=True)
        frames.append(x)
    if not frames:
        raise RuntimeError("No full-history MGC 1m files found")
    d = pd.concat(frames, ignore_index=True)
    d = d.drop_duplicates("timestamp", keep="last").sort_values("timestamp")
    d = d.set_index("timestamp")
    d = d.rename(columns={"open":"Open","high":"High","low":"Low","close":"Close","volume":"Volume"})
    return d[["Open","High","Low","Close","Volume"]].dropna().copy()


def longest_loss_streak(r: pd.Series) -> int:
    best = cur = 0
    for x in r.astype(float):
        if x < -1e-9:
            cur += 1
            best = max(best, cur)
        else:
            cur = 0
    return best


def period_stats(trades: pd.DataFrame, ledger: pd.DataFrame, freq: str) -> list[dict]:
    if trades.empty or ledger.empty:
        return []
    t = trades.copy().reset_index(drop=True)
    l = ledger.copy().reset_index(drop=True)
    n = min(len(t), len(l))
    t = t.iloc[:n].copy(); l = l.iloc[:n].copy()
    t["entry_time"] = pd.to_datetime(t["entry_time"], utc=True)
    l["entry_time"] = pd.to_datetime(l["entry_time"], utc=True)
    if freq == "year":
        t["bucket"] = t["entry_time"].dt.year.astype(str)
        l["bucket"] = l["entry_time"].dt.year.astype(str)
    elif freq == "quarter":
        t["bucket"] = t["entry_time"].dt.tz_localize(None).dt.to_period("Q").astype(str)
        l["bucket"] = l["entry_time"].dt.tz_localize(None).dt.to_period("Q").astype(str)
    else:
        raise ValueError(freq)

    out = []
    for bucket, g in t.groupby("bucket", sort=True):
        r = g["R"].astype(float)
        wins = int((r > 1e-9).sum()); losses = int((r < -1e-9).sum()); be = int((r.abs() <= 1e-9).sum())
        gl = l[l["bucket"] == bucket]
        out.append({
            "period": bucket, "trades": int(len(g)), "wins": wins, "losses": losses, "breakeven": be,
            "win_rate_ex_be_pct": float(100*wins/(wins+losses)) if wins+losses else 0.0,
            "avg_R": float(r.mean()) if len(r) else 0.0, "sum_R": float(r.sum()),
            "net_profit_dollars": float(gl["pnl_dollars"].astype(float).sum()) if not gl.empty else 0.0,
            "average_risk_dollars": float(gl["risk_dollars"].astype(float).mean()) if not gl.empty else 0.0,
            "minimum_risk_dollars": float(gl["risk_dollars"].astype(float).min()) if not gl.empty else 0.0,
            "maximum_risk_dollars": float(gl["risk_dollars"].astype(float).max()) if not gl.empty else 0.0,
            "longest_loss_streak": longest_loss_streak(r),
        })
    return out


def main():
    d1 = load_full_1m()
    d5 = b.make_5m(d1)
    data_start = str(d1.index.min()); data_end = str(d1.index.max())
    elapsed_days = float((d1.index.max()-d1.index.min())/pd.Timedelta(days=1)); elapsed_years = elapsed_days/365.2425

    trades = m17.simulate_m17(d1, d5)
    trades.to_csv(OUT/"m21_full_history_trades.csv", index=False)
    ev = m20.evaluate_dynamic20_capped900(trades, d1)
    ledger = ev["ledger"]; ledger.to_csv(OUT/"m21_full_history_ledger.csv", index=False)
    summary = m20.summarize(trades, ev)
    summary.update({"data_start":data_start,"data_end":data_end,"elapsed_days":elapsed_days,"elapsed_years":elapsed_years,
                    "longest_loss_streak":longest_loss_streak(trades["R"] if not trades.empty else pd.Series(dtype=float))})
    annual = period_stats(trades, ledger, "year"); quarterly = period_stats(trades, ledger, "quarter")

    payload = {"method":"offline research simulation only","strategy":"M20 unchanged",
               "only_change":"window extended to every daily CSV in pinned MGC source","data_start":data_start,"data_end":data_end,
               "elapsed_years":elapsed_years,"summary":summary,"annual":annual,"quarterly":quarterly,
               "caveats":["continuous normalized sizing; integer MGC contract granularity not modeled","commissions and slippage not modeled","holiday early closes not modeled","continuous research series uses source-defined rollover"]}
    (OUT/"m21_results.json").write_text(json.dumps(payload,indent=2),encoding="utf-8")

    s=summary
    lines=["# M21 — M20 over full available MGC history","",f"Data: {data_start} -> {data_end} (~{elapsed_years:.2f} years)",
           "No strategy or sizing parameter changed versus M20.","",
           "| Trades | W | L | BE | WR ex-BE | Avg R | Net $ | Final balance | Avg risk $ | Min risk $ | Max risk $ | Trades at $900 | Min MLL headroom $ | Longest loss streak | Survived |",
           "|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|",
           f"| {s['trades']} | {s['wins']} | {s['losses']} | {s['breakeven']} | {s['win_rate_ex_be_pct']:.2f}% | {s['avg_R']:.3f} | {s['net_profit']:.0f} | {s['final_balance']:.0f} | {s['average_risk_dollars']:.0f} | {s['minimum_risk_dollars']:.0f} | {s['maximum_risk_dollars']:.0f} | {s['cap_hit_trades']} | {s['minimum_mll_headroom']:.0f} | {s['longest_loss_streak']} | {s['topstep_survived']} |","","## By calendar year","",
           "| Year | Trades | W | L | BE | WR ex-BE | Avg R | Sum R | Net $ | Avg risk $ | Loss streak |","|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for r in annual:
        lines.append(f"| {r['period']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['breakeven']} | {r['win_rate_ex_be_pct']:.2f}% | {r['avg_R']:.3f} | {r['sum_R']:.1f} | {r['net_profit_dollars']:.0f} | {r['average_risk_dollars']:.0f} | {r['longest_loss_streak']} |")
    lines += ["","## By quarter","","| Quarter | Trades | WR ex-BE | Avg R | Sum R | Net $ | Avg risk $ | Loss streak |","|---|---:|---:|---:|---:|---:|---:|---:|"]
    for r in quarterly:
        lines.append(f"| {r['period']} | {r['trades']} | {r['win_rate_ex_be_pct']:.2f}% | {r['avg_R']:.3f} | {r['sum_R']:.1f} | {r['net_profit_dollars']:.0f} | {r['average_risk_dollars']:.0f} | {r['longest_loss_streak']} |")
    report="\n".join(lines)+"\n"; (OUT/"m21_report.md").write_text(report,encoding="utf-8"); print(report)

if __name__=="__main__": main()
