from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

import run_m10_trailing_initial_risk as b
import run_m14_topstep_150k_risk300 as m14
import run_m16_eb3_1h_sma50 as m16

OUT = Path("artifacts")
OUT.mkdir(parents=True, exist_ok=True)

BASE_ENTRY_ALLOWED = m14.entry_allowed


def entry_allowed_m17(ts: pd.Timestamp) -> bool:
    """M16 hours plus no new weekday entries from 10:00 to 17:00 CT.

    Existing positions are NOT closed at 10:00; they keep normal M16/M13
    stop/TP management and are still forcibly flattened at 15:10 CT by the
    Topstep-style session rule.
    """
    if not BASE_ENTRY_ALLOWED(ts):
        return False
    x = m14._ct(ts)
    if x.weekday() <= 4:
        hm = x.hour * 60 + x.minute
        if 10 * 60 <= hm < 17 * 60:
            return False
    return True


def simulate_m17(d1: pd.DataFrame, d5: pd.DataFrame) -> pd.DataFrame:
    original = m14.entry_allowed
    m14.entry_allowed = entry_allowed_m17
    try:
        return m16.simulate_m16(d1, d5)
    finally:
        m14.entry_allowed = original


def main():
    d1 = b.load_1m()
    d5 = b.make_5m(d1)

    results = []
    for label, start in b.STARTS.items():
        x1 = d1.loc[start:]
        x5 = d5.loc[start:]
        t = simulate_m17(x1, x5)
        t.to_csv(OUT / f"m17_topstep_{label}_trades.csv", index=False)
        risk_eval = m14.evaluate_mll(t, x1)
        risk_eval["ledger"].to_csv(OUT / f"m17_topstep_{label}_ledger.csv", index=False)
        s = m14.summarize(t, risk_eval)
        s["window"] = label
        results.append(s)

    payload = {
        "method": "offline research only",
        "baseline": "M16",
        "only_change": "no new entries Monday-Friday 10:00 <= CT < 17:00",
        "existing_positions_at_10": "remain open under normal stop/TP management",
        "forced_flat": "15:10 CT Topstep-style rule remains",
        "entry": "5m EB3 body engulfs previous 3 bodies; long above completed 1h SMA50, short below",
        "management": "initial stop at EB3 wick; TP 7R; 1.5R trailing distance until BE, then 3R trailing distance with BE floor",
        "starting_balance": m14.START_BALANCE,
        "risk_dollars_per_trade": m14.RISK_DOLLARS,
        "mll_distance": m14.MLL_DISTANCE,
        "results": results,
    }
    (OUT / "m17_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = [
        "# M17 — M16 + no new entries 10:00–17:00 CT weekdays",
        "",
        "Existing positions are not closed at 10:00; normal management continues.",
        "Topstep-style forced flat at 15:10 CT remains.",
        "",
        "| Window | Trades | W | L | BE | WR ex-BE | Avg R | Net $ | Closed DD $ | Min MLL headroom $ | Survived |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|",
    ]
    for r in results:
        lines.append(
            f"| {r['window']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['breakeven']} | "
            f"{r['win_rate_ex_be_pct']:.2f}% | {r['avg_R']:.3f} | {r['fixed_risk_net_profit']:.0f} | "
            f"{r['closed_equity_max_drawdown']:.0f} | {r['minimum_mll_headroom']:.0f} | {r['topstep_survived']} |"
        )
    report = "\n".join(lines) + "\n"
    (OUT / "m17_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
