from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

import run_m10_trailing_initial_risk as b
import run_m14_topstep_150k_risk300 as m14
import run_m15_topstep_1h_sma50 as m15
import run_m16_eb3_1h_sma50 as m16
import run_m17_eb3_noentry_10_17ct as m17
import run_m21_m20_full_mgc_history as m21

OUT = Path("artifacts/m32_m17_tp_ladder")
OUT.mkdir(parents=True, exist_ok=True)
ONE_NS = pd.Timedelta(nanoseconds=1)
FIXED_RISK_DOLLARS = 300.0
START_BALANCE = 150_000.0


def price_at_r(pos: dict, r_mult: float) -> float:
    return float(pos["entry"]) + int(pos["side"]) * float(pos["risk"]) * float(r_mult)


def move_r(pos: dict, price: float) -> float:
    return ((float(price) - float(pos["entry"])) / float(pos["risk"])) * int(pos["side"])


def finish(pos: dict, price: float, ts: pd.Timestamp, reason: str) -> dict:
    remaining = float(pos["remaining_frac"])
    total_r = float(pos["realized_R"]) + remaining * move_r(pos, price)
    return {
        **pos,
        "exit": float(price),
        "exit_time": ts,
        "reason": reason,
        "R": float(total_r),
        "remaining_frac_at_exit": remaining,
    }


def process_minutes_m32(pos: dict | None, mins: pd.DataFrame) -> tuple[dict | None, dict | None]:
    """M17/M13 management plus M31-style 50/25/25 partial targets.

    Everything in M17 is preserved:
    - same initial EB3 wick stop
    - same M13 phase-1 1.5R trailing logic to BE
    - same phase-2 3R trailing logic with BE floor
    - same Topstep 15:10 CT forced flat

    Only addition: realize 50% at +1R, 25% at +3R, final 25% at +7R.
    Stop gets priority when stop and favorable target are both touched inside the
    same 1-minute bar, matching the conservative ordering used in M31.
    """
    if pos is None or mins.empty:
        return pos, None

    eps = 1e-12
    for ts, bar in mins.iterrows():
        if m14.force_flat_now(ts):
            return None, finish(pos, float(bar.Open), ts, "topstep_1510_flat")

        side = int(pos["side"])
        stop = float(pos["active_stop"])
        o = float(bar.Open)
        h = float(bar.High)
        l = float(bar.Low)

        # Conservative priority: stop known before this minute is evaluated first.
        if side == 1:
            if o <= stop:
                return None, finish(pos, o, ts, "gap_stop")
            if l <= stop:
                return None, finish(pos, stop, ts, "stop")
        else:
            if o >= stop:
                return None, finish(pos, o, ts, "gap_stop")
            if h >= stop:
                return None, finish(pos, stop, ts, "stop")

        # TP1 = +1R, close 50% of original position.
        if not bool(pos["hit_tp1"]):
            lvl1 = price_at_r(pos, 1.0)
            reached = (o >= lvl1 or h >= lvl1) if side == 1 else (o <= lvl1 or l <= lvl1)
            if reached:
                pos["hit_tp1"] = True
                pos["realized_R"] += 0.50 * 1.0
                pos["remaining_frac"] -= 0.50

        # TP2 = +3R, close 25% of original position.
        if bool(pos["hit_tp1"]) and not bool(pos["hit_tp2"]):
            lvl2 = price_at_r(pos, 3.0)
            reached = (o >= lvl2 or h >= lvl2) if side == 1 else (o <= lvl2 or l <= lvl2)
            if reached:
                pos["hit_tp2"] = True
                pos["realized_R"] += 0.25 * 3.0
                pos["remaining_frac"] -= 0.25

        # TP3 = +7R, close final 25% of original position. Full ladder = +3R.
        if bool(pos["hit_tp2"]) and not bool(pos["hit_tp3"]):
            lvl3 = price_at_r(pos, 7.0)
            reached = (o >= lvl3 or h >= lvl3) if side == 1 else (o <= lvl3 or l <= lvl3)
            if reached:
                pos["hit_tp3"] = True
                pos["realized_R"] += float(pos["remaining_frac"]) * 7.0
                pos["remaining_frac"] = 0.0
                return None, finish(pos, lvl3, ts, "tp3_7R")

        # Preserve M17/M13 trailing exactly, applied after this minute for future bars.
        entry = float(pos["entry"])
        risk = float(pos["risk"])
        if side == 1:
            pos["best_price"] = max(float(pos["best_price"]), h)
            if not bool(pos.get("phase2", False)):
                candidate = float(pos["best_price"]) - 1.5 * risk
                pos["active_stop"] = max(float(pos["active_stop"]), min(entry, candidate))
                if float(pos["active_stop"]) >= entry - eps:
                    pos["active_stop"] = entry
                    pos["phase2"] = True
            else:
                candidate = float(pos["best_price"]) - 3.0 * risk
                pos["active_stop"] = max(entry, float(pos["active_stop"]), candidate)
        else:
            pos["best_price"] = min(float(pos["best_price"]), l)
            if not bool(pos.get("phase2", False)):
                candidate = float(pos["best_price"]) + 1.5 * risk
                pos["active_stop"] = min(float(pos["active_stop"]), max(entry, candidate))
                if float(pos["active_stop"]) <= entry + eps:
                    pos["active_stop"] = entry
                    pos["phase2"] = True
            else:
                candidate = float(pos["best_price"]) + 3.0 * risk
                pos["active_stop"] = min(entry, float(pos["active_stop"]), candidate)

    return pos, None


def simulate_m32(d1: pd.DataFrame, d5: pd.DataFrame) -> pd.DataFrame:
    h1_sma = m15.completed_h1_sma50(d1)
    if h1_sma.empty:
        return pd.DataFrame()

    pos = None
    rec: list[dict] = []
    idx5 = d5.index

    for i in range(len(d5)):
        close_time = idx5[i] + pd.Timedelta(minutes=5)
        prev_close = idx5[i] if i == 0 else idx5[i - 1] + pd.Timedelta(minutes=5)

        if pos is not None:
            pos, done = process_minutes_m32(pos, d1.loc[prev_close:close_time - ONE_NS])
            if done is not None:
                rec.append(done)

        if pos is not None or not m17.entry_allowed_m17(close_time):
            continue

        sig = m16.eb3_signal(d5, i)
        if sig == 0:
            continue

        hist = h1_sma.loc[:close_time]
        if hist.empty:
            continue
        sma50 = float(hist.iloc[-1])
        entry = float(d5.Close.iloc[i])

        if sig == 1:
            if entry <= sma50:
                continue
            sl = float(d5.Low.iloc[i])
            risk = entry - sl
            if risk <= 0:
                continue
        else:
            if entry >= sma50:
                continue
            sl = float(d5.High.iloc[i])
            risk = sl - entry
            if risk <= 0:
                continue

        pos = {
            "side": int(sig),
            "entry": entry,
            "entry_time": close_time,
            "risk": risk,
            "initial_stop": sl,
            "active_stop": sl,
            "best_price": entry,
            "phase2": False,
            "sma50_h1": sma50,
            "eb3_time": idx5[i],
            "eb3_open": float(d5.Open.iloc[i]),
            "eb3_high": float(d5.High.iloc[i]),
            "eb3_low": float(d5.Low.iloc[i]),
            "eb3_close": entry,
            "remaining_frac": 1.0,
            "realized_R": 0.0,
            "hit_tp1": False,
            "hit_tp2": False,
            "hit_tp3": False,
        }

    if pos is not None:
        pos, done = process_minutes_m32(pos, d1.loc[idx5[-1] + pd.Timedelta(minutes=5):])
        if done is not None:
            rec.append(done)

    return pd.DataFrame(rec)


def longest_loss_streak(r: pd.Series) -> int:
    best = cur = 0
    for x in r.astype(float):
        if x < -1e-9:
            cur += 1
            best = max(best, cur)
        else:
            cur = 0
    return best


def closed_drawdown_dollars(r: pd.Series) -> float:
    if r.empty:
        return 0.0
    eq = START_BALANCE + r.astype(float).cumsum() * FIXED_RISK_DOLLARS
    peak = eq.cummax()
    return float((eq - peak).min())


def summarize(trades: pd.DataFrame) -> dict:
    if trades.empty:
        return {
            "trades": 0, "wins": 0, "losses": 0, "breakeven": 0,
            "win_rate_ex_be_pct": 0.0, "avg_R": 0.0, "sum_R": 0.0,
            "fixed_risk_profit_300": 0.0, "closed_drawdown_300": 0.0,
            "longest_loss_streak": 0,
        }
    r = trades["R"].astype(float)
    wins = int((r > 1e-9).sum())
    losses = int((r < -1e-9).sum())
    be = int((r.abs() <= 1e-9).sum())
    return {
        "trades": int(len(trades)),
        "wins": wins,
        "losses": losses,
        "breakeven": be,
        "win_rate_ex_be_pct": float(100 * wins / (wins + losses)) if wins + losses else 0.0,
        "avg_R": float(r.mean()),
        "sum_R": float(r.sum()),
        "fixed_risk_profit_300": float(r.sum() * FIXED_RISK_DOLLARS),
        "closed_drawdown_300": closed_drawdown_dollars(r),
        "longest_loss_streak": longest_loss_streak(r),
    }


def annual_stats(trades: pd.DataFrame) -> list[dict]:
    if trades.empty:
        return []
    t = trades.copy()
    t["entry_time"] = pd.to_datetime(t["entry_time"], utc=True)
    t["year"] = t["entry_time"].dt.year
    rows = []
    for year, g in t.groupby("year", sort=True):
        s = summarize(g)
        s["year"] = int(year)
        if "hit_tp1" in g.columns:
            s["tp1_hits"] = int(g["hit_tp1"].astype(bool).sum())
            s["tp2_hits"] = int(g["hit_tp2"].astype(bool).sum())
            s["tp3_hits"] = int(g["hit_tp3"].astype(bool).sum())
        rows.append(s)
    return rows


def main() -> None:
    d1 = m21.load_full_1m()
    d5 = b.make_5m(d1)
    data_start = str(d1.index.min())
    data_end = str(d1.index.max())
    elapsed_years = float((d1.index.max() - d1.index.min()) / pd.Timedelta(days=365.2425))

    # Exact baseline on the exact same full-history dataset.
    baseline = m17.simulate_m17(d1, d5)
    ladder = simulate_m32(d1, d5)

    baseline.to_csv(OUT / "m17_baseline_full_history_trades.csv", index=False)
    ladder.to_csv(OUT / "m32_m17_tp_ladder_trades.csv", index=False)

    bsum = summarize(baseline)
    lsum = summarize(ladder)
    if not ladder.empty:
        lsum.update({
            "tp1_hits": int(ladder["hit_tp1"].astype(bool).sum()),
            "tp2_hits": int(ladder["hit_tp2"].astype(bool).sum()),
            "tp3_hits": int(ladder["hit_tp3"].astype(bool).sum()),
            "tp1_hit_pct": float(100 * ladder["hit_tp1"].astype(bool).mean()),
            "tp2_hit_pct": float(100 * ladder["hit_tp2"].astype(bool).mean()),
            "tp3_hit_pct": float(100 * ladder["hit_tp3"].astype(bool).mean()),
        })

    payload = {
        "method": "offline research simulation only",
        "experiment": "M32",
        "baseline": "M17",
        "only_change": "add M31 TP ladder: 50% at +1R, 25% at +3R, 25% at +7R",
        "unchanged": [
            "5m EB3 body engulfs previous 3 candle bodies",
            "latest completed 1h SMA50 directional filter",
            "M17 no-new-entry weekdays 10:00-17:00 CT",
            "Topstep-style 15:10 CT forced flat",
            "initial stop at EB3 wick",
            "M13 1.5R trail to BE then 3R trail with BE floor",
        ],
        "fixed_dollar_comparison": "$300 per initial R; no dynamic sizing",
        "data_start": data_start,
        "data_end": data_end,
        "elapsed_years": elapsed_years,
        "baseline_m17": bsum,
        "m32_ladder": lsum,
        "baseline_annual": annual_stats(baseline),
        "m32_annual": annual_stats(ladder),
        "caveats": [
            "commissions and slippage not modeled",
            "continuous research series uses source-defined rollover",
            "fixed $300/R comparison is used so money-management does not obscure strategy expectancy",
        ],
    }
    (OUT / "m32_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = [
        "# M32 — M17 + TP1/TP2/TP3 ladder over full MGC history",
        "",
        f"Data: {data_start} -> {data_end} (~{elapsed_years:.2f} years)",
        "Only change from M17: 50% at +1R, 25% at +3R, final 25% at +7R.",
        "All M17 entry filters, stop logic, M13 trailing and time rules are unchanged.",
        "Dollar comparison uses fixed $300 per initial R; dynamic sizing is intentionally excluded.",
        "",
        "| Version | Trades | W | L | BE | WR ex-BE | Avg R | Sum R | Profit @ $300/R | Closed DD @ $300/R | Loss streak |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
        f"| M17 baseline | {bsum['trades']} | {bsum['wins']} | {bsum['losses']} | {bsum['breakeven']} | {bsum['win_rate_ex_be_pct']:.2f}% | {bsum['avg_R']:.3f} | {bsum['sum_R']:.1f} | ${bsum['fixed_risk_profit_300']:,.0f} | ${bsum['closed_drawdown_300']:,.0f} | {bsum['longest_loss_streak']} |",
        f"| M32 M17 + ladder | {lsum['trades']} | {lsum['wins']} | {lsum['losses']} | {lsum['breakeven']} | {lsum['win_rate_ex_be_pct']:.2f}% | {lsum['avg_R']:.3f} | {lsum['sum_R']:.1f} | ${lsum['fixed_risk_profit_300']:,.0f} | ${lsum['closed_drawdown_300']:,.0f} | {lsum['longest_loss_streak']} |",
        "",
    ]
    if not ladder.empty:
        lines += [
            "## Ladder reach",
            "",
            f"- TP1 +1R: {lsum['tp1_hits']} trades ({lsum['tp1_hit_pct']:.2f}%)",
            f"- TP2 +3R: {lsum['tp2_hits']} trades ({lsum['tp2_hit_pct']:.2f}%)",
            f"- TP3 +7R: {lsum['tp3_hits']} trades ({lsum['tp3_hit_pct']:.2f}%)",
            "",
        ]

    lines += [
        "## M32 by calendar year",
        "",
        "| Year | Trades | WR ex-BE | Avg R | Sum R | Profit @ $300/R | TP1 | TP2 | TP3 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in payload["m32_annual"]:
        lines.append(
            f"| {r['year']} | {r['trades']} | {r['win_rate_ex_be_pct']:.2f}% | {r['avg_R']:.3f} | {r['sum_R']:.1f} | "
            f"${r['fixed_risk_profit_300']:,.0f} | {r.get('tp1_hits', 0)} | {r.get('tp2_hits', 0)} | {r.get('tp3_hits', 0)} |"
        )

    report = "\n".join(lines) + "\n"
    (OUT / "m32_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
