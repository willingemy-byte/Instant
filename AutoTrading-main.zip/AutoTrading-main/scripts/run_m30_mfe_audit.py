from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

import run_m10_trailing_initial_risk as b
import run_m21_m20_full_mgc_history as m21
import run_m30_fib_358_entryonly_trailing10_tp7 as m30

OUT = Path('artifacts/m30_mfe_audit')
OUT.mkdir(parents=True, exist_ok=True)


def trade_mfe_r(row: pd.Series, d1: pd.DataFrame) -> float:
    entry = float(row['entry'])
    risk = float(row['risk'])
    side = int(row['side'])
    et = pd.Timestamp(row['entry_time'])
    xt = pd.Timestamp(row['exit_time'])

    # Conservative: exclude the 1m exit bar for stop/forced-flat exits because
    # OHLC does not reveal whether the favorable extreme happened before or after
    # the exit inside that minute. For TP exits, the trade necessarily reached 7R.
    reason = str(row['reason'])
    pre_exit = d1.loc[(d1.index >= et) & (d1.index < xt)]

    if pre_exit.empty:
        mfe = 0.0
    elif side == 1:
        mfe = (float(pre_exit['High'].max()) - entry) / risk
    else:
        mfe = (entry - float(pre_exit['Low'].min())) / risk

    if reason in {'tp7', 'gap_tp7'}:
        mfe = max(mfe, float(row['R']), 7.0)

    return max(0.0, float(mfe))


def main() -> None:
    d1 = m21.load_full_1m()
    d5 = b.make_5m(d1)
    trades, _ = m30.simulate_m30(d1, d5)
    if trades.empty:
        raise RuntimeError('No M30 trades')

    trades = trades.copy()
    trades['mfe_R'] = trades.apply(lambda r: trade_mfe_r(r, d1), axis=1)
    trades['pct_of_TP7'] = 100.0 * trades['mfe_R'] / 7.0
    trades['pct_of_TP7_capped'] = trades['pct_of_TP7'].clip(upper=100.0)
    trades.to_csv(OUT / 'm30_trades_with_mfe.csv', index=False)

    thresholds = [10, 25, 50, 75, 90, 100]
    reached = {
        str(p): {
            'count': int((trades['pct_of_TP7'] >= p).sum()),
            'pct_trades': float(100.0 * (trades['pct_of_TP7'] >= p).mean()),
        }
        for p in thresholds
    }

    non_tp = trades[~trades['reason'].isin(['tp7', 'gap_tp7'])].copy()
    trailing = trades[trades['reason'].isin(['trailing10_stop', 'gap_trailing10_stop'])].copy()

    summary = {
        'method': 'offline research simulation only; conservative MFE excludes exit minute except TP exits',
        'trades': int(len(trades)),
        'mean_mfe_R': float(trades['mfe_R'].mean()),
        'median_mfe_R': float(trades['mfe_R'].median()),
        'mean_pct_of_TP7': float(trades['pct_of_TP7_capped'].mean()),
        'median_pct_of_TP7': float(trades['pct_of_TP7_capped'].median()),
        'non_tp_mean_pct_of_TP7': float(non_tp['pct_of_TP7_capped'].mean()),
        'non_tp_median_pct_of_TP7': float(non_tp['pct_of_TP7_capped'].median()),
        'trailing_exit_mean_pct_of_TP7': float(trailing['pct_of_TP7_capped'].mean()),
        'trailing_exit_median_pct_of_TP7': float(trailing['pct_of_TP7_capped'].median()),
        'reached_thresholds': reached,
        'quantiles_pct_of_TP7': {
            'p10': float(trades['pct_of_TP7_capped'].quantile(0.10)),
            'p25': float(trades['pct_of_TP7_capped'].quantile(0.25)),
            'p50': float(trades['pct_of_TP7_capped'].quantile(0.50)),
            'p75': float(trades['pct_of_TP7_capped'].quantile(0.75)),
            'p90': float(trades['pct_of_TP7_capped'].quantile(0.90)),
        },
    }

    (OUT / 'm30_mfe_summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')

    print('# M30 MFE audit')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
