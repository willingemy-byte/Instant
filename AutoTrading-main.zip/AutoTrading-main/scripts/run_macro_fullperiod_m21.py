from __future__ import annotations

import itertools
import json
import math
from pathlib import Path
from datetime import datetime, timezone

import numpy as np
import pandas as pd
from scipy.stats import pearsonr, spearmanr

import run_m21_m20_full_mgc_history as m21
import run_m17_eb3_noentry_10_17ct as m17
import run_m20_m17_dynamic20_capped900 as m20
import run_macro_leadlag as macro

OUT = Path("artifacts/macro_fullperiod_m21")
OUT.mkdir(parents=True, exist_ok=True)
START = pd.Timestamp("2023-01-02", tz="UTC")
END = pd.Timestamp("2026-03-23 23:59:59", tz="UTC")
LAGS = list(range(-26, 27))


def clean_weekly(s: pd.Series) -> pd.Series:
    vals = pd.to_numeric(pd.Series(s.to_numpy()), errors="coerce").to_numpy()
    idx = pd.to_datetime(s.index, errors="coerce", utc=True)
    good = (~pd.isna(idx)) & (~pd.isna(vals))
    if not bool(np.any(good)):
        return pd.Series(dtype=float, name=s.name)
    clean = pd.Series(vals[good], index=pd.DatetimeIndex(idx[good]), name=s.name)
    clean = clean[~clean.index.duplicated(keep="last")].sort_index()
    clean = clean.loc[(clean.index >= START) & (clean.index <= END)]
    return clean.resample("W-FRI").last().dropna()


def regenerate_strategy() -> tuple[pd.DataFrame, pd.DataFrame]:
    d1 = m21.load_full_1m()
    d1 = d1.loc[(d1.index >= START) & (d1.index <= END)]
    d5 = m21.b.make_5m(d1)
    trades = m17.simulate_m17(d1, d5).copy()
    trades["entry_time"] = pd.to_datetime(trades["entry_time"], utc=True)
    trades = trades[(trades["entry_time"] >= START) & (trades["entry_time"] <= END)].reset_index(drop=True)
    ev = m20.evaluate_dynamic20_capped900(trades, d1)
    ledger = ev["ledger"].copy().reset_index(drop=True)
    ledger["entry_time"] = pd.to_datetime(ledger["entry_time"], utc=True)
    return trades, ledger


def strategy_weekly(trades: pd.DataFrame, ledger: pd.DataFrame) -> pd.DataFrame:
    t = trades.copy().reset_index(drop=True)
    l = ledger.copy().reset_index(drop=True)
    n = min(len(t), len(l))
    t = t.iloc[:n].copy()
    l = l.iloc[:n].copy()
    t["entry_time"] = pd.to_datetime(t["entry_time"], utc=True)
    l["entry_time"] = pd.to_datetime(l["entry_time"], utc=True)
    t["week"] = t["entry_time"].dt.to_period("W-FRI").dt.end_time.dt.tz_localize("UTC").dt.normalize()
    l["week"] = l["entry_time"].dt.to_period("W-FRI").dt.end_time.dt.tz_localize("UTC").dt.normalize()

    rows = []
    for week, g in t.groupby("week", sort=True):
        r = pd.to_numeric(g["R"], errors="coerce").dropna()
        wins = int((r > 1e-9).sum())
        losses = int((r < -1e-9).sum())
        be = int((r.abs() <= 1e-9).sum())
        gl = l[l["week"] == week]
        rows.append({
            "date": week,
            "STRAT_TRADES": int(len(g)),
            "STRAT_WINS": wins,
            "STRAT_LOSSES": losses,
            "STRAT_BE": be,
            "STRAT_WINRATE_EX_BE": float(wins / (wins + losses)) if wins + losses else np.nan,
            "STRAT_SUM_R": float(r.sum()) if len(r) else 0.0,
            "STRAT_AVG_R": float(r.mean()) if len(r) else np.nan,
            "STRAT_PNL_DOLLARS": float(pd.to_numeric(gl.get("pnl_dollars"), errors="coerce").sum()) if not gl.empty else 0.0,
            "STRAT_AVG_RISK_DOLLARS": float(pd.to_numeric(gl.get("risk_dollars"), errors="coerce").mean()) if not gl.empty else np.nan,
        })
    if not rows:
        return pd.DataFrame()
    return pd.DataFrame(rows).set_index("date").sort_index()


def fetch_macro_levels() -> tuple[pd.DataFrame, list[dict]]:
    errors = []
    fetchers = {
        "FED_TREAST": lambda: macro.fetch_fred("TREAST"),
        "FED_WALCL": lambda: macro.fetch_fred("WALCL"),
        "BOC_GOC_BONDS": lambda: macro.fetch_boc("V36613"),
        "ECB_MONPOL_SECURITIES": lambda: macro.fetch_ecb("W.U2.C.A070100.U2.EUR"),
        "DXY": lambda: macro.fetch_market("DX-Y.NYB", "DXY"),
        "GOLD": lambda: macro.fetch_market("GC=F", "GOLD"),
        "WTI": lambda: macro.fetch_market("CL=F", "WTI"),
        "BRENT": lambda: macro.fetch_market("BZ=F", "BRENT"),
    }
    levels = {}
    for name, fn in fetchers.items():
        try:
            s = clean_weekly(fn())
            if s.empty:
                raise RuntimeError("zero valid weekly observations in exact M21 window")
            levels[name] = s.rename(name)
        except Exception as exc:
            errors.append({"series": name, "error": str(exc)})
    if "DXY" not in levels or "GOLD" not in levels:
        raise RuntimeError(f"Required market series unavailable: {errors}")
    return pd.concat(levels.values(), axis=1).sort_index(), errors


def descriptive_table(panel: pd.DataFrame, freq: str) -> pd.DataFrame:
    x = panel.copy()
    if freq == "year":
        keys = x.index.year.astype(str)
    elif freq == "quarter":
        keys = x.index.tz_localize(None).to_period("Q").astype(str)
    elif freq == "month":
        keys = x.index.tz_localize(None).to_period("M").astype(str)
    else:
        raise ValueError(freq)

    out = []
    level_cols = [c for c in ["FED_TREAST", "FED_WALCL", "BOC_GOC_BONDS", "ECB_MONPOL_SECURITIES", "DXY", "WTI", "BRENT", "GOLD"] if c in x.columns]
    for bucket in pd.unique(keys):
        g = x.loc[keys == bucket]
        row = {"period": str(bucket), "weeks": int(len(g))}
        for c in level_cols:
            s = pd.to_numeric(g[c], errors="coerce").dropna()
            row[f"{c}_start"] = float(s.iloc[0]) if len(s) else np.nan
            row[f"{c}_end"] = float(s.iloc[-1]) if len(s) else np.nan
            row[f"{c}_pct_change"] = float(s.iloc[-1] / s.iloc[0] - 1) if len(s) > 1 and s.iloc[0] != 0 else np.nan
        for c in ["STRAT_TRADES", "STRAT_WINS", "STRAT_LOSSES", "STRAT_BE", "STRAT_SUM_R", "STRAT_PNL_DOLLARS"]:
            if c in g.columns:
                row[c] = float(pd.to_numeric(g[c], errors="coerce").fillna(0).sum())
        if "STRAT_AVG_R" in g.columns:
            row["STRAT_AVG_R_mean"] = float(pd.to_numeric(g["STRAT_AVG_R"], errors="coerce").mean())
        if "STRAT_WINRATE_EX_BE" in g.columns:
            row["STRAT_WINRATE_EX_BE_mean"] = float(pd.to_numeric(g["STRAT_WINRATE_EX_BE"], errors="coerce").mean())
        out.append(row)
    return pd.DataFrame(out)


def build_transform_panel(levels: pd.DataFrame, strat: pd.DataFrame) -> pd.DataFrame:
    features = {}
    for c in ["FED_TREAST", "FED_WALCL", "BOC_GOC_BONDS", "ECB_MONPOL_SECURITIES"]:
        if c not in levels.columns:
            continue
        available = levels[c].shift(1)
        features[f"{c}_DIFF_AVAIL"] = available.diff()
        features[f"{c}_PCT_AVAIL"] = available.pct_change(fill_method=None)
    features["DXY_RET"] = levels["DXY"].pct_change(fill_method=None)
    features["GOLD_RET"] = levels["GOLD"].pct_change(fill_method=None)
    if "WTI" in levels.columns:
        features["WTI_RET"] = levels["WTI"].pct_change(fill_method=None)
    if "BRENT" in levels.columns:
        features["BRENT_RET"] = levels["BRENT"].pct_change(fill_method=None)

    for c in ["STRAT_TRADES", "STRAT_SUM_R", "STRAT_AVG_R", "STRAT_WINRATE_EX_BE", "STRAT_PNL_DOLLARS", "STRAT_AVG_RISK_DOLLARS"]:
        if c in strat.columns:
            features[c] = strat[c]
    return pd.concat(features, axis=1).sort_index().loc[(lambda z: (z.index >= START) & (z.index <= END))]


def corr_stats(a: pd.Series, b: pd.Series) -> tuple[float, float, float, float, int]:
    z = pd.concat([a, b], axis=1).replace([np.inf, -np.inf], np.nan).dropna()
    n = len(z)
    if n < 12 or z.iloc[:, 0].nunique() < 2 or z.iloc[:, 1].nunique() < 2:
        return np.nan, np.nan, np.nan, np.nan, n
    pr, pp = pearsonr(z.iloc[:, 0], z.iloc[:, 1])
    sr, sp = spearmanr(z.iloc[:, 0], z.iloc[:, 1])
    return float(pr), float(pp), float(sr), float(sp), n


def bh_adjust(pvals: pd.Series) -> pd.Series:
    p = pd.to_numeric(pvals, errors="coerce")
    valid = p.dropna().sort_values()
    if valid.empty:
        return pd.Series(np.nan, index=p.index)
    m = len(valid)
    ranks = np.arange(1, m + 1)
    raw = valid.to_numpy() * m / ranks
    adjusted = np.minimum.accumulate(raw[::-1])[::-1]
    adjusted = np.clip(adjusted, 0, 1)
    out = pd.Series(np.nan, index=p.index, dtype=float)
    out.loc[valid.index] = adjusted
    return out


def discover_all_pairs(transforms: pd.DataFrame) -> pd.DataFrame:
    rows = []
    cols = list(transforms.columns)
    for a, b in itertools.combinations(cols, 2):
        for lag in LAGS:
            target = transforms[b].shift(-lag)
            pr, pp, sr, sp, n = corr_stats(transforms[a], target)
            rows.append({
                "A": a, "B": b, "lag_weeks": lag,
                "meaning": "positive=A leads B; negative=B leads A",
                "pearson": pr, "pearson_p": pp,
                "spearman": sr, "spearman_p": sp,
                "n": n,
            })
    out = pd.DataFrame(rows)
    out["pearson_q_bh"] = bh_adjust(out["pearson_p"])
    out["spearman_q_bh"] = bh_adjust(out["spearman_p"])
    out["abs_score"] = out[["pearson", "spearman"]].abs().mean(axis=1)
    return out.sort_values(["abs_score", "n"], ascending=[False, False])


def regime_stability(transforms: pd.DataFrame, ranked: pd.DataFrame, top_n: int = 100) -> pd.DataFrame:
    periods = {
        "2023": (pd.Timestamp("2023-01-02", tz="UTC"), pd.Timestamp("2023-12-31 23:59:59", tz="UTC")),
        "2024": (pd.Timestamp("2024-01-01", tz="UTC"), pd.Timestamp("2024-12-31 23:59:59", tz="UTC")),
        "2025": (pd.Timestamp("2025-01-01", tz="UTC"), pd.Timestamp("2025-12-31 23:59:59", tz="UTC")),
        "2026_YTD": (pd.Timestamp("2026-01-01", tz="UTC"), END),
        "2024_2026": (pd.Timestamp("2024-01-01", tz="UTC"), END),
    }
    rows = []
    for _, r in ranked.head(top_n).iterrows():
        a, b, lag = r["A"], r["B"], int(r["lag_weeks"])
        row = {"A": a, "B": b, "lag_weeks": lag, "global_pearson": r["pearson"], "global_spearman": r["spearman"], "global_n": int(r["n"])}
        signs = []
        for name, (lo, hi) in periods.items():
            sub = transforms.loc[(transforms.index >= lo) & (transforms.index <= hi)]
            pr, pp, sr, sp, n = corr_stats(sub[a], sub[b].shift(-lag))
            row[f"{name}_pearson"] = pr
            row[f"{name}_spearman"] = sr
            row[f"{name}_n"] = n
            if n >= 8 and math.isfinite(pr):
                signs.append(int(np.sign(pr)))
        global_sign = int(np.sign(r["pearson"])) if math.isfinite(r["pearson"]) else 0
        row["same_sign_subperiods"] = int(sum(1 for s in signs if s == global_sign and s != 0))
        row["usable_subperiods"] = int(len(signs))
        rows.append(row)
    return pd.DataFrame(rows)


def main() -> None:
    trades, ledger = regenerate_strategy()
    strat = strategy_weekly(trades, ledger)
    levels, errors = fetch_macro_levels()
    panel = levels.join(strat, how="outer").sort_index()
    panel = panel.loc[(panel.index >= START) & (panel.index <= END)]
    panel.to_csv(OUT / "fullperiod_weekly_panel.csv")

    annual = descriptive_table(panel, "year")
    quarterly = descriptive_table(panel, "quarter")
    monthly = descriptive_table(panel, "month")
    annual.to_csv(OUT / "descriptive_by_year.csv", index=False)
    quarterly.to_csv(OUT / "descriptive_by_quarter.csv", index=False)
    monthly.to_csv(OUT / "descriptive_by_month.csv", index=False)

    transforms = build_transform_panel(levels, strat)
    transforms.to_csv(OUT / "fullperiod_transforms.csv")
    all_corr = discover_all_pairs(transforms)
    all_corr.to_csv(OUT / "all_pairwise_leadlag.csv", index=False)

    ranked = all_corr[(all_corr["n"] >= 40) & all_corr["abs_score"].notna()].copy()
    ranked.head(500).to_csv(OUT / "ranked_correlations.csv", index=False)
    focus_mask = ranked["A"].str.contains("GOLD|WTI|BRENT|STRAT", regex=True) | ranked["B"].str.contains("GOLD|WTI|BRENT|STRAT", regex=True)
    ranked_focus = ranked[focus_mask].copy()
    ranked_focus.head(300).to_csv(OUT / "ranked_gold_strategy_correlations.csv", index=False)

    stability = regime_stability(transforms, ranked_focus if not ranked_focus.empty else ranked, top_n=100)
    stability.to_csv(OUT / "regime_stability.csv", index=False)

    loaded = [c for c in ["FED_TREAST", "FED_WALCL", "BOC_GOC_BONDS", "ECB_MONPOL_SECURITIES", "DXY", "WTI", "BRENT", "GOLD"] if c in levels.columns]
    full_summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "exact_window_start": str(START),
        "exact_window_end": str(END),
        "strategy_trades": int(len(trades)),
        "series_loaded": loaded,
        "fetch_errors": errors,
        "weekly_rows": int(len(panel)),
        "correlation_tests": int(len(all_corr)),
        "method_order": "Phase A descriptive full-period map first; Phase B pairwise correlation discovery second",
        "lag_definition": "positive lag means A leads B by that many weeks",
        "release_handling": "central-bank weekly level shifted one week before transforms to reduce publication look-ahead",
        "multiple_testing": "Benjamini-Hochberg q-values reported separately for Pearson and Spearman p-values",
        "warning": "Exploratory historical correlations do not establish causality or future predictability.",
    }
    (OUT / "summary.json").write_text(json.dumps(full_summary, indent=2), encoding="utf-8")

    lines = [
        "# Exact M21 full-period macro/strategy correlation discovery",
        "",
        f"Window: **{START.date()} -> {END.date()}**. Same M21 pinned MGC history and M20/M17 trade logic.",
        "",
        "Method order is deliberate: **describe the complete period first, then search correlations**. No preferred relationship is selected before the scan.",
        "",
        f"Strategy trades regenerated: **{len(trades)}**. Weekly panel rows: **{len(panel)}**.",
        f"Loaded series: {', '.join(loaded)}.",
    ]
    if errors:
        lines += ["", "## Source errors / missing series"] + [f"- {e['series']}: {e['error']}" for e in errors]

    lines += ["", "## Phase A — annual map", ""]
    if not annual.empty:
        show_cols = [c for c in ["period", "weeks", "GOLD_pct_change", "WTI_pct_change", "BRENT_pct_change", "DXY_pct_change", "FED_TREAST_pct_change", "FED_WALCL_pct_change", "BOC_GOC_BONDS_pct_change", "ECB_MONPOL_SECURITIES_pct_change", "STRAT_TRADES", "STRAT_SUM_R", "STRAT_PNL_DOLLARS"] if c in annual.columns]
        lines.append("| " + " | ".join(show_cols) + " |")
        lines.append("|" + "|".join(["---"] * len(show_cols)) + "|")
        for _, rr in annual[show_cols].iterrows():
            vals = []
            for c in show_cols:
                v = rr[c]
                if c.endswith("pct_change") and pd.notna(v):
                    vals.append(f"{100*float(v):.2f}%")
                elif isinstance(v, (float, np.floating)) and pd.notna(v):
                    vals.append(f"{float(v):.3f}")
                else:
                    vals.append(str(v))
            lines.append("| " + " | ".join(vals) + " |")

    lines += ["", "## Phase B — strongest exploratory relationships involving Gold, oil or strategy", "", "| A | B | Lag weeks | Pearson | Spearman | N | Pearson q(BH) | Spearman q(BH) |", "|---|---|---:|---:|---:|---:|---:|---:|"]
    for _, r in ranked_focus.head(25).iterrows():
        lines.append(f"| {r['A']} | {r['B']} | {int(r['lag_weeks'])} | {r['pearson']:.3f} | {r['spearman']:.3f} | {int(r['n'])} | {r['pearson_q_bh']:.3g} | {r['spearman_q_bh']:.3g} |")

    lines += [
        "",
        "## Interpretation gate",
        "",
        "A high exploratory correlation is only a candidate. Promotion requires stability across subperiods, sensible publication timing, and out-of-sample reproduction. The runner does not modify M20/M21 strategy rules.",
    ]
    report = "\n".join(lines) + "\n"
    (OUT / "report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
