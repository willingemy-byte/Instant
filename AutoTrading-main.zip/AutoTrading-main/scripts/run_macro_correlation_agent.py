from __future__ import annotations

import json
import os
import re
import urllib.parse
import urllib.request
from pathlib import Path
from datetime import datetime, timezone

OUT = Path("artifacts/macro_agent")
OUT.mkdir(parents=True, exist_ok=True)
SKILLDB = Path("external/skilldb/skilldb.json")

SKILL_TERMS = {
    "macro": 5, "macroeconomic": 7, "econometrics": 8, "time-series": 7,
    "time series": 7, "correlation": 5, "causality": 7, "granger": 9,
    "var": 4, "vector autoregression": 9, "regime": 6, "changepoint": 7,
    "change point": 7, "fred": 8, "federal reserve": 8, "central bank": 8,
    "ecb": 8, "bank of canada": 8, "treasury": 7, "bond": 4,
    "gold": 5, "dxy": 7, "dollar index": 7, "financial data": 5,
    "data engineering": 4, "forecast": 4, "lead lag": 8, "lead-lag": 8,
}

REPO_QUERIES = [
    "MCP FRED Federal Reserve data",
    "MCP central bank macroeconomic data",
    "MCP ECB data API",
    "MCP Bank of Canada data",
    "MCP econometrics time series",
    "agent skills Granger causality time series",
    "agent skills macroeconomics FRED",
    "financial data MCP server macroeconomic",
]

SOURCE_CATALOG = [
    {
        "institution": "Federal Reserve",
        "name": "H.4.1 Factors Affecting Reserve Balances",
        "url": "https://www.federalreserve.gov/releases/h41/",
        "role": "official balance-sheet source; Treasury securities, total assets and reserve-related series",
        "frequency": "weekly",
        "priority": 1,
    },
    {
        "institution": "Federal Reserve / FRED",
        "name": "FRED economic data",
        "url": "https://fred.stlouisfed.org/",
        "role": "machine-readable historical macro series; identify exact H.4.1/Fed holdings series and dollar proxies",
        "frequency": "mixed",
        "priority": 1,
    },
    {
        "institution": "Bank of Canada",
        "name": "Valet API",
        "url": "https://www.bankofcanada.ca/valet/docs",
        "role": "official machine-readable BoC financial/economic series",
        "frequency": "mixed",
        "priority": 1,
    },
    {
        "institution": "European Central Bank",
        "name": "ECB Data Portal API",
        "url": "https://data-api.ecb.europa.eu/service/data",
        "role": "official ECB/Eurosystem balance-sheet and monetary series",
        "frequency": "mixed",
        "priority": 1,
    },
    {
        "institution": "ICE",
        "name": "U.S. Dollar Index (DXY)",
        "url": "https://www.ice.com/products/194/US-Dollar-Index-Futures",
        "role": "canonical DXY definition/market; historical machine-readable access may require licensed source",
        "frequency": "market",
        "priority": 1,
    },
    {
        "institution": "LBMA",
        "name": "LBMA Gold Price",
        "url": "https://www.lbma.org.uk/prices-and-data/lbma-gold-price",
        "role": "gold benchmark; use licensed/public historical source where permitted",
        "frequency": "daily",
        "priority": 1,
    },
]


def score_text(text: str) -> tuple[int, list[str]]:
    s = text.lower()
    score = 0
    hits = []
    for term, weight in SKILL_TERMS.items():
        if term in s:
            score += weight
            hits.append(term)
    return score, hits


def load_skilldb() -> list[dict]:
    if not SKILLDB.exists():
        return []
    try:
        obj = json.loads(SKILLDB.read_text(encoding="utf-8"))
    except Exception:
        return []
    if isinstance(obj, list):
        return obj
    if isinstance(obj, dict):
        for k in ("skills", "data", "items"):
            if isinstance(obj.get(k), list):
                return obj[k]
    return []


def scout_skilldb() -> list[dict]:
    rows = []
    for x in load_skilldb():
        text = " ".join(str(x.get(k, "")) for k in ("id", "name", "owner", "repo", "skillPath", "githubUrl"))
        score, hits = score_text(text)
        if score <= 0:
            continue
        rows.append({
            "source": "SkillDB",
            "id": x.get("id"),
            "name": x.get("name"),
            "owner": x.get("owner"),
            "repo": x.get("repo"),
            "skillPath": x.get("skillPath"),
            "githubUrl": x.get("githubUrl"),
            "sources": x.get("sources", []),
            "installs": x.get("installs", 0),
            "score": score,
            "hits": hits,
        })
    rows.sort(key=lambda r: (r["score"], int(r.get("installs") or 0)), reverse=True)
    return rows[:100]


def github_search() -> list[dict]:
    token = os.getenv("GITHUB_TOKEN", "")
    headers = {"Accept": "application/vnd.github+json", "User-Agent": "AutoTrading-Macro-Agent"}
    if token:
        headers["Authorization"] = f"Bearer {token}"
    found = {}
    for query in REPO_QUERIES:
        url = "https://api.github.com/search/repositories?" + urllib.parse.urlencode({"q": query, "sort": "stars", "order": "desc", "per_page": 10})
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.load(resp)
        except Exception as exc:
            found[f"error:{query}"] = {"source": "GitHub", "query": query, "error": str(exc), "score": 0}
            continue
        for item in data.get("items", []):
            full = item.get("full_name")
            text = " ".join([full or "", item.get("description") or "", query])
            score, hits = score_text(text)
            rec = {
                "source": "GitHub repository search",
                "query": query,
                "full_name": full,
                "url": item.get("html_url"),
                "description": item.get("description"),
                "stars": item.get("stargazers_count", 0),
                "updated_at": item.get("updated_at"),
                "score": score,
                "hits": hits,
            }
            if full and (full not in found or rec["score"] > found[full].get("score", 0)):
                found[full] = rec
    rows = [v for k, v in found.items() if not k.startswith("error:")]
    rows.sort(key=lambda r: (r["score"], int(r.get("stars") or 0)), reverse=True)
    return rows[:60]


def probe_sources() -> list[dict]:
    rows = []
    for src in SOURCE_CATALOG:
        rec = dict(src)
        try:
            req = urllib.request.Request(src["url"], headers={"User-Agent": "AutoTrading-Macro-Agent"})
            with urllib.request.urlopen(req, timeout=20) as resp:
                rec["http_status"] = getattr(resp, "status", 200)
                rec["reachable"] = True
        except Exception as exc:
            rec["reachable"] = False
            rec["probe_error"] = str(exc)
        rows.append(rec)
    return rows


def write_report(skills: list[dict], repos: list[dict], sources: list[dict]) -> None:
    lines = [
        "# Macro Correlation Agent — discovery report",
        "",
        f"Generated: {datetime.now(timezone.utc).isoformat()}",
        "",
        "Mission: find reproducible methods to test Fed/BoC/ECB balance-sheet and sovereign-bond holdings against DXY and Gold, including lead/lag structure.",
        "",
        "## Safety / methodology",
        "",
        "- Research only; no broker/live execution.",
        "- Third-party skills are discovered and scored but not executed automatically.",
        "- Prefer official central-bank sources; pin versions/endpoints where possible.",
        "- Correlation is not causation. Levels are diagnostic only; primary inference uses changes/returns and stationarity checks.",
        "",
        "## Top SkillDB candidates",
        "",
        "| Score | Skill | Repo | Installs | Hits |",
        "|---:|---|---|---:|---|",
    ]
    for r in skills[:25]:
        lines.append(f"| {r['score']} | {r.get('name','')} | {r.get('owner','')}/{r.get('repo','')} | {r.get('installs',0)} | {', '.join(r.get('hits',[])[:6])} |")
    lines += ["", "## Top GitHub/MCP repository candidates", "", "| Score | Repo | Stars | Why |", "|---:|---|---:|---|"]
    for r in repos[:20]:
        lines.append(f"| {r['score']} | {r.get('full_name','')} | {r.get('stars',0)} | {', '.join(r.get('hits',[])[:6])} |")
    lines += ["", "## Official source probes", "", "| Institution | Source | Reachable | Role |", "|---|---|---|---|"]
    for s in sources:
        lines.append(f"| {s['institution']} | {s['name']} | {s.get('reachable')} | {s['role']} |")
    lines += [
        "",
        "## Correlation experiment contract",
        "",
        "1. Normalize official central-bank series to weekly Friday observations; retain native dates to prevent look-ahead.",
        "2. Compute weekly changes and percentage/log changes where economically meaningful.",
        "3. Compute Gold and DXY weekly returns on matching timestamps.",
        "4. For each macro feature, estimate Pearson and Spearman correlations at lags -26..+26 weeks.",
        "5. Repeat in rolling 13w, 26w and 52w windows; record sign stability and confidence intervals.",
        "6. Split QE/QT and volatility regimes; compare 2023 with 2024-2026 separately.",
        "7. Run Granger/VAR only after stationarity checks and sufficient sample size; never infer causality from correlation alone.",
        "8. A candidate leading indicator must reproduce out-of-sample and across more than one regime before being promoted.",
    ]
    (OUT / "macro_agent_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    skills = scout_skilldb()
    repos = github_search()
    sources = probe_sources()
    payload = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "skilldb_candidates": skills,
        "github_mcp_candidates": repos,
        "source_catalog": sources,
        "experiment": {
            "markets": ["Gold", "DXY"],
            "institutions": ["Federal Reserve", "Bank of Canada", "ECB"],
            "lags_weeks": list(range(-26, 27)),
            "rolling_windows_weeks": [13, 26, 52],
            "primary_transforms": ["weekly change", "weekly pct/log change", "market weekly return"],
            "methods": ["Pearson", "Spearman", "rolling correlation", "lead-lag grid", "regime split", "Granger/VAR after assumptions"],
        },
    }
    (OUT / "skill_candidates.json").write_text(json.dumps({"skilldb": skills, "github": repos}, indent=2), encoding="utf-8")
    (OUT / "source_catalog.json").write_text(json.dumps(sources, indent=2), encoding="utf-8")
    (OUT / "macro_agent.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    write_report(skills, repos, sources)
    print((OUT / "macro_agent_report.md").read_text(encoding="utf-8"))


if __name__ == "__main__":
    main()
