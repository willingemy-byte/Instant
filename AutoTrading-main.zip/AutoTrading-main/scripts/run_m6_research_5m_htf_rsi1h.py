from __future__ import annotations

import hashlib, json
from pathlib import Path
import pandas as pd

DATA = Path('external/mgc5/ohlcv_MGC_5m_continuous.csv')
OUT = Path('artifacts'); OUT.mkdir(parents=True, exist_ok=True)
NY = 'America/New_York'
STARTS = {'1y':'2025-03-23','6m':'2025-09-23','3m':'2025-12-23'}
END = pd.Timestamp('2026-03-23 23:59:59', tz='UTC')


def rsi(s, n=21):
    d=s.diff(); g=d.mask(d<0,0); l=-d.mask(d>0,0)
    ag=g.ewm(com=n-1,adjust=False).mean(); al=l.ewm(com=n-1,adjust=False).mean()
    out=100-(100/(1+ag/al)); return out.where(al!=0,100.0)


def load():
    d=pd.read_csv(DATA)
    d['timestamp']=pd.to_datetime(d['timestamp'], utc=True)
    d=d.set_index('timestamp').sort_index()
    d=d.rename(columns={'open':'Open','high':'High','low':'Low','close':'Close','volume':'Volume'})
    d=d[['Open','High','Low','Close','Volume']].dropna()
    d['RSI5']=rsi(d.Close,21); d['RSI5_MA50']=d.RSI5.rolling(50).mean(); d['PRICE_MA50']=d.Close.rolling(50).mean()
    h=d.resample('1h',label='left',closed='left').agg({'Open':'first','High':'max','Low':'min','Close':'last','Volume':'sum'}).dropna()
    h['RSI1H']=rsi(h.Close,21); h['RSI1H_MA50']=h.RSI1H.rolling(50).mean()
    avail=h[['RSI1H','RSI1H_MA50']].copy(); avail.index=avail.index+pd.Timedelta(hours=1)
    a=avail.reindex(d.index,method='ffill'); d['RSI1H']=a.RSI1H; d['RSI1H_MA50']=a.RSI1H_MA50
    return d


def in_session(ts):
    z=ts.tz_convert(NY); return z.weekday()<5 and 8<=z.hour<12


def simulate(data, session):
    bull=bear=False; bull_top=bear_bottom=None; pos=None; pending=None; trades=[]
    idx=data.index
    for i in range(3,len(data)):
        t=idx[i]; row=data.iloc[i]
        if pending is not None and pos is None:
            pos={**pending,'entry':float(row.Open),'entry_time':t}; pending=None
        if pos is not None:
            o,h,l=float(row.Open),float(row.High),float(row.Low)
            side=pos['side']; sl=pos['sl']; tp=pos['tp']; exitp=None; why=None
            if side=='long':
                if o<=sl: exitp=o; why='gap_sl'
                elif o>=tp: exitp=o; why='gap_tp'
                elif l<=sl and h>=tp: exitp=sl; why='both_stop_first'
                elif l<=sl: exitp=sl; why='sl'
                elif h>=tp: exitp=tp; why='tp'
            else:
                if o>=sl: exitp=o; why='gap_sl'
                elif o<=tp: exitp=o; why='gap_tp'
                elif h>=sl and l<=tp: exitp=sl; why='both_stop_first'
                elif h>=sl: exitp=sl; why='sl'
                elif l<=tp: exitp=tp; why='tp'
            if exitp is not None:
                gross=(exitp/pos['entry']-1)*(1 if side=='long' else -1)
                net=gross-0.004
                trades.append({**pos,'exit':exitp,'exit_time':t,'exit_reason':why,'gross_ret':gross,'net_ret':net})
                pos=None
        co,cc=float(row.Open),float(row.Close); blo,bhi=min(co,cc),max(co,cc)
        lows=[min(float(data.Open.iloc[i-j]),float(data.Close.iloc[i-j])) for j in (1,2,3)]
        highs=[max(float(data.Open.iloc[i-j]),float(data.Close.iloc[i-j])) for j in (1,2,3)]
        engulf=blo<=min(lows) and bhi>=max(highs); be=cc>co and engulf; se=cc<co and engulf
        if bull and not be and bull_top is not None and cc<=bull_top: bull=False; bull_top=None
        if bear and not se and bear_bottom is not None and cc>=bear_bottom: bear=False; bear_bottom=None
        if be: bull=True; bull_top=bhi
        if se: bear=True; bear_bottom=blo
        if pos is not None or pending is not None or i+1>=len(data): continue
        if row[['RSI5','RSI5_MA50','PRICE_MA50','RSI1H','RSI1H_MA50']].isna().any(): continue
        fill_t=idx[i+1]
        if session and not in_session(fill_t): continue
        long_ok=cc>row.PRICE_MA50 and row.RSI5>row.RSI5_MA50 and row.RSI1H>row.RSI1H_MA50
        short_ok=cc<row.PRICE_MA50 and row.RSI5<row.RSI5_MA50 and row.RSI1H<row.RSI1H_MA50
        if bull and long_ok:
            sl=float(data.Low.iloc[i-1]); sl=cc*0.99 if sl>=cc-cc*0.001 else sl; risk=cc-sl
            if risk>0: pending={'side':'long','signal_time':t,'ref':cc,'sl':sl,'tp':cc+3*risk}; bull=False; bull_top=None
        elif bear and short_ok:
            sl=float(data.High.iloc[i-1]); sl=cc*1.01 if sl<=cc+cc*0.001 else sl; risk=sl-cc
            if risk>0: pending={'side':'short','signal_time':t,'ref':cc,'sl':sl,'tp':cc-3*risk}; bear=False; bear_bottom=None
    return pd.DataFrame(trades)


def metrics(tr):
    if tr.empty: return {'trades':0,'wins':0,'losses':0,'win_rate_pct':0.0,'return_pct':0.0,'max_drawdown_pct':0.0,'profit_factor':None}
    wins=int((tr.net_ret>0).sum()); losses=int((tr.net_ret<=0).sum()); wr=100*wins/len(tr)
    eq=(1+tr.net_ret).cumprod(); peak=eq.cummax(); dd=(eq/peak-1).min()*100; ret=(eq.iloc[-1]-1)*100
    gp=tr.loc[tr.net_ret>0,'net_ret'].sum(); gl=-tr.loc[tr.net_ret<0,'net_ret'].sum(); pf=(gp/gl if gl>0 else None)
    return {'trades':int(len(tr)),'wins':wins,'losses':losses,'win_rate_pct':wr,'return_pct':float(ret),'max_drawdown_pct':float(dd),'profit_factor':None if pf is None else float(pf)}


def main():
    d=load(); results=[]
    snap=d.loc[(d.index>=pd.Timestamp('2025-03-23',tz='UTC'))&(d.index<=END)]
    sp=OUT/'m6_mgc_5m_with_htf.csv'; snap.to_csv(sp); sha=hashlib.sha256(sp.read_bytes()).hexdigest()
    for mode,session in [('ny_8_12',True),('no_session_filter',False)]:
        for label,s in STARTS.items():
            x=snap.loc[snap.index>=pd.Timestamp(s,tz='UTC')]
            tr=simulate(x,session); tr.to_csv(OUT/f'm6_{mode}_{label}_trades.csv',index=False)
            m=metrics(tr); m.update({'mode':mode,'window':label}); results.append(m)
    payload={'method':'offline research simulation only','instrument':'MGC','timeframe':'5m','htf_rule':'RSI21 1h above/below SMA50 of RSI21; completed 1h bars only','snapshot_sha256':sha,'results':results}
    (OUT/'m6_results.json').write_text(json.dumps(payload,indent=2))
    lines=['# M6 — 5m + 1h RSI21/SMA50 filter','',f'Snapshot SHA256: `{sha}`','', '| Mode | Window | Trades | Wins | Losses | WR | Return* | Max DD* | PF* |','|---|---|---:|---:|---:|---:|---:|---:|---:|']
    for r in results: lines.append(f"| {r['mode']} | {r['window']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['win_rate_pct']:.2f}% | {r['return_pct']:.2f}% | {r['max_drawdown_pct']:.2f}% | {r['profit_factor'] if r['profit_factor'] is not None else 'n/a'} |")
    lines += ['', '*Return/DD/PF are from the offline research replay with 0.4% round-trip cost approximation; use WR/trade counts as the primary comparison.', '- No break-even.', '- 1h RSI values become available only after the hourly candle is complete.', '- ny_8_12 restricts actual hypothetical fills to Monday-Friday 08:00-12:00 America/New_York.', '- no_session_filter applies no strategic time gate.']
    report='\n'.join(lines)+'\n'; (OUT/'m6_report.md').write_text(report); print(report)

if __name__=='__main__': main()
