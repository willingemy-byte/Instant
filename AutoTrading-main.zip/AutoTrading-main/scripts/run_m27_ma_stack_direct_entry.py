from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

import run_m10_trailing_initial_risk as b
import run_m14_topstep_150k_risk300 as m14
import run_m17_eb3_noentry_10_17ct as m17
import run_m20_m17_dynamic20_capped900 as m20
import run_m21_m20_full_mgc_history as m21
import run_m25_h1_sma20_vs_sma200 as m25

OUT = Path("artifacts/m27_ma_stack_direct_entry")
OUT.mkdir(parents=True, exist_ok=True)


def five_minute_stack(d5: pd.DataFrame) -> pd.DataFrame:
    out = pd.DataFrame(index=d5.index)
    close = d5["Close"]
    for n in (5, 8, 13, 20, 200):
        out[f"sma{n}_5m"] = close.rolling(n, min_periods=n).mean()
    return out


def simulate_m27(d1: pd.DataFrame, d5: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Direct 5m moving-average-stack entry; no EB3 requirement.

    Long setup forms when SMA5>SMA8>SMA13>SMA20>SMA200.
    Short setup forms when the reverse ordering holds.
    A setup is consumed after entry and rearms only after the stack breaks and
    later reforms. If a stack forms during a no-entry period, it remains armed
    while still valid and may enter at the first allowed close.
    """
    h1_ma = m25.completed_h1_sma20_sma200(d1)
    ma5 = five_minute_stack(d5)
    if h1_ma.empty or ma5["sma200_5m"].dropna().empty:
        return pd.DataFrame(), {}

    pos = None
    rec: list[dict] = []
    idx5 = d5.index
    one_ns = pd.Timedelta(nanoseconds=1)

    prev_long_stack = False
    prev_short_stack = False
    long_armed = False
    short_armed = False

    counters = {
        "long_stack_formations": 0,
        "short_stack_formations": 0,
        "blocked_1h_price_sma200": 0,
        "blocked_1h_sma20_vs_sma200": 0,
        "accepted_long_entries": 0,
        "accepted_short_entries": 0,
    }

    for i in range(len(d5)):
        close_time = idx5[i] + pd.Timedelta(minutes=5)
        prev_close = idx5[i] if i == 0 else idx5[i - 1] + pd.Timedelta(minutes=5)

        if pos is not None:
            pos, done = m14.process_minutes_topstep(pos, d1.loc[prev_close:close_time - one_ns])
            if done is not None:
                rec.append(done)

        row = ma5.iloc[i]
        vals = [row[f"sma{n}_5m"] for n in (5, 8, 13, 20, 200)]
        valid_ma = not any(pd.isna(v) or not np.isfinite(float(v)) for v in vals)
        if not valid_ma:
            prev_long_stack = False
            prev_short_stack = False
            long_armed = False
            short_armed = False
            continue

        sma5_5m, sma8_5m, sma13_5m, sma20_5m, sma200_5m = map(float, vals)
        long_stack = sma5_5m > sma8_5m > sma13_5m > sma20_5m > sma200_5m
        short_stack = sma5_5m < sma8_5m < sma13_5m < sma20_5m < sma200_5m

        if long_stack and not prev_long_stack:
            long_armed = True
            counters["long_stack_formations"] += 1
        elif not long_stack:
            long_armed = False

        if short_stack and not prev_short_stack:
            short_armed = True
            counters["short_stack_formations"] += 1
        elif not short_stack:
            short_armed = False

        prev_long_stack = long_stack
        prev_short_stack = short_stack

        if pos is not None or not m17.entry_allowed_m17(close_time):
            continue

        hist = h1_ma.loc[:close_time]
        if hist.empty:
            continue
        sma20_h1 = float(hist.iloc[-1]["sma20_h1"])
        sma200_h1 = float(hist.iloc[-1]["sma200_h1"])
        entry = float(d5.Close.iloc[i])

        if long_armed and long_stack:
            if entry <= sma200_h1:
                counters["blocked_1h_price_sma200"] += 1
                continue
            if sma20_h1 <= sma200_h1:
                counters["blocked_1h_sma20_vs_sma200"] += 1
                continue
            sl = float(d5.Low.iloc[i])
            risk = entry - sl
            if risk <= 0:
                continue
            pos = {
                "side": 1,
                "entry": entry,
                "entry_time": close_time,
                "risk": risk,
                "initial_stop": sl,
                "active_stop": sl,
                "tp": entry + 7.0 * risk,
                "best_price": entry,
                "phase2": False,
                "sma5_5m": sma5_5m,
                "sma8_5m": sma8_5m,
                "sma13_5m": sma13_5m,
                "sma20_5m": sma20_5m,
                "sma200_5m": sma200_5m,
                "sma20_h1": sma20_h1,
                "sma200_h1": sma200_h1,
                "trigger_time": idx5[i],
                "trigger_open": float(d5.Open.iloc[i]),
                "trigger_high": float(d5.High.iloc[i]),
                "trigger_low": float(d5.Low.iloc[i]),
                "trigger_close": entry,
            }
            long_armed = False
            counters["accepted_long_entries"] += 1

        elif short_armed and short_stack:
            if entry >= sma200_h1:
                counters["blocked_1h_price_sma200"] += 1
                continue
            if sma20_h1 >= sma200_h1:
                counters["blocked_1h_sma20_vs_sma200"] += 1
                continue
            sl = float(d5.High.iloc[i])
            risk = sl - entry
            if risk <= 0:
                continue
            pos = {
                "side": -1,
                "entry": entry,
                "entry_time": close_time,
                "risk": risk,
                "initial_stop": sl,
                "active_stop": sl,
                "tp": entry - 7.0 * risk,
                "best_price": entry,
                "phase2": False,
                "sma5_5m": sma5_5m,
                "sma8_5m": sma8_5m,
                "sma13_5m": sma13_5m,
                "sma20_5m": sma20_5m,
                "sma200_5m": sma200_5m,
                "sma20_h1": sma20_h1,
                "sma200_h1": sma200_h1,
                "trigger_time": idx5[i],
                "trigger_open": float(d5.Open.iloc[i]),
                "trigger_high": float(d5.High.iloc[i]),
                "trigger_low": float(d5.Low.iloc[i]),
                "trigger_close": entry,
            }
            short_armed = False
            counters["accepted_short_entries"] += 1

    if pos is not None:
        pos, done = m14.process_minutes_topstep(pos, d1.loc[idx5[-1] + pd.Timedelta(minutes=5):])
        if done is not None:
            rec.append(done)

    return pd.DataFrame(rec), counters


def main() -> None:
    d1 = m21.load_full_1m()
    d5 = b.make_5m(d1)
    data_start = str(d1.index.min())
    data_end = str(d1.index.max())
    elapsed_days = float((d1.index.max() - d1.index.min()) / pd.Timedelta(days=1))
    elapsed_years = elapsed_days / 365.2425

    trades, counters = simulate_m27(d1, d5)
    trades.to_csv(OUT / "m27_full_history_trades.csv", index=False)

    ev = m20.evaluate_dynamic20_capped900(trades, d1)
    ledger = ev["ledger"].copy()
    ledger.to_csv(OUT / "m27_full_history_ledger.csv", index=False)

    summary = m20.summarize(trades, ev)
    summary.update({
        "data_start": data_start,
        "data_end": data_end,
        "elapsed_days": elapsed_days,
        "elapsed_years": elapsed_years,
        "longest_loss_streak": m21.longest_loss_streak(trades["R"] if not trades.empty else pd.Series(dtype=float)),
    })
    annual = m21.period_stats(trades, ledger, "year")
    quarterly = m21.period_stats(trades, ledger, "quarter")

    payload = {
        "method": "offline research simulation only",
        "baseline_context": "M25 higher-timeframe filters and M13/M17/M20 management/risk",
        "entry_change": "replace EB3 trigger with first eligible close of a newly formed 5m SMA5/8/13/20/200 ordered stack",
        "long_trigger": "SMA5>SMA8>SMA13>SMA20>SMA200",
        "short_trigger": "SMA5<SMA8<SMA13<SMA20<SMA200",
        "rearm": "same-direction stack must break before a new entry setup can form",
        "stop_adaptation": "opposite wick extreme of the 5m trigger candle because no EB3 candle exists",
        "unchanged": [
            "1h price-vs-completed-SMA200 directional filter",
            "completed 1h SMA20-vs-SMA200 alignment",
            "M13 TP7/trailing management",
            "M17 no-entry 10:00-17:00 CT",
            "M20 dynamic 20% headroom risk capped at $900",
        ],
        "data_start": data_start,
        "data_end": data_end,
        "elapsed_years": elapsed_years,
        "counters": counters,
        "summary": summary,
        "annual": annual,
        "quarterly": quarterly,
    }
    (OUT / "m27_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    s = summary
    lines = [
        "# M27 — direct entry on 5m SMA stack",
        "",
        f"Data: {data_start} -> {data_end} (~{elapsed_years:.2f} years)",
        "",
        "Entry trigger replaces EB3: first eligible close after SMA5>SMA8>SMA13>SMA20>SMA200 (reverse for short).",
        "Stop = opposite wick extreme of trigger candle. Existing 1h M25 filters and M13/M17/M20 rules remain.",
        "",
        "| Trades | W | L | BE | WR ex-BE | Avg R | Net $ | Final balance | Avg risk $ | Min risk $ | Max risk $ | Trades at $900 | Min MLL headroom $ | Loss streak | Survived |",
        "|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|",
        f"| {s['trades']} | {s['wins']} | {s['losses']} | {s['breakeven']} | {s['win_rate_ex_be_pct']:.2f}% | {s['avg_R']:.3f} | {s['net_profit']:.0f} | {s['final_balance']:.0f} | {s['average_risk_dollars']:.0f} | {s['minimum_risk_dollars']:.0f} | {s['maximum_risk_dollars']:.0f} | {s['cap_hit_trades']} | {s['minimum_mll_headroom']:.0f} | {s['longest_loss_streak']} | {s['topstep_survived']} |",
        "",
        "## Setup/entry counts",
        "",
        f"- Long stack formations: {counters.get('long_stack_formations', 0)}",
        f"- Short stack formations: {counters.get('short_stack_formations', 0)}",
        f"- Accepted long entries: {counters.get('accepted_long_entries', 0)}",
        f"- Accepted short entries: {counters.get('accepted_short_entries', 0)}",
        "",
        "## By calendar year",
        "",
        "| Year | Trades | W | L | BE | WR ex-BE | Avg R | Sum R | Net $ | Avg risk $ | Loss streak |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in annual:
        lines.append(
            f"| {r['period']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['breakeven']} | "
            f"{r['win_rate_ex_be_pct']:.2f}% | {r['avg_R']:.3f} | {r['sum_R']:.1f} | "
            f"{r['net_profit_dollars']:.0f} | {r['average_risk_dollars']:.0f} | {r['longest_loss_streak']} |"
        )

    report = "\n".join(lines) + "\n"
    (OUT / "m27_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
