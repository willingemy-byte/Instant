from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

import run_m10_trailing_initial_risk as b
import run_m14_topstep_150k_risk300 as m14
import run_m16_eb3_1h_sma50 as m16
import run_m17_eb3_noentry_10_17ct as m17
import run_m20_m17_dynamic20_capped900 as m20
import run_m21_m20_full_mgc_history as m21

OUT = Path("artifacts/m25_h1_sma20_vs_sma200")
OUT.mkdir(parents=True, exist_ok=True)


def completed_h1_sma20_sma200(d1: pd.DataFrame) -> pd.DataFrame:
    """Return completed 1h SMA20 and SMA200 indexed by hour close time."""
    h1 = d1.resample("1h", label="left", closed="left").agg({
        "Open": "first",
        "High": "max",
        "Low": "min",
        "Close": "last",
        "Volume": "sum",
    }).dropna(subset=["Open", "High", "Low", "Close"])
    out = pd.DataFrame(index=h1.index)
    out["sma20_h1"] = h1["Close"].rolling(20, min_periods=20).mean()
    out["sma200_h1"] = h1["Close"].rolling(200, min_periods=200).mean()
    out.index = out.index + pd.Timedelta(hours=1)
    return out.dropna()


def simulate_m25(d1: pd.DataFrame, d5: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """M24 plus completed 1h SMA20-vs-SMA200 trend alignment."""
    h1_ma = completed_h1_sma20_sma200(d1)
    sma5 = d5["Close"].rolling(200, min_periods=200).mean()
    if h1_ma.empty or sma5.dropna().empty:
        return pd.DataFrame(), {}

    pos = None
    rec: list[dict] = []
    idx5 = d5.index
    one_ns = pd.Timedelta(nanoseconds=1)
    counters = {
        "eligible_eb3_candidates": 0,
        "blocked_5m_sma200": 0,
        "blocked_1h_price_sma200": 0,
        "blocked_1h_sma20_vs_sma200": 0,
        "accepted_entries": 0,
    }

    for i in range(len(d5)):
        close_time = idx5[i] + pd.Timedelta(minutes=5)
        prev_close = idx5[i] if i == 0 else idx5[i - 1] + pd.Timedelta(minutes=5)

        if pos is not None:
            pos, done = m14.process_minutes_topstep(pos, d1.loc[prev_close:close_time - one_ns])
            if done is not None:
                rec.append(done)

        if pos is not None or not m17.entry_allowed_m17(close_time):
            continue

        sig = m16.eb3_signal(d5, i)
        if sig == 0:
            continue

        sma200_5m = float(sma5.iloc[i]) if i < len(sma5) and pd.notna(sma5.iloc[i]) else np.nan
        hist = h1_ma.loc[:close_time]
        if not np.isfinite(sma200_5m) or hist.empty:
            continue

        sma20_h1 = float(hist.iloc[-1]["sma20_h1"])
        sma200_h1 = float(hist.iloc[-1]["sma200_h1"])
        entry = float(d5.Close.iloc[i])
        counters["eligible_eb3_candidates"] += 1

        if sig == 1:
            if entry <= sma200_5m:
                counters["blocked_5m_sma200"] += 1
                continue
            if entry <= sma200_h1:
                counters["blocked_1h_price_sma200"] += 1
                continue
            if sma20_h1 <= sma200_h1:
                counters["blocked_1h_sma20_vs_sma200"] += 1
                continue
            sl = float(d5.Low.iloc[i])
            risk = entry - sl
            if risk <= 0:
                continue
            pos = {
                "side": 1,
                "entry": entry,
                "entry_time": close_time,
                "risk": risk,
                "initial_stop": sl,
                "active_stop": sl,
                "tp": entry + 7.0 * risk,
                "best_price": entry,
                "phase2": False,
                "sma200_5m": sma200_5m,
                "sma20_h1": sma20_h1,
                "sma200_h1": sma200_h1,
                "eb3_time": idx5[i],
                "eb3_open": float(d5.Open.iloc[i]),
                "eb3_high": float(d5.High.iloc[i]),
                "eb3_low": float(d5.Low.iloc[i]),
                "eb3_close": entry,
            }
        else:
            if entry >= sma200_5m:
                counters["blocked_5m_sma200"] += 1
                continue
            if entry >= sma200_h1:
                counters["blocked_1h_price_sma200"] += 1
                continue
            if sma20_h1 >= sma200_h1:
                counters["blocked_1h_sma20_vs_sma200"] += 1
                continue
            sl = float(d5.High.iloc[i])
            risk = sl - entry
            if risk <= 0:
                continue
            pos = {
                "side": -1,
                "entry": entry,
                "entry_time": close_time,
                "risk": risk,
                "initial_stop": sl,
                "active_stop": sl,
                "tp": entry - 7.0 * risk,
                "best_price": entry,
                "phase2": False,
                "sma200_5m": sma200_5m,
                "sma20_h1": sma20_h1,
                "sma200_h1": sma200_h1,
                "eb3_time": idx5[i],
                "eb3_open": float(d5.Open.iloc[i]),
                "eb3_high": float(d5.High.iloc[i]),
                "eb3_low": float(d5.Low.iloc[i]),
                "eb3_close": entry,
            }
        counters["accepted_entries"] += 1

    if pos is not None:
        pos, done = m14.process_minutes_topstep(pos, d1.loc[idx5[-1] + pd.Timedelta(minutes=5):])
        if done is not None:
            rec.append(done)

    return pd.DataFrame(rec), counters


def main() -> None:
    d1 = m21.load_full_1m()
    d5 = b.make_5m(d1)
    data_start = str(d1.index.min())
    data_end = str(d1.index.max())
    elapsed_days = float((d1.index.max() - d1.index.min()) / pd.Timedelta(days=1))
    elapsed_years = elapsed_days / 365.2425

    trades, counters = simulate_m25(d1, d5)
    trades.to_csv(OUT / "m25_full_history_trades.csv", index=False)

    ev = m20.evaluate_dynamic20_capped900(trades, d1)
    ledger = ev["ledger"].copy()
    ledger.to_csv(OUT / "m25_full_history_ledger.csv", index=False)

    summary = m20.summarize(trades, ev)
    summary.update({
        "data_start": data_start,
        "data_end": data_end,
        "elapsed_days": elapsed_days,
        "elapsed_years": elapsed_years,
        "longest_loss_streak": m21.longest_loss_streak(trades["R"] if not trades.empty else pd.Series(dtype=float)),
    })
    annual = m21.period_stats(trades, ledger, "year")
    quarterly = m21.period_stats(trades, ledger, "quarter")

    payload = {
        "method": "offline research simulation only",
        "baseline": "M24",
        "only_change": "completed 1h SMA20 must be above SMA200 for long and below SMA200 for short",
        "unchanged": [
            "5m EB3 direct entry",
            "5m price-vs-SMA200 directional filter",
            "1h price-vs-completed-SMA200 directional filter",
            "M13 TP7/trailing management",
            "M17 no-entry 10:00-17:00 CT",
            "M20 dynamic 20% headroom risk capped at $900",
        ],
        "data_start": data_start,
        "data_end": data_end,
        "elapsed_years": elapsed_years,
        "entry_filter_counters": counters,
        "summary": summary,
        "annual": annual,
        "quarterly": quarterly,
    }
    (OUT / "m25_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    s = summary
    lines = [
        "# M25 — M24 + completed 1h SMA20 vs SMA200 alignment",
        "",
        f"Data: {data_start} -> {data_end} (~{elapsed_years:.2f} years)",
        "",
        "Only change vs M24: long requires completed 1h SMA20 > SMA200; short requires SMA20 < SMA200.",
        "",
        "| Trades | W | L | BE | WR ex-BE | Avg R | Net $ | Final balance | Avg risk $ | Min risk $ | Max risk $ | Trades at $900 | Min MLL headroom $ | Loss streak | Survived |",
        "|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|",
        f"| {s['trades']} | {s['wins']} | {s['losses']} | {s['breakeven']} | {s['win_rate_ex_be_pct']:.2f}% | {s['avg_R']:.3f} | {s['net_profit']:.0f} | {s['final_balance']:.0f} | {s['average_risk_dollars']:.0f} | {s['minimum_risk_dollars']:.0f} | {s['maximum_risk_dollars']:.0f} | {s['cap_hit_trades']} | {s['minimum_mll_headroom']:.0f} | {s['longest_loss_streak']} | {s['topstep_survived']} |",
        "",
        "## Entry filter counts",
        "",
        f"- Eligible EB3 candidates: {counters.get('eligible_eb3_candidates', 0)}",
        f"- Blocked by 5m SMA200: {counters.get('blocked_5m_sma200', 0)}",
        f"- Passed 5m but blocked by 1h price/SMA200: {counters.get('blocked_1h_price_sma200', 0)}",
        f"- Passed price filters but blocked by 1h SMA20/SMA200 alignment: {counters.get('blocked_1h_sma20_vs_sma200', 0)}",
        f"- Accepted entries: {counters.get('accepted_entries', 0)}",
        "",
        "## By calendar year",
        "",
        "| Year | Trades | W | L | BE | WR ex-BE | Avg R | Sum R | Net $ | Avg risk $ | Loss streak |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in annual:
        lines.append(
            f"| {r['period']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['breakeven']} | "
            f"{r['win_rate_ex_be_pct']:.2f}% | {r['avg_R']:.3f} | {r['sum_R']:.1f} | "
            f"{r['net_profit_dollars']:.0f} | {r['average_risk_dollars']:.0f} | {r['longest_loss_streak']} |"
        )

    report = "\n".join(lines) + "\n"
    (OUT / "m25_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
