from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

import run_m10_trailing_initial_risk as b
import run_m17_eb3_noentry_10_17ct as m17
import run_m20_m17_dynamic20_capped900 as m20
import run_m21_m20_full_mgc_history as m21
import run_m28_fib_358_mtf_exit as m28
import run_m29_fib_358_trailing10_tp7 as m29

OUT = Path("artifacts/m30_fib_358_entryonly_trailing10_tp7")
OUT.mkdir(parents=True, exist_ok=True)
EPS = 1e-9


def simulate_m30(d1: pd.DataFrame, d5: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """M29 entry logic; after entry, MA 3/5/8 no longer affects exits."""
    h1 = m28.completed_h1_fib_mas(d1)
    m5 = m28.five_minute_fib_mas(d5)
    low10 = d5["Low"].rolling(10, min_periods=10).min()
    high10 = d5["High"].rolling(10, min_periods=10).max()

    idx5 = d5.index
    one_ns = pd.Timedelta(nanoseconds=1)
    pos = None
    rec: list[dict] = []

    prev_eligible_long = False
    prev_eligible_short = False
    long_armed = False
    short_armed = False

    counters = {
        "long_setups_formed": 0,
        "short_setups_formed": 0,
        "accepted_long_entries": 0,
        "accepted_short_entries": 0,
        "blocked_by_entry_hours": 0,
        "invalid_10bar_stop": 0,
        "stop_ratchets": 0,
    }

    for i in range(len(d5)):
        close_time = idx5[i] + pd.Timedelta(minutes=5)
        prev_close = idx5[i] if i == 0 else idx5[i - 1] + pd.Timedelta(minutes=5)

        if pos is not None:
            pos, done = m29.process_interval(pos, d1.loc[prev_close:close_time - one_ns])
            if done is not None:
                rec.append(done)

        row5 = m5.iloc[i]
        vals5 = [row5.get(f"sma{n}_5m", np.nan) for n in (3, 5, 8)]
        valid5 = all(pd.notna(v) and np.isfinite(float(v)) for v in vals5)
        if not valid5:
            prev_eligible_long = prev_eligible_short = False
            long_armed = short_armed = False
            continue
        sma3_5, sma5_5, sma8_5 = map(float, vals5)

        hist = h1.loc[:close_time]
        if hist.empty:
            continue
        hr = hist.iloc[-1]
        close_h1 = float(hr["close_h1"])
        sma3_h1 = float(hr["sma3_h1"])
        sma5_h1 = float(hr["sma5_h1"])
        sma8_h1 = float(hr["sma8_h1"])
        sma200_h1 = float(hr["sma200_h1"])

        long_regime = close_h1 > sma200_h1 and sma3_h1 > sma5_h1 > sma8_h1 > sma200_h1
        short_regime = close_h1 < sma200_h1 and sma3_h1 < sma5_h1 < sma8_h1 < sma200_h1
        long_5m = sma3_5 > sma5_5 and sma3_5 > sma8_5
        short_5m = sma3_5 < sma5_5 and sma3_5 < sma8_5
        eligible_long = long_regime and long_5m
        eligible_short = short_regime and short_5m

        if eligible_long and not prev_eligible_long:
            long_armed = True
            counters["long_setups_formed"] += 1
        elif not eligible_long:
            long_armed = False

        if eligible_short and not prev_eligible_short:
            short_armed = True
            counters["short_setups_formed"] += 1
        elif not eligible_short:
            short_armed = False

        prev_eligible_long = eligible_long
        prev_eligible_short = eligible_short

        # No SMA3/SMA8 exit here. MAs are entry-only in M30.
        if pos is not None:
            side = int(pos["side"])
            old = float(pos["active_stop"])
            if side == 1 and pd.notna(low10.iloc[i]):
                new = max(old, float(low10.iloc[i]))
                if new > old + EPS:
                    counters["stop_ratchets"] += 1
                pos["active_stop"] = new
            elif side == -1 and pd.notna(high10.iloc[i]):
                new = min(old, float(high10.iloc[i]))
                if new < old - EPS:
                    counters["stop_ratchets"] += 1
                pos["active_stop"] = new

        if pos is not None:
            continue

        if not m17.entry_allowed_m17(close_time):
            if long_armed or short_armed:
                counters["blocked_by_entry_hours"] += 1
            continue

        if pd.isna(low10.iloc[i]) or pd.isna(high10.iloc[i]):
            continue

        entry = float(d5.Close.iloc[i])
        if long_armed and eligible_long:
            sl = float(low10.iloc[i])
            risk = entry - sl
            if risk <= 0:
                counters["invalid_10bar_stop"] += 1
                continue
            pos = {
                "side": 1,
                "entry": entry,
                "entry_time": close_time,
                "risk": risk,
                "initial_stop": sl,
                "active_stop": sl,
                "tp": entry + 7.0 * risk,
                "trigger_time": idx5[i],
                "sma3_5m": sma3_5,
                "sma5_5m": sma5_5,
                "sma8_5m": sma8_5,
                "close_h1": close_h1,
                "sma3_h1": sma3_h1,
                "sma5_h1": sma5_h1,
                "sma8_h1": sma8_h1,
                "sma200_h1": sma200_h1,
            }
            long_armed = False
            counters["accepted_long_entries"] += 1
        elif short_armed and eligible_short:
            sl = float(high10.iloc[i])
            risk = sl - entry
            if risk <= 0:
                counters["invalid_10bar_stop"] += 1
                continue
            pos = {
                "side": -1,
                "entry": entry,
                "entry_time": close_time,
                "risk": risk,
                "initial_stop": sl,
                "active_stop": sl,
                "tp": entry - 7.0 * risk,
                "trigger_time": idx5[i],
                "sma3_5m": sma3_5,
                "sma5_5m": sma5_5,
                "sma8_5m": sma8_5,
                "close_h1": close_h1,
                "sma3_h1": sma3_h1,
                "sma5_h1": sma5_h1,
                "sma8_h1": sma8_h1,
                "sma200_h1": sma200_h1,
            }
            short_armed = False
            counters["accepted_short_entries"] += 1

    if pos is not None:
        end_ts = idx5[-1] + pd.Timedelta(minutes=5)
        rec.append(m29.finish_trade(pos, float(d5.Close.iloc[-1]), end_ts, "data_end"))

    return pd.DataFrame(rec), counters


def main() -> None:
    d1 = m21.load_full_1m()
    d5 = b.make_5m(d1)
    data_start = str(d1.index.min())
    data_end = str(d1.index.max())
    elapsed_years = float((d1.index.max() - d1.index.min()) / pd.Timedelta(days=365.2425))

    trades, counters = simulate_m30(d1, d5)
    trades.to_csv(OUT / "m30_full_history_trades.csv", index=False)

    ev = m20.evaluate_dynamic20_capped900(trades, d1)
    ev["ledger"].to_csv(OUT / "m30_full_history_ledger.csv", index=False)

    summary = m20.summarize(trades, ev)
    summary["longest_loss_streak"] = m21.longest_loss_streak(trades["R"] if not trades.empty else pd.Series(dtype=float))
    annual_raw = m29.raw_period_stats(trades, "year")
    quarterly_raw = m29.raw_period_stats(trades, "quarter")
    exits = trades["reason"].value_counts().to_dict() if not trades.empty else {}

    payload = {
        "method": "offline research simulation only",
        "strategy": "M30 Fibonacci SMA 3/5/8 entry-only + rolling 10x5m wick stop + TP7",
        "only_change_vs_M29": "remove SMA3/SMA8 close exit entirely",
        "entry_logic": "same as M29",
        "initial_stop": "long lowest low / short highest high of last 10 completed 5m candles including signal candle",
        "trailing_stop": "rolling 10-bar wick extreme, ratchet only, updated after each completed 5m bar",
        "tp": "fixed 7R from initial 10-bar stop distance",
        "exit_logic": "rolling10 trailing stop, TP7, or 15:10 CT forced-flat only",
        "data_start": data_start,
        "data_end": data_end,
        "elapsed_years": elapsed_years,
        "counters": counters,
        "exit_reasons": exits,
        "summary": summary,
        "annual_raw_all_trades": annual_raw,
        "quarterly_raw_all_trades": quarterly_raw,
    }
    (OUT / "m30_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    s = summary
    lines = [
        "# M30 — Fibonacci 3/5/8 entry-only + rolling 10-bar stop + TP7",
        "",
        f"Data: {data_start} -> {data_end} (~{elapsed_years:.2f} years)",
        "",
        "Moving averages are entry-only after a position opens. No SMA3/SMA8 exit.",
        "Exit priority: active rolling-10 stop / TP7 intraminute, or 15:10 CT forced-flat.",
        "",
        "| Trades | W | L | BE | WR ex-BE | Avg R | Sum R | Net $ dynamic | Final balance | Avg risk $ | Min risk $ | Max risk $ | Min MLL headroom $ | Loss streak | Survived |",
        "|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|",
        f"| {s['trades']} | {s['wins']} | {s['losses']} | {s['breakeven']} | {s['win_rate_ex_be_pct']:.2f}% | {s['avg_R']:.3f} | {s.get('sum_R', 0):.1f} | {s['net_profit']:.0f} | {s['final_balance']:.0f} | {s['average_risk_dollars']:.0f} | {s['minimum_risk_dollars']:.2f} | {s['maximum_risk_dollars']:.0f} | {s['minimum_mll_headroom']:.2f} | {s['longest_loss_streak']} | {s['topstep_survived']} |",
        "",
        "## Exit reasons",
        "",
    ]
    for k, v in sorted(exits.items(), key=lambda kv: (-kv[1], kv[0])):
        lines.append(f"- {k}: {v}")
    lines += [
        "",
        "## Raw performance by calendar year (all trades, independent of MLL path)",
        "",
        "| Year | Trades | W | L | BE | WR ex-BE | Avg R | Sum R | Loss streak |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in annual_raw:
        lines.append(
            f"| {r['period']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['breakeven']} | "
            f"{r['win_rate_ex_be_pct']:.2f}% | {r['avg_R']:.3f} | {r['sum_R']:.1f} | {r['longest_loss_streak']} |"
        )
    report = "\n".join(lines) + "\n"
    (OUT / "m30_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
