from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

DATA = Path("external/mgc5/ohlcv_MGC_5m_continuous.csv")
OUT = Path("artifacts")
OUT.mkdir(parents=True, exist_ok=True)
END = pd.Timestamp("2026-03-23 23:59:59", tz="UTC")
STARTS = {
    "1y": pd.Timestamp("2025-03-23", tz="UTC"),
    "6m": pd.Timestamp("2025-09-23", tz="UTC"),
    "3m": pd.Timestamp("2025-12-23", tz="UTC"),
}
RR = 3.0


def load_data() -> pd.DataFrame:
    d = pd.read_csv(DATA)
    d["timestamp"] = pd.to_datetime(d["timestamp"], utc=True)
    d = d.set_index("timestamp").sort_index()
    d = d.rename(columns={"open": "Open", "high": "High", "low": "Low", "close": "Close", "volume": "Volume"})
    d = d[["Open", "High", "Low", "Close", "Volume"]].dropna()
    return d.loc[(d.index >= STARTS["1y"]) & (d.index <= END)].copy()


def add_pivot(pivots: list[dict], kind: str, idx_i: int, price: float) -> None:
    p = {"kind": kind, "i": idx_i, "price": float(price)}
    if not pivots:
        pivots.append(p)
        return
    if pivots[-1]["kind"] != kind:
        pivots.append(p)
        return
    # Consecutive pivots of the same kind collapse to the more extreme wick.
    if kind == "L" and price < pivots[-1]["price"]:
        pivots[-1] = p
    elif kind == "H" and price > pivots[-1]["price"]:
        pivots[-1] = p


def simulate(d: pd.DataFrame) -> pd.DataFrame:
    O = d.Open.to_numpy(float)
    H = d.High.to_numpy(float)
    L = d.Low.to_numpy(float)
    C = d.Close.to_numpy(float)
    idx = d.index
    n = len(d)

    pivots: list[dict] = []
    consumed_patterns: set[tuple] = set()
    pos = None
    trades: list[dict] = []

    for i in range(2, n):
        # Manage an already-open research trade using bars AFTER its breakout-close entry.
        if pos is not None:
            side = pos["side"]
            sl = pos["sl"]
            tp = pos["tp"]
            exit_price = None
            reason = None

            if side == 1:
                if O[i] <= sl:
                    exit_price, reason = O[i], "gap_sl"
                elif O[i] >= tp:
                    exit_price, reason = O[i], "gap_tp"
                elif L[i] <= sl and H[i] >= tp:
                    exit_price, reason = sl, "both_stop_first"
                elif L[i] <= sl:
                    exit_price, reason = sl, "sl"
                elif H[i] >= tp:
                    exit_price, reason = tp, "tp"
            else:
                if O[i] >= sl:
                    exit_price, reason = O[i], "gap_sl"
                elif O[i] <= tp:
                    exit_price, reason = O[i], "gap_tp"
                elif H[i] >= sl and L[i] <= tp:
                    exit_price, reason = sl, "both_stop_first"
                elif H[i] >= sl:
                    exit_price, reason = sl, "sl"
                elif L[i] <= tp:
                    exit_price, reason = tp, "tp"

            if exit_price is not None:
                gross_r = ((float(exit_price) - pos["entry"]) * side) / pos["risk"]
                trades.append({**pos, "exit": float(exit_price), "exit_time": idx[i], "exit_reason": reason, "result_r": float(gross_r)})
                pos = None

        # At bar i, pivot candidate i-1 is now confirmed using one bar on each side.
        j = i - 1
        pivot_low = L[j] < L[j - 1] and L[j] < L[j + 1]
        pivot_high = H[j] > H[j - 1] and H[j] > H[j + 1]
        # An outside bar that is simultaneously a high and low pivot is ignored because
        # its internal high/low order is unknowable from OHLC alone.
        if pivot_low and not pivot_high:
            add_pivot(pivots, "L", j, L[j])
        elif pivot_high and not pivot_low:
            add_pivot(pivots, "H", j, H[j])

        if pos is not None or len(pivots) < 3:
            continue

        a, b, c = pivots[-3], pivots[-2], pivots[-1]

        # W = low1 -> high1 -> higher low2 -> CLOSE above high1.
        if a["kind"] == "L" and b["kind"] == "H" and c["kind"] == "L" and c["price"] > a["price"]:
            key = ("W", a["i"], b["i"], c["i"])
            if key not in consumed_patterns and i > c["i"] and C[i] > b["price"]:
                entry = float(C[i])
                sl = float(min(a["price"], c["price"]))
                risk = entry - sl
                if risk > 0:
                    pos = {
                        "pattern": "W_LONG",
                        "side": 1,
                        "pivot1_time": idx[a["i"]],
                        "pivot2_time": idx[b["i"]],
                        "pivot3_time": idx[c["i"]],
                        "pivot1": a["price"],
                        "pivot2": b["price"],
                        "pivot3": c["price"],
                        "entry": entry,
                        "entry_time": idx[i],
                        "sl": sl,
                        "tp": entry + RR * risk,
                        "risk": risk,
                    }
                    consumed_patterns.add(key)
                    continue

        # M = high1 -> low1 -> lower high2 -> CLOSE below low1.
        if a["kind"] == "H" and b["kind"] == "L" and c["kind"] == "H" and c["price"] < a["price"]:
            key = ("M", a["i"], b["i"], c["i"])
            if key not in consumed_patterns and i > c["i"] and C[i] < b["price"]:
                entry = float(C[i])
                sl = float(max(a["price"], c["price"]))
                risk = sl - entry
                if risk > 0:
                    pos = {
                        "pattern": "M_SHORT",
                        "side": -1,
                        "pivot1_time": idx[a["i"]],
                        "pivot2_time": idx[b["i"]],
                        "pivot3_time": idx[c["i"]],
                        "pivot1": a["price"],
                        "pivot2": b["price"],
                        "pivot3": c["price"],
                        "entry": entry,
                        "entry_time": idx[i],
                        "sl": sl,
                        "tp": entry - RR * risk,
                        "risk": risk,
                    }
                    consumed_patterns.add(key)

    return pd.DataFrame(trades)


def enrich_excursions(d: pd.DataFrame, t: pd.DataFrame) -> pd.DataFrame:
    if t.empty:
        return t
    out = t.copy()
    mfe_tp, mae_sl = [], []
    for _, tr in out.iterrows():
        bars = d.loc[(d.index > pd.Timestamp(tr.entry_time)) & (d.index <= pd.Timestamp(tr.exit_time))]
        if bars.empty:
            mfe_tp.append(np.nan)
            mae_sl.append(np.nan)
            continue
        entry, sl, tp = float(tr.entry), float(tr.sl), float(tr.tp)
        if int(tr.side) == 1:
            fav = max(0.0, float(bars.High.max()) - entry)
            adv = max(0.0, entry - float(bars.Low.min()))
            tp_dist, sl_dist = tp - entry, entry - sl
        else:
            fav = max(0.0, entry - float(bars.Low.min()))
            adv = max(0.0, float(bars.High.max()) - entry)
            tp_dist, sl_dist = entry - tp, sl - entry
        mfe_tp.append(min(100.0, 100 * fav / tp_dist) if tp_dist > 0 else np.nan)
        mae_sl.append(min(100.0, 100 * adv / sl_dist) if sl_dist > 0 else np.nan)
    out["MFE_TP_pct"] = mfe_tp
    out["MAE_SL_pct"] = mae_sl
    return out


def metrics(t: pd.DataFrame) -> dict:
    if t.empty:
        return {"trades": 0, "wins": 0, "losses": 0, "win_rate_pct": 0.0, "avg_r": None, "profit_factor_r": None}
    wins = t.result_r > 0
    gross_win = float(t.loc[wins, "result_r"].sum())
    gross_loss = float(-t.loc[~wins, "result_r"].sum())
    return {
        "trades": int(len(t)),
        "wins": int(wins.sum()),
        "losses": int((~wins).sum()),
        "win_rate_pct": float(100 * wins.mean()),
        "avg_r": float(t.result_r.mean()),
        "profit_factor_r": gross_win / gross_loss if gross_loss > 0 else None,
    }


def main() -> None:
    d = load_data()
    snap = OUT / "m8_mgc_5m_price_action_snapshot.csv"
    d.to_csv(snap)
    sha = hashlib.sha256(snap.read_bytes()).hexdigest()
    results = []

    for label, start in STARTS.items():
        x = d.loc[d.index >= start].copy()
        t = enrich_excursions(x, simulate(x))
        t.to_csv(OUT / f"m8_trades_{label}.csv", index=False)
        m = metrics(t)
        m["window"] = label
        if len(t):
            losses = t[t.result_r < 0]
            m["loss_mfe_tp_mean"] = float(losses.MFE_TP_pct.mean()) if len(losses) else None
        results.append(m)

    payload = {
        "method": "offline research-only price-action replay",
        "instrument": "MGC Micro Gold Futures",
        "timeframe": "5m",
        "session_filter": None,
        "indicators": None,
        "pattern_rule": {
            "pivot": "one-bar-left/one-bar-right wick pivot; ambiguous outside bars ignored",
            "long": "L1-H1-L2 with L2>L1, then close>H1",
            "short": "H1-L1-H2 with H2<H1, then close<L1",
            "entry": "breakout bar close",
            "stop_long": "lowest wick of W",
            "stop_short": "highest wick of M",
            "take_profit": "3R",
        },
        "snapshot_sha256": sha,
        "results": results,
    }
    (OUT / "m8_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = [
        "# M8 — Pure price-action W/M, 5m",
        "",
        f"Snapshot SHA256: `{sha}`",
        "",
        "| Window | Trades | Wins | Losses | WR | Avg R | PF(R) | Loss MFE→TP mean |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in results:
        lines.append(
            f"| {r['window']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['win_rate_pct']:.2f}% | "
            f"{r['avg_r']:.3f} | {r['profit_factor_r']:.3f} | {r.get('loss_mfe_tp_mean', float('nan')):.2f}% |"
        )
    lines += [
        "",
        "Rules:",
        "- No RSI, no moving averages, no engulfing/EB3, no break-even, no session filter.",
        "- Pivot lows/highs use candle wicks and are confirmed by one candle on each side.",
        "- W: lower first low, middle high, higher second low, then close above middle high.",
        "- M: higher first high, middle low, lower second high, then close below middle low.",
        "- Entry is the breakout candle CLOSE; stop uses the extreme wick of the full structure; TP = 3R.",
        "- If a later OHLC bar touches both stop and TP, stop is assumed first (conservative).",
    ]
    report = "\n".join(lines) + "\n"
    (OUT / "m8_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
