#!/usr/bin/env python3
"""Autonomous, bounded coding worker for AutoTrading issue #2.

The worker can use either GitHub Models or a local Ollama model running inside
the GitHub Actions runner. It edits only allow-listed research/backtest paths,
runs the repository test suite, and gives the model a bounded number of repair
rounds. It never places orders or connects to a brokerage account.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
REPO = os.environ.get("GITHUB_REPOSITORY", "willingemy-byte/AutoTrading")
TOKEN = os.environ["GITHUB_TOKEN"]
ISSUE_NUMBER = int(os.environ.get("ISSUE_NUMBER", "2"))
MODEL_PROVIDER = os.environ.get("MODEL_PROVIDER", "github").strip().lower()
MODEL = os.environ.get(
    "MODEL", "qwen2.5-coder:3b" if MODEL_PROVIDER == "ollama" else "openai/gpt-4.1"
)
RUN_ID = os.environ.get("GITHUB_RUN_ID", "local")
MAX_ROUNDS = int(os.environ.get("MAX_ROUNDS", "3"))
GITHUB_MODEL_URL = "https://models.github.ai/inference/chat/completions"
OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://127.0.0.1:11434/api/chat")
API_ROOT = "https://api.github.com"

ALLOWED_PREFIXES = ("backtest/", "tests/", "docs/")
ALLOWED_EXACT = {"requirements.txt"}
CONTEXT_FILES = [
    "AGENTS.md",
    "WORKPLAN.md",
    "STATUS.md",
    "docs/strategy-baseline.md",
    "strategies/manus_v1_executable.pine",
    "strategies/manus_v1_no_time_filter.pine",
    "tests/test_strategy_contract.py",
]


def http_json(url: str, *, method: str = "GET", payload: dict | None = None) -> dict:
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {TOKEN}",
        "X-GitHub-Api-Version": "2026-03-10",
    }
    data = None
    if payload is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(payload).encode("utf-8")
    request = Request(url, method=method, headers=headers, data=data)
    try:
        with urlopen(request, timeout=180) as response:
            return json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code} from {url}: {detail[:2000]}") from exc


def local_json(url: str, payload: dict) -> dict:
    request = Request(
        url,
        method="POST",
        headers={"Content-Type": "application/json"},
        data=json.dumps(payload).encode("utf-8"),
    )
    try:
        with urlopen(request, timeout=900) as response:
            return json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code} from local model: {detail[:2000]}") from exc


def read_context() -> str:
    chunks: list[str] = []
    for relative in CONTEXT_FILES:
        path = ROOT / relative
        if path.exists():
            text = path.read_text(encoding="utf-8")
            chunks.append(f"\n===== {relative} =====\n{text[:30000]}")
    return "".join(chunks)


def issue_payload() -> str:
    issue = http_json(f"{API_ROOT}/repos/{REPO}/issues/{ISSUE_NUMBER}")
    return f"{issue.get('title', '')}\n\n{issue.get('body', '')}"


def run_tests() -> tuple[int, str]:
    completed = subprocess.run(
        [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"],
        cwd=ROOT,
        text=True,
        capture_output=True,
        timeout=240,
    )
    output = (completed.stdout + "\n" + completed.stderr).strip()
    return completed.returncode, output[-16000:]


def safe_path(raw: str) -> Path:
    raw = raw.strip().replace("\\", "/")
    if raw in ALLOWED_EXACT or raw.startswith(ALLOWED_PREFIXES):
        candidate = (ROOT / raw).resolve()
        candidate.relative_to(ROOT.resolve())
        return candidate
    raise ValueError(f"Model attempted disallowed path: {raw}")


def model_call(task: str, context: str, prior_tests: str, round_no: int) -> dict:
    system = (
        "You are AGENT-ENGINE, a coding worker inside the AutoTrading repository. "
        "This is research/backtesting only: never add brokerage connectivity, order execution, "
        "credential handling, or live trading. Follow AGENTS.md and the issue literally. "
        "Do not optimize parameters. Preserve recovered historical baselines. "
        "Return ONLY a JSON object with keys summary and files. files must map repository-relative "
        "paths to COMPLETE UTF-8 file contents. You may modify only backtest/, tests/, docs/, or "
        "requirements.txt. Prefer the Python standard library unless a dependency is necessary. "
        "The implementation must be deterministic and must explicitly document/test ambiguous "
        "intrabar stop/target behavior."
    )
    user = (
        f"TASK (GitHub issue #{ISSUE_NUMBER}):\n{task}\n\n"
        f"ROUND: {round_no}/{MAX_ROUNDS}\n"
        f"CURRENT REPOSITORY CONTEXT:\n{context}\n\n"
        f"LATEST TEST OUTPUT:\n{prior_tests or 'No new test output yet.'}\n\n"
        "Produce the smallest complete set of file changes that advances the issue and passes all tests."
    )
    messages = [
        {"role": "system", "content": system},
        {"role": "user", "content": user},
    ]

    if MODEL_PROVIDER == "ollama":
        payload = {
            "model": MODEL,
            "messages": messages,
            "stream": False,
            "format": "json",
            "options": {
                "temperature": 0.1,
                "num_ctx": 32768,
                "num_predict": 10000,
            },
        }
        response = local_json(OLLAMA_URL, payload)
        content = response["message"]["content"]
    elif MODEL_PROVIDER == "github":
        payload = {
            "model": MODEL,
            "messages": messages,
            "temperature": 0.1,
            "max_tokens": 12000,
            "response_format": {"type": "json_object"},
        }
        response = http_json(GITHUB_MODEL_URL, method="POST", payload=payload)
        content = response["choices"][0]["message"]["content"]
    else:
        raise RuntimeError(f"Unsupported MODEL_PROVIDER: {MODEL_PROVIDER}")

    try:
        result = json.loads(content)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Model did not return valid JSON: {content[:2000]}") from exc
    if not isinstance(result.get("files"), dict):
        raise RuntimeError("Model response missing files object")
    return result


def apply_files(files: dict[str, str]) -> list[str]:
    changed: list[str] = []
    for relative, content in files.items():
        if not isinstance(relative, str) or not isinstance(content, str):
            raise ValueError("files must map string paths to string contents")
        path = safe_path(relative)
        path.parent.mkdir(parents=True, exist_ok=True)
        old = path.read_text(encoding="utf-8") if path.exists() else None
        if old != content:
            path.write_text(content, encoding="utf-8")
            changed.append(path.relative_to(ROOT).as_posix())
    return changed


def refreshed_context(changed: list[str]) -> str:
    base = read_context()
    extra: list[str] = []
    for relative in changed:
        path = ROOT / relative
        if path.exists():
            extra.append(f"\n===== CURRENT {relative} =====\n{path.read_text(encoding='utf-8')[:30000]}")
    return base + "".join(extra)


def write_report(report: dict) -> None:
    directory = ROOT / "agent_runs"
    directory.mkdir(exist_ok=True)
    (directory / f"engine-{RUN_ID}.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def main() -> int:
    report: dict[str, object] = {
        "run_id": RUN_ID,
        "issue": ISSUE_NUMBER,
        "provider": MODEL_PROVIDER,
        "model": MODEL,
        "rounds": [],
        "changed_files": [],
        "success": False,
    }
    all_changed: list[str] = []
    try:
        task = issue_payload()
        context = read_context()
        code, test_output = run_tests()
        report["initial_tests"] = {"returncode": code, "output": test_output}

        for round_no in range(1, MAX_ROUNDS + 1):
            result = model_call(task, context, test_output, round_no)
            changed = apply_files(result["files"])
            all_changed.extend(changed)
            code, test_output = run_tests()
            report["rounds"].append(
                {
                    "round": round_no,
                    "summary": result.get("summary", ""),
                    "changed": changed,
                    "test_returncode": code,
                    "test_output": test_output,
                }
            )
            if code == 0 and changed:
                report["success"] = True
                break
            context = refreshed_context(list(dict.fromkeys(all_changed)))

        report["changed_files"] = list(dict.fromkeys(all_changed))
        report["final_tests"] = {"returncode": code, "output": test_output}
        write_report(report)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0 if report["success"] else 1
    except Exception as exc:
        report["error"] = f"{type(exc).__name__}: {exc}"
        report["changed_files"] = list(dict.fromkeys(all_changed))
        write_report(report)
        print(json.dumps(report, ensure_ascii=False, indent=2), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
