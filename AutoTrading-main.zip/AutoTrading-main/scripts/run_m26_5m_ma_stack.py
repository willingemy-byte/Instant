from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

import run_m10_trailing_initial_risk as b
import run_m14_topstep_150k_risk300 as m14
import run_m16_eb3_1h_sma50 as m16
import run_m17_eb3_noentry_10_17ct as m17
import run_m20_m17_dynamic20_capped900 as m20
import run_m21_m20_full_mgc_history as m21
import run_m25_h1_sma20_vs_sma200 as m25

OUT = Path("artifacts/m26_5m_ma_stack")
OUT.mkdir(parents=True, exist_ok=True)


def five_minute_stack(d5: pd.DataFrame) -> pd.DataFrame:
    out = pd.DataFrame(index=d5.index)
    close = d5["Close"]
    for n in (5, 8, 13, 20, 200):
        out[f"sma{n}_5m"] = close.rolling(n, min_periods=n).mean()
    return out


def simulate_m26(d1: pd.DataFrame, d5: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """M25 plus 5m SMA5/8/13/20/200 ordered-stack confirmation.

    Long EB3 entry requires SMA5 > SMA8 > SMA13 > SMA20 > SMA200.
    Short EB3 entry requires SMA5 < SMA8 < SMA13 < SMA20 < SMA200.
    All other M25 conditions and management are unchanged.
    """
    h1_ma = m25.completed_h1_sma20_sma200(d1)
    ma5 = five_minute_stack(d5)
    if h1_ma.empty or ma5["sma200_5m"].dropna().empty:
        return pd.DataFrame(), {}

    pos = None
    rec: list[dict] = []
    idx5 = d5.index
    one_ns = pd.Timedelta(nanoseconds=1)
    counters = {
        "eligible_eb3_candidates": 0,
        "blocked_5m_stack": 0,
        "blocked_1h_price_sma200": 0,
        "blocked_1h_sma20_vs_sma200": 0,
        "accepted_entries": 0,
    }

    for i in range(len(d5)):
        close_time = idx5[i] + pd.Timedelta(minutes=5)
        prev_close = idx5[i] if i == 0 else idx5[i - 1] + pd.Timedelta(minutes=5)

        if pos is not None:
            pos, done = m14.process_minutes_topstep(pos, d1.loc[prev_close:close_time - one_ns])
            if done is not None:
                rec.append(done)

        if pos is not None or not m17.entry_allowed_m17(close_time):
            continue

        sig = m16.eb3_signal(d5, i)
        if sig == 0:
            continue

        row = ma5.iloc[i]
        vals = [row[f"sma{n}_5m"] for n in (5, 8, 13, 20, 200)]
        if any(pd.isna(v) or not np.isfinite(float(v)) for v in vals):
            continue

        sma5_5m, sma8_5m, sma13_5m, sma20_5m, sma200_5m = map(float, vals)
        hist = h1_ma.loc[:close_time]
        if hist.empty:
            continue

        sma20_h1 = float(hist.iloc[-1]["sma20_h1"])
        sma200_h1 = float(hist.iloc[-1]["sma200_h1"])
        entry = float(d5.Close.iloc[i])
        counters["eligible_eb3_candidates"] += 1

        if sig == 1:
            stack_ok = sma5_5m > sma8_5m > sma13_5m > sma20_5m > sma200_5m
            if not stack_ok:
                counters["blocked_5m_stack"] += 1
                continue
            if entry <= sma200_h1:
                counters["blocked_1h_price_sma200"] += 1
                continue
            if sma20_h1 <= sma200_h1:
                counters["blocked_1h_sma20_vs_sma200"] += 1
                continue
            sl = float(d5.Low.iloc[i])
            risk = entry - sl
            if risk <= 0:
                continue
            pos = {
                "side": 1,
                "entry": entry,
                "entry_time": close_time,
                "risk": risk,
                "initial_stop": sl,
                "active_stop": sl,
                "tp": entry + 7.0 * risk,
                "best_price": entry,
                "phase2": False,
                "sma5_5m": sma5_5m,
                "sma8_5m": sma8_5m,
                "sma13_5m": sma13_5m,
                "sma20_5m": sma20_5m,
                "sma200_5m": sma200_5m,
                "sma20_h1": sma20_h1,
                "sma200_h1": sma200_h1,
                "eb3_time": idx5[i],
                "eb3_open": float(d5.Open.iloc[i]),
                "eb3_high": float(d5.High.iloc[i]),
                "eb3_low": float(d5.Low.iloc[i]),
                "eb3_close": entry,
            }
        else:
            stack_ok = sma5_5m < sma8_5m < sma13_5m < sma20_5m < sma200_5m
            if not stack_ok:
                counters["blocked_5m_stack"] += 1
                continue
            if entry >= sma200_h1:
                counters["blocked_1h_price_sma200"] += 1
                continue
            if sma20_h1 >= sma200_h1:
                counters["blocked_1h_sma20_vs_sma200"] += 1
                continue
            sl = float(d5.High.iloc[i])
            risk = sl - entry
            if risk <= 0:
                continue
            pos = {
                "side": -1,
                "entry": entry,
                "entry_time": close_time,
                "risk": risk,
                "initial_stop": sl,
                "active_stop": sl,
                "tp": entry - 7.0 * risk,
                "best_price": entry,
                "phase2": False,
                "sma5_5m": sma5_5m,
                "sma8_5m": sma8_5m,
                "sma13_5m": sma13_5m,
                "sma20_5m": sma20_5m,
                "sma200_5m": sma200_5m,
                "sma20_h1": sma20_h1,
                "sma200_h1": sma200_h1,
                "eb3_time": idx5[i],
                "eb3_open": float(d5.Open.iloc[i]),
                "eb3_high": float(d5.High.iloc[i]),
                "eb3_low": float(d5.Low.iloc[i]),
                "eb3_close": entry,
            }

        counters["accepted_entries"] += 1

    if pos is not None:
        pos, done = m14.process_minutes_topstep(pos, d1.loc[idx5[-1] + pd.Timedelta(minutes=5):])
        if done is not None:
            rec.append(done)

    return pd.DataFrame(rec), counters


def main() -> None:
    d1 = m21.load_full_1m()
    d5 = b.make_5m(d1)
    data_start = str(d1.index.min())
    data_end = str(d1.index.max())
    elapsed_days = float((d1.index.max() - d1.index.min()) / pd.Timedelta(days=1))
    elapsed_years = elapsed_days / 365.2425

    trades, counters = simulate_m26(d1, d5)
    trades.to_csv(OUT / "m26_full_history_trades.csv", index=False)

    ev = m20.evaluate_dynamic20_capped900(trades, d1)
    ledger = ev["ledger"].copy()
    ledger.to_csv(OUT / "m26_full_history_ledger.csv", index=False)

    summary = m20.summarize(trades, ev)
    summary.update({
        "data_start": data_start,
        "data_end": data_end,
        "elapsed_days": elapsed_days,
        "elapsed_years": elapsed_years,
        "longest_loss_streak": m21.longest_loss_streak(trades["R"] if not trades.empty else pd.Series(dtype=float)),
    })
    annual = m21.period_stats(trades, ledger, "year")
    quarterly = m21.period_stats(trades, ledger, "quarter")

    payload = {
        "method": "offline research simulation only",
        "baseline": "M25",
        "only_change": "require ordered 5m SMA stack on the EB3 entry candle: 5>8>13>20>200 long; reverse short",
        "unchanged": [
            "5m EB3 direct entry trigger",
            "initial stop at EB3 wick extreme",
            "1h price-vs-completed-SMA200 directional filter",
            "completed 1h SMA20-vs-SMA200 alignment",
            "M13 TP7/trailing management",
            "M17 no-entry 10:00-17:00 CT",
            "M20 dynamic 20% headroom risk capped at $900",
        ],
        "data_start": data_start,
        "data_end": data_end,
        "elapsed_years": elapsed_years,
        "entry_filter_counters": counters,
        "summary": summary,
        "annual": annual,
        "quarterly": quarterly,
    }
    (OUT / "m26_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    s = summary
    lines = [
        "# M26 — M25 + 5m SMA5/8/13/20/200 stack",
        "",
        f"Data: {data_start} -> {data_end} (~{elapsed_years:.2f} years)",
        "",
        "Only change vs M25: EB3 long requires SMA5>SMA8>SMA13>SMA20>SMA200 on 5m; short requires reverse ordering.",
        "",
        "| Trades | W | L | BE | WR ex-BE | Avg R | Net $ | Final balance | Avg risk $ | Min risk $ | Max risk $ | Trades at $900 | Min MLL headroom $ | Loss streak | Survived |",
        "|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|",
        f"| {s['trades']} | {s['wins']} | {s['losses']} | {s['breakeven']} | {s['win_rate_ex_be_pct']:.2f}% | {s['avg_R']:.3f} | {s['net_profit']:.0f} | {s['final_balance']:.0f} | {s['average_risk_dollars']:.0f} | {s['minimum_risk_dollars']:.0f} | {s['maximum_risk_dollars']:.0f} | {s['cap_hit_trades']} | {s['minimum_mll_headroom']:.0f} | {s['longest_loss_streak']} | {s['topstep_survived']} |",
        "",
        "## Entry filter counts",
        "",
        f"- Eligible EB3 candidates: {counters.get('eligible_eb3_candidates', 0)}",
        f"- Blocked by 5m MA stack: {counters.get('blocked_5m_stack', 0)}",
        f"- Passed stack but blocked by 1h price/SMA200: {counters.get('blocked_1h_price_sma200', 0)}",
        f"- Passed price filters but blocked by 1h SMA20/SMA200: {counters.get('blocked_1h_sma20_vs_sma200', 0)}",
        f"- Accepted entries: {counters.get('accepted_entries', 0)}",
        "",
        "## By calendar year",
        "",
        "| Year | Trades | W | L | BE | WR ex-BE | Avg R | Sum R | Net $ | Avg risk $ | Loss streak |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in annual:
        lines.append(
            f"| {r['period']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['breakeven']} | "
            f"{r['win_rate_ex_be_pct']:.2f}% | {r['avg_R']:.3f} | {r['sum_R']:.1f} | "
            f"{r['net_profit_dollars']:.0f} | {r['average_risk_dollars']:.0f} | {r['longest_loss_streak']} |"
        )

    report = "\n".join(lines) + "\n"
    (OUT / "m26_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
