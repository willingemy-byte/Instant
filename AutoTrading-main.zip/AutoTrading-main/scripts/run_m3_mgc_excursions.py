from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pandas as pd
from backtesting import Backtest

from run_m3_mgc_long_windows import (
    Eb3Persistent3mStrategy,
    SOURCE_COMMIT,
    SOURCE_REPO,
    SOURCE_END,
    load_one_year_1m,
    to_3m,
)

OUT_DIR = Path("artifacts")
OUT_DIR.mkdir(parents=True, exist_ok=True)


def enrich_trades_with_excursions(trades: pd.DataFrame, data: pd.DataFrame) -> pd.DataFrame:
    enriched = trades.copy()
    records = []

    required = {"Size", "EntryBar", "ExitBar", "EntryPrice", "ExitPrice", "SL", "TP", "PnL"}
    missing = required.difference(enriched.columns)
    if missing:
        raise RuntimeError(f"Backtesting trade table missing required columns: {sorted(missing)}")

    for _, trade in enriched.iterrows():
        entry_bar = int(trade["EntryBar"])
        exit_bar = int(trade["ExitBar"])
        entry = float(trade["EntryPrice"])
        sl = float(trade["SL"])
        tp = float(trade["TP"])
        size = float(trade["Size"])

        # Inclusive bar range. On the exit 3m candle the exact intrabar order of
        # high/low is unknowable from OHLC alone, so raw excursion can exceed 100%.
        path = data.iloc[entry_bar : exit_bar + 1]
        if path.empty:
            raise RuntimeError(f"Empty price path for trade EntryBar={entry_bar} ExitBar={exit_bar}")

        max_high = float(path["High"].max())
        min_low = float(path["Low"].min())

        is_long = size > 0
        if is_long:
            risk = entry - sl
            reward = tp - entry
            favorable_move = max(0.0, max_high - entry)
            adverse_move = max(0.0, entry - min_low)
            favorable_price = max_high
            adverse_price = min_low
        else:
            risk = sl - entry
            reward = entry - tp
            favorable_move = max(0.0, entry - min_low)
            adverse_move = max(0.0, max_high - entry)
            favorable_price = min_low
            adverse_price = max_high

        if risk <= 0 or reward <= 0:
            mfe_r = float("nan")
            mae_r = float("nan")
            mfe_tp_raw = float("nan")
            mae_sl_raw = float("nan")
        else:
            mfe_r = favorable_move / risk
            mae_r = adverse_move / risk
            mfe_tp_raw = (favorable_move / reward) * 100.0
            mae_sl_raw = (adverse_move / risk) * 100.0

        records.append(
            {
                "Direction": "LONG" if is_long else "SHORT",
                "Outcome": "WIN" if float(trade["PnL"]) > 0 else ("LOSS" if float(trade["PnL"]) < 0 else "BE"),
                "MaxFavorablePrice": favorable_price,
                "MaxAdversePrice": adverse_price,
                "MFE_R": mfe_r,
                "MAE_R": mae_r,
                "MFE_TP_raw_pct": mfe_tp_raw,
                "MAE_SL_raw_pct": mae_sl_raw,
                "MFE_TP_pct": min(100.0, mfe_tp_raw) if pd.notna(mfe_tp_raw) else float("nan"),
                "MAE_SL_pct": min(100.0, mae_sl_raw) if pd.notna(mae_sl_raw) else float("nan"),
            }
        )

    excursion_df = pd.DataFrame(records, index=enriched.index)
    return pd.concat([enriched, excursion_df], axis=1)


def summarize_excursions(trades: pd.DataFrame) -> dict:
    losses = trades.loc[trades["Outcome"] == "LOSS"]
    wins = trades.loc[trades["Outcome"] == "WIN"]

    thresholds = [25, 50, 75, 90]
    loss_threshold_counts = {
        f"losses_reached_{t}pct_TP": int((losses["MFE_TP_pct"] >= t).sum())
        for t in thresholds
    }
    loss_threshold_pcts = {
        f"losses_reached_{t}pct_TP_pct": (
            float((losses["MFE_TP_pct"] >= t).mean() * 100.0) if len(losses) else 0.0
        )
        for t in thresholds
    }

    return {
        "all_mfe_tp_mean_pct": float(trades["MFE_TP_pct"].mean()) if len(trades) else 0.0,
        "all_mfe_tp_median_pct": float(trades["MFE_TP_pct"].median()) if len(trades) else 0.0,
        "all_mae_sl_mean_pct": float(trades["MAE_SL_pct"].mean()) if len(trades) else 0.0,
        "all_mae_sl_median_pct": float(trades["MAE_SL_pct"].median()) if len(trades) else 0.0,
        "wins_mae_sl_mean_pct": float(wins["MAE_SL_pct"].mean()) if len(wins) else 0.0,
        "wins_mae_sl_median_pct": float(wins["MAE_SL_pct"].median()) if len(wins) else 0.0,
        "losses_mfe_tp_mean_pct": float(losses["MFE_TP_pct"].mean()) if len(losses) else 0.0,
        "losses_mfe_tp_median_pct": float(losses["MFE_TP_pct"].median()) if len(losses) else 0.0,
        **loss_threshold_counts,
        **loss_threshold_pcts,
    }


def run_window(label: str, data: pd.DataFrame) -> dict:
    bt = Backtest(
        data,
        Eb3Persistent3mStrategy,
        cash=100000,
        commission=0.002,
        exclusive_orders=True,
    )
    stats = bt.run()
    trades = enrich_trades_with_excursions(stats["_trades"].copy(), data)
    trades.to_csv(OUT_DIR / f"trades_{label}_with_excursions.csv", index=False)

    pnl = trades["PnL"] if len(trades) else pd.Series(dtype=float)
    excursion_summary = summarize_excursions(trades)

    return {
        "label": label,
        "start": str(data.index.min()),
        "end": str(data.index.max()),
        "bars_3m": int(len(data)),
        "trades": int(len(trades)),
        "wins": int((pnl > 0).sum()),
        "losses": int((pnl < 0).sum()),
        "breakeven": int((pnl == 0).sum()),
        "win_rate_pct": float(stats["Win Rate [%]"]),
        "return_pct": float(stats["Return [%]"]),
        "max_drawdown_pct": float(stats["Max. Drawdown [%]"]),
        "profit_factor": float(stats["Profit Factor"]),
        "excursions": excursion_summary,
    }


def main():
    raw_1m = load_one_year_1m()
    data_3m = to_3m(raw_1m)

    snapshot_path = OUT_DIR / "mgc_3m_2025-03-23_2026-03-23.csv"
    data_3m.to_csv(snapshot_path)
    snapshot_sha = hashlib.sha256(snapshot_path.read_bytes()).hexdigest()

    windows = {
        "1y": pd.Timestamp("2025-03-23", tz="UTC"),
        "6m": pd.Timestamp("2025-09-23", tz="UTC"),
        "3m": pd.Timestamp("2025-12-23", tz="UTC"),
    }

    results = []
    for label, start in windows.items():
        subset = data_3m.loc[(data_3m.index >= start) & (data_3m.index <= SOURCE_END)].copy()
        results.append(run_window(label, subset))

    payload = {
        "source_repo": SOURCE_REPO,
        "source_commit": SOURCE_COMMIT,
        "instrument": "MGC Micro Gold Futures",
        "strategy": "M3 EB3 persistent 3m, no break-even",
        "snapshot_sha256": snapshot_sha,
        "excursion_method": "OHLC 3m inclusive from EntryBar through ExitBar. MFE/MAE capped at 100% for zone percentages; raw percentages and R multiples retained. Exit-bar intrabar ordering is unknown without tick data.",
        "results": results,
    }
    (OUT_DIR / "m3_mgc_excursions.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = [
        "# M3 MGC 3m — MFE / MAE excursion analysis",
        "",
        f"Source: `{SOURCE_REPO}` @ `{SOURCE_COMMIT}`",
        f"Snapshot SHA256: `{snapshot_sha}`",
        "",
        "| Window | Trades | Wins | Losses | WR | Loss MFE→TP mean | Loss MFE→TP median | Win MAE→SL mean | Win MAE→SL median |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]

    for r in results:
        e = r["excursions"]
        lines.append(
            f"| {r['label']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['win_rate_pct']:.2f}% | "
            f"{e['losses_mfe_tp_mean_pct']:.2f}% | {e['losses_mfe_tp_median_pct']:.2f}% | "
            f"{e['wins_mae_sl_mean_pct']:.2f}% | {e['wins_mae_sl_median_pct']:.2f}% |"
        )

    lines += ["", "## Losing trades that traveled toward TP before losing", ""]
    lines += [
        "| Window | ≥25% TP | ≥50% TP | ≥75% TP | ≥90% TP |",
        "|---|---:|---:|---:|---:|",
    ]
    for r in results:
        e = r["excursions"]
        lines.append(
            f"| {r['label']} | {e['losses_reached_25pct_TP']} ({e['losses_reached_25pct_TP_pct']:.1f}%) | "
            f"{e['losses_reached_50pct_TP']} ({e['losses_reached_50pct_TP_pct']:.1f}%) | "
            f"{e['losses_reached_75pct_TP']} ({e['losses_reached_75pct_TP_pct']:.1f}%) | "
            f"{e['losses_reached_90pct_TP']} ({e['losses_reached_90pct_TP_pct']:.1f}%) |"
        )

    lines += [
        "",
        "Notes:",
        "- No strategy rule was changed; this is post-trade analytics only.",
        "- MFE_TP_pct = maximum favorable movement / entry-to-TP distance, capped at 100%.",
        "- MAE_SL_pct = maximum adverse movement / entry-to-SL distance, capped at 100%.",
        "- Raw percentages and MFE_R/MAE_R are preserved in each detailed trade CSV.",
        "- The exact order of high/low inside the 3-minute exit candle is unknowable from OHLC; tick data would remove this ambiguity.",
    ]

    report = "\n".join(lines) + "\n"
    (OUT_DIR / "m3_mgc_excursions.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
