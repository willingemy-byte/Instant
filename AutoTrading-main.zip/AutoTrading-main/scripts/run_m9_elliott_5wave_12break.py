from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

DATA = Path("external/mgc5/ohlcv_MGC_5m_continuous.csv")
OUT = Path("artifacts")
OUT.mkdir(parents=True, exist_ok=True)
END = pd.Timestamp("2026-03-23 23:59:59", tz="UTC")
STARTS = {
    "1y": pd.Timestamp("2025-03-23", tz="UTC"),
    "6m": pd.Timestamp("2025-09-23", tz="UTC"),
    "3m": pd.Timestamp("2025-12-23", tz="UTC"),
}


def load_data() -> pd.DataFrame:
    d = pd.read_csv(DATA)
    d["timestamp"] = pd.to_datetime(d["timestamp"], utc=True)
    d = d.set_index("timestamp").sort_index()
    d = d.rename(columns={
        "open": "Open", "high": "High", "low": "Low", "close": "Close", "volume": "Volume"
    })[["Open", "High", "Low", "Close", "Volume"]].dropna()
    return d.loc[(d.index >= STARTS["1y"]) & (d.index <= END)].copy()


def raw_pivots(d: pd.DataFrame):
    """One bar left/right wick pivots, exposed only one bar after the pivot bar closes."""
    h = d.High.to_numpy(float)
    l = d.Low.to_numpy(float)
    idx = d.index
    out = []
    for i in range(1, len(d) - 1):
        is_h = h[i] > h[i - 1] and h[i] >= h[i + 1]
        is_l = l[i] < l[i - 1] and l[i] <= l[i + 1]
        # Outside/ambiguous bars are ignored so a pivot has one unambiguous type.
        if is_h == is_l:
            continue
        out.append({
            "type": "H" if is_h else "L",
            "pivot_i": i,
            "confirm_i": i + 1,
            "time": idx[i],
            "confirm_time": idx[i + 1],
            "price": h[i] if is_h else l[i],
        })
    return out


def compress_pivots(pivots):
    """Alternate H/L pivots; consecutive same-type pivots keep only the more extreme one."""
    out = []
    for p in pivots:
        if not out or p["type"] != out[-1]["type"]:
            out.append(p.copy())
            continue
        prev = out[-1]
        replace = (p["type"] == "H" and p["price"] >= prev["price"]) or (
            p["type"] == "L" and p["price"] <= prev["price"]
        )
        if replace:
            out[-1] = p.copy()
    return out


def bearish_five(seq):
    if len(seq) < 6:
        return None
    q = seq[-6:]
    if [x["type"] for x in q] != ["H", "L", "H", "L", "H", "L"]:
        return None
    h0, l1, h2, l3, h4, l5 = q
    if not (h2["price"] < h0["price"] and h4["price"] < h2["price"]):
        return None
    if not (l3["price"] < l1["price"] and l5["price"] < l3["price"]):
        return None
    return q


def bullish_five(seq):
    if len(seq) < 6:
        return None
    q = seq[-6:]
    if [x["type"] for x in q] != ["L", "H", "L", "H", "L", "H"]:
        return None
    l0, h1, l2, h3, l4, h5 = q
    if not (l2["price"] > l0["price"] and l4["price"] > l2["price"]):
        return None
    if not (h3["price"] > h1["price"] and h5["price"] > h3["price"]):
        return None
    return q


def simulate(d: pd.DataFrame) -> pd.DataFrame:
    O = d.Open.to_numpy(float)
    H = d.High.to_numpy(float)
    L = d.Low.to_numpy(float)
    C = d.Close.to_numpy(float)
    idx = d.index

    pivots = raw_pivots(d)
    by_confirm = {}
    for p in pivots:
        by_confirm.setdefault(p["confirm_i"], []).append(p)

    swing_seq = []
    long_state = None
    short_state = None
    pos = None
    records = []

    for i in range(len(d)):
        # Manage an open hypothetical position first, from bars after entry onward.
        if pos is not None and i > pos["entry_i"]:
            side, sl, tp = pos["side"], pos["sl"], pos["tp"]
            ex = why = None
            if side == 1:
                if O[i] <= sl:
                    ex, why = O[i], "gap_sl"
                elif O[i] >= tp:
                    ex, why = O[i], "gap_tp"
                elif L[i] <= sl and H[i] >= tp:
                    ex, why = sl, "both_stop_first"
                elif L[i] <= sl:
                    ex, why = sl, "sl"
                elif H[i] >= tp:
                    ex, why = tp, "tp"
            else:
                if O[i] >= sl:
                    ex, why = O[i], "gap_sl"
                elif O[i] <= tp:
                    ex, why = O[i], "gap_tp"
                elif H[i] >= sl and L[i] <= tp:
                    ex, why = sl, "both_stop_first"
                elif H[i] >= sl:
                    ex, why = sl, "sl"
                elif L[i] <= tp:
                    ex, why = tp, "tp"
            if ex is not None:
                r = ((ex - pos["entry"]) / pos["risk"]) * side
                records.append({**pos, "exit": ex, "exit_time": idx[i], "exit_i": i, "reason": why, "R": r})
                pos = None

        # Expose newly confirmed pivots causally.
        for p in by_confirm.get(i, []):
            if not swing_seq or p["type"] != swing_seq[-1]["type"]:
                swing_seq.append(p.copy())
            else:
                prev = swing_seq[-1]
                replace = (p["type"] == "H" and p["price"] >= prev["price"]) or (
                    p["type"] == "L" and p["price"] <= prev["price"]
                )
                if replace:
                    swing_seq[-1] = p.copy()

            # Keep a bounded swing history.
            if len(swing_seq) > 30:
                swing_seq = swing_seq[-30:]

            bf = bearish_five(swing_seq)
            if bf is not None:
                long_state = {
                    "phase": "wait_wave1_high",
                    "five": [x.copy() for x in bf],
                    "terminal": bf[-1].copy(),
                    "wave1": None,
                    "wave2": None,
                }

            uf = bullish_five(swing_seq)
            if uf is not None:
                short_state = {
                    "phase": "wait_wave1_low",
                    "five": [x.copy() for x in uf],
                    "terminal": uf[-1].copy(),
                    "wave1": None,
                    "wave2": None,
                }

            # Advance long reversal state after bearish five-wave exhaustion.
            if long_state is not None:
                term = long_state["terminal"]
                if p["pivot_i"] > term["pivot_i"]:
                    if long_state["phase"] == "wait_wave1_high" and p["type"] == "H":
                        long_state["wave1"] = p.copy()
                        long_state["phase"] = "wait_wave2_low"
                    elif long_state["phase"] == "wait_wave2_low" and p["type"] == "L":
                        if p["price"] > term["price"]:
                            long_state["wave2"] = p.copy()
                            long_state["phase"] = "armed"
                        else:
                            long_state = None

            # Advance short reversal state after bullish five-wave exhaustion.
            if short_state is not None:
                term = short_state["terminal"]
                if p["pivot_i"] > term["pivot_i"]:
                    if short_state["phase"] == "wait_wave1_low" and p["type"] == "L":
                        short_state["wave1"] = p.copy()
                        short_state["phase"] = "wait_wave2_high"
                    elif short_state["phase"] == "wait_wave2_high" and p["type"] == "H":
                        if p["price"] < term["price"]:
                            short_state["wave2"] = p.copy()
                            short_state["phase"] = "armed"
                        else:
                            short_state = None

        # Invalidate armed reversal if price takes out the five-wave terminal extreme before confirmation.
        if long_state is not None and long_state["phase"] == "armed" and L[i] <= long_state["terminal"]["price"]:
            long_state = None
        if short_state is not None and short_state["phase"] == "armed" and H[i] >= short_state["terminal"]["price"]:
            short_state = None

        # One position at a time. Entry occurs at the confirming bar close exactly as specified.
        if pos is None:
            if long_state is not None and long_state["phase"] == "armed":
                w1 = long_state["wave1"]
                w2 = long_state["wave2"]
                if C[i] > w1["price"] and i > w2["confirm_i"]:
                    entry = C[i]
                    sl = w2["price"]
                    risk = entry - sl
                    if risk > 0:
                        pos = {
                            "side": 1,
                            "entry": entry,
                            "entry_time": idx[i],
                            "entry_i": i,
                            "sl": sl,
                            "tp": entry + 3.0 * risk,
                            "risk": risk,
                            "five_terminal_time": long_state["terminal"]["time"],
                            "five_terminal_price": long_state["terminal"]["price"],
                            "wave1_time": w1["time"],
                            "wave1_price": w1["price"],
                            "wave2_time": w2["time"],
                            "wave2_price": w2["price"],
                        }
                        long_state = None
            elif short_state is not None and short_state["phase"] == "armed":
                w1 = short_state["wave1"]
                w2 = short_state["wave2"]
                if C[i] < w1["price"] and i > w2["confirm_i"]:
                    entry = C[i]
                    sl = w2["price"]
                    risk = sl - entry
                    if risk > 0:
                        pos = {
                            "side": -1,
                            "entry": entry,
                            "entry_time": idx[i],
                            "entry_i": i,
                            "sl": sl,
                            "tp": entry - 3.0 * risk,
                            "risk": risk,
                            "five_terminal_time": short_state["terminal"]["time"],
                            "five_terminal_price": short_state["terminal"]["price"],
                            "wave1_time": w1["time"],
                            "wave1_price": w1["price"],
                            "wave2_time": w2["time"],
                            "wave2_price": w2["price"],
                        }
                        short_state = None

    return pd.DataFrame(records)


def add_excursions(d: pd.DataFrame, t: pd.DataFrame) -> pd.DataFrame:
    if t.empty:
        return t
    out = t.copy()
    mfe_tp, mae_sl = [], []
    for _, r in out.iterrows():
        bars = d.iloc[int(r.entry_i): int(r.exit_i) + 1]
        entry, risk, side = float(r.entry), float(r.risk), int(r.side)
        if side == 1:
            fav = max(0.0, float(bars.High.max()) - entry)
            adv = max(0.0, entry - float(bars.Low.min()))
        else:
            fav = max(0.0, entry - float(bars.Low.min()))
            adv = max(0.0, float(bars.High.max()) - entry)
        mfe_tp.append(min(100.0, 100.0 * fav / (3.0 * risk)))
        mae_sl.append(min(100.0, 100.0 * adv / risk))
    out["MFE_TP_pct"] = mfe_tp
    out["MAE_SL_pct"] = mae_sl
    return out


def metrics(t: pd.DataFrame):
    if t.empty:
        return {"trades": 0, "wins": 0, "losses": 0, "win_rate_pct": 0.0, "avg_R": None, "profit_factor_R": None}
    wins = t.R > 0
    gp = t.loc[wins, "R"].sum()
    gl = -t.loc[~wins, "R"].sum()
    losses = t.loc[t.R < 0]
    return {
        "trades": int(len(t)),
        "wins": int(wins.sum()),
        "losses": int((t.R < 0).sum()),
        "win_rate_pct": float(100.0 * wins.mean()),
        "avg_R": float(t.R.mean()),
        "profit_factor_R": float(gp / gl) if gl > 0 else None,
        "loss_mfe_tp_mean": float(losses.MFE_TP_pct.mean()) if len(losses) else None,
    }


def main():
    d = load_data()
    snap = OUT / "m9_mgc_5m_snapshot.csv"
    d.to_csv(snap)
    sha = hashlib.sha256(snap.read_bytes()).hexdigest()
    results = []
    for label, start in STARTS.items():
        x = d.loc[d.index >= start].copy()
        t = add_excursions(x, simulate(x))
        t.to_csv(OUT / f"m9_{label}_trades.csv", index=False)
        m = metrics(t)
        m["window"] = label
        results.append(m)

    payload = {
        "method": "offline research replay only",
        "instrument": "MGC Micro Gold Futures continuous",
        "timeframe": "5m",
        "snapshot_sha256": sha,
        "strategy": "M9 Elliott-inspired five-wave exhaustion + wave1/wave2 + close beyond wave1",
        "rules": {
            "bearish_exhaustion_for_long": "H-L-H-L-H-L with strictly lower swing highs and strictly lower swing lows",
            "bullish_exhaustion_for_short": "L-H-L-H-L-H with strictly higher swing lows and strictly higher swing highs",
            "reversal_confirmation_long": "first pivot high after terminal low = wave1, next pivot low must remain above terminal low = wave2, enter at later 5m close above wave1 high",
            "reversal_confirmation_short": "symmetric",
            "stop": "wave2 wick",
            "take_profit": "3R",
            "pivot": "one-bar-left/one-bar-right wick pivot, available only after right bar closes",
            "session_filter": None,
        },
        "results": results,
    }
    (OUT / "m9_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = [
        "# M9 — Elliott-inspired 5-wave exhaustion + 1/2 breakout, 5m",
        "",
        f"Snapshot SHA256: `{sha}`",
        "",
        "| Window | Trades | Wins | Losses | WR | Avg R | PF(R) | Loss MFE→TP mean |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in results:
        lines.append(
            f"| {r['window']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['win_rate_pct']:.2f}% | "
            f"{r['avg_R'] if r['avg_R'] is not None else 'n/a'} | "
            f"{r['profit_factor_R'] if r['profit_factor_R'] is not None else 'n/a'} | "
            f"{r['loss_mfe_tp_mean'] if r['loss_mfe_tp_mean'] is not None else 'n/a'} |"
        )
    lines += [
        "",
        "Rules:",
        "- Pure price action: no RSI, no moving averages, no engulfing/EB3, no break-even, no session filter.",
        "- A bearish five-wave exhaustion is encoded as six alternating swing points H-L-H-L-H-L with lower highs and lower lows.",
        "- A bullish five-wave exhaustion is symmetric.",
        "- After exhaustion, wait for reversal wave 1, then wave 2 that does not invalidate the terminal extreme.",
        "- Entry is the 5m CLOSE beyond the wave-1 extreme after wave 2 is confirmed.",
        "- Stop is the wave-2 wick; TP = 3R.",
        "- Pivot points are causal: one candle on each side, exposed only after the right-side candle closes.",
        "- If a future OHLC bar touches stop and TP, stop is assumed first (conservative).",
    ]
    report = "\n".join(lines) + "\n"
    (OUT / "m9_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
