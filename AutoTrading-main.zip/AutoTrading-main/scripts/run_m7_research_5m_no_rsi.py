from __future__ import annotations
import hashlib, json
from pathlib import Path
import numpy as np, pandas as pd

DATA=Path('external/mgc5/ohlcv_MGC_5m_continuous.csv'); OUT=Path('artifacts'); OUT.mkdir(parents=True,exist_ok=True)
END=pd.Timestamp('2026-03-23 23:59:59',tz='UTC')
STARTS={'1y':pd.Timestamp('2025-03-23',tz='UTC'),'6m':pd.Timestamp('2025-09-23',tz='UTC'),'3m':pd.Timestamp('2025-12-23',tz='UTC')}

def load():
    d=pd.read_csv(DATA)
    d['timestamp']=pd.to_datetime(d.timestamp,utc=True)
    d=d.set_index('timestamp').sort_index()
    d=d.rename(columns={'open':'Open','high':'High','low':'Low','close':'Close','volume':'Volume'})[['Open','High','Low','Close','Volume']].dropna()
    d['PRICE_MA50']=d.Close.rolling(50).mean()
    return d.loc[(d.index>=STARTS['1y'])&(d.index<=END)].copy()

def simulate(d):
    O=d.Open.to_numpy(float); H=d.High.to_numpy(float); L=d.Low.to_numpy(float); C=d.Close.to_numpy(float); pm=d.PRICE_MA50.to_numpy(float); idx=d.index; n=len(d)
    bull=bear=False; bull_top=bear_bottom=np.nan; pos=None; pending=None; rec=[]
    for i in range(3,n):
        if pending is not None and pos is None:
            pos=pending; pos['entry']=O[i]; pos['entry_time']=idx[i]; pending=None
        if pos is not None:
            side=pos['side']; sl=pos['sl']; tp=pos['tp']; ex=None; why=None
            if side==1:
                if O[i]<=sl: ex=O[i]; why='gap_sl'
                elif O[i]>=tp: ex=O[i]; why='gap_tp'
                elif L[i]<=sl and H[i]>=tp: ex=sl; why='both_stop_first'
                elif L[i]<=sl: ex=sl; why='sl'
                elif H[i]>=tp: ex=tp; why='tp'
            else:
                if O[i]>=sl: ex=O[i]; why='gap_sl'
                elif O[i]<=tp: ex=O[i]; why='gap_tp'
                elif H[i]>=sl and L[i]<=tp: ex=sl; why='both_stop_first'
                elif H[i]>=sl: ex=sl; why='sl'
                elif L[i]<=tp: ex=tp; why='tp'
            if ex is not None:
                gross=(ex/pos['entry']-1)*side
                net=gross-0.004
                rec.append({**pos,'exit':ex,'exit_time':idx[i],'reason':why,'gross_ret':gross,'net_ret':net})
                pos=None
        blo=min(O[i],C[i]); bhi=max(O[i],C[i])
        pl=[min(O[i-j],C[i-j]) for j in (1,2,3)]; ph=[max(O[i-j],C[i-j]) for j in (1,2,3)]
        engulf=blo<=min(pl) and bhi>=max(ph)
        be=C[i]>O[i] and engulf; se=C[i]<O[i] and engulf
        if bull and not be and C[i]<=bull_top: bull=False; bull_top=np.nan
        if bear and not se and C[i]>=bear_bottom: bear=False; bear_bottom=np.nan
        if be: bull=True; bull_top=bhi
        if se: bear=True; bear_bottom=blo
        if pos is not None or pending is not None or i+1>=n: continue
        if not np.isfinite(pm[i]): continue
        long_ok=C[i]>pm[i]
        short_ok=C[i]<pm[i]
        if bull and long_ok:
            sl=L[i-1]
            sl=C[i]*0.99 if sl>=C[i]-C[i]*0.001 else sl
            risk=C[i]-sl
            if risk>0:
                pending={'side':1,'signal_time':idx[i],'ref':C[i],'sl':sl,'tp':C[i]+3*risk}
                bull=False; bull_top=np.nan
        elif bear and short_ok:
            sl=H[i-1]
            sl=C[i]*1.01 if sl<=C[i]+C[i]*0.001 else sl
            risk=sl-C[i]
            if risk>0:
                pending={'side':-1,'signal_time':idx[i],'ref':C[i],'sl':sl,'tp':C[i]-3*risk}
                bear=False; bear_bottom=np.nan
    return pd.DataFrame(rec)

def add_excursions(d,t):
    if t.empty: return t
    mfe=[]; mae=[]
    for _,r in t.iterrows():
        bars=d.loc[(d.index>=r.entry_time)&(d.index<=r.exit_time)]
        entry=float(r.entry); sl=float(r.sl); tp=float(r.tp); side=int(r.side)
        if side==1:
            fav=max(0.0,float(bars.High.max())-entry); adv=max(0.0,entry-float(bars.Low.min())); tpd=tp-entry; sld=entry-sl
        else:
            fav=max(0.0,entry-float(bars.Low.min())); adv=max(0.0,float(bars.High.max())-entry); tpd=entry-tp; sld=sl-entry
        mfe.append(min(100.0,100.0*fav/tpd) if tpd>0 else np.nan)
        mae.append(min(100.0,100.0*adv/sld) if sld>0 else np.nan)
    t=t.copy(); t['MFE_TP_pct']=mfe; t['MAE_SL_pct']=mae
    return t

def metric(t):
    if t.empty:return {'trades':0,'wins':0,'losses':0,'win_rate_pct':0,'return_pct':0,'max_drawdown_pct':0,'profit_factor':None,'loss_mfe_tp_mean':None}
    win=t.net_ret>0
    eq=(1+t.net_ret).cumprod(); dd=(eq/eq.cummax()-1).min()*100
    gp=t.loc[win,'net_ret'].sum(); gl=-t.loc[~win,'net_ret'].sum()
    losses=t.loc[~win]
    return {'trades':len(t),'wins':int(win.sum()),'losses':int((~win).sum()),'win_rate_pct':100*win.mean(),'return_pct':100*(eq.iloc[-1]-1),'max_drawdown_pct':dd,'profit_factor':float(gp/gl) if gl>0 else None,'loss_mfe_tp_mean':float(losses.MFE_TP_pct.mean()) if len(losses) else None}

def main():
    d=load(); snap=OUT/'m7_mgc_5m_no_rsi_snapshot.csv'; d.to_csv(snap); sha=hashlib.sha256(snap.read_bytes()).hexdigest(); results=[]
    for w,st in STARTS.items():
        x=d.loc[d.index>=st]
        t=add_excursions(x,simulate(x))
        t.to_csv(OUT/f'm7_{w}_trades.csv',index=False)
        m=metric(t); m.update(window=w); results.append(m)
    p={'method':'offline research replay only','instrument':'MGC','timeframe':'5m','session_filter':'none','rsi_filters':'none','price_filter':'Close vs SMA50','snapshot_sha256':sha,'results':results}
    (OUT/'m7_results.json').write_text(json.dumps(p,indent=2))
    lines=['# M7 5m — no RSI, no session filter','',f'Snapshot SHA256: `{sha}`','', '| Window | Trades | Wins | Losses | WR | Return* | Max DD* | PF* | Loss MFE→TP mean |','|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    for r in results:
        lines.append(f"| {r['window']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['win_rate_pct']:.2f}% | {r['return_pct']:.2f}% | {r['max_drawdown_pct']:.2f}% | {r['profit_factor'] if r['profit_factor'] is not None else 'n/a'} | {r['loss_mfe_tp_mean']:.2f}% |")
    lines+=['','*Return/DD/PF use the same offline replay cost approximation as M6; WR and trade counts are the primary comparison.','- No break-even.','- No strategic time filter.','- No RSI on 5m and no RSI on 1h.','- Entry confirmation is EB3 persistent + Close above/below price SMA50 only.']
    report='\n'.join(lines)+'\n'; (OUT/'m7_report.md').write_text(report); print(report)
if __name__=='__main__':main()
