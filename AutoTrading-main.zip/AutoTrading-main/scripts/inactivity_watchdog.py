#!/usr/bin/env python3
"""Priority watchdog for AutoTrading ENTRY-PATH V1.

The watchdog is intentionally narrow: it watches the current AutoTrading
priority branch and its historical campaign instead of treating unrelated LAB
workflows as useful activity. It never trades, never touches the blind holdout,
and never modifies or merges main.

When the priority campaign fails, stalls, finishes without its report, or
completes successfully, the watchdog emits a durable issue marker plus a
repository_dispatch event for an external orchestrator. A configured webhook
can receive the same payload.
"""
from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

WATCHDOG_WORKFLOW_NAME = "INACTIVITY-WATCHDOG"
ACTIVE_STATUSES = {"queued", "in_progress", "waiting", "requested", "pending"}
QUEUE_STATUSES = {"queued", "waiting", "requested", "pending"}


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def parse_dt(value: str | None) -> datetime | None:
    if not value:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def github_request(method: str, url: str, token: str, payload: dict[str, Any] | None = None) -> Any:
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {token}",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "AutoTrading-Entry-Path-Watchdog",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as response:
            raw = response.read()
            return json.loads(raw) if raw else None
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"GitHub API {method} {url} -> HTTP {exc.code}: {body[:1000]}") from exc


@dataclass(frozen=True)
class PriorityRun:
    run_id: int
    status: str
    conclusion: str | None
    created_at: datetime
    updated_at: datetime
    head_sha: str | None
    html_url: str | None


@dataclass(frozen=True)
class PriorityState:
    code: str
    run: PriorityRun | None
    report_exists: bool
    branch_updated_at: datetime | None

    @property
    def actionable(self) -> bool:
        return self.code in {
            "FAILED",
            "STALLED_QUEUE",
            "STALLED_RUN",
            "STALLED_NO_RUN",
            "OUTPUT_MISSING",
            "COMPLETE",
        }


def latest_priority_run(api: str, repo: str, token: str, workflow: str, branch: str) -> PriorityRun | None:
    workflow_q = urllib.parse.quote(workflow, safe="")
    branch_q = urllib.parse.quote(branch, safe="")
    payload = github_request(
        "GET",
        f"{api}/repos/{repo}/actions/workflows/{workflow_q}/runs?branch={branch_q}&per_page=10",
        token,
    )
    runs = payload.get("workflow_runs", []) if isinstance(payload, dict) else []
    if not runs:
        return None
    run = runs[0]
    created = parse_dt(run.get("created_at"))
    updated = parse_dt(run.get("updated_at")) or created
    if created is None or updated is None:
        raise RuntimeError("priority workflow run is missing timestamps")
    return PriorityRun(
        run_id=int(run["id"]),
        status=str(run.get("status") or ""),
        conclusion=(str(run["conclusion"]) if run.get("conclusion") is not None else None),
        created_at=created,
        updated_at=updated,
        head_sha=run.get("head_sha"),
        html_url=run.get("html_url"),
    )


def priority_branch_updated_at(api: str, repo: str, token: str, branch: str) -> datetime | None:
    branch_q = urllib.parse.quote(branch, safe="")
    payload = github_request("GET", f"{api}/repos/{repo}/branches/{branch_q}", token)
    commit = (payload or {}).get("commit") or {}
    nested = commit.get("commit") or {}
    committer = nested.get("committer") or {}
    author = nested.get("author") or {}
    return parse_dt(committer.get("date") or author.get("date"))


def priority_report_exists(api: str, repo: str, token: str, branch: str, report_path: str) -> bool:
    path_q = urllib.parse.quote(report_path, safe="/")
    branch_q = urllib.parse.quote(branch, safe="")
    try:
        github_request("GET", f"{api}/repos/{repo}/contents/{path_q}?ref={branch_q}", token)
        return True
    except RuntimeError as exc:
        if "HTTP 404" in str(exc):
            return False
        raise


def classify_priority_state(
    run: PriorityRun | None,
    *,
    report_exists: bool,
    branch_updated_at: datetime | None,
    now: datetime,
    idle_threshold: timedelta,
    queue_stall: timedelta,
    run_timeout: timedelta,
) -> PriorityState:
    if run is not None:
        if run.status in ACTIVE_STATUSES:
            age = now - run.created_at
            if run.status in QUEUE_STATUSES and age >= queue_stall:
                return PriorityState("STALLED_QUEUE", run, report_exists, branch_updated_at)
            if run.status == "in_progress" and age >= run_timeout:
                return PriorityState("STALLED_RUN", run, report_exists, branch_updated_at)
            return PriorityState("RUNNING", run, report_exists, branch_updated_at)

        if run.status == "completed":
            if run.conclusion == "success":
                code = "COMPLETE" if report_exists else "OUTPUT_MISSING"
                return PriorityState(code, run, report_exists, branch_updated_at)
            return PriorityState("FAILED", run, report_exists, branch_updated_at)

        return PriorityState("FAILED", run, report_exists, branch_updated_at)

    if report_exists:
        return PriorityState("COMPLETE", None, True, branch_updated_at)

    if branch_updated_at is None or now - branch_updated_at >= idle_threshold:
        return PriorityState("STALLED_NO_RUN", None, False, branch_updated_at)
    return PriorityState("WAITING_FOR_RUN", None, False, branch_updated_at)


def state_event_type(code: str) -> str | None:
    return {
        "FAILED": "entry_path_failure",
        "STALLED_QUEUE": "entry_path_stalled",
        "STALLED_RUN": "entry_path_stalled",
        "STALLED_NO_RUN": "entry_path_stalled",
        "OUTPUT_MISSING": "entry_path_output_missing",
        "COMPLETE": "entry_path_complete",
    }.get(code)


def fingerprint(state: PriorityState) -> str:
    if state.run is not None:
        return f"{state.code}:run-{state.run.run_id}"
    stamp = state.branch_updated_at.isoformat() if state.branch_updated_at else "unknown"
    return f"{state.code}:branch-{stamp}"


def marker_for(state: PriorityState) -> str:
    return f"<!-- AUTOTRADING_ENTRY_PATH_WATCHDOG:{fingerprint(state)} -->"


def marker_already_posted(api: str, repo: str, issue: int, token: str, marker: str) -> bool:
    comments = github_request("GET", f"{api}/repos/{repo}/issues/{issue}/comments?per_page=100", token)
    return any(marker in str(comment.get("body") or "") for comment in comments or [])


def issue_message(state: PriorityState, priority_branch: str, workflow: str, report_path: str) -> str:
    marker = marker_for(state)
    run_text = "none"
    if state.run is not None:
        run_text = f"#{state.run.run_id} `{state.run.status}` / `{state.run.conclusion}` @ `{state.run.head_sha}`"
    if state.code == "COMPLETE":
        headline = "✅ ENTRY-PATH V1 a produit son rapport prioritaire."
    elif state.code == "OUTPUT_MISSING":
        headline = "🚨 ENTRY-PATH V1: le workflow est vert mais le rapport attendu manque."
    elif state.code == "FAILED":
        headline = "🚨 ENTRY-PATH V1: échec technique du workflow prioritaire."
    else:
        headline = "⚠️ ENTRY-PATH V1 semble bloqué ou sans run utile."
    return (
        f"{marker}\n"
        f"{headline}\n\n"
        f"- branche prioritaire: `{priority_branch}`\n"
        f"- workflow: `{workflow}`\n"
        f"- état watchdog: `{state.code}`\n"
        f"- run: {run_text}\n"
        f"- rapport attendu: `{report_path}` (présent: `{state.report_exists}`)\n\n"
        "Orchestration: diagnostiquer/corriger uniquement sur `research/entry-path-v1`, "
        "ne pas toucher `main`, ne pas relancer UNIVERSAL RANGE et ne jamais charger le holdout `2026-04-01+`. "
        "Un échec technique n'est pas un résultat de trading."
    )


def post_issue_alert(api: str, repo: str, issue: int, token: str, body: str) -> None:
    github_request("POST", f"{api}/repos/{repo}/issues/{issue}/comments", token, {"body": body})


def emit_dispatch(
    api: str,
    repo: str,
    token: str,
    event_type: str,
    state: PriorityState,
    priority_branch: str,
    workflow: str,
    report_path: str,
) -> dict[str, Any]:
    payload = {
        "priority": "ENTRY-PATH V1",
        "state": state.code,
        "priority_branch": priority_branch,
        "workflow": workflow,
        "report_path": report_path,
        "report_exists": state.report_exists,
        "run_id": state.run.run_id if state.run else None,
        "run_status": state.run.status if state.run else None,
        "run_conclusion": state.run.conclusion if state.run else None,
        "run_head_sha": state.run.head_sha if state.run else None,
        "run_url": state.run.html_url if state.run else None,
        "source": "entry-path-watchdog",
        "guardrails": {
            "universal_range_paused": True,
            "never_modify_main_automatically": True,
            "blind_holdout_starts": "2026-04-01",
            "technical_failure_is_not_trading_result": True,
        },
    }
    github_request(
        "POST",
        f"{api}/repos/{repo}/dispatches",
        token,
        {"event_type": event_type, "client_payload": payload},
    )
    return payload


def post_optional_webhook(url: str, event_type: str, payload: dict[str, Any]) -> None:
    req = urllib.request.Request(
        url,
        data=json.dumps({"event": event_type, **payload}).encode("utf-8"),
        method="POST",
        headers={"Content-Type": "application/json", "User-Agent": "AutoTrading-Entry-Path-Watchdog"},
    )
    with urllib.request.urlopen(req, timeout=20) as response:
        response.read()


def main() -> int:
    repo = os.environ["GITHUB_REPOSITORY"]
    token = os.environ["GITHUB_TOKEN"]
    api = os.environ.get("GITHUB_API_URL", "https://api.github.com")
    issue = int(os.environ.get("WATCHDOG_ISSUE", "112"))
    priority_branch = os.environ.get("PRIORITY_BRANCH", "research/entry-path-v1")
    workflow = os.environ.get("PRIORITY_WORKFLOW", "entry-path-v1-campaign.yml")
    report_path = os.environ.get("PRIORITY_REPORT", "results/entry-path-v1/current/report.md")
    idle_threshold = timedelta(minutes=int(os.environ.get("IDLE_MINUTES", "15")))
    queue_stall = timedelta(minutes=int(os.environ.get("QUEUE_STALL_MINUTES", "30")))
    run_timeout = timedelta(minutes=int(os.environ.get("RUN_TIMEOUT_MINUTES", "360")))
    dry_run = os.environ.get("WATCHDOG_DRY_RUN", "0").strip().lower() in {"1", "true", "yes"}
    now = utcnow()

    run = latest_priority_run(api, repo, token, workflow, priority_branch)
    branch_updated = priority_branch_updated_at(api, repo, token, priority_branch)
    report_exists = priority_report_exists(api, repo, token, priority_branch, report_path)
    state = classify_priority_state(
        run,
        report_exists=report_exists,
        branch_updated_at=branch_updated,
        now=now,
        idle_threshold=idle_threshold,
        queue_stall=queue_stall,
        run_timeout=run_timeout,
    )

    summary = {
        "priority": "ENTRY-PATH V1",
        "priority_branch": priority_branch,
        "workflow": workflow,
        "report_path": report_path,
        "state": state.code,
        "report_exists": report_exists,
        "branch_updated_at": branch_updated.isoformat() if branch_updated else None,
        "run_id": run.run_id if run else None,
        "run_status": run.status if run else None,
        "run_conclusion": run.conclusion if run else None,
        "run_head_sha": run.head_sha if run else None,
        "dry_run": dry_run,
    }
    print(json.dumps(summary, indent=2, sort_keys=True))

    if not state.actionable:
        print(f"WATCHDOG: {state.code}; no orchestration signal needed.")
        return 0

    event_type = state_event_type(state.code)
    if event_type is None:
        return 0

    marker = marker_for(state)
    if dry_run:
        print(f"WATCHDOG: DRY-RUN — would emit {event_type} with marker {marker}")
        return 0

    if marker_already_posted(api, repo, issue, token, marker):
        print(f"WATCHDOG: {state.code} already emitted for this exact fingerprint.")
        return 0

    post_issue_alert(api, repo, issue, token, issue_message(state, priority_branch, workflow, report_path))
    payload = emit_dispatch(api, repo, token, event_type, state, priority_branch, workflow, report_path)

    webhook = os.environ.get("ORCHESTRATOR_WEBHOOK_URL", "").strip()
    if webhook:
        post_optional_webhook(webhook, event_type, payload)
        print("WATCHDOG: optional orchestrator webhook notified.")

    print(f"WATCHDOG: emitted {event_type} for {fingerprint(state)}.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"WATCHDOG ERROR: {exc}", file=sys.stderr)
        raise
