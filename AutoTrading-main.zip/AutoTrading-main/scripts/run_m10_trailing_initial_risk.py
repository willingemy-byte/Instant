from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

SRC = Path("external/mgc-src/data")
OUT = Path("artifacts")
OUT.mkdir(parents=True, exist_ok=True)
END = pd.Timestamp("2026-03-23 23:59:59", tz="UTC")
STARTS = {
    "1y": pd.Timestamp("2025-03-23", tz="UTC"),
    "6m": pd.Timestamp("2025-09-23", tz="UTC"),
    "3m": pd.Timestamp("2025-12-23", tz="UTC"),
}


def load_1m() -> pd.DataFrame:
    frames = []
    for p in sorted(SRC.glob("ohlcv_MGC_*.csv")):
        try:
            day = pd.Timestamp(p.stem.rsplit("_", 1)[-1], tz="UTC")
        except Exception:
            continue
        if day < STARTS["1y"] - pd.Timedelta(days=2) or day > END + pd.Timedelta(days=1):
            continue
        x = pd.read_csv(p)
        x["timestamp"] = pd.to_datetime(x["timestamp"], utc=True)
        frames.append(x)
    if not frames:
        raise RuntimeError("No 1m MGC files found")
    d = pd.concat(frames, ignore_index=True)
    d = d.drop_duplicates("timestamp", keep="last").sort_values("timestamp")
    d = d.set_index("timestamp")
    d = d.rename(columns={"open":"Open","high":"High","low":"Low","close":"Close","volume":"Volume"})
    d = d[["Open","High","Low","Close","Volume"]].dropna()
    return d.loc[(d.index >= STARTS["1y"]) & (d.index <= END)].copy()


def make_5m(d1: pd.DataFrame) -> pd.DataFrame:
    return d1.resample("5min", label="left", closed="left").agg({
        "Open":"first", "High":"max", "Low":"min", "Close":"last", "Volume":"sum"
    }).dropna()


def raw_pivots(d: pd.DataFrame):
    h, l, idx = d.High.to_numpy(float), d.Low.to_numpy(float), d.index
    out = []
    for i in range(1, len(d)-1):
        ih = h[i] > h[i-1] and h[i] >= h[i+1]
        il = l[i] < l[i-1] and l[i] <= l[i+1]
        if ih == il:
            continue
        out.append({"type":"H" if ih else "L", "pivot_i":i, "confirm_i":i+1,
                    "time":idx[i], "confirm_time":idx[i+1], "price":h[i] if ih else l[i]})
    return out


def bearish_five(seq):
    if len(seq) < 6: return None
    q = seq[-6:]
    if [x["type"] for x in q] != ["H","L","H","L","H","L"]: return None
    h0,l1,h2,l3,h4,l5 = q
    if not (h2["price"] < h0["price"] and h4["price"] < h2["price"]): return None
    if not (l3["price"] < l1["price"] and l5["price"] < l3["price"]): return None
    return q


def bullish_five(seq):
    if len(seq) < 6: return None
    q = seq[-6:]
    if [x["type"] for x in q] != ["L","H","L","H","L","H"]: return None
    l0,h1,l2,h3,l4,h5 = q
    if not (l2["price"] > l0["price"] and l4["price"] > l2["price"]): return None
    if not (h3["price"] > h1["price"] and h5["price"] > h3["price"]): return None
    return q


def process_minutes(pos, mins: pd.DataFrame, trailing: bool):
    if pos is None or mins.empty:
        return pos, None
    for ts, b in mins.iterrows():
        side, stop, tp = pos["side"], pos["active_stop"], pos["tp"]
        ex = why = None
        if side == 1:
            if b.Open <= stop: ex,why = float(b.Open),"gap_stop"
            elif b.Open >= tp: ex,why = float(b.Open),"gap_tp"
            elif b.Low <= stop and b.High >= tp: ex,why = stop,"both_stop_first"
            elif b.Low <= stop: ex,why = stop,"stop"
            elif b.High >= tp: ex,why = tp,"tp"
        else:
            if b.Open >= stop: ex,why = float(b.Open),"gap_stop"
            elif b.Open <= tp: ex,why = float(b.Open),"gap_tp"
            elif b.High >= stop and b.Low <= tp: ex,why = stop,"both_stop_first"
            elif b.High >= stop: ex,why = stop,"stop"
            elif b.Low <= tp: ex,why = tp,"tp"
        if ex is not None:
            r = ((ex-pos["entry"])/pos["risk"])*side
            rec = {**pos, "exit":ex, "exit_time":ts, "reason":why, "R":r}
            return None, rec
        if trailing:
            if side == 1:
                pos["best_price"] = max(pos["best_price"], float(b.High))
                pos["active_stop"] = max(pos["active_stop"], pos["best_price"] - pos["risk"])
            else:
                pos["best_price"] = min(pos["best_price"], float(b.Low))
                pos["active_stop"] = min(pos["active_stop"], pos["best_price"] + pos["risk"])
    return pos, None


def simulate(d1: pd.DataFrame, d5: pd.DataFrame, trailing: bool) -> pd.DataFrame:
    C5, H5, L5, idx5 = d5.Close.to_numpy(float), d5.High.to_numpy(float), d5.Low.to_numpy(float), d5.index
    pivots = raw_pivots(d5)
    by_confirm = {}
    for p in pivots: by_confirm.setdefault(p["confirm_i"], []).append(p)
    seq=[]; long_state=None; short_state=None; pos=None; rec=[]

    for i in range(len(d5)):
        close_time = idx5[i] + pd.Timedelta(minutes=5)
        prev_close = idx5[i] if i == 0 else idx5[i-1] + pd.Timedelta(minutes=5)
        if pos is not None:
            mins = d1.loc[(d1.index >= prev_close) & (d1.index < close_time)]
            pos, done = process_minutes(pos, mins, trailing)
            if done is not None: rec.append(done)

        for p in by_confirm.get(i, []):
            if not seq or p["type"] != seq[-1]["type"]:
                seq.append(p.copy())
            else:
                q=seq[-1]
                replace=(p["type"]=="H" and p["price"]>=q["price"]) or (p["type"]=="L" and p["price"]<=q["price"])
                if replace: seq[-1]=p.copy()
            if len(seq)>30: seq=seq[-30:]

            bf=bearish_five(seq)
            if bf is not None:
                long_state={"phase":"wait_wave1_high","terminal":bf[-1].copy(),"wave1":None,"wave2":None}
            uf=bullish_five(seq)
            if uf is not None:
                short_state={"phase":"wait_wave1_low","terminal":uf[-1].copy(),"wave1":None,"wave2":None}

            if long_state is not None and p["pivot_i"] > long_state["terminal"]["pivot_i"]:
                if long_state["phase"]=="wait_wave1_high" and p["type"]=="H":
                    long_state["wave1"]=p.copy(); long_state["phase"]="wait_wave2_low"
                elif long_state["phase"]=="wait_wave2_low" and p["type"]=="L":
                    if p["price"] > long_state["terminal"]["price"]:
                        long_state["wave2"]=p.copy(); long_state["phase"]="armed"
                    else: long_state=None

            if short_state is not None and p["pivot_i"] > short_state["terminal"]["pivot_i"]:
                if short_state["phase"]=="wait_wave1_low" and p["type"]=="L":
                    short_state["wave1"]=p.copy(); short_state["phase"]="wait_wave2_high"
                elif short_state["phase"]=="wait_wave2_high" and p["type"]=="H":
                    if p["price"] < short_state["terminal"]["price"]:
                        short_state["wave2"]=p.copy(); short_state["phase"]="armed"
                    else: short_state=None

        if long_state is not None and long_state["phase"]=="armed" and L5[i] <= long_state["terminal"]["price"]:
            long_state=None
        if short_state is not None and short_state["phase"]=="armed" and H5[i] >= short_state["terminal"]["price"]:
            short_state=None

        if pos is None:
            if long_state is not None and long_state["phase"]=="armed":
                w1,w2,term=long_state["wave1"],long_state["wave2"],long_state["terminal"]
                if C5[i] > w1["price"] and i > w2["confirm_i"]:
                    entry=float(C5[i]); sl=float(term["price"]); risk=entry-sl
                    if risk>0:
                        pos={"side":1,"entry":entry,"entry_time":close_time,"risk":risk,"initial_stop":sl,
                             "active_stop":sl,"tp":entry+3*risk,"best_price":entry,
                             "terminal_time":term["time"],"wave1_time":w1["time"],"wave2_time":w2["time"]}
                        long_state=None
            elif short_state is not None and short_state["phase"]=="armed":
                w1,w2,term=short_state["wave1"],short_state["wave2"],short_state["terminal"]
                if C5[i] < w1["price"] and i > w2["confirm_i"]:
                    entry=float(C5[i]); sl=float(term["price"]); risk=sl-entry
                    if risk>0:
                        pos={"side":-1,"entry":entry,"entry_time":close_time,"risk":risk,"initial_stop":sl,
                             "active_stop":sl,"tp":entry-3*risk,"best_price":entry,
                             "terminal_time":term["time"],"wave1_time":w1["time"],"wave2_time":w2["time"]}
                        short_state=None

    if pos is not None:
        start = idx5[-1] + pd.Timedelta(minutes=5)
        pos, done = process_minutes(pos, d1.loc[d1.index >= start], trailing)
        if done is not None: rec.append(done)
    return pd.DataFrame(rec)


def metrics(t: pd.DataFrame):
    if t.empty: return {"trades":0,"wins":0,"losses":0,"win_rate_pct":0.0,"avg_R":None,"profit_factor_R":None}
    win=t.R>0; gp=t.loc[win,"R"].sum(); gl=-t.loc[~win,"R"].sum()
    return {"trades":int(len(t)),"wins":int(win.sum()),"losses":int((~win).sum()),
            "win_rate_pct":float(100*win.mean()),"avg_R":float(t.R.mean()),
            "profit_factor_R":float(gp/gl) if gl>0 else None,
            "median_R":float(t.R.median()),"full_losses":int((t.R<=-0.999).sum()),
            "partial_or_positive_exits":int((t.R>-0.999).sum())}


def main():
    d1=load_1m(); d5=make_5m(d1)
    snap=OUT/"m10_mgc_5m_from_1m_snapshot.csv"; d5.to_csv(snap)
    sha=hashlib.sha256(snap.read_bytes()).hexdigest(); results=[]
    for mode,trailing in [("fixed_structure_stop",False),("trailing_initial_1R",True)]:
        for label,start in STARTS.items():
            x1=d1.loc[d1.index>=start]; x5=d5.loc[d5.index>=start]
            t=simulate(x1,x5,trailing); t.to_csv(OUT/f"m10_{mode}_{label}_trades.csv",index=False)
            m=metrics(t); m.update(mode=mode,window=label); results.append(m)
    payload={"method":"offline research only","instrument":"MGC","signal_timeframe":"5m","management_timeframe":"1m",
             "snapshot_sha256":sha,"trailing_rule":"distance equals initial structural risk; long stop=max(old stop,best high-in-completed-1m-bar-risk), short symmetric; stop never loosens; fixed TP=3R",
             "intraminute_rule":"existing stop/TP checked first; trailing level updated from completed 1m bar for next minute to avoid unknowable intraminute path","results":results}
    (OUT/"m10_results.json").write_text(json.dumps(payload,indent=2),encoding="utf-8")
    lines=["# M10 — M9b + trailing stop at initial-risk distance","",f"Snapshot SHA256: `{sha}`","",
           "Signals remain 5m; position management uses underlying 1m bars.","",
           "| Mode | Window | Trades | Wins | Losses | WR | Avg R | PF(R) | Full -1R losses |",
           "|---|---|---:|---:|---:|---:|---:|---:|---:|"]
    for r in results:
        lines.append(f"| {r['mode']} | {r['window']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['win_rate_pct']:.2f}% | {r['avg_R']:.3f} | {r['profit_factor_R']:.3f} | {r['full_losses']} |")
    lines += ["","Rules:","- Same M9b five-wave exhaustion + wave1/wave2 + breakout-close entry.","- Initial stop remains at full five-wave terminal structure extreme.","- TP remains fixed at 3R.","- Trailing distance is exactly the initial entry-to-structure-stop distance (1R).","- Long: after each completed 1m bar, active stop = max(previous stop, highest price seen - 1R). Short symmetric.","- Existing stop/TP is evaluated before updating from that minute, avoiding an invented high/low sequence inside a 1m candle."]
    report="\n".join(lines)+"\n"; (OUT/"m10_report.md").write_text(report,encoding="utf-8"); print(report)

if __name__=="__main__": main()
