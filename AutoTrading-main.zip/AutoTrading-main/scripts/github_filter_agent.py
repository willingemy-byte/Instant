#!/usr/bin/env python3
"""Focused bounded worker for controlled strategy-filter experiments.

Used for additive research filters such as RANGE-GATE and NEWS-BLACKOUT.
No brokerage connectivity, credentials, or live order execution are permitted.
"""
from __future__ import annotations

import json

import github_engine_agent as base

# Keep the prompt deliberately small enough for a local 3B coder. The issue body
# is fetched separately by github_engine_agent, so only the representative
# strategy implementations needed to wire an additive gate are included here.
base.CONTEXT_FILES = [
    "AGENTS.md",
    "scripts/run_m16_eb3_1h_sma50.py",
    "scripts/run_m17_eb3_noentry_10_17ct.py",
    "scripts/run_m31_tp_ladder_matrix.py",
    "scripts/run_m32_m17_tp_ladder_full_history.py",
]


def model_call(task: str, context: str, prior_tests: str, round_no: int) -> dict:
    system = (
        "You are FILTER-ENGINE, a bounded coding worker inside the AutoTrading repository. "
        "Follow AGENTS.md and the assigned GitHub issue literally. This is OFFLINE research/backtesting only: "
        "never add brokerage connectivity, live order execution, credential handling, or autonomous real-money trading. "
        "The assigned filter must be ADDITIVE: preserve every baseline strategy rule except the single gate described in the issue. "
        "Never fabricate historical results. Keep 3m/6m/1y as official validation windows and 3.22y only as secondary stress. "
        "Separate RAW strategy metrics from ACCOUNT/MLL metrics; MLL survival ranks before profit. "
        "Avoid lookahead: current breakout/event information must not leak into prior-state calculations. "
        "Preserve stop-first conservative intrabar ordering. "
        "Build reusable filter logic plus deterministic tests and a runnable historical experiment adapter whenever repository data loaders allow it. "
        "Return ONLY a JSON object with keys summary and files. files maps repository-relative paths to COMPLETE UTF-8 contents. "
        "You may modify only backtest/, tests/, docs/, or requirements.txt. Prefer existing repository dependencies."
    )
    user = (
        f"TASK (GitHub issue #{base.ISSUE_NUMBER}):\n{task}\n\n"
        f"ROUND: {round_no}/{base.MAX_ROUNDS}\n"
        f"CURRENT REPOSITORY CONTEXT:\n{context}\n\n"
        f"LATEST TEST OUTPUT:\n{prior_tests or 'No new test output yet.'}\n\n"
        "Produce the smallest COMPLETE coherent implementation that materially advances this exact experiment. "
        "If the full historical run cannot safely execute in this bounded coding pass, implement the deterministic adapter/tests and document the exact next command instead of inventing metrics."
    )
    messages = [{"role": "system", "content": system}, {"role": "user", "content": user}]

    if base.MODEL_PROVIDER == "ollama":
        payload = {
            "model": base.MODEL,
            "messages": messages,
            "stream": False,
            "format": "json",
            "options": {"temperature": 0.05, "num_ctx": 32768, "num_predict": 6000},
        }
        response = base.local_json(base.OLLAMA_URL, payload)
        content = response["message"]["content"]
    elif base.MODEL_PROVIDER == "github":
        payload = {
            "model": base.MODEL,
            "messages": messages,
            "temperature": 0.05,
            "max_tokens": 8000,
            "response_format": {"type": "json_object"},
        }
        response = base.http_json(base.GITHUB_MODEL_URL, method="POST", payload=payload)
        content = response["choices"][0]["message"]["content"]
    else:
        raise RuntimeError(f"Unsupported MODEL_PROVIDER: {base.MODEL_PROVIDER}")

    try:
        result = json.loads(content)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"Model did not return valid JSON: {content[:2000]}") from exc
    if not isinstance(result.get("files"), dict):
        raise RuntimeError("Model response missing files object")
    return result


base.model_call = model_call

if __name__ == "__main__":
    raise SystemExit(base.main())
