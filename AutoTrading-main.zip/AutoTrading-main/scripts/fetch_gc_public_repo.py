#!/usr/bin/env python3
"""Fetch and validate a public GC 5-minute futures dataset from GitHub.

Source repository: axb0306/cme-futures-ohlc
Source data is documented there as TopstepX / ProjectX Gateway API data.
This script keeps only the last 60 calendar days available in the source file.
Research/backtesting only; no brokerage connectivity or order execution.
"""
from __future__ import annotations

import argparse
import csv
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.request import Request, urlopen

SOURCE_URL = (
    "https://raw.githubusercontent.com/axb0306/cme-futures-ohlc/main/GC/"
    "GC_5min_20260120_20260415.csv"
)


def parse_dt(value: str) -> datetime:
    text = value.strip().replace("Z", "+00:00")
    dt = datetime.fromisoformat(text)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def download_text(url: str = SOURCE_URL) -> str:
    req = Request(url, headers={"User-Agent": "AutoTrading-DATA-Agent/1.0"})
    with urlopen(req, timeout=60) as response:
        return response.read().decode("utf-8")


def normalize(text: str, days: int = 60) -> tuple[list[dict[str, object]], dict[str, object]]:
    reader = csv.DictReader(text.splitlines())
    required = {"datetime", "open", "high", "low", "close", "volume"}
    if not reader.fieldnames or not required.issubset({name.strip().lower() for name in reader.fieldnames}):
        raise RuntimeError(f"Unexpected CSV header: {reader.fieldnames}")

    rows: list[dict[str, object]] = []
    seen: set[datetime] = set()
    for raw in reader:
        lowered = {str(k).strip().lower(): v for k, v in raw.items()}
        dt = parse_dt(str(lowered["datetime"]))
        if dt in seen:
            continue
        seen.add(dt)
        o = float(lowered["open"])
        h = float(lowered["high"])
        l = float(lowered["low"])
        c = float(lowered["close"])
        v = float(lowered["volume"] or 0)
        if h < max(o, l, c) or l > min(o, h, c):
            raise RuntimeError(f"Invalid OHLC at {dt.isoformat()}: {(o, h, l, c)}")
        rows.append({
            "datetime": dt,
            "open": o,
            "high": h,
            "low": l,
            "close": c,
            "volume": v,
        })

    rows.sort(key=lambda row: row["datetime"])
    if len(rows) < 1000:
        raise RuntimeError(f"Too few source rows: {len(rows)}")
    end = rows[-1]["datetime"]
    start = end - timedelta(days=days)
    sliced = [row for row in rows if row["datetime"] >= start]
    if len(sliced) < 5000:
        raise RuntimeError(f"Too few rows in {days}-day slice: {len(sliced)}")

    out_rows = [
        {
            **row,
            "datetime": row["datetime"].isoformat().replace("+00:00", "Z"),
        }
        for row in sliced
    ]
    report = {
        "source_repository": "axb0306/cme-futures-ohlc",
        "source_url": SOURCE_URL,
        "documented_upstream": "TopstepX / ProjectX Gateway API",
        "instrument": "GC Gold Futures",
        "interval": "5m",
        "timezone": "UTC",
        "source_rows": len(rows),
        "slice_days": days,
        "slice_rows": len(out_rows),
        "first_bar_utc": out_rows[0]["datetime"],
        "last_bar_utc": out_rows[-1]["datetime"],
    }
    return out_rows, report


def write(rows: list[dict[str, object]], report: dict[str, object], output: Path, meta: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    temp = output.with_suffix(output.suffix + ".tmp")
    with temp.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["datetime", "open", "high", "low", "close", "volume"])
        writer.writeheader()
        writer.writerows(rows)
    temp.replace(output)
    meta.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--days", type=int, default=60)
    parser.add_argument("--output", default="data/gc_5m_60d.csv")
    parser.add_argument("--report", default="data/gc_5m_60d.meta.json")
    args = parser.parse_args()
    rows, report = normalize(download_text(), days=args.days)
    write(rows, report, Path(args.output), Path(args.report))
    print(json.dumps(report, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
