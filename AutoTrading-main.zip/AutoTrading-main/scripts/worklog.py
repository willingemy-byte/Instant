#!/usr/bin/env python3
"""Write durable, resumable checkpoints for the AutoTrading project.

This records an operational trace: actions, evidence, decisions, files, tests,
blockers, and the exact next action. It does not and cannot capture a model's
private reasoning tokens.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Sequence


EVENT_TYPES = ("start", "checkpoint", "decision", "test", "block", "finish")


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def clean_items(values: Iterable[str] | None) -> list[str]:
    return [value.strip() for value in (values or []) if value.strip()]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Append a durable work checkpoint and refresh STATUS.md."
    )
    parser.add_argument("event", choices=EVENT_TYPES)
    parser.add_argument("--run-id", required=True, help="Stable identifier for this work session.")
    parser.add_argument("--step", required=True, help="Current WORKPLAN step or focused sub-step.")
    parser.add_argument("--summary", required=True, help="Concise factual progress summary.")
    parser.add_argument("--next", required=True, dest="next_action", help="Exact next action.")
    parser.add_argument("--payoff", default="", help="Verifiable artifact expected from this step.")
    parser.add_argument("--action", action="append", default=[], help="Action taken; repeat as needed.")
    parser.add_argument("--result", action="append", default=[], help="Observed result; repeat as needed.")
    parser.add_argument("--file", action="append", default=[], help="Changed repository path; repeat as needed.")
    parser.add_argument("--test", action="append", default=[], help="Test and result; repeat as needed.")
    parser.add_argument("--blocker", default="", help="Current blocker, if any.")
    parser.add_argument("--commit", action="store_true", help="Create a Git checkpoint commit.")
    parser.add_argument("--push", action="store_true", help="Push the checkpoint commit to the current remote.")
    parser.add_argument("--message", default="", help="Optional Git commit message.")
    parser.add_argument("--dry-run", action="store_true", help="Print the event without writing files.")
    return parser


def build_event(args: argparse.Namespace) -> dict[str, object]:
    return {
        "schema_version": 1,
        "event_id": str(uuid.uuid4()),
        "timestamp_utc": utc_now(),
        "run_id": args.run_id.strip(),
        "event": args.event,
        "step": args.step.strip(),
        "payoff": args.payoff.strip(),
        "summary": args.summary.strip(),
        "actions": clean_items(args.action),
        "results": clean_items(args.result),
        "files": clean_items(args.file),
        "tests": clean_items(args.test),
        "blocker": args.blocker.strip(),
        "next_action": args.next_action.strip(),
    }


def markdown_list(items: Sequence[str], empty: str = "Aucun.") -> str:
    if not items:
        return f"- {empty}"
    return "\n".join(f"- {item}" for item in items)


def render_status(event: dict[str, object]) -> str:
    blocker = str(event["blocker"]) or "Aucun."
    payoff = str(event["payoff"]) or "Non précisé."
    return f"""# AutoTrading — Point de reprise

Dernière mise à jour : `{event['timestamp_utc']}`  
Run : `{event['run_id']}`  
État : `{event['event']}`

## Étape active

{event['step']}

## Payoff attendu

{payoff}

## Résumé factuel

{event['summary']}

## Actions effectuées

{markdown_list(event['actions'])}

## Résultats observés

{markdown_list(event['results'])}

## Fichiers touchés

{markdown_list(event['files'])}

## Tests

{markdown_list(event['tests'])}

## Blocage

{blocker}

## Prochaine action exacte

{event['next_action']}

## Reprise

1. Lire `WORKPLAN.md`.
2. Lire ce fichier.
3. Lire les dernières lignes de `WORKLOG.jsonl`.
4. Vérifier le dernier commit avec `git log -1 --oneline`.
5. Exécuter uniquement la prochaine action exacte ci-dessus.
"""


def append_event(root: Path, event: dict[str, object]) -> None:
    root.mkdir(parents=True, exist_ok=True)
    log_path = root / "WORKLOG.jsonl"
    with log_path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")
        handle.flush()
        os.fsync(handle.fileno())

    status_path = root / "STATUS.md"
    temporary = root / ".STATUS.md.tmp"
    temporary.write_text(render_status(event), encoding="utf-8")
    temporary.replace(status_path)


def safe_repo_path(root: Path, raw_path: str) -> str:
    relative = Path(raw_path)
    if relative.is_absolute():
        raise ValueError(f"Absolute paths cannot be staged: {raw_path}")
    resolved_root = root.resolve()
    resolved = (resolved_root / relative).resolve()
    try:
        resolved.relative_to(resolved_root)
    except ValueError as exc:
        raise ValueError(f"Path escapes repository root: {raw_path}") from exc
    return relative.as_posix()


def run_git(root: Path, arguments: Sequence[str]) -> str:
    completed = subprocess.run(
        ["git", *arguments],
        cwd=root,
        check=False,
        capture_output=True,
        text=True,
    )
    if completed.returncode != 0:
        detail = completed.stderr.strip() or completed.stdout.strip()
        raise RuntimeError(f"git {' '.join(arguments)} failed: {detail}")
    return completed.stdout.strip()


def commit_checkpoint(root: Path, event: dict[str, object], message: str, push: bool) -> str:
    paths = ["WORKLOG.jsonl", "STATUS.md"]
    paths.extend(safe_repo_path(root, path) for path in event["files"])
    unique_paths = list(dict.fromkeys(paths))

    run_git(root, ["add", "-A", "--", *unique_paths])
    commit_message = message.strip() or f"worklog: {event['event']} {event['run_id']}"
    run_git(root, ["commit", "-m", commit_message])
    commit_sha = run_git(root, ["rev-parse", "HEAD"])
    if push:
        run_git(root, ["push"])
    return commit_sha


def main(argv: Sequence[str] | None = None, root: Path | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.push and not args.commit:
        raise SystemExit("--push requires --commit")

    event = build_event(args)
    if not event["run_id"] or not event["step"] or not event["summary"] or not event["next_action"]:
        raise SystemExit("run-id, step, summary, and next action cannot be empty")

    if args.dry_run:
        print(json.dumps(event, ensure_ascii=False, indent=2, sort_keys=True))
        return 0

    repository_root = (root or Path(__file__).resolve().parents[1]).resolve()
    append_event(repository_root, event)

    commit_sha = ""
    if args.commit:
        commit_sha = commit_checkpoint(repository_root, event, args.message, args.push)

    print(f"checkpoint={event['event']} run_id={event['run_id']}")
    print(f"journal={repository_root / 'WORKLOG.jsonl'}")
    print(f"status={repository_root / 'STATUS.md'}")
    if commit_sha:
        print(f"commit={commit_sha}")
        print(f"pushed={'yes' if args.push else 'no'}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (RuntimeError, ValueError) as error:
        print(f"error: {error}", file=sys.stderr)
        raise SystemExit(1)
