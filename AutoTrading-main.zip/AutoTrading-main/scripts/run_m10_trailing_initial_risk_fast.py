from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pandas as pd

import run_m10_trailing_initial_risk as b

OUT = Path("artifacts")
OUT.mkdir(parents=True, exist_ok=True)


def simulate_fast(d1: pd.DataFrame, d5: pd.DataFrame, trailing: bool) -> pd.DataFrame:
    C5 = d5.Close.to_numpy(float)
    H5 = d5.High.to_numpy(float)
    L5 = d5.Low.to_numpy(float)
    idx5 = d5.index
    pivots = b.raw_pivots(d5)
    by_confirm = {}
    for p in pivots:
        by_confirm.setdefault(p["confirm_i"], []).append(p)

    seq=[]; long_state=None; short_state=None; pos=None; rec=[]
    one_ns = pd.Timedelta(nanoseconds=1)

    for i in range(len(d5)):
        close_time = idx5[i] + pd.Timedelta(minutes=5)
        prev_close = idx5[i] if i == 0 else idx5[i-1] + pd.Timedelta(minutes=5)
        if pos is not None:
            mins = d1.loc[prev_close:close_time-one_ns]
            pos, done = b.process_minutes(pos, mins, trailing)
            if done is not None:
                rec.append(done)

        for p in by_confirm.get(i, []):
            if not seq or p["type"] != seq[-1]["type"]:
                seq.append(p.copy())
            else:
                q=seq[-1]
                replace=(p["type"]=="H" and p["price"]>=q["price"]) or (p["type"]=="L" and p["price"]<=q["price"])
                if replace: seq[-1]=p.copy()
            if len(seq)>30: seq=seq[-30:]

            bf=b.bearish_five(seq)
            if bf is not None:
                long_state={"phase":"wait_wave1_high","terminal":bf[-1].copy(),"wave1":None,"wave2":None}
            uf=b.bullish_five(seq)
            if uf is not None:
                short_state={"phase":"wait_wave1_low","terminal":uf[-1].copy(),"wave1":None,"wave2":None}

            if long_state is not None and p["pivot_i"] > long_state["terminal"]["pivot_i"]:
                if long_state["phase"]=="wait_wave1_high" and p["type"]=="H":
                    long_state["wave1"]=p.copy(); long_state["phase"]="wait_wave2_low"
                elif long_state["phase"]=="wait_wave2_low" and p["type"]=="L":
                    if p["price"] > long_state["terminal"]["price"]:
                        long_state["wave2"]=p.copy(); long_state["phase"]="armed"
                    else:
                        long_state=None

            if short_state is not None and p["pivot_i"] > short_state["terminal"]["pivot_i"]:
                if short_state["phase"]=="wait_wave1_low" and p["type"]=="L":
                    short_state["wave1"]=p.copy(); short_state["phase"]="wait_wave2_high"
                elif short_state["phase"]=="wait_wave2_high" and p["type"]=="H":
                    if p["price"] < short_state["terminal"]["price"]:
                        short_state["wave2"]=p.copy(); short_state["phase"]="armed"
                    else:
                        short_state=None

        if long_state is not None and long_state["phase"]=="armed" and L5[i] <= long_state["terminal"]["price"]:
            long_state=None
        if short_state is not None and short_state["phase"]=="armed" and H5[i] >= short_state["terminal"]["price"]:
            short_state=None

        if pos is None:
            if long_state is not None and long_state["phase"]=="armed":
                w1,w2,term=long_state["wave1"],long_state["wave2"],long_state["terminal"]
                if C5[i] > w1["price"] and i > w2["confirm_i"]:
                    entry=float(C5[i]); sl=float(term["price"]); risk=entry-sl
                    if risk>0:
                        pos={"side":1,"entry":entry,"entry_time":close_time,"risk":risk,"initial_stop":sl,
                             "active_stop":sl,"tp":entry+3*risk,"best_price":entry,
                             "terminal_time":term["time"],"wave1_time":w1["time"],"wave2_time":w2["time"]}
                        long_state=None
            elif short_state is not None and short_state["phase"]=="armed":
                w1,w2,term=short_state["wave1"],short_state["wave2"],short_state["terminal"]
                if C5[i] < w1["price"] and i > w2["confirm_i"]:
                    entry=float(C5[i]); sl=float(term["price"]); risk=sl-entry
                    if risk>0:
                        pos={"side":-1,"entry":entry,"entry_time":close_time,"risk":risk,"initial_stop":sl,
                             "active_stop":sl,"tp":entry-3*risk,"best_price":entry,
                             "terminal_time":term["time"],"wave1_time":w1["time"],"wave2_time":w2["time"]}
                        short_state=None

    if pos is not None:
        start=idx5[-1]+pd.Timedelta(minutes=5)
        pos,done=b.process_minutes(pos,d1.loc[start:],trailing)
        if done is not None: rec.append(done)
    return pd.DataFrame(rec)


def main():
    d1=b.load_1m(); d5=b.make_5m(d1)
    snap=OUT/"m10_mgc_5m_from_1m_snapshot.csv"; d5.to_csv(snap)
    sha=hashlib.sha256(snap.read_bytes()).hexdigest(); results=[]
    for mode,trailing in [("fixed_structure_stop",False),("trailing_initial_1R",True)]:
        for label,start in b.STARTS.items():
            x1=d1.loc[start:]; x5=d5.loc[start:]
            t=simulate_fast(x1,x5,trailing)
            t.to_csv(OUT/f"m10_{mode}_{label}_trades.csv",index=False)
            m=b.metrics(t); m.update(mode=mode,window=label); results.append(m)
    payload={"method":"offline research only","instrument":"MGC","signal_timeframe":"5m","management_timeframe":"1m",
             "snapshot_sha256":sha,"trailing_rule":"distance equals initial structural risk; stop never loosens; fixed TP=3R",
             "intraminute_rule":"existing stop/TP checked first; trailing updated from completed 1m bar for next minute","results":results}
    (OUT/"m10_results.json").write_text(json.dumps(payload,indent=2),encoding="utf-8")
    lines=["# M10 — M9b + trailing stop at initial-risk distance","",f"Snapshot SHA256: `{sha}`","",
           "Signals remain 5m; position management uses underlying 1m bars.","",
           "| Mode | Window | Trades | Wins | Losses | WR | Avg R | PF(R) | Full -1R losses |",
           "|---|---|---:|---:|---:|---:|---:|---:|---:|"]
    for r in results:
        lines.append(f"| {r['mode']} | {r['window']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['win_rate_pct']:.2f}% | {r['avg_R']:.3f} | {r['profit_factor_R']:.3f} | {r['full_losses']} |")
    lines += ["","- Same M9b entry logic and full-structure initial stop.","- Fixed TP remains 3R.","- Trailing distance equals the initial structural risk (1R).","- Trail is managed on completed 1m bars; it never loosens."]
    report="\n".join(lines)+"\n"; (OUT/"m10_report.md").write_text(report,encoding="utf-8"); print(report)

if __name__=="__main__": main()
