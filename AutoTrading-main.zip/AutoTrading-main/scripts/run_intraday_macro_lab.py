from __future__ import annotations

import json
from pathlib import Path
from datetime import datetime, timezone

import numpy as np
import pandas as pd
from scipy.stats import pearsonr, spearmanr

import run_m10_trailing_initial_risk as b
import run_m17_eb3_noentry_10_17ct as m17

OUT = Path("artifacts/intraday_macro_lab")
OUT.mkdir(parents=True, exist_ok=True)
CME = Path("external/cme-intraday")
MGC_SRC = Path("external/mgc-src/data")

START = pd.Timestamp("2026-03-08 00:00:00", tz="UTC")
END = pd.Timestamp("2026-03-23 23:59:59", tz="UTC")
CONTEXT_START = pd.Timestamp("2026-02-20 00:00:00", tz="UTC")
LAGS_BARS = [-24, -12, -6, -3, -1, 0, 1, 3, 6, 12, 24]  # 5m bars; +/-120 minutes

FILES = {
    "GC": "GC/GC_5min_20260120_20260415.csv",
    "CL": "CL/CL_5min_20260120_20260415.csv",
    "ZN": "ZN/ZN_5min_20260222_20260415.csv",
    "6E": "6E/6E_5min_20260308_20260415.csv",
}


def load_cme_5m(symbol: str, rel: str) -> pd.DataFrame:
    p = CME / rel
    if not p.exists():
        raise FileNotFoundError(p)
    x = pd.read_csv(p)
    required = {"datetime", "open", "high", "low", "close", "volume"}
    if not required.issubset(x.columns):
        raise RuntimeError(f"{symbol} missing columns: {required - set(x.columns)}")
    x["datetime"] = pd.to_datetime(x["datetime"], utc=True, errors="coerce")
    x = x.dropna(subset=["datetime", "close"]).drop_duplicates("datetime", keep="last").sort_values("datetime")
    x = x.set_index("datetime")
    x = x.loc[(x.index >= START) & (x.index <= END)].copy()
    return x[["open", "high", "low", "close", "volume"]]


def build_market_panel() -> pd.DataFrame:
    closes = {}
    coverage = []
    for sym, rel in FILES.items():
        x = load_cme_5m(sym, rel)
        closes[sym] = pd.to_numeric(x["close"], errors="coerce").rename(sym)
        coverage.append({
            "symbol": sym,
            "rows": int(len(x)),
            "start": str(x.index.min()) if len(x) else None,
            "end": str(x.index.max()) if len(x) else None,
            "source_file": rel,
        })
    pd.DataFrame(coverage).to_csv(OUT / "intraday_source_inventory.csv", index=False)
    (OUT / "intraday_source_inventory.json").write_text(json.dumps(coverage, indent=2), encoding="utf-8")

    levels = pd.concat(closes.values(), axis=1, join="inner").dropna().sort_index()
    levels.columns = list(closes.keys())
    if levels.empty:
        raise RuntimeError("No common 5-minute overlap across GC/CL/ZN/6E")

    ret = levels.pct_change(fill_method=None)
    panel = pd.DataFrame(index=levels.index)
    panel["GOLD_RET"] = ret["GC"]
    panel["WTI_RET"] = ret["CL"]
    # 6E is EUR/USD. Negating its return is only a USD-strength proxy, NOT DXY.
    panel["USD_PROXY_RET"] = -ret["6E"]
    # ZN futures price rises when 10Y yield pressure generally falls. Negating is a yield-pressure proxy, NOT a yield series.
    panel["YIELD_PROXY_RET"] = -ret["ZN"]
    panel["GC_CLOSE"] = levels["GC"]
    panel["CL_CLOSE"] = levels["CL"]
    panel["ZN_CLOSE"] = levels["ZN"]
    panel["6E_CLOSE"] = levels["6E"]

    ct = panel.index.tz_convert("America/Chicago")
    mins = ct.hour * 60 + ct.minute
    session = np.full(len(panel), "OTHER", dtype=object)
    session[(mins >= 7*60) & (mins < 10*60)] = "US_AM_CT_07_10"
    session[(mins >= 10*60) & (mins < 12*60)] = "MIDDAY_CT_10_12"
    session[(mins >= 12*60) & (mins <= 15*60+10)] = "PM_CT_12_1510"
    session[(mins >= 17*60)] = "EVENING_CT_17_24"
    session[(mins < 7*60)] = "OVERNIGHT_CT_00_07"
    panel["SESSION"] = session
    panel.to_csv(OUT / "intraday_common_panel.csv")
    return panel


def corr_stats(a: pd.Series, b: pd.Series) -> tuple[float, float, int]:
    z = pd.concat([a, b], axis=1).replace([np.inf, -np.inf], np.nan).dropna()
    if len(z) < 30 or z.iloc[:, 0].nunique() < 2 or z.iloc[:, 1].nunique() < 2:
        return np.nan, np.nan, len(z)
    return float(pearsonr(z.iloc[:, 0], z.iloc[:, 1]).statistic), float(spearmanr(z.iloc[:, 0], z.iloc[:, 1]).statistic), len(z)


def leadlag_table(panel: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for feature in ["WTI_RET", "USD_PROXY_RET", "YIELD_PROXY_RET"]:
        for lag_bars in LAGS_BARS:
            # Positive lag_minutes: feature at t is compared with Gold at t+lag.
            target = panel["GOLD_RET"].shift(-lag_bars)
            p, s, n = corr_stats(panel[feature], target)
            rows.append({
                "feature": feature,
                "target": "GOLD_RET",
                "lag_minutes": lag_bars * 5,
                "meaning": "positive=feature leads Gold; negative=Gold leads feature",
                "pearson": p,
                "spearman": s,
                "n": n,
                "scope": "ALL",
            })
        for session, sub in panel.groupby("SESSION"):
            for lag_bars in [-12, -6, -3, -1, 0, 1, 3, 6, 12]:
                target = sub["GOLD_RET"].shift(-lag_bars)
                p, s, n = corr_stats(sub[feature], target)
                rows.append({
                    "feature": feature,
                    "target": "GOLD_RET",
                    "lag_minutes": lag_bars * 5,
                    "meaning": "positive=feature leads Gold; negative=Gold leads feature",
                    "pearson": p,
                    "spearman": s,
                    "n": n,
                    "scope": session,
                })
    out = pd.DataFrame(rows)
    out["abs_score"] = out[["pearson", "spearman"]].abs().mean(axis=1)
    out = out.sort_values(["scope", "abs_score", "n"], ascending=[True, False, False])
    out.to_csv(OUT / "intraday_leadlag.csv", index=False)
    return out


def rolling_summary(panel: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for feature in ["WTI_RET", "USD_PROXY_RET", "YIELD_PROXY_RET"]:
        for bars, label in [(288, "1d"), (1440, "5d")]:
            r = panel[feature].rolling(bars, min_periods=max(60, bars // 3)).corr(panel["GOLD_RET"])
            z = r.dropna()
            rows.append({
                "feature": feature,
                "window": label,
                "observations": int(len(z)),
                "mean_corr": float(z.mean()) if len(z) else np.nan,
                "median_corr": float(z.median()) if len(z) else np.nan,
                "min_corr": float(z.min()) if len(z) else np.nan,
                "max_corr": float(z.max()) if len(z) else np.nan,
                "positive_share": float((z > 0).mean()) if len(z) else np.nan,
            })
    out = pd.DataFrame(rows)
    out.to_csv(OUT / "intraday_rolling_summary.csv", index=False)
    return out


def load_mgc_context() -> pd.DataFrame:
    frames = []
    for p in sorted(MGC_SRC.glob("ohlcv_MGC_*.csv")):
        stem = p.stem
        try:
            datestr = stem.rsplit("_", 1)[-1]
            d = pd.Timestamp(datestr, tz="UTC")
        except Exception:
            continue
        if d < CONTEXT_START.normalize() or d > END.normalize():
            continue
        x = pd.read_csv(p)
        if "timestamp" not in x.columns:
            continue
        x["timestamp"] = pd.to_datetime(x["timestamp"], utc=True, errors="coerce")
        frames.append(x)
    if not frames:
        raise RuntimeError("No MGC daily files for strategy context")
    d = pd.concat(frames, ignore_index=True).dropna(subset=["timestamp"]).drop_duplicates("timestamp", keep="last").sort_values("timestamp")
    d = d.set_index("timestamp").rename(columns={"open":"Open","high":"High","low":"Low","close":"Close","volume":"Volume"})
    return d[["Open","High","Low","Close","Volume"]].dropna().copy()


def strategy_conditionals(panel: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    d1 = load_mgc_context()
    d5 = b.make_5m(d1)
    trades = m17.simulate_m17(d1, d5).copy()
    if trades.empty:
        return pd.DataFrame(), pd.DataFrame()
    trades["entry_time"] = pd.to_datetime(trades["entry_time"], utc=True)
    trades = trades[(trades["entry_time"] >= START) & (trades["entry_time"] <= END)].copy()
    if trades.empty:
        return trades, pd.DataFrame()

    feats = panel[["WTI_RET", "USD_PROXY_RET", "YIELD_PROXY_RET"]].copy()
    for c in ["WTI_RET", "USD_PROXY_RET", "YIELD_PROXY_RET"]:
        for bars, mins in [(1,5),(3,15),(6,30),(12,60)]:
            # Past cumulative move ending at entry bar.
            feats[f"{c}_PAST_{mins}M"] = panel[c].rolling(bars, min_periods=bars).sum()
    joined = trades.merge(feats.reset_index().rename(columns={"datetime":"entry_time", "index":"entry_time"}), on="entry_time", how="left")
    joined.to_csv(OUT / "intraday_strategy_trade_context.csv", index=False)

    eps = 1e-9
    joined["outcome"] = np.where(joined["R"].astype(float) > eps, "WIN", np.where(joined["R"].astype(float) < -eps, "LOSS", "BE"))
    rows = []
    feature_cols = [c for c in joined.columns if c.startswith(("WTI_RET", "USD_PROXY_RET", "YIELD_PROXY_RET"))]
    for outcome, g in joined.groupby("outcome"):
        for c in feature_cols:
            s = pd.to_numeric(g[c], errors="coerce").dropna()
            rows.append({"outcome": outcome, "feature": c, "trades": int(len(g)), "n": int(len(s)), "mean": float(s.mean()) if len(s) else np.nan, "median": float(s.median()) if len(s) else np.nan})
    summary = pd.DataFrame(rows)
    summary.to_csv(OUT / "intraday_strategy_conditionals.csv", index=False)
    return joined, summary


def main() -> None:
    panel = build_market_panel()
    leadlag = leadlag_table(panel)
    rolling = rolling_summary(panel)
    trades, cond = strategy_conditionals(panel)

    all_scope = leadlag[leadlag["scope"] == "ALL"].sort_values("abs_score", ascending=False)
    top = all_scope.head(15).to_dict(orient="records")
    payload = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "window_start": str(START),
        "window_end": str(END),
        "common_5m_rows": int(len(panel)),
        "strategy_trades_in_window": int(len(trades)),
        "symbols": {
            "GC": "Gold futures",
            "CL": "WTI crude futures",
            "ZN": "10Y Treasury Note futures; negative return used only as yield-pressure proxy",
            "6E": "Euro FX futures; negative return used only as USD-strength proxy, not DXY",
        },
        "top_all_session_relationships": top,
        "warning": "Short exploratory historical window. Correlation does not establish causality or future predictability; 6E and -ZN are proxies, not DXY or Treasury yields.",
    }
    (OUT / "summary.json").write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")

    lines = [
        "# Intraday macro lab — Gold / WTI / USD proxy / Treasury proxy",
        "",
        f"Window: **{START.date()} -> {END.date()}**; common 5-minute rows: **{len(panel)}**; strategy trades in window: **{len(trades)}**.",
        "",
        "All source timestamps are UTC. 6E is used as an inverse USD-strength proxy, not DXY. -ZN return is a yield-pressure proxy, not a yield quote.",
        "",
        "## Strongest all-session short-horizon relationships",
        "",
        "| Feature | Lead/lag min | Pearson | Spearman | N |",
        "|---|---:|---:|---:|---:|",
    ]
    for r in top[:12]:
        lines.append(f"| {r['feature']} | {int(r['lag_minutes'])} | {r['pearson']:.3f} | {r['spearman']:.3f} | {int(r['n'])} |")
    lines += [
        "",
        "Positive minutes = feature moves first, Gold later. Negative minutes = Gold moves first. Zero = same 5-minute bar.",
        "",
        "This is an offline research diagnostic only; no strategy rule is changed.",
    ]
    (OUT / "report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print((OUT / "report.md").read_text(encoding="utf-8"))


if __name__ == "__main__":
    main()
