from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

import run_m10_trailing_initial_risk as b
import run_m14_topstep_150k_risk300 as m14

OUT = Path("artifacts")
OUT.mkdir(parents=True, exist_ok=True)


def completed_h1_sma50(d1: pd.DataFrame) -> pd.Series:
    """Return 1h SMA50 indexed by the hour CLOSE time.

    A 5m signal at time t may only use an hourly value whose hour has already
    closed at or before t. This prevents higher-timeframe look-ahead.
    """
    h1 = d1.resample("1h", label="left", closed="left").agg({
        "Open": "first", "High": "max", "Low": "min", "Close": "last", "Volume": "sum"
    }).dropna(subset=["Open", "High", "Low", "Close"])
    sma = h1["Close"].rolling(50, min_periods=50).mean()
    sma.index = sma.index + pd.Timedelta(hours=1)
    sma.name = "sma50_h1"
    return sma.dropna()


def simulate_topstep_trades_sma50(d1: pd.DataFrame, d5: pd.DataFrame) -> pd.DataFrame:
    c5 = d5.Close.to_numpy(float)
    h5 = d5.High.to_numpy(float)
    l5 = d5.Low.to_numpy(float)
    idx5 = d5.index

    h1_sma = completed_h1_sma50(d1)
    if h1_sma.empty:
        return pd.DataFrame()

    pivots = b.raw_pivots(d5)
    by_confirm = {}
    for p in pivots:
        by_confirm.setdefault(p["confirm_i"], []).append(p)

    seq = []
    long_state = short_state = pos = None
    rec = []
    one_ns = pd.Timedelta(nanoseconds=1)

    for i in range(len(d5)):
        close_time = idx5[i] + pd.Timedelta(minutes=5)
        prev_close = idx5[i] if i == 0 else idx5[i - 1] + pd.Timedelta(minutes=5)

        if pos is not None:
            pos, done = m14.process_minutes_topstep(pos, d1.loc[prev_close:close_time - one_ns])
            if done is not None:
                rec.append(done)

        for p in by_confirm.get(i, []):
            if not seq or p["type"] != seq[-1]["type"]:
                seq.append(p.copy())
            else:
                q = seq[-1]
                replace = (
                    (p["type"] == "H" and p["price"] >= q["price"])
                    or (p["type"] == "L" and p["price"] <= q["price"])
                )
                if replace:
                    seq[-1] = p.copy()
            if len(seq) > 30:
                seq = seq[-30:]

            bf = b.bearish_five(seq)
            if bf is not None:
                long_state = {"phase": "wait_wave1_high", "terminal": bf[-1].copy(), "wave1": None, "wave2": None}
            uf = b.bullish_five(seq)
            if uf is not None:
                short_state = {"phase": "wait_wave1_low", "terminal": uf[-1].copy(), "wave1": None, "wave2": None}

            if long_state is not None and p["pivot_i"] > long_state["terminal"]["pivot_i"]:
                if long_state["phase"] == "wait_wave1_high" and p["type"] == "H":
                    long_state["wave1"] = p.copy()
                    long_state["phase"] = "wait_wave2_low"
                elif long_state["phase"] == "wait_wave2_low" and p["type"] == "L":
                    if p["price"] > long_state["terminal"]["price"]:
                        long_state["wave2"] = p.copy()
                        long_state["phase"] = "armed"
                    else:
                        long_state = None

            if short_state is not None and p["pivot_i"] > short_state["terminal"]["pivot_i"]:
                if short_state["phase"] == "wait_wave1_low" and p["type"] == "L":
                    short_state["wave1"] = p.copy()
                    short_state["phase"] = "wait_wave2_high"
                elif short_state["phase"] == "wait_wave2_high" and p["type"] == "H":
                    if p["price"] < short_state["terminal"]["price"]:
                        short_state["wave2"] = p.copy()
                        short_state["phase"] = "armed"
                    else:
                        short_state = None

        if long_state is not None and long_state["phase"] == "armed" and l5[i] <= long_state["terminal"]["price"]:
            long_state = None
        if short_state is not None and short_state["phase"] == "armed" and h5[i] >= short_state["terminal"]["price"]:
            short_state = None

        if pos is None and m14.entry_allowed(close_time):
            hist = h1_sma.loc[:close_time]
            sma50 = float(hist.iloc[-1]) if len(hist) else None
            if sma50 is None:
                continue

            if long_state is not None and long_state["phase"] == "armed":
                w1, w2, term = long_state["wave1"], long_state["wave2"], long_state["terminal"]
                long_breakout = c5[i] > w1["price"] and i > w2["confirm_i"]
                trend_ok = c5[i] > sma50
                if long_breakout and trend_ok:
                    entry = float(c5[i]); sl = float(term["price"]); risk = entry - sl
                    if risk > 0:
                        pos = {
                            "side": 1, "entry": entry, "entry_time": close_time, "risk": risk,
                            "initial_stop": sl, "active_stop": sl, "tp": entry + 7 * risk,
                            "best_price": entry, "phase2": False,
                            "terminal_time": term["time"], "wave1_time": w1["time"], "wave2_time": w2["time"],
                            "sma50_h1": sma50,
                        }
                        long_state = None

            elif short_state is not None and short_state["phase"] == "armed":
                w1, w2, term = short_state["wave1"], short_state["wave2"], short_state["terminal"]
                short_breakout = c5[i] < w1["price"] and i > w2["confirm_i"]
                trend_ok = c5[i] < sma50
                if short_breakout and trend_ok:
                    entry = float(c5[i]); sl = float(term["price"]); risk = sl - entry
                    if risk > 0:
                        pos = {
                            "side": -1, "entry": entry, "entry_time": close_time, "risk": risk,
                            "initial_stop": sl, "active_stop": sl, "tp": entry - 7 * risk,
                            "best_price": entry, "phase2": False,
                            "terminal_time": term["time"], "wave1_time": w1["time"], "wave2_time": w2["time"],
                            "sma50_h1": sma50,
                        }
                        short_state = None

    if pos is not None:
        pos, done = m14.process_minutes_topstep(pos, d1.loc[idx5[-1] + pd.Timedelta(minutes=5):])
        if done is not None:
            rec.append(done)

    return pd.DataFrame(rec)


def main():
    d1 = b.load_1m()
    d5 = b.make_5m(d1)

    results = []
    for label, start in b.STARTS.items():
        x1 = d1.loc[start:]
        x5 = d5.loc[start:]
        t = simulate_topstep_trades_sma50(x1, x5)
        t.to_csv(OUT / f"m15_topstep_{label}_trades.csv", index=False)
        risk_eval = m14.evaluate_mll(t, x1)
        risk_eval["ledger"].to_csv(OUT / f"m15_topstep_{label}_ledger.csv", index=False)
        s = m14.summarize(t, risk_eval)
        s["window"] = label
        results.append(s)

    payload = {
        "method": "offline research only",
        "baseline": "M14 Topstep-style simulation",
        "only_strategy_change": "1h SMA50 directional regime filter",
        "filter": {
            "long": "5m breakout close must be above latest completed 1h SMA50",
            "short": "5m breakout close must be below latest completed 1h SMA50",
            "lookahead": "forbidden; only completed 1h bars used",
        },
        "starting_balance": m14.START_BALANCE,
        "risk_dollars_per_trade": m14.RISK_DOLLARS,
        "mll_distance": m14.MLL_DISTANCE,
        "results": results,
    }
    (OUT / "m15_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = [
        "# M15 — M14 + completed 1h SMA50 directional filter",
        "",
        "Only change vs M14: long if 5m entry close > latest completed 1h SMA50; short if below.",
        "",
        "| Window | Trades | W | L | BE | WR all | WR ex-BE | Avg R | Net $ | Final balance | Closed DD $ | Min MLL headroom $ | Survived |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|",
    ]
    for r in results:
        lines.append(
            f"| {r['window']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['breakeven']} | "
            f"{r['win_rate_all_pct']:.2f}% | {r['win_rate_ex_be_pct']:.2f}% | {r['avg_R']:.3f} | "
            f"{r['fixed_risk_net_profit']:.0f} | {r['final_balance']:.0f} | {r['closed_equity_max_drawdown']:.0f} | "
            f"{r['minimum_mll_headroom']:.0f} | {r['topstep_survived']} |"
        )
    report = "\n".join(lines) + "\n"
    (OUT / "m15_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
