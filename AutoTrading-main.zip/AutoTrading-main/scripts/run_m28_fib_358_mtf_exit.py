from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

import run_m10_trailing_initial_risk as b
import run_m14_topstep_150k_risk300 as m14
import run_m17_eb3_noentry_10_17ct as m17
import run_m20_m17_dynamic20_capped900 as m20
import run_m21_m20_full_mgc_history as m21

OUT = Path("artifacts/m28_fib_358_mtf_exit")
OUT.mkdir(parents=True, exist_ok=True)


def completed_h1_fib_mas(d1: pd.DataFrame) -> pd.DataFrame:
    """Hourly close and completed SMA3/5/8/200, timestamped at hour close."""
    h1 = d1.resample("1h", label="left", closed="left").agg({
        "Open": "first",
        "High": "max",
        "Low": "min",
        "Close": "last",
        "Volume": "sum",
    }).dropna(subset=["Open", "High", "Low", "Close"])
    out = pd.DataFrame(index=h1.index)
    out["close_h1"] = h1["Close"]
    for n in (3, 5, 8, 200):
        out[f"sma{n}_h1"] = h1["Close"].rolling(n, min_periods=n).mean()
    out.index = out.index + pd.Timedelta(hours=1)
    return out.dropna()


def five_minute_fib_mas(d5: pd.DataFrame) -> pd.DataFrame:
    out = pd.DataFrame(index=d5.index)
    for n in (3, 5, 8):
        out[f"sma{n}_5m"] = d5["Close"].rolling(n, min_periods=n).mean()
    return out


def finish_trade(pos: dict, ex: float, ts: pd.Timestamp, reason: str) -> dict:
    side = int(pos["side"])
    risk = float(pos["risk"])
    r = ((float(ex) - float(pos["entry"])) / risk) * side
    return {**pos, "exit": float(ex), "exit_time": ts, "reason": reason, "R": float(r)}


def process_static_stop(pos: dict | None, mins: pd.DataFrame) -> tuple[dict | None, dict | None]:
    """Protective static stop + Topstep-style 15:10 CT flatten; no TP/trailing."""
    if pos is None or mins.empty:
        return pos, None
    side = int(pos["side"])
    stop = float(pos["initial_stop"])
    for ts, bar in mins.iterrows():
        if m14.force_flat_now(ts):
            return None, finish_trade(pos, float(bar.Open), ts, "topstep_1510_flat")
        if side == 1:
            if float(bar.Open) <= stop:
                return None, finish_trade(pos, float(bar.Open), ts, "gap_stop")
            if float(bar.Low) <= stop:
                return None, finish_trade(pos, stop, ts, "stop")
        else:
            if float(bar.Open) >= stop:
                return None, finish_trade(pos, float(bar.Open), ts, "gap_stop")
            if float(bar.High) >= stop:
                return None, finish_trade(pos, stop, ts, "stop")
    return pos, None


def simulate_m28(d1: pd.DataFrame, d5: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    h1 = completed_h1_fib_mas(d1)
    m5 = five_minute_fib_mas(d5)
    if h1.empty or m5.dropna().empty:
        return pd.DataFrame(), {}

    idx5 = d5.index
    one_ns = pd.Timedelta(nanoseconds=1)
    pos = None
    rec: list[dict] = []

    prev_eligible_long = False
    prev_eligible_short = False
    long_armed = False
    short_armed = False

    counters = {
        "hourly_long_regime_bars": 0,
        "hourly_short_regime_bars": 0,
        "long_setups_formed": 0,
        "short_setups_formed": 0,
        "accepted_long_entries": 0,
        "accepted_short_entries": 0,
        "blocked_by_entry_hours": 0,
    }

    for i in range(len(d5)):
        close_time = idx5[i] + pd.Timedelta(minutes=5)
        prev_close = idx5[i] if i == 0 else idx5[i - 1] + pd.Timedelta(minutes=5)

        if pos is not None:
            pos, done = process_static_stop(pos, d1.loc[prev_close:close_time - one_ns])
            if done is not None:
                rec.append(done)

        row5 = m5.iloc[i]
        vals5 = [row5.get(f"sma{n}_5m", np.nan) for n in (3, 5, 8)]
        valid5 = all(pd.notna(v) and np.isfinite(float(v)) for v in vals5)
        if not valid5:
            prev_eligible_long = prev_eligible_short = False
            long_armed = short_armed = False
            continue
        sma3_5, sma5_5, sma8_5 = map(float, vals5)

        hist = h1.loc[:close_time]
        if hist.empty:
            continue
        hr = hist.iloc[-1]
        close_h1 = float(hr["close_h1"])
        sma3_h1 = float(hr["sma3_h1"])
        sma5_h1 = float(hr["sma5_h1"])
        sma8_h1 = float(hr["sma8_h1"])
        sma200_h1 = float(hr["sma200_h1"])

        long_regime = close_h1 > sma200_h1 and sma3_h1 > sma5_h1 > sma8_h1 > sma200_h1
        short_regime = close_h1 < sma200_h1 and sma3_h1 < sma5_h1 < sma8_h1 < sma200_h1
        if long_regime:
            counters["hourly_long_regime_bars"] += 1
        if short_regime:
            counters["hourly_short_regime_bars"] += 1

        long_5m = sma3_5 > sma5_5 and sma3_5 > sma8_5
        short_5m = sma3_5 < sma5_5 and sma3_5 < sma8_5
        eligible_long = long_regime and long_5m
        eligible_short = short_regime and short_5m

        # A newly valid combined setup arms once. If it forms during a no-entry
        # period it remains armed while still valid and may enter later.
        if eligible_long and not prev_eligible_long:
            long_armed = True
            counters["long_setups_formed"] += 1
        elif not eligible_long:
            long_armed = False

        if eligible_short and not prev_eligible_short:
            short_armed = True
            counters["short_setups_formed"] += 1
        elif not eligible_short:
            short_armed = False

        prev_eligible_long = eligible_long
        prev_eligible_short = eligible_short

        # MA close exit replaces TP/trailing.
        if pos is not None:
            side = int(pos["side"])
            if side == 1 and sma3_5 < sma8_5:
                rec.append(finish_trade(pos, float(d5.Close.iloc[i]), close_time, "sma3_below_sma8"))
                pos = None
            elif side == -1 and sma3_5 > sma8_5:
                rec.append(finish_trade(pos, float(d5.Close.iloc[i]), close_time, "sma3_above_sma8"))
                pos = None

        if pos is not None:
            continue

        if not m17.entry_allowed_m17(close_time):
            if long_armed or short_armed:
                counters["blocked_by_entry_hours"] += 1
            continue

        entry = float(d5.Close.iloc[i])
        if long_armed and eligible_long:
            sl = float(d5.Low.iloc[i])
            risk = entry - sl
            if risk > 0:
                pos = {
                    "side": 1,
                    "entry": entry,
                    "entry_time": close_time,
                    "risk": risk,
                    "initial_stop": sl,
                    "active_stop": sl,
                    "trigger_time": idx5[i],
                    "sma3_5m": sma3_5,
                    "sma5_5m": sma5_5,
                    "sma8_5m": sma8_5,
                    "close_h1": close_h1,
                    "sma3_h1": sma3_h1,
                    "sma5_h1": sma5_h1,
                    "sma8_h1": sma8_h1,
                    "sma200_h1": sma200_h1,
                }
                long_armed = False
                counters["accepted_long_entries"] += 1
        elif short_armed and eligible_short:
            sl = float(d5.High.iloc[i])
            risk = sl - entry
            if risk > 0:
                pos = {
                    "side": -1,
                    "entry": entry,
                    "entry_time": close_time,
                    "risk": risk,
                    "initial_stop": sl,
                    "active_stop": sl,
                    "trigger_time": idx5[i],
                    "sma3_5m": sma3_5,
                    "sma5_5m": sma5_5,
                    "sma8_5m": sma8_5,
                    "close_h1": close_h1,
                    "sma3_h1": sma3_h1,
                    "sma5_h1": sma5_h1,
                    "sma8_h1": sma8_h1,
                    "sma200_h1": sma200_h1,
                }
                short_armed = False
                counters["accepted_short_entries"] += 1

    if pos is not None:
        end_ts = idx5[-1] + pd.Timedelta(minutes=5)
        rec.append(finish_trade(pos, float(d5.Close.iloc[-1]), end_ts, "data_end"))

    return pd.DataFrame(rec), counters


def main() -> None:
    d1 = m21.load_full_1m()
    d5 = b.make_5m(d1)
    data_start = str(d1.index.min())
    data_end = str(d1.index.max())
    elapsed_years = float((d1.index.max() - d1.index.min()) / pd.Timedelta(days=365.2425))

    trades, counters = simulate_m28(d1, d5)
    trades.to_csv(OUT / "m28_full_history_trades.csv", index=False)

    ev = m20.evaluate_dynamic20_capped900(trades, d1)
    ledger = ev["ledger"].copy()
    ledger.to_csv(OUT / "m28_full_history_ledger.csv", index=False)

    summary = m20.summarize(trades, ev)
    summary["longest_loss_streak"] = m21.longest_loss_streak(trades["R"] if not trades.empty else pd.Series(dtype=float))
    annual = m21.period_stats(trades, ledger, "year")
    quarterly = m21.period_stats(trades, ledger, "quarter")
    exits = trades["reason"].value_counts().to_dict() if not trades.empty else {}

    payload = {
        "method": "offline research simulation only",
        "strategy": "M28 Fibonacci SMA 3/5/8 multi-timeframe",
        "hourly_long": "close>SMA200 and SMA3>SMA5>SMA8>SMA200 using completed hourly bars",
        "hourly_short": "close<SMA200 and SMA3<SMA5<SMA8<SMA200 using completed hourly bars",
        "entry_long_5m": "first combined-valid close with SMA3>SMA5 and SMA3>SMA8",
        "entry_short_5m": "first combined-valid close with SMA3<SMA5 and SMA3<SMA8",
        "exit_long": "5m close when SMA3<SMA8",
        "exit_short": "5m close when SMA3>SMA8",
        "no_tp": True,
        "no_trailing": True,
        "protective_stop": "opposite wick of entry candle",
        "entry_hours": "M17 no-entry 10:00-17:00 CT; Topstep-style session availability",
        "forced_flat": "15:10 CT",
        "sizing": "M20 dynamic 20% of realized MLL headroom capped at $900",
        "data_start": data_start,
        "data_end": data_end,
        "elapsed_years": elapsed_years,
        "counters": counters,
        "exit_reasons": exits,
        "summary": summary,
        "annual": annual,
        "quarterly": quarterly,
    }
    (OUT / "m28_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    s = summary
    lines = [
        "# M28 — Fibonacci SMA 3/5/8 MTF + SMA3/SMA8 exit",
        "",
        f"Data: {data_start} -> {data_end} (~{elapsed_years:.2f} years)",
        "",
        "No EB3. No TP7. No M13 trailing. Static protective wick stop remains for risk definition.",
        "",
        "| Trades | W | L | BE | WR ex-BE | Avg R | Sum R | Net $ dynamic | Final balance | Avg risk $ | Min risk $ | Max risk $ | Min MLL headroom $ | Loss streak | Survived |",
        "|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|",
        f"| {s['trades']} | {s['wins']} | {s['losses']} | {s['breakeven']} | {s['win_rate_ex_be_pct']:.2f}% | {s['avg_R']:.3f} | {s.get('sum_R', 0):.1f} | {s['net_profit']:.0f} | {s['final_balance']:.0f} | {s['average_risk_dollars']:.0f} | {s['minimum_risk_dollars']:.2f} | {s['maximum_risk_dollars']:.0f} | {s['minimum_mll_headroom']:.2f} | {s['longest_loss_streak']} | {s['topstep_survived']} |",
        "",
        "## Exit reasons",
        "",
    ]
    for k, v in sorted(exits.items(), key=lambda kv: (-kv[1], kv[0])):
        lines.append(f"- {k}: {v}")
    lines += [
        "",
        "## By calendar year",
        "",
        "| Year | Trades | W | L | BE | WR ex-BE | Avg R | Sum R | Net $ dynamic | Avg risk $ | Loss streak |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in annual:
        lines.append(
            f"| {r['period']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['breakeven']} | "
            f"{r['win_rate_ex_be_pct']:.2f}% | {r['avg_R']:.3f} | {r['sum_R']:.1f} | "
            f"{r['net_profit_dollars']:.0f} | {r['average_risk_dollars']:.0f} | {r['longest_loss_streak']} |"
        )
    report = "\n".join(lines) + "\n"
    (OUT / "m28_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
