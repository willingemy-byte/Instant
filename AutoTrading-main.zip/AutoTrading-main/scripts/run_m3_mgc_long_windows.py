from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pandas as pd
from backtesting import Backtest, Strategy

SOURCE_COMMIT = "bf75ac4587e7995ceae64c3d696e076c37be12cc"
SOURCE_REPO = "domzack/mgc-ohlcv-data"
SOURCE_END = pd.Timestamp("2026-03-23 23:59:59", tz="UTC")
DATA_DIR = Path("external/mgc/data")
OUT_DIR = Path("artifacts")
OUT_DIR.mkdir(parents=True, exist_ok=True)


class Eb3Persistent3mStrategy(Strategy):
    rsi_length = 21
    rsi_ma_length = 50
    price_ma_length = 50
    risk_reward_ratio = 3.0

    def init(self):
        def calculate_rsi(close_prices, rsi_length):
            delta = pd.Series(close_prices).diff()
            gain = delta.mask(delta < 0, 0)
            loss = -delta.mask(delta > 0, 0)
            avg_gain = gain.ewm(com=rsi_length - 1, adjust=False).mean()
            avg_loss = loss.ewm(com=rsi_length - 1, adjust=False).mean()
            rs = avg_gain / avg_loss
            return pd.Series([
                100 - (100 / (1 + val)) if val != 0 and not pd.isna(val)
                else (100 if pd.isna(val) else 0)
                for val in rs
            ])

        self.rsi = self.I(calculate_rsi, self.data.Close, self.rsi_length, name="RSI")
        self.rsi_ma = self.I(
            lambda x: pd.Series(x).rolling(self.rsi_ma_length).mean(),
            self.rsi,
            name="RSI_MA",
        )
        self.price_ma = self.I(
            lambda x: pd.Series(x).rolling(self.price_ma_length).mean(),
            self.data.Close,
            name="Price_MA",
        )

        self.bullish_block_armed = False
        self.bearish_block_armed = False
        self.bullish_block_body_top = None
        self.bearish_block_body_bottom = None

    def _detect_eb3(self):
        if len(self.data.Open) < 4:
            return False, False

        current_open = self.data.Open[-1]
        current_close = self.data.Close[-1]
        current_body_low = min(current_open, current_close)
        current_body_high = max(current_open, current_close)

        previous_body_lows = [
            min(self.data.Open[-i], self.data.Close[-i])
            for i in (2, 3, 4)
        ]
        previous_body_highs = [
            max(self.data.Open[-i], self.data.Close[-i])
            for i in (2, 3, 4)
        ]

        engulfs_three_bodies = (
            current_body_low <= min(previous_body_lows)
            and current_body_high >= max(previous_body_highs)
        )

        bullish = current_close > current_open and engulfs_three_bodies
        bearish = current_close < current_open and engulfs_three_bodies
        return bullish, bearish

    def next(self):
        bullish_eb3, bearish_eb3 = self._detect_eb3()
        current_close = self.data.Close[-1]

        if (
            self.bullish_block_armed
            and not bullish_eb3
            and self.bullish_block_body_top is not None
            and current_close <= self.bullish_block_body_top
        ):
            self.bullish_block_armed = False
            self.bullish_block_body_top = None

        if (
            self.bearish_block_armed
            and not bearish_eb3
            and self.bearish_block_body_bottom is not None
            and current_close >= self.bearish_block_body_bottom
        ):
            self.bearish_block_armed = False
            self.bearish_block_body_bottom = None

        if bullish_eb3:
            self.bullish_block_armed = True
            self.bullish_block_body_top = max(self.data.Open[-1], self.data.Close[-1])

        if bearish_eb3:
            self.bearish_block_armed = True
            self.bearish_block_body_bottom = min(self.data.Open[-1], self.data.Close[-1])

        if pd.isna(self.rsi[-1]) or pd.isna(self.rsi_ma[-1]) or pd.isna(self.price_ma[-1]):
            return

        if self.position:
            return

        long_confirmation = (
            current_close > self.price_ma[-1]
            and self.rsi[-1] > self.rsi_ma[-1]
        )
        short_confirmation = (
            current_close < self.price_ma[-1]
            and self.rsi[-1] < self.rsi_ma[-1]
        )

        if self.bullish_block_armed and long_confirmation:
            entry_price = current_close
            stop_loss = self.data.Low[-2]

            if stop_loss >= entry_price - (entry_price * 0.001):
                stop_loss = entry_price * 0.99

            risk = entry_price - stop_loss
            if risk > 0:
                take_profit = entry_price + (risk * self.risk_reward_ratio)
                self.buy(sl=stop_loss, tp=take_profit)
                self.bullish_block_armed = False
                self.bullish_block_body_top = None

        elif self.bearish_block_armed and short_confirmation:
            entry_price = current_close
            stop_loss = self.data.High[-2]

            if stop_loss <= entry_price + (entry_price * 0.001):
                stop_loss = entry_price * 1.01

            risk = stop_loss - entry_price
            if risk > 0:
                take_profit = entry_price - (risk * self.risk_reward_ratio)
                self.sell(sl=stop_loss, tp=take_profit)
                self.bearish_block_armed = False
                self.bearish_block_body_bottom = None


def load_one_year_1m() -> pd.DataFrame:
    start_date = pd.Timestamp("2025-03-23")
    end_date = pd.Timestamp("2026-03-23")
    frames = []
    files_used = []

    for path in sorted(DATA_DIR.glob("ohlcv_MGC_*.csv")):
        try:
            date_str = path.stem.replace("ohlcv_MGC_", "")
            day = pd.Timestamp(date_str)
        except Exception:
            continue
        if start_date <= day <= end_date:
            df = pd.read_csv(path)
            if df.empty:
                continue
            df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
            df = df.set_index("timestamp")
            frames.append(df[["open", "high", "low", "close", "volume"]])
            files_used.append(path.name)

    if not frames:
        raise RuntimeError("No MGC source files found for requested one-year window")

    data = pd.concat(frames).sort_index()
    data = data[~data.index.duplicated(keep="last")]
    data = data.rename(columns={
        "open": "Open",
        "high": "High",
        "low": "Low",
        "close": "Close",
        "volume": "Volume",
    }).dropna()

    (OUT_DIR / "source_files_used.txt").write_text("\n".join(files_used) + "\n", encoding="utf-8")
    return data


def to_3m(raw_1m: pd.DataFrame) -> pd.DataFrame:
    return raw_1m.resample("3min", label="left", closed="left").agg({
        "Open": "first",
        "High": "max",
        "Low": "min",
        "Close": "last",
        "Volume": "sum",
    }).dropna()


def window_metrics(label: str, data: pd.DataFrame) -> dict:
    bt = Backtest(
        data,
        Eb3Persistent3mStrategy,
        cash=100000,
        commission=0.002,
        exclusive_orders=True,
    )
    stats = bt.run()
    trades = stats["_trades"].copy()
    pnl = trades["PnL"] if len(trades) else pd.Series(dtype=float)

    result = {
        "label": label,
        "start": str(data.index.min()),
        "end": str(data.index.max()),
        "bars_3m": int(len(data)),
        "trades": int(len(trades)),
        "wins": int((pnl > 0).sum()),
        "losses": int((pnl < 0).sum()),
        "breakeven": int((pnl == 0).sum()),
        "win_rate_pct": float(stats["Win Rate [%]"]),
        "return_pct": float(stats["Return [%]"]),
        "max_drawdown_pct": float(stats["Max. Drawdown [%]"]),
        "profit_factor": float(stats["Profit Factor"]),
        "equity_final": float(stats["Equity Final [$]"]),
        "commissions": float(stats["Commissions [$]"]),
        "best_trade_pct": float(stats["Best Trade [%]"]),
        "worst_trade_pct": float(stats["Worst Trade [%]"]),
    }
    trades.to_csv(OUT_DIR / f"trades_{label}.csv", index=False)
    return result


def main():
    raw_1m = load_one_year_1m()
    data_3m = to_3m(raw_1m)

    # Freeze the exact 3-minute snapshot used by all three tests.
    snapshot_path = OUT_DIR / "mgc_3m_2025-03-23_2026-03-23.csv"
    data_3m.to_csv(snapshot_path)
    snapshot_sha = hashlib.sha256(snapshot_path.read_bytes()).hexdigest()

    windows = {
        "1y": pd.Timestamp("2025-03-23", tz="UTC"),
        "6m": pd.Timestamp("2025-09-23", tz="UTC"),
        "3m": pd.Timestamp("2025-12-23", tz="UTC"),
    }

    results = []
    for label, start in windows.items():
        subset = data_3m.loc[(data_3m.index >= start) & (data_3m.index <= SOURCE_END)].copy()
        if subset.empty:
            raise RuntimeError(f"No data for {label}")
        results.append(window_metrics(label, subset))

    payload = {
        "source_repo": SOURCE_REPO,
        "source_commit": SOURCE_COMMIT,
        "instrument": "MGC Micro Gold Futures",
        "source_declared": "Databento API / CME",
        "source_timezone": "UTC (verified from origin JSON ts_event Z)",
        "strategy": "M3 EB3 persistent 3m, no break-even",
        "commission_setting": 0.002,
        "cash": 100000,
        "snapshot_sha256": snapshot_sha,
        "raw_1m_rows": int(len(raw_1m)),
        "bars_3m_total": int(len(data_3m)),
        "snapshot_start": str(data_3m.index.min()),
        "snapshot_end": str(data_3m.index.max()),
        "results": results,
    }
    (OUT_DIR / "m3_mgc_long_windows.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = [
        "# M3 on MGC/Databento — 3m long windows",
        "",
        f"Source: `{SOURCE_REPO}` @ `{SOURCE_COMMIT}`",
        f"Snapshot SHA256: `{snapshot_sha}`",
        f"Raw 1m rows: {len(raw_1m):,}",
        f"3m bars: {len(data_3m):,}",
        f"Snapshot: {data_3m.index.min()} → {data_3m.index.max()}",
        "",
        "| Window | 3m bars | Trades | Wins | Losses | BE | Win rate | Return | Max DD | PF |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in results:
        lines.append(
            f"| {r['label']} | {r['bars_3m']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['breakeven']} | "
            f"{r['win_rate_pct']:.2f}% | {r['return_pct']:.2f}% | {r['max_drawdown_pct']:.2f}% | {r['profit_factor']:.3f} |"
        )
    lines += [
        "",
        "Notes:",
        "- Strategy logic is copied unchanged from M3; only the data source/window changed.",
        "- 3-minute bars are deterministically aggregated from the repository's 1-minute MGC files.",
        "- The source README documents a smart volume-based continuous rollover strategy.",
        "- P&L still uses the existing Backtesting.py commission=0.002 model for one-variable-at-a-time comparability; this is not yet a futures fee model.",
    ]
    report = "\n".join(lines) + "\n"
    (OUT_DIR / "m3_mgc_long_windows.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
