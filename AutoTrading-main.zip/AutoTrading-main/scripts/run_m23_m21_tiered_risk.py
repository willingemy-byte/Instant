from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

import run_m14_topstep_150k_risk300 as m14
import run_m17_eb3_noentry_10_17ct as m17
import run_m21_m20_full_mgc_history as m21

OUT = Path("artifacts")
OUT.mkdir(parents=True, exist_ok=True)

START_BALANCE = m14.START_BALANCE
MLL_DISTANCE = m14.MLL_DISTANCE
RISK_CAP = 900.0
TIERS = [0.20, 0.15, 0.10, 0.05]
RESET_HEADROOM = 4500.0
EPS = 1e-9


def evaluate_tiered(trades: pd.DataFrame, d1: pd.DataFrame) -> dict:
    if trades.empty:
        return {"survived": True, "ledger": pd.DataFrame(), "final_balance": START_BALANCE}

    t = trades.sort_values("entry_time").reset_index(drop=True).copy()
    t["session"] = t["entry_time"].map(m14.session_label)

    balance = START_BALANCE
    mll = START_BALANCE - MLL_DISTANCE
    tier_idx = 0
    current_session = None
    min_headroom = float("inf")
    min_headroom_time = None
    breach = None
    rows = []
    resets = 0

    for j, tr in t.iterrows():
        sess = tr["session"]
        if current_session is not None and sess != current_session:
            mll = min(START_BALANCE, max(mll, balance - MLL_DISTANCE))
        current_session = sess

        available = balance - mll
        if available <= 0:
            breach = {
                "trade_index": int(j),
                "time": str(tr["entry_time"]),
                "equity": float(balance),
                "mll": float(mll),
                "headroom": float(available),
                "reason": "no_headroom_at_entry",
            }
            break

        # User rule: once the full $4,500 headroom has been rebuilt, reset to 20%.
        # Before that, winners do not increase the tier.
        if available >= RESET_HEADROOM - EPS and tier_idx != 0:
            tier_idx = 0
            resets += 1

        fraction = TIERS[tier_idx]
        risk_dollars = min(RISK_CAP, fraction * available)

        entry = float(tr["entry"])
        risk_points = float(tr["risk"])
        side = int(tr["side"])
        et = pd.Timestamp(tr["entry_time"])
        xt = pd.Timestamp(tr["exit_time"])
        dollars_per_price = risk_dollars / risk_points
        mins = d1.loc[et:xt]
        local_min_headroom = float("inf")
        local_min_time = et

        for ts, bar in mins.iterrows():
            reason = str(tr["reason"])
            if ts == xt and reason in {"stop", "gap_stop", "both_stop_first", "topstep_1510_flat"}:
                worst_pnl = float(tr["R"]) * risk_dollars
            else:
                if side == 1:
                    worst_pnl = (float(bar.Low) - entry) * dollars_per_price
                else:
                    worst_pnl = (entry - float(bar.High)) * dollars_per_price
                if ts == xt:
                    worst_pnl = min(worst_pnl, float(tr["R"]) * risk_dollars)

            equity_worst = balance + worst_pnl
            headroom = equity_worst - mll
            if headroom < local_min_headroom:
                local_min_headroom = headroom
                local_min_time = ts
            if headroom < min_headroom:
                min_headroom = headroom
                min_headroom_time = ts
            if equity_worst <= mll and breach is None:
                breach = {
                    "trade_index": int(j),
                    "time": str(ts),
                    "equity": float(equity_worst),
                    "mll": float(mll),
                    "headroom": float(headroom),
                    "entry_time": str(et),
                    "risk_dollars": float(risk_dollars),
                    "tier_fraction": float(fraction),
                    "R_at_exit": float(tr["R"]),
                }
                break

        pnl = float(tr["R"]) * risk_dollars
        balance_before = balance
        tier_before = tier_idx
        if breach is None:
            balance += pnl

        # Step down one tier after any negative trade. BE and winners do not step up.
        if breach is None and float(tr["R"]) < -EPS:
            tier_idx = min(tier_idx + 1, len(TIERS) - 1)

        rows.append({
            "trade": int(j + 1),
            "entry_time": str(et),
            "exit_time": str(xt),
            "session": sess,
            "R": float(tr["R"]),
            "reason": str(tr["reason"]),
            "balance_before": float(balance_before),
            "mll_before_trade": float(mll),
            "available_headroom_before": float(available),
            "tier_before": int(tier_before),
            "risk_fraction": float(fraction),
            "risk_cap": RISK_CAP,
            "risk_dollars": float(risk_dollars),
            "pnl_dollars": float(pnl),
            "balance_after": float(balance),
            "tier_after": int(tier_idx),
            "min_headroom_trade": float(local_min_headroom),
            "min_headroom_time": str(local_min_time),
        })

        if breach is not None:
            break

    if breach is None and current_session is not None:
        mll = min(START_BALANCE, max(mll, balance - MLL_DISTANCE))

    ledger = pd.DataFrame(rows)
    rs = ledger["risk_dollars"] if not ledger.empty else pd.Series(dtype=float)
    return {
        "survived": breach is None,
        "trades": int(len(t)),
        "trades_processed": int(len(ledger)),
        "final_balance": float(balance),
        "net_profit": float(balance - START_BALANCE),
        "ending_mll": float(mll),
        "minimum_headroom": float(min_headroom),
        "minimum_headroom_time": str(min_headroom_time),
        "breach": breach,
        "resets_to_20pct": int(resets),
        "average_risk_dollars": float(rs.mean()) if len(rs) else 0.0,
        "median_risk_dollars": float(rs.median()) if len(rs) else 0.0,
        "minimum_risk_dollars": float(rs.min()) if len(rs) else 0.0,
        "maximum_risk_dollars": float(rs.max()) if len(rs) else 0.0,
        "trades_below_100_risk": int((rs < 100.0).sum()) if len(rs) else 0,
        "ledger": ledger,
    }


def annual_stats(trades: pd.DataFrame, ledger: pd.DataFrame) -> list[dict]:
    if trades.empty or ledger.empty:
        return []
    t = trades.sort_values("entry_time").reset_index(drop=True).copy()
    l = ledger.reset_index(drop=True).copy()
    n = min(len(t), len(l))
    t = t.iloc[:n].copy()
    l = l.iloc[:n].copy()
    t["entry_time"] = pd.to_datetime(t["entry_time"], utc=True)
    l["entry_time"] = pd.to_datetime(l["entry_time"], utc=True)
    t["year"] = t["entry_time"].dt.year
    l["year"] = l["entry_time"].dt.year
    out = []
    for year, g in t.groupby("year", sort=True):
        gl = l[l["year"] == year]
        r = g["R"].astype(float)
        wins = int((r > EPS).sum())
        losses = int((r < -EPS).sum())
        be = int((r.abs() <= EPS).sum())
        out.append({
            "year": int(year),
            "trades": int(len(g)),
            "wins": wins,
            "losses": losses,
            "breakeven": be,
            "win_rate_ex_be_pct": float(100 * wins / (wins + losses)) if wins + losses else 0.0,
            "raw_sum_R": float(r.sum()),
            "net_profit_dollars": float(gl["pnl_dollars"].sum()),
            "avg_risk_dollars": float(gl["risk_dollars"].mean()),
            "min_risk_dollars": float(gl["risk_dollars"].min()),
            "max_risk_dollars": float(gl["risk_dollars"].max()),
            "below_100": int((gl["risk_dollars"] < 100).sum()),
        })
    return out


def main():
    d1 = m21.load_full_1m()
    d5 = m21.b.make_5m(d1)
    trades = m17.simulate_m17(d1, d5)
    trades.to_csv(OUT / "m23_full_history_trades.csv", index=False)

    ev = evaluate_tiered(trades, d1)
    ledger = ev["ledger"]
    ledger.to_csv(OUT / "m23_full_history_ledger.csv", index=False)
    annual = annual_stats(trades, ledger)

    tier_counts = {}
    if not ledger.empty:
        for f, g in ledger.groupby("risk_fraction"):
            tier_counts[f"{100*f:.0f}%"] = int(len(g))

    payload = {
        "method": "offline research simulation only",
        "strategy": "M21/M17 trades unchanged over full pinned MGC history",
        "sizing_rule": {
            "start": "20% of current MLL headroom, capped at $900",
            "after_first_loss": "15% of current headroom",
            "after_second_consecutive_loss": "10% of current headroom",
            "after_third_or_later_loss": "5% of current headroom and stay there",
            "winner": "does not raise tier",
            "breakeven": "does not change tier",
            "reset": "only when available headroom before a new trade is at least $4,500; then reset to 20%, still capped at $900",
            "no_minimum_risk_floor": True,
        },
        "data_start": str(d1.index.min()),
        "data_end": str(d1.index.max()),
        "summary": {k: v for k, v in ev.items() if k != "ledger"},
        "tier_counts": tier_counts,
        "annual": annual,
        "caveats": [
            "continuous normalized sizing; integer MGC contract granularity not modeled",
            "commissions and slippage not modeled",
            "holiday early closes not modeled",
            "raw R is shown only as a strategy-quality statistic; dollar P&L uses the dynamic tiered risk for each trade",
        ],
    }
    (OUT / "m23_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    s = payload["summary"]
    lines = [
        "# M23 — Full-history M21 with tiered 20% -> 15% -> 10% -> 5% risk",
        "",
        f"Data: {payload['data_start']} -> {payload['data_end']}",
        "Strategy/trades unchanged from M21. Only position sizing changes.",
        "Loss steps down one tier. Winner/BE does not step up. Reset to 20% only after headroom is rebuilt to at least $4,500.",
        "No artificial $100 minimum risk floor.",
        "",
        "| Trades | Net $ | Final balance | Avg risk $ | Median risk $ | Min risk $ | Max risk $ | Trades risk < $100 | Resets to 20% | Min MLL headroom $ | Survived |",
        "|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|",
        f"| {s['trades_processed']} | {s['net_profit']:.0f} | {s['final_balance']:.0f} | {s['average_risk_dollars']:.0f} | {s['median_risk_dollars']:.0f} | {s['minimum_risk_dollars']:.2f} | {s['maximum_risk_dollars']:.0f} | {s['trades_below_100_risk']} | {s['resets_to_20pct']} | {s['minimum_headroom']:.0f} | {s['survived']} |",
        "",
        "## Tier usage",
        "",
    ]
    for k in ["20%", "15%", "10%", "5%"]:
        lines.append(f"- {k}: {tier_counts.get(k, 0)} trades")
    lines += [
        "",
        "## By calendar year",
        "",
        "| Year | Trades | WR ex-BE | Raw Sum R | Net $ dynamic | Avg risk $ | Min risk $ | Max risk $ | Risk < $100 |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in annual:
        lines.append(
            f"| {r['year']} | {r['trades']} | {r['win_rate_ex_be_pct']:.2f}% | {r['raw_sum_R']:.1f} | "
            f"{r['net_profit_dollars']:.0f} | {r['avg_risk_dollars']:.0f} | {r['min_risk_dollars']:.2f} | "
            f"{r['max_risk_dollars']:.0f} | {r['below_100']} |"
        )
    report = "\n".join(lines) + "\n"
    (OUT / "m23_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
