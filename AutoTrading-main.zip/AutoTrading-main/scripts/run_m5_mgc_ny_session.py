from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pandas as pd
from backtesting import Backtest, Strategy

SOURCE_COMMIT = "bf75ac4587e7995ceae64c3d696e076c37be12cc"
SOURCE_REPO = "domzack/mgc-ohlcv-data"
SOURCE_END = pd.Timestamp("2026-03-23 23:59:59", tz="UTC")
DATA_DIR = Path("external/mgc/data")
OUT_DIR = Path("artifacts")
OUT_DIR.mkdir(parents=True, exist_ok=True)
NY_TZ = "America/New_York"
BAR_MINUTES = 3


class Eb3Persistent3mNySessionStrategy(Strategy):
    rsi_length = 21
    rsi_ma_length = 50
    price_ma_length = 50
    risk_reward_ratio = 3.0

    def init(self):
        def calculate_rsi(close_prices, rsi_length):
            delta = pd.Series(close_prices).diff()
            gain = delta.mask(delta < 0, 0)
            loss = -delta.mask(delta > 0, 0)
            avg_gain = gain.ewm(com=rsi_length - 1, adjust=False).mean()
            avg_loss = loss.ewm(com=rsi_length - 1, adjust=False).mean()
            rs = avg_gain / avg_loss
            return pd.Series([
                100 - (100 / (1 + val)) if val != 0 and not pd.isna(val)
                else (100 if pd.isna(val) else 0)
                for val in rs
            ])

        self.rsi = self.I(calculate_rsi, self.data.Close, self.rsi_length, name="RSI")
        self.rsi_ma = self.I(lambda x: pd.Series(x).rolling(self.rsi_ma_length).mean(), self.rsi, name="RSI_MA")
        self.price_ma = self.I(lambda x: pd.Series(x).rolling(self.price_ma_length).mean(), self.data.Close, name="Price_MA")
        self.bullish_block_armed = False
        self.bearish_block_armed = False
        self.bullish_block_body_top = None
        self.bearish_block_body_bottom = None

    def _detect_eb3(self):
        if len(self.data.Open) < 4:
            return False, False
        current_open = self.data.Open[-1]
        current_close = self.data.Close[-1]
        current_body_low = min(current_open, current_close)
        current_body_high = max(current_open, current_close)
        previous_body_lows = [min(self.data.Open[-i], self.data.Close[-i]) for i in (2, 3, 4)]
        previous_body_highs = [max(self.data.Open[-i], self.data.Close[-i]) for i in (2, 3, 4)]
        engulf = current_body_low <= min(previous_body_lows) and current_body_high >= max(previous_body_highs)
        return current_close > current_open and engulf, current_close < current_open and engulf

    def _next_fill_inside_session(self):
        # Backtesting.py fills market orders on the next bar by default.
        # Gate the signal using the nominal next 3-minute timestamp so the actual
        # entry, not merely the signal, remains inside 08:00-12:00 New York.
        ts = pd.Timestamp(self.data.index[-1])
        if ts.tzinfo is None:
            ts = ts.tz_localize("UTC")
        fill_ny = (ts + pd.Timedelta(minutes=BAR_MINUTES)).tz_convert(NY_TZ)
        return fill_ny.weekday() < 5 and 8 <= fill_ny.hour < 12

    def next(self):
        bullish_eb3, bearish_eb3 = self._detect_eb3()
        current_close = self.data.Close[-1]

        if self.bullish_block_armed and not bullish_eb3 and self.bullish_block_body_top is not None and current_close <= self.bullish_block_body_top:
            self.bullish_block_armed = False
            self.bullish_block_body_top = None
        if self.bearish_block_armed and not bearish_eb3 and self.bearish_block_body_bottom is not None and current_close >= self.bearish_block_body_bottom:
            self.bearish_block_armed = False
            self.bearish_block_body_bottom = None

        if bullish_eb3:
            self.bullish_block_armed = True
            self.bullish_block_body_top = max(self.data.Open[-1], self.data.Close[-1])
        if bearish_eb3:
            self.bearish_block_armed = True
            self.bearish_block_body_bottom = min(self.data.Open[-1], self.data.Close[-1])

        if pd.isna(self.rsi[-1]) or pd.isna(self.rsi_ma[-1]) or pd.isna(self.price_ma[-1]):
            return
        if self.position:
            return
        if not self._next_fill_inside_session():
            return

        long_confirmation = current_close > self.price_ma[-1] and self.rsi[-1] > self.rsi_ma[-1]
        short_confirmation = current_close < self.price_ma[-1] and self.rsi[-1] < self.rsi_ma[-1]

        if self.bullish_block_armed and long_confirmation:
            entry_price = current_close
            stop_loss = self.data.Low[-2]
            if stop_loss >= entry_price - (entry_price * 0.001):
                stop_loss = entry_price * 0.99
            risk = entry_price - stop_loss
            if risk > 0:
                self.buy(sl=stop_loss, tp=entry_price + risk * self.risk_reward_ratio)
                self.bullish_block_armed = False
                self.bullish_block_body_top = None
        elif self.bearish_block_armed and short_confirmation:
            entry_price = current_close
            stop_loss = self.data.High[-2]
            if stop_loss <= entry_price + (entry_price * 0.001):
                stop_loss = entry_price * 1.01
            risk = stop_loss - entry_price
            if risk > 0:
                self.sell(sl=stop_loss, tp=entry_price - risk * self.risk_reward_ratio)
                self.bearish_block_armed = False
                self.bearish_block_body_bottom = None


def load_one_year_1m():
    start_date = pd.Timestamp("2025-03-23")
    end_date = pd.Timestamp("2026-03-23")
    frames = []
    files_used = []
    for path in sorted(DATA_DIR.glob("ohlcv_MGC_*.csv")):
        try:
            day = pd.Timestamp(path.stem.replace("ohlcv_MGC_", ""))
        except Exception:
            continue
        if start_date <= day <= end_date:
            df = pd.read_csv(path)
            if df.empty:
                continue
            df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
            df = df.set_index("timestamp")
            frames.append(df[["open", "high", "low", "close", "volume"]])
            files_used.append(path.name)
    if not frames:
        raise RuntimeError("No MGC source files")
    data = pd.concat(frames).sort_index()
    data = data[~data.index.duplicated(keep="last")]
    data = data.rename(columns={"open":"Open","high":"High","low":"Low","close":"Close","volume":"Volume"}).dropna()
    (OUT_DIR / "source_files_used.txt").write_text("\n".join(files_used) + "\n", encoding="utf-8")
    return data


def to_3m(raw):
    return raw.resample("3min", label="left", closed="left").agg({"Open":"first","High":"max","Low":"min","Close":"last","Volume":"sum"}).dropna()


def analyze_excursions(data, trades):
    out = trades.copy()
    mfe_tp = []
    mae_sl = []
    for _, t in out.iterrows():
        entry = float(t["EntryPrice"])
        sl = float(t["SL"]) if pd.notna(t["SL"]) else None
        tp = float(t["TP"]) if pd.notna(t["TP"]) else None
        side_long = int(t["Size"]) > 0
        bars = data.loc[(data.index >= pd.Timestamp(t["EntryTime"])) & (data.index <= pd.Timestamp(t["ExitTime"]))]
        if bars.empty or sl is None or tp is None:
            mfe_tp.append(float("nan")); mae_sl.append(float("nan")); continue
        if side_long:
            favorable = max(0.0, float(bars["High"].max()) - entry)
            adverse = max(0.0, entry - float(bars["Low"].min()))
            tp_dist = tp - entry; sl_dist = entry - sl
        else:
            favorable = max(0.0, entry - float(bars["Low"].min()))
            adverse = max(0.0, float(bars["High"].max()) - entry)
            tp_dist = entry - tp; sl_dist = sl - entry
        mfe_tp.append(min(100.0, 100.0 * favorable / tp_dist) if tp_dist > 0 else float("nan"))
        mae_sl.append(min(100.0, 100.0 * adverse / sl_dist) if sl_dist > 0 else float("nan"))
    out["MFE_TP_pct"] = mfe_tp
    out["MAE_SL_pct"] = mae_sl
    return out


def run_window(label, data):
    bt = Backtest(data, Eb3Persistent3mNySessionStrategy, cash=100000, commission=0.002, exclusive_orders=True)
    stats = bt.run()
    trades = stats["_trades"].copy()
    pnl = trades["PnL"] if len(trades) else pd.Series(dtype=float)
    invalid_count = 0
    if len(trades):
        entry_times = pd.to_datetime(trades["EntryTime"], utc=True).dt.tz_convert(NY_TZ)
        valid_mask = (entry_times.dt.weekday < 5) & (entry_times.dt.hour >= 8) & (entry_times.dt.hour < 12)
        invalid_count = int((~valid_mask).sum())
        session_ok = bool(valid_mask.all())
    else:
        session_ok = True
    enriched = analyze_excursions(data, trades) if len(trades) else trades
    enriched.to_csv(OUT_DIR / f"m5_trades_{label}.csv", index=False)
    losses = enriched[enriched["PnL"] < 0] if len(enriched) else enriched
    return {
        "label": label,
        "bars_3m": int(len(data)),
        "trades": int(len(trades)),
        "wins": int((pnl > 0).sum()),
        "losses": int((pnl < 0).sum()),
        "breakeven": int((pnl == 0).sum()),
        "win_rate_pct": float(stats["Win Rate [%]"]),
        "return_pct": float(stats["Return [%]"]),
        "max_drawdown_pct": float(stats["Max. Drawdown [%]"]),
        "profit_factor": float(stats["Profit Factor"]),
        "session_entries_valid": session_ok,
        "invalid_entry_count": invalid_count,
        "loss_mfe_tp_mean": float(losses["MFE_TP_pct"].mean()) if len(losses) else None,
        "loss_mfe_tp_median": float(losses["MFE_TP_pct"].median()) if len(losses) else None,
    }


def main():
    raw = load_one_year_1m()
    data3 = to_3m(raw)
    snap = OUT_DIR / "mgc_3m_2025-03-23_2026-03-23.csv"
    data3.to_csv(snap)
    sha = hashlib.sha256(snap.read_bytes()).hexdigest()
    windows = {"1y": pd.Timestamp("2025-03-23", tz="UTC"), "6m": pd.Timestamp("2025-09-23", tz="UTC"), "3m": pd.Timestamp("2025-12-23", tz="UTC")}
    results = []
    for label, start in windows.items():
        subset = data3.loc[(data3.index >= start) & (data3.index <= SOURCE_END)].copy()
        results.append(run_window(label, subset))
    if not all(r["session_entries_valid"] for r in results):
        raise RuntimeError(f"M5 session validation failed: {[(r['label'], r['invalid_entry_count']) for r in results]}")
    payload = {
        "source_repo": SOURCE_REPO,
        "source_commit": SOURCE_COMMIT,
        "snapshot_sha256": sha,
        "instrument": "MGC Micro Gold Futures",
        "strategy": "M5 = M3 no-BE + actual fills restricted to weekday NY 08:00-12:00",
        "entry_timezone": NY_TZ,
        "entry_window": "Monday-Friday, actual EntryTime 08:00 inclusive to 12:00 exclusive",
        "positions_may_exit_after_noon": True,
        "results": results,
    }
    (OUT_DIR / "m5_mgc_ny_session.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    lines = ["# M5 MGC 3m — New York opening session", "", f"Snapshot SHA256: `{sha}`", "", "| Window | Trades | Wins | Losses | WR | Return | Max DD | PF | Session valid | Loss MFE→TP mean |", "|---|---:|---:|---:|---:|---:|---:|---:|---|---:|"]
    for r in results:
        lines.append(f"| {r['label']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['win_rate_pct']:.2f}% | {r['return_pct']:.2f}% | {r['max_drawdown_pct']:.2f}% | {r['profit_factor']:.3f} | {r['session_entries_valid']} | {r['loss_mfe_tp_mean']:.2f}% |")
    lines += ["", "Notes:", "- No break-even.", "- Actual EntryTime is restricted Monday-Friday 08:00-12:00 America/New_York.", "- Because Backtesting.py fills market orders on the next bar, the signal gate anticipates the nominal next 3-minute fill timestamp.", "- Existing positions may remain open after 12:00 until normal TP/SL exit.", "- America/New_York timezone conversion handles DST.", "- Commission remains 0.002 for comparability with prior runs."]
    report = "\n".join(lines) + "\n"
    (OUT_DIR / "m5_mgc_ny_session.md").write_text(report, encoding="utf-8")
    print(report)

if __name__ == "__main__":
    main()
