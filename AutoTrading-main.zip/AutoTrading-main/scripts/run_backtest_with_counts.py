import runpy
import sys

if len(sys.argv) != 2:
    raise SystemExit("Usage: python scripts/run_backtest_with_counts.py <backtest_script.py>")

namespace = runpy.run_path(sys.argv[1])
stats = namespace.get("stats")
if stats is None:
    raise RuntimeError("Target backtest script did not expose a 'stats' object")

trades = stats["_trades"]
if "PnL" not in trades.columns:
    raise RuntimeError("Backtest trade table does not contain PnL")

wins = int((trades["PnL"] > 0).sum())
losses = int((trades["PnL"] < 0).sum())
breakeven = int((trades["PnL"] == 0).sum())
total = int(len(trades))

print("\n=== TRADE COUNTS ===")
print(f"Total trades: {total}")
print(f"Winning trades: {wins}")
print(f"Losing trades: {losses}")
print(f"Breakeven trades: {breakeven}")
print(f"Win rate [%]: {stats['Win Rate [%]']}")
print(f"Return [%]: {stats['Return [%]']}")
print(f"Max. Drawdown [%]: {stats['Max. Drawdown [%]']}")
print(f"Profit Factor: {stats['Profit Factor']}")
