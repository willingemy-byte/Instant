from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

import run_m10_trailing_initial_risk as b
import run_m14_topstep_150k_risk300 as m14
import run_m17_eb3_noentry_10_17ct as m17
import run_m20_m17_dynamic20_capped900 as m20
import run_m21_m20_full_mgc_history as m21
import run_m28_fib_358_mtf_exit as m28

OUT = Path("artifacts/m29_fib_358_trailing10_tp7")
OUT.mkdir(parents=True, exist_ok=True)

EPS = 1e-9


def finish_trade(pos: dict, ex: float, ts: pd.Timestamp, reason: str) -> dict:
    side = int(pos["side"])
    risk = float(pos["risk"])
    r = ((float(ex) - float(pos["entry"])) / risk) * side
    return {**pos, "exit": float(ex), "exit_time": ts, "reason": reason, "R": float(r)}


def process_interval(pos: dict | None, mins: pd.DataFrame) -> tuple[dict | None, dict | None]:
    """Process active rolling-10 stop + fixed 7R target + forced-flat intraminute.

    The active stop was computed only from already completed 5m candles before
    this minute interval. If stop and TP are both touched inside the same 1m
    bar, use the conservative stop-first convention.
    """
    if pos is None or mins.empty:
        return pos, None

    side = int(pos["side"])
    for ts, bar in mins.iterrows():
        if m14.force_flat_now(ts):
            return None, finish_trade(pos, float(bar.Open), ts, "topstep_1510_flat")

        stop = float(pos["active_stop"])
        tp = float(pos["tp"])
        o = float(bar.Open)
        h = float(bar.High)
        l = float(bar.Low)

        if side == 1:
            if o <= stop:
                return None, finish_trade(pos, o, ts, "gap_trailing10_stop")
            if o >= tp:
                return None, finish_trade(pos, o, ts, "gap_tp7")
            if l <= stop and h >= tp:
                return None, finish_trade(pos, stop, ts, "both_stop_first")
            if l <= stop:
                return None, finish_trade(pos, stop, ts, "trailing10_stop")
            if h >= tp:
                return None, finish_trade(pos, tp, ts, "tp7")
        else:
            if o >= stop:
                return None, finish_trade(pos, o, ts, "gap_trailing10_stop")
            if o <= tp:
                return None, finish_trade(pos, o, ts, "gap_tp7")
            if h >= stop and l <= tp:
                return None, finish_trade(pos, stop, ts, "both_stop_first")
            if h >= stop:
                return None, finish_trade(pos, stop, ts, "trailing10_stop")
            if l <= tp:
                return None, finish_trade(pos, tp, ts, "tp7")

    return pos, None


def raw_period_stats(trades: pd.DataFrame, freq: str) -> list[dict]:
    if trades.empty:
        return []
    t = trades.copy()
    et = pd.to_datetime(t["entry_time"], utc=True)
    if freq == "year":
        key = et.dt.year.astype(str)
    elif freq == "quarter":
        key = et.dt.to_period("Q").astype(str)
    else:
        raise ValueError(freq)
    t["period"] = key

    rows: list[dict] = []
    for period, g in t.groupby("period", sort=True):
        r = g["R"].astype(float)
        wins = int((r > EPS).sum())
        losses = int((r < -EPS).sum())
        be = int((r.abs() <= EPS).sum())
        rows.append({
            "period": str(period),
            "trades": int(len(g)),
            "wins": wins,
            "losses": losses,
            "breakeven": be,
            "win_rate_ex_be_pct": float(100 * wins / (wins + losses)) if wins + losses else 0.0,
            "avg_R": float(r.mean()),
            "sum_R": float(r.sum()),
            "longest_loss_streak": int(m21.longest_loss_streak(r)),
        })
    return rows


def simulate_m29(d1: pd.DataFrame, d5: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    h1 = m28.completed_h1_fib_mas(d1)
    m5 = m28.five_minute_fib_mas(d5)
    low10 = d5["Low"].rolling(10, min_periods=10).min()
    high10 = d5["High"].rolling(10, min_periods=10).max()

    idx5 = d5.index
    one_ns = pd.Timedelta(nanoseconds=1)
    pos = None
    rec: list[dict] = []

    prev_eligible_long = False
    prev_eligible_short = False
    long_armed = False
    short_armed = False

    counters = {
        "long_setups_formed": 0,
        "short_setups_formed": 0,
        "accepted_long_entries": 0,
        "accepted_short_entries": 0,
        "blocked_by_entry_hours": 0,
        "invalid_10bar_stop": 0,
        "stop_ratchets": 0,
    }

    for i in range(len(d5)):
        close_time = idx5[i] + pd.Timedelta(minutes=5)
        prev_close = idx5[i] if i == 0 else idx5[i - 1] + pd.Timedelta(minutes=5)

        # First, simulate the interval using the stop known before this 5m close.
        if pos is not None:
            pos, done = process_interval(pos, d1.loc[prev_close:close_time - one_ns])
            if done is not None:
                rec.append(done)

        row5 = m5.iloc[i]
        vals5 = [row5.get(f"sma{n}_5m", np.nan) for n in (3, 5, 8)]
        valid5 = all(pd.notna(v) and np.isfinite(float(v)) for v in vals5)
        if not valid5:
            prev_eligible_long = prev_eligible_short = False
            long_armed = short_armed = False
            continue
        sma3_5, sma5_5, sma8_5 = map(float, vals5)

        hist = h1.loc[:close_time]
        if hist.empty:
            continue
        hr = hist.iloc[-1]
        close_h1 = float(hr["close_h1"])
        sma3_h1 = float(hr["sma3_h1"])
        sma5_h1 = float(hr["sma5_h1"])
        sma8_h1 = float(hr["sma8_h1"])
        sma200_h1 = float(hr["sma200_h1"])

        long_regime = close_h1 > sma200_h1 and sma3_h1 > sma5_h1 > sma8_h1 > sma200_h1
        short_regime = close_h1 < sma200_h1 and sma3_h1 < sma5_h1 < sma8_h1 < sma200_h1
        long_5m = sma3_5 > sma5_5 and sma3_5 > sma8_5
        short_5m = sma3_5 < sma5_5 and sma3_5 < sma8_5
        eligible_long = long_regime and long_5m
        eligible_short = short_regime and short_5m

        if eligible_long and not prev_eligible_long:
            long_armed = True
            counters["long_setups_formed"] += 1
        elif not eligible_long:
            long_armed = False

        if eligible_short and not prev_eligible_short:
            short_armed = True
            counters["short_setups_formed"] += 1
        elif not eligible_short:
            short_armed = False

        prev_eligible_long = eligible_long
        prev_eligible_short = eligible_short

        # User's primary logical exit: 3/8 relation flips on a completed 5m close.
        if pos is not None:
            side = int(pos["side"])
            if side == 1 and sma3_5 < sma8_5:
                rec.append(finish_trade(pos, float(d5.Close.iloc[i]), close_time, "sma3_below_sma8"))
                pos = None
            elif side == -1 and sma3_5 > sma8_5:
                rec.append(finish_trade(pos, float(d5.Close.iloc[i]), close_time, "sma3_above_sma8"))
                pos = None

        # If still open, update the structural stop for future minutes only.
        if pos is not None:
            side = int(pos["side"])
            old = float(pos["active_stop"])
            if side == 1 and pd.notna(low10.iloc[i]):
                new = max(old, float(low10.iloc[i]))
                if new > old + EPS:
                    counters["stop_ratchets"] += 1
                pos["active_stop"] = new
            elif side == -1 and pd.notna(high10.iloc[i]):
                new = min(old, float(high10.iloc[i]))
                if new < old - EPS:
                    counters["stop_ratchets"] += 1
                pos["active_stop"] = new

        if pos is not None:
            continue

        if not m17.entry_allowed_m17(close_time):
            if long_armed or short_armed:
                counters["blocked_by_entry_hours"] += 1
            continue

        if pd.isna(low10.iloc[i]) or pd.isna(high10.iloc[i]):
            continue

        entry = float(d5.Close.iloc[i])
        if long_armed and eligible_long:
            sl = float(low10.iloc[i])
            risk = entry - sl
            if risk <= 0:
                counters["invalid_10bar_stop"] += 1
                continue
            pos = {
                "side": 1,
                "entry": entry,
                "entry_time": close_time,
                "risk": risk,
                "initial_stop": sl,
                "active_stop": sl,
                "tp": entry + 7.0 * risk,
                "trigger_time": idx5[i],
                "sma3_5m": sma3_5,
                "sma5_5m": sma5_5,
                "sma8_5m": sma8_5,
                "close_h1": close_h1,
                "sma3_h1": sma3_h1,
                "sma5_h1": sma5_h1,
                "sma8_h1": sma8_h1,
                "sma200_h1": sma200_h1,
            }
            long_armed = False
            counters["accepted_long_entries"] += 1

        elif short_armed and eligible_short:
            sl = float(high10.iloc[i])
            risk = sl - entry
            if risk <= 0:
                counters["invalid_10bar_stop"] += 1
                continue
            pos = {
                "side": -1,
                "entry": entry,
                "entry_time": close_time,
                "risk": risk,
                "initial_stop": sl,
                "active_stop": sl,
                "tp": entry - 7.0 * risk,
                "trigger_time": idx5[i],
                "sma3_5m": sma3_5,
                "sma5_5m": sma5_5,
                "sma8_5m": sma8_5,
                "close_h1": close_h1,
                "sma3_h1": sma3_h1,
                "sma5_h1": sma5_h1,
                "sma8_h1": sma8_h1,
                "sma200_h1": sma200_h1,
            }
            short_armed = False
            counters["accepted_short_entries"] += 1

    if pos is not None:
        end_ts = idx5[-1] + pd.Timedelta(minutes=5)
        rec.append(finish_trade(pos, float(d5.Close.iloc[-1]), end_ts, "data_end"))

    return pd.DataFrame(rec), counters


def main() -> None:
    d1 = m21.load_full_1m()
    d5 = b.make_5m(d1)
    data_start = str(d1.index.min())
    data_end = str(d1.index.max())
    elapsed_years = float((d1.index.max() - d1.index.min()) / pd.Timedelta(days=365.2425))

    trades, counters = simulate_m29(d1, d5)
    trades.to_csv(OUT / "m29_full_history_trades.csv", index=False)

    ev = m20.evaluate_dynamic20_capped900(trades, d1)
    ledger = ev["ledger"].copy()
    ledger.to_csv(OUT / "m29_full_history_ledger.csv", index=False)

    summary = m20.summarize(trades, ev)
    summary["longest_loss_streak"] = m21.longest_loss_streak(trades["R"] if not trades.empty else pd.Series(dtype=float))
    annual_raw = raw_period_stats(trades, "year")
    quarterly_raw = raw_period_stats(trades, "quarter")
    exits = trades["reason"].value_counts().to_dict() if not trades.empty else {}

    payload = {
        "method": "offline research simulation only",
        "strategy": "M29 Fibonacci SMA 3/5/8 MTF + rolling 10x5m wick stop + fixed TP7",
        "hourly_long": "completed H1 close>SMA200 and SMA3>SMA5>SMA8>SMA200",
        "hourly_short": "completed H1 close<SMA200 and SMA3<SMA5<SMA8<SMA200",
        "entry_long_5m": "first combined-valid 5m close with SMA3>SMA5 and SMA3>SMA8",
        "entry_short_5m": "first combined-valid 5m close with SMA3<SMA5 and SMA3<SMA8",
        "initial_stop": "long lowest low / short highest high of last 10 completed 5m candles including signal candle",
        "trailing_stop": "rolling 10-bar wick extreme, ratchet only, updated after each completed 5m bar for future minutes",
        "tp": "fixed 7R from initial 10-bar stop distance",
        "ma_exit_long": "first completed 5m close with SMA3<SMA8",
        "ma_exit_short": "first completed 5m close with SMA3>SMA8",
        "entry_hours": "M17 no-entry 10:00-17:00 CT",
        "forced_flat": "15:10 CT",
        "sizing": "M20 dynamic 20% of realized MLL headroom capped at $900",
        "data_start": data_start,
        "data_end": data_end,
        "elapsed_years": elapsed_years,
        "counters": counters,
        "exit_reasons": exits,
        "summary": summary,
        "annual_raw_all_trades": annual_raw,
        "quarterly_raw_all_trades": quarterly_raw,
    }
    (OUT / "m29_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    s = summary
    lines = [
        "# M29 — Fibonacci 3/5/8 + rolling 10-bar stop + TP7",
        "",
        f"Data: {data_start} -> {data_end} (~{elapsed_years:.2f} years)",
        "",
        "Exit priority: active 10-bar stop / TP7 intraminute, SMA3-vs-SMA8 at 5m close, or 15:10 CT forced-flat.",
        "10-bar stop only ratchets favorably and is updated after a bar closes, never using future data.",
        "",
        "| Trades | W | L | BE | WR ex-BE | Avg R | Sum R | Net $ dynamic | Final balance | Avg risk $ | Min risk $ | Max risk $ | Min MLL headroom $ | Loss streak | Survived |",
        "|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|",
        f"| {s['trades']} | {s['wins']} | {s['losses']} | {s['breakeven']} | {s['win_rate_ex_be_pct']:.2f}% | {s['avg_R']:.3f} | {s.get('sum_R', 0):.1f} | {s['net_profit']:.0f} | {s['final_balance']:.0f} | {s['average_risk_dollars']:.0f} | {s['minimum_risk_dollars']:.2f} | {s['maximum_risk_dollars']:.0f} | {s['minimum_mll_headroom']:.2f} | {s['longest_loss_streak']} | {s['topstep_survived']} |",
        "",
        "## Exit reasons",
        "",
    ]
    for k, v in sorted(exits.items(), key=lambda kv: (-kv[1], kv[0])):
        lines.append(f"- {k}: {v}")
    lines += [
        "",
        "## Raw performance by calendar year (all trades, independent of MLL path)",
        "",
        "| Year | Trades | W | L | BE | WR ex-BE | Avg R | Sum R | Loss streak |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in annual_raw:
        lines.append(
            f"| {r['period']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['breakeven']} | "
            f"{r['win_rate_ex_be_pct']:.2f}% | {r['avg_R']:.3f} | {r['sum_R']:.1f} | {r['longest_loss_streak']} |"
        )

    report = "\n".join(lines) + "\n"
    (OUT / "m29_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
