from __future__ import annotations

from pathlib import Path
import requests

OUT = Path("artifacts")
OUT.mkdir(parents=True, exist_ok=True)
OUTFILE = OUT / "skilldb_search.txt"

SEARCHES = ["data", "time series", "research", "python", "finance", "api", "database"]
WEIGHTS = {
    "data": 5,
    "time": 2,
    "series": 4,
    "quality": 5,
    "research": 4,
    "python": 3,
    "finance": 5,
    "financial": 5,
    "market": 5,
    "database": 3,
    "api": 2,
    "engineering": 3,
    "analytics": 3,
    "quant": 4,
    "github": 3,
    "validation": 4,
}


def score(skill: dict) -> int:
    text = " ".join(
        str(skill.get(k) or "")
        for k in ("name", "title", "description", "category", "pack")
    ).lower()
    return sum(weight for token, weight in WEIGHTS.items() if token in text)


def main():
    seen = {}
    errors = []
    for query in SEARCHES:
        try:
            r = requests.get(
                "https://skilldb.dev/api/v1/skills",
                params={"search": query},
                timeout=25,
            )
            r.raise_for_status()
            payload = r.json()
            for skill in payload.get("skills", []):
                sid = skill.get("id") or f"{skill.get('pack')}/{skill.get('name')}"
                if sid:
                    seen[sid] = skill
        except Exception as exc:
            errors.append(f"{query}: {exc}")

    ranked = sorted(
        ((score(skill), sid, skill) for sid, skill in seen.items()),
        key=lambda row: (row[0], row[1]),
        reverse=True,
    )

    with OUTFILE.open("a", encoding="utf-8") as f:
        f.write("\n=== SkillDB API task-aligned recommendations ===\n")
        f.write("Task: reliable historical gold-futures data discovery, provenance, validation and GitHub/MCP research.\n")
        if errors:
            f.write("API warnings: " + " | ".join(errors) + "\n")
        if not ranked:
            f.write("No API recommendations found.\n")
            return
        for idx, (points, sid, skill) in enumerate(ranked[:15], 1):
            title = skill.get("title") or skill.get("name") or sid
            category = skill.get("category") or "unknown"
            pack = skill.get("pack") or "unknown"
            desc = (skill.get("description") or "").replace("\n", " ").strip()
            f.write(f"{idx:02d}. score={points:02d} | {sid} | {title} | {category} | pack={pack}")
            if desc:
                f.write(f" | {desc[:220]}")
            f.write("\n")


if __name__ == "__main__":
    main()
