from __future__ import annotations
import hashlib, json
from pathlib import Path
import numpy as np, pandas as pd

DATA=Path('external/mgc5/ohlcv_MGC_5m_continuous.csv'); OUT=Path('artifacts'); OUT.mkdir(parents=True,exist_ok=True)
NY='America/New_York'; END=pd.Timestamp('2026-03-23 23:59:59',tz='UTC')
STARTS={'1y':pd.Timestamp('2025-03-23',tz='UTC'),'6m':pd.Timestamp('2025-09-23',tz='UTC'),'3m':pd.Timestamp('2025-12-23',tz='UTC')}

def rsi(s,n=21):
    d=s.diff(); g=d.mask(d<0,0); l=-d.mask(d>0,0); ag=g.ewm(com=n-1,adjust=False).mean(); al=l.ewm(com=n-1,adjust=False).mean(); x=100-(100/(1+ag/al)); return x.where(al!=0,100.0)

def load():
    d=pd.read_csv(DATA); d['timestamp']=pd.to_datetime(d.timestamp,utc=True); d=d.set_index('timestamp').sort_index(); d=d.rename(columns={'open':'Open','high':'High','low':'Low','close':'Close','volume':'Volume'})[['Open','High','Low','Close','Volume']].dropna()
    d['RSI5']=rsi(d.Close); d['RSI5_MA50']=d.RSI5.rolling(50).mean(); d['PRICE_MA50']=d.Close.rolling(50).mean()
    h=d.resample('1h',label='left',closed='left').agg({'Open':'first','High':'max','Low':'min','Close':'last','Volume':'sum'}).dropna(); h['RSI1H']=rsi(h.Close); h['RSI1H_MA50']=h.RSI1H.rolling(50).mean(); a=h[['RSI1H','RSI1H_MA50']].copy(); a.index+=pd.Timedelta(hours=1); a=a.reindex(d.index,method='ffill'); d['RSI1H']=a.RSI1H; d['RSI1H_MA50']=a.RSI1H_MA50
    return d.loc[(d.index>=STARTS['1y'])&(d.index<=END)].copy()

def simulate(d,session):
    O=d.Open.to_numpy(float); H=d.High.to_numpy(float); L=d.Low.to_numpy(float); C=d.Close.to_numpy(float); r5=d.RSI5.to_numpy(float); rm=d.RSI5_MA50.to_numpy(float); pm=d.PRICE_MA50.to_numpy(float); rh=d.RSI1H.to_numpy(float); rhm=d.RSI1H_MA50.to_numpy(float); idx=d.index; n=len(d)
    if session:
        z=idx.tz_convert(NY); valid=np.array([(x.weekday()<5 and 8<=x.hour<12) for x in z],dtype=bool)
    else: valid=np.ones(n,dtype=bool)
    bull=bear=False; bull_top=bear_bottom=np.nan; pos=None; pending=None; rec=[]
    for i in range(3,n):
        if pending is not None and pos is None:
            pos=pending; pos['entry']=O[i]; pos['entry_time']=idx[i]; pending=None
        if pos is not None:
            side=pos['side']; sl=pos['sl']; tp=pos['tp']; ex=None; why=None
            if side==1:
                if O[i]<=sl: ex=O[i]; why='gap_sl'
                elif O[i]>=tp: ex=O[i]; why='gap_tp'
                elif L[i]<=sl and H[i]>=tp: ex=sl; why='both_stop_first'
                elif L[i]<=sl: ex=sl; why='sl'
                elif H[i]>=tp: ex=tp; why='tp'
            else:
                if O[i]>=sl: ex=O[i]; why='gap_sl'
                elif O[i]<=tp: ex=O[i]; why='gap_tp'
                elif H[i]>=sl and L[i]<=tp: ex=sl; why='both_stop_first'
                elif H[i]>=sl: ex=sl; why='sl'
                elif L[i]<=tp: ex=tp; why='tp'
            if ex is not None:
                gross=(ex/pos['entry']-1)*side; net=gross-0.004; rec.append({**pos,'exit':ex,'exit_time':idx[i],'reason':why,'gross_ret':gross,'net_ret':net}); pos=None
        blo=min(O[i],C[i]); bhi=max(O[i],C[i]); pl=[min(O[i-j],C[i-j]) for j in (1,2,3)]; ph=[max(O[i-j],C[i-j]) for j in (1,2,3)]; engulf=blo<=min(pl) and bhi>=max(ph); be=C[i]>O[i] and engulf; se=C[i]<O[i] and engulf
        if bull and not be and C[i]<=bull_top: bull=False; bull_top=np.nan
        if bear and not se and C[i]>=bear_bottom: bear=False; bear_bottom=np.nan
        if be: bull=True; bull_top=bhi
        if se: bear=True; bear_bottom=blo
        if pos is not None or pending is not None or i+1>=n: continue
        if not np.isfinite([r5[i],rm[i],pm[i],rh[i],rhm[i]]).all(): continue
        if session and not valid[i+1]: continue
        long_ok=C[i]>pm[i] and r5[i]>rm[i] and rh[i]>rhm[i]; short_ok=C[i]<pm[i] and r5[i]<rm[i] and rh[i]<rhm[i]
        if bull and long_ok:
            sl=L[i-1]; sl=C[i]*0.99 if sl>=C[i]-C[i]*0.001 else sl; risk=C[i]-sl
            if risk>0: pending={'side':1,'signal_time':idx[i],'ref':C[i],'sl':sl,'tp':C[i]+3*risk}; bull=False; bull_top=np.nan
        elif bear and short_ok:
            sl=H[i-1]; sl=C[i]*1.01 if sl<=C[i]+C[i]*0.001 else sl; risk=sl-C[i]
            if risk>0: pending={'side':-1,'signal_time':idx[i],'ref':C[i],'sl':sl,'tp':C[i]-3*risk}; bear=False; bear_bottom=np.nan
    return pd.DataFrame(rec)

def metric(t):
    if t.empty:return {'trades':0,'wins':0,'losses':0,'win_rate_pct':0,'return_pct':0,'max_drawdown_pct':0,'profit_factor':None}
    win=t.net_ret>0; eq=(1+t.net_ret).cumprod(); dd=(eq/eq.cummax()-1).min()*100; gp=t.loc[win,'net_ret'].sum(); gl=-t.loc[~win,'net_ret'].sum(); return {'trades':len(t),'wins':int(win.sum()),'losses':int((~win).sum()),'win_rate_pct':100*win.mean(),'return_pct':100*(eq.iloc[-1]-1),'max_drawdown_pct':dd,'profit_factor':float(gp/gl) if gl>0 else None}

def main():
    d=load(); snap=OUT/'m6_mgc_5m_htf_snapshot.csv'; d.to_csv(snap); sha=hashlib.sha256(snap.read_bytes()).hexdigest(); results=[]
    for mode,sess in [('ny_8_12',True),('no_session_filter',False)]:
        for w,st in STARTS.items():
            x=d.loc[d.index>=st]; t=simulate(x,sess); t.to_csv(OUT/f'm6_{mode}_{w}_trades.csv',index=False); m=metric(t); m.update(mode=mode,window=w); results.append(m)
    p={'method':'offline research replay only','instrument':'MGC','timeframe':'5m','htf':'RSI21 1h vs SMA50; completed hourly bars only','snapshot_sha256':sha,'results':results}; (OUT/'m6_results.json').write_text(json.dumps(p,indent=2))
    lines=['# M6 5m + 1h RSI filter','',f'Snapshot SHA256: `{sha}`','', '| Mode | Window | Trades | Wins | Losses | WR | Return* | Max DD* | PF* |','|---|---|---:|---:|---:|---:|---:|---:|---:|']
    for r in results: lines.append(f"| {r['mode']} | {r['window']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['win_rate_pct']:.2f}% | {r['return_pct']:.2f}% | {r['max_drawdown_pct']:.2f}% | {r['profit_factor'] if r['profit_factor'] is not None else 'n/a'} |")
    lines+=['','*Return/DD/PF use an offline replay with a 0.4% round-trip cost approximation; WR and trade counts are the primary comparison.','- No break-even.','- Hourly RSI is exposed only after the 1h candle has fully closed.','- ny_8_12 restricts hypothetical fills to Monday-Friday 08:00-12:00 America/New_York.','- no_session_filter has no strategic time gate.']; report='\n'.join(lines)+'\n'; (OUT/'m6_report.md').write_text(report); print(report)
if __name__=='__main__':main()
