#!/usr/bin/env python3
"""Operational watchdog for AutoTrading PRICE ACTION V1.

This module watches execution/progress/integrity only. It never changes Price
Action scientific rules, strategy parameters, strategy code, or the reserved
Site branch. Recoveries are signalled through repository_dispatch so a bounded
orchestrator can resume existing work without deleting validated artifacts.
"""
from __future__ import annotations

import json
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable

ACTIVE_STATUSES = {"queued", "in_progress", "waiting", "requested", "pending"}
QUEUE_STATUSES = {"queued", "waiting", "requested", "pending"}
DEFAULT_TIMEFRAMES = ("1W", "1D", "4H", "2H", "1H", "15m", "5m", "3m", "1m", "tick")
ACTIONABLE = {
    "FAILED",
    "STALLED_QUEUE",
    "STALLED_RUN",
    "STALLED_NO_RUN",
    "STALLED_NO_WORKFLOW",
    "INTEGRITY_ERROR",
    "COMPLETE",
}


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def parse_dt(value: str | None) -> datetime | None:
    if not value:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def github_request(method: str, url: str, token: str, payload: dict[str, Any] | None = None, *, allow_404: bool = False) -> Any:
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {token}",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "AutoTrading-Price-Action-Watchdog",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=25) as response:
            raw = response.read()
            return json.loads(raw) if raw else None
    except urllib.error.HTTPError as exc:
        if allow_404 and exc.code == 404:
            return None
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"GitHub API {method} {url} -> HTTP {exc.code}: {body[:1000]}") from exc


@dataclass(frozen=True)
class WorkflowRun:
    run_id: int
    name: str
    path: str
    status: str
    conclusion: str | None
    created_at: datetime
    updated_at: datetime
    head_sha: str | None
    html_url: str | None


@dataclass(frozen=True)
class IntegrityReport:
    current_exists: bool
    site_exists: bool
    manifests: tuple[str, ...]
    checksum_files: tuple[str, ...]
    checkpoints: tuple[str, ...]
    completed_timeframes: tuple[str, ...]
    missing_timeframes: tuple[str, ...]
    mismatches: tuple[str, ...]
    scientific_generated_at: datetime | None
    site_generated_at: datetime | None

    @property
    def errors(self) -> tuple[str, ...]:
        errors: list[str] = []
        if not self.current_exists:
            errors.append("current artifact root missing")
        if not self.site_exists:
            errors.append("site-ready root missing")
        if self.current_exists and not self.manifests:
            errors.append("manifest missing")
        if self.current_exists and not self.checksum_files:
            errors.append("hash/checksum evidence missing")
        if self.current_exists and not self.checkpoints:
            errors.append("checkpoint evidence missing")
        if self.current_exists and self.missing_timeframes:
            errors.append("incomplete timeframes: " + ", ".join(self.missing_timeframes))
        errors.extend(self.mismatches)
        return tuple(errors)


@dataclass(frozen=True)
class WatchState:
    code: str
    run: WorkflowRun | None
    branch_sha: str | None
    branch_updated_at: datetime | None
    workflow_seen: bool
    integrity: IntegrityReport

    @property
    def actionable(self) -> bool:
        return self.code in ACTIONABLE


def load_registry(path: str, project_id: str) -> dict[str, Any]:
    with open(path, "r", encoding="utf-8") as fh:
        payload = json.load(fh)
    for project in payload.get("projects", []):
        if project.get("id") == project_id:
            return dict(project)
    raise KeyError(f"watchdog registry project not found: {project_id}")


def branch_snapshot(api: str, repo: str, token: str, branch: str) -> tuple[str | None, datetime | None, str | None]:
    branch_q = urllib.parse.quote(branch, safe="")
    payload = github_request("GET", f"{api}/repos/{repo}/branches/{branch_q}", token)
    commit = (payload or {}).get("commit") or {}
    nested = commit.get("commit") or {}
    committer = nested.get("committer") or {}
    author = nested.get("author") or {}
    tree = nested.get("tree") or {}
    return commit.get("sha"), parse_dt(committer.get("date") or author.get("date")), tree.get("sha")


def latest_project_run(api: str, repo: str, token: str, branch: str, workflow_name: str, workflow_path: str) -> tuple[WorkflowRun | None, bool]:
    branch_q = urllib.parse.quote(branch, safe="")
    payload = github_request("GET", f"{api}/repos/{repo}/actions/runs?branch={branch_q}&per_page=100", token)
    runs = payload.get("workflow_runs", []) if isinstance(payload, dict) else []
    wanted_path = workflow_path if workflow_path.startswith(".github/workflows/") else f".github/workflows/{workflow_path}"
    matches = []
    for raw in runs:
        name = str(raw.get("name") or "")
        path = str(raw.get("path") or "")
        if name == workflow_name or path == wanted_path or path.endswith("/" + workflow_path):
            matches.append(raw)
    if not matches:
        return None, False
    raw = matches[0]
    created = parse_dt(raw.get("created_at"))
    updated = parse_dt(raw.get("updated_at")) or created
    if created is None or updated is None:
        raise RuntimeError("Price Action workflow run is missing timestamps")
    return (
        WorkflowRun(
            run_id=int(raw["id"]),
            name=str(raw.get("name") or ""),
            path=str(raw.get("path") or ""),
            status=str(raw.get("status") or ""),
            conclusion=(str(raw["conclusion"]) if raw.get("conclusion") is not None else None),
            created_at=created,
            updated_at=updated,
            head_sha=raw.get("head_sha"),
            html_url=raw.get("html_url"),
        ),
        True,
    )


def tree_paths(api: str, repo: str, token: str, tree_sha: str | None) -> tuple[str, ...]:
    if not tree_sha:
        return ()
    payload = github_request("GET", f"{api}/repos/{repo}/git/trees/{tree_sha}?recursive=1", token)
    return tuple(str(item.get("path") or "") for item in (payload or {}).get("tree", []) if item.get("path"))


def _path_under(paths: Iterable[str], root: str) -> tuple[str, ...]:
    root = root.rstrip("/")
    prefix = root + "/"
    return tuple(p for p in paths if p == root or p.startswith(prefix))


def timeframe_progress(paths: Iterable[str], expected: Iterable[str]) -> tuple[tuple[str, ...], tuple[str, ...]]:
    lowered_parts: list[set[str]] = []
    for path in paths:
        parts = set(re.split(r"[/_.\-=]+", path.lower()))
        lowered_parts.append(parts)
    completed: list[str] = []
    for timeframe in expected:
        token = timeframe.lower()
        if any(token in parts for parts in lowered_parts):
            completed.append(timeframe)
    missing = [tf for tf in expected if tf not in completed]
    return tuple(completed), tuple(missing)


def _is_manifest(path: str) -> bool:
    name = path.rsplit("/", 1)[-1].lower()
    return name.endswith(".json") and "manifest" in name


def _is_checksum(path: str) -> bool:
    name = path.rsplit("/", 1)[-1].lower()
    return any(token in name for token in ("checksum", "sha256", "hashes", "hash_manifest"))


def _is_checkpoint(path: str) -> bool:
    return "checkpoint" in path.lower()


def fetch_json_file(api: str, repo: str, token: str, branch: str, path: str) -> dict[str, Any] | None:
    path_q = urllib.parse.quote(path, safe="/")
    branch_q = urllib.parse.quote(branch, safe="")
    payload = github_request("GET", f"{api}/repos/{repo}/contents/{path_q}?ref={branch_q}", token, allow_404=True)
    if not isinstance(payload, dict) or payload.get("type") != "file":
        return None
    import base64

    encoded = payload.get("content")
    if not encoded:
        return None
    try:
        raw = base64.b64decode(str(encoded)).decode("utf-8")
        value = json.loads(raw)
        return value if isinstance(value, dict) else None
    except Exception:
        return None


def _find_scalar(obj: Any, names: set[str]) -> Any:
    if isinstance(obj, dict):
        for key, value in obj.items():
            if str(key).lower() in names and not isinstance(value, (dict, list)):
                return value
        for value in obj.values():
            found = _find_scalar(value, names)
            if found is not None:
                return found
    elif isinstance(obj, list):
        for value in obj:
            found = _find_scalar(value, names)
            if found is not None:
                return found
    return None


def _manifest_timestamp(manifest: dict[str, Any] | None) -> datetime | None:
    if not manifest:
        return None
    value = _find_scalar(manifest, {"generated_at", "created_at", "updated_at"})
    return parse_dt(str(value)) if value else None


def compare_manifests(scientific: dict[str, Any] | None, site: dict[str, Any] | None) -> tuple[str, ...]:
    if not scientific or not site:
        return ()
    mismatches: list[str] = []
    keys = {
        "dataset_id": {"dataset_id"},
        "dataset_hash": {"dataset_hash", "data_hash"},
        "code_hash": {"code_hash", "git_sha", "commit_sha"},
        "schema_version": {"schema_version"},
    }
    for label, aliases in keys.items():
        left = _find_scalar(scientific, aliases)
        right = _find_scalar(site, aliases)
        if left is not None and right is not None and str(left) != str(right):
            mismatches.append(f"scientific/site {label} mismatch: {left!r} != {right!r}")
    sci_time = _manifest_timestamp(scientific)
    site_time = _manifest_timestamp(site)
    if sci_time and site_time and site_time < sci_time:
        mismatches.append("site-ready manifest is older than scientific manifest")
    return tuple(mismatches)


def inspect_integrity(api: str, repo: str, token: str, branch: str, all_paths: Iterable[str], current_root: str, site_root: str, expected_timeframes: Iterable[str]) -> IntegrityReport:
    all_paths = tuple(all_paths)
    current_paths = _path_under(all_paths, current_root)
    site_paths = _path_under(all_paths, site_root)
    manifests = tuple(sorted(p for p in current_paths if _is_manifest(p)))
    checksums = tuple(sorted(p for p in current_paths if _is_checksum(p)))
    checkpoints = tuple(sorted(p for p in current_paths if _is_checkpoint(p)))
    completed, missing = timeframe_progress(current_paths, expected_timeframes)

    scientific_candidates = [p for p in manifests if not p.startswith(site_root.rstrip("/") + "/")]
    site_candidates = [p for p in manifests if p.startswith(site_root.rstrip("/") + "/")]
    scientific_manifest = fetch_json_file(api, repo, token, branch, scientific_candidates[0]) if scientific_candidates else None
    site_manifest = fetch_json_file(api, repo, token, branch, site_candidates[0]) if site_candidates else None
    mismatches = compare_manifests(scientific_manifest, site_manifest)

    return IntegrityReport(
        current_exists=bool(current_paths),
        site_exists=bool(site_paths),
        manifests=manifests,
        checksum_files=checksums,
        checkpoints=checkpoints,
        completed_timeframes=completed,
        missing_timeframes=missing,
        mismatches=mismatches,
        scientific_generated_at=_manifest_timestamp(scientific_manifest),
        site_generated_at=_manifest_timestamp(site_manifest),
    )


def classify_state(run: WorkflowRun | None, *, workflow_seen: bool, integrity: IntegrityReport, branch_sha: str | None, branch_updated_at: datetime | None, now: datetime, idle_threshold: timedelta, queue_stall: timedelta, run_timeout: timedelta) -> WatchState:
    if run is not None:
        if run.status in ACTIVE_STATUSES:
            age = now - run.created_at
            if run.status in QUEUE_STATUSES and age >= queue_stall:
                return WatchState("STALLED_QUEUE", run, branch_sha, branch_updated_at, workflow_seen, integrity)
            if run.status == "in_progress" and age >= run_timeout:
                return WatchState("STALLED_RUN", run, branch_sha, branch_updated_at, workflow_seen, integrity)
            return WatchState("RUNNING", run, branch_sha, branch_updated_at, workflow_seen, integrity)
        if run.status == "completed":
            if run.conclusion != "success":
                return WatchState("FAILED", run, branch_sha, branch_updated_at, workflow_seen, integrity)
            code = "COMPLETE" if not integrity.errors else "INTEGRITY_ERROR"
            return WatchState(code, run, branch_sha, branch_updated_at, workflow_seen, integrity)
        return WatchState("FAILED", run, branch_sha, branch_updated_at, workflow_seen, integrity)

    if integrity.current_exists and not integrity.errors:
        return WatchState("COMPLETE", None, branch_sha, branch_updated_at, workflow_seen, integrity)

    stale = branch_updated_at is None or now - branch_updated_at >= idle_threshold
    if stale and not workflow_seen:
        return WatchState("STALLED_NO_WORKFLOW", None, branch_sha, branch_updated_at, workflow_seen, integrity)
    if stale:
        return WatchState("STALLED_NO_RUN", None, branch_sha, branch_updated_at, workflow_seen, integrity)
    return WatchState("SETUP_PENDING" if not workflow_seen else "WAITING_FOR_RUN", None, branch_sha, branch_updated_at, workflow_seen, integrity)


def event_type(code: str) -> str | None:
    return {
        "FAILED": "price_action_failure",
        "STALLED_QUEUE": "price_action_stalled",
        "STALLED_RUN": "price_action_stalled",
        "STALLED_NO_RUN": "price_action_stalled",
        "STALLED_NO_WORKFLOW": "price_action_stalled",
        "INTEGRITY_ERROR": "price_action_integrity_error",
        "COMPLETE": "price_action_complete",
    }.get(code)


def fingerprint(state: WatchState) -> str:
    if state.run:
        return f"{state.code}:run-{state.run.run_id}:{state.branch_sha or 'unknown'}"
    return f"{state.code}:branch-{state.branch_sha or 'unknown'}"


def marker_for(state: WatchState) -> str:
    return f"<!-- AUTOTRADING_PRICE_ACTION_WATCHDOG:{fingerprint(state)} -->"


def marker_already_posted(api: str, repo: str, issue: int, token: str, marker: str) -> bool:
    comments = github_request("GET", f"{api}/repos/{repo}/issues/{issue}/comments?per_page=100", token)
    return any(marker in str(comment.get("body") or "") for comment in comments or [])


def issue_message(state: WatchState, cfg: dict[str, Any]) -> str:
    run_text = "none"
    if state.run:
        run_text = f"#{state.run.run_id} `{state.run.status}` / `{state.run.conclusion}` @ `{state.run.head_sha}`"
    completed = ", ".join(state.integrity.completed_timeframes) or "none"
    missing = ", ".join(state.integrity.missing_timeframes) or "none"
    problems = "; ".join(state.integrity.errors) or "none"
    return (
        f"{marker_for(state)}\n"
        f"PRICE ACTION V1 watchdog state: **{state.code}**\n\n"
        f"- branch: `{cfg['branch']}` @ `{state.branch_sha or 'unknown'}`\n"
        f"- workflow expected: `{cfg['workflow']}` (seen: `{state.workflow_seen}`)\n"
        f"- run: {run_text}\n"
        f"- current: `{cfg['current_root']}` (present: `{state.integrity.current_exists}`)\n"
        f"- site-ready: `{cfg['site_root']}` (present: `{state.integrity.site_exists}`)\n"
        f"- timeframes complete: `{completed}`\n"
        f"- timeframes missing: `{missing}`\n"
        f"- manifests: `{len(state.integrity.manifests)}`; checksums/hashes: `{len(state.integrity.checksum_files)}`; checkpoints: `{len(state.integrity.checkpoints)}`\n"
        f"- integrity findings: {problems}\n\n"
        "Recovery contract: resume from the last valid checkpoint, preserve existing artifacts, do not intentionally recompute validated artifacts, and do not modify Price Action scientific semantics or `site/entry-path-dashboard-v1`."
    )


def emit_dispatch(api: str, repo: str, token: str, action: str, state: WatchState, cfg: dict[str, Any]) -> dict[str, Any]:
    payload = {
        "priority": cfg["name"],
        "state": state.code,
        "priority_branch": cfg["branch"],
        "workflow": cfg["workflow"],
        "issue": cfg["issue"],
        "current_root": cfg["current_root"],
        "site_root": cfg["site_root"],
        "branch_sha": state.branch_sha,
        "branch_updated_at": state.branch_updated_at.isoformat() if state.branch_updated_at else None,
        "run_id": state.run.run_id if state.run else None,
        "run_status": state.run.status if state.run else None,
        "run_conclusion": state.run.conclusion if state.run else None,
        "run_head_sha": state.run.head_sha if state.run else None,
        "run_url": state.run.html_url if state.run else None,
        "completed_timeframes": list(state.integrity.completed_timeframes),
        "missing_timeframes": list(state.integrity.missing_timeframes),
        "integrity_errors": list(state.integrity.errors),
        "source": "price-action-watchdog",
        "guardrails": {
            "scientific_logic_immutable_to_watchdog": True,
            "preserve_existing_artifacts": True,
            "resume_from_checkpoint": True,
            "do_not_recompute_valid_artifacts": True,
            "reserved_site_branch": "site/entry-path-dashboard-v1",
            "never_modify_reserved_site_branch": True,
        },
    }
    github_request("POST", f"{api}/repos/{repo}/dispatches", token, {"event_type": action, "client_payload": payload})
    return payload


def main() -> int:
    repo = os.environ["GITHUB_REPOSITORY"]
    token = os.environ["GITHUB_TOKEN"]
    api = os.environ.get("GITHUB_API_URL", "https://api.github.com")
    registry = os.environ.get("WATCHDOG_REGISTRY", ".github/watchdog-registry.json")
    cfg = load_registry(registry, os.environ.get("WATCHDOG_PROJECT", "price-action-v1"))
    idle_threshold = timedelta(minutes=int(os.environ.get("IDLE_MINUTES", str(cfg.get("idle_minutes", 15)))))
    queue_stall = timedelta(minutes=int(os.environ.get("QUEUE_STALL_MINUTES", str(cfg.get("queue_stall_minutes", 30)))))
    run_timeout = timedelta(minutes=int(os.environ.get("RUN_TIMEOUT_MINUTES", str(cfg.get("run_timeout_minutes", 360)))))
    dry_run = os.environ.get("WATCHDOG_DRY_RUN", "0").strip().lower() in {"1", "true", "yes"}

    branch_sha, branch_updated_at, tree_sha = branch_snapshot(api, repo, token, cfg["branch"])
    run, workflow_seen = latest_project_run(api, repo, token, cfg["branch"], cfg["workflow_name"], cfg["workflow"])
    paths = tree_paths(api, repo, token, tree_sha)
    integrity = inspect_integrity(api, repo, token, cfg["branch"], paths, cfg["current_root"], cfg["site_root"], cfg.get("timeframes", DEFAULT_TIMEFRAMES))
    state = classify_state(
        run,
        workflow_seen=workflow_seen,
        integrity=integrity,
        branch_sha=branch_sha,
        branch_updated_at=branch_updated_at,
        now=utcnow(),
        idle_threshold=idle_threshold,
        queue_stall=queue_stall,
        run_timeout=run_timeout,
    )

    summary = {
        "priority": cfg["name"],
        "state": state.code,
        "branch": cfg["branch"],
        "branch_sha": branch_sha,
        "branch_updated_at": branch_updated_at.isoformat() if branch_updated_at else None,
        "workflow_seen": workflow_seen,
        "run_id": run.run_id if run else None,
        "run_status": run.status if run else None,
        "run_conclusion": run.conclusion if run else None,
        "current_exists": integrity.current_exists,
        "site_exists": integrity.site_exists,
        "completed_timeframes": list(integrity.completed_timeframes),
        "missing_timeframes": list(integrity.missing_timeframes),
        "manifests": list(integrity.manifests),
        "checksum_files": list(integrity.checksum_files),
        "checkpoints": list(integrity.checkpoints),
        "integrity_errors": list(integrity.errors),
        "dry_run": dry_run,
    }
    print(json.dumps(summary, indent=2, sort_keys=True))

    if not state.actionable:
        print(f"PRICE ACTION WATCHDOG: {state.code}; no orchestration signal needed.")
        return 0

    action = event_type(state.code)
    if not action:
        return 0
    marker = marker_for(state)
    if dry_run:
        print(f"PRICE ACTION WATCHDOG: DRY-RUN — would emit {action} with marker {marker}")
        return 0

    issue = int(cfg["issue"])
    if marker_already_posted(api, repo, issue, token, marker):
        print(f"PRICE ACTION WATCHDOG: {state.code} already emitted for this fingerprint.")
        return 0

    github_request("POST", f"{api}/repos/{repo}/issues/{issue}/comments", token, {"body": issue_message(state, cfg)})
    emit_dispatch(api, repo, token, action, state, cfg)
    print(f"PRICE ACTION WATCHDOG: emitted {action} for {fingerprint(state)}.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"PRICE ACTION WATCHDOG ERROR: {exc}", file=sys.stderr)
        raise
