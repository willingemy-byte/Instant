from __future__ import annotations

import base64
import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path

import requests

TOKEN = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
HEADERS = {
    "Accept": "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
}
if TOKEN:
    HEADERS["Authorization"] = f"Bearer {TOKEN}"

OUT = Path("artifacts/tick_data_scout")
OUT.mkdir(parents=True, exist_ok=True)

QUERIES = [
    '"gold futures" "tick data"',
    'GC futures tick data',
    'MGC futures tick data',
    'COMEX gold tick data',
    'XAUUSD tick data MetaTrader',
    'Dukascopy XAUUSD ticks',
    'Topstep market data gold futures',
    'prop firm tick data gold',
]

DATA_EXTENSIONS = (".csv", ".parquet", ".jsonl", ".ndjson", ".feather", ".h5", ".hdf5", ".zip", ".gz")


def gh_get(path: str, params: dict | None = None):
    url = path if path.startswith("http") else "https://api.github.com" + path
    r = requests.get(url, headers=HEADERS, params=params, timeout=45)
    if r.status_code in (403, 404, 422):
        return None
    r.raise_for_status()
    return r.json()


def readme(full_name: str) -> str:
    data = gh_get(f"/repos/{full_name}/readme")
    if not data or not data.get("content"):
        return ""
    try:
        return base64.b64decode(data["content"]).decode("utf-8", errors="replace")
    except Exception:
        return ""


def tree_files(repo: dict) -> list[str]:
    branch = repo.get("default_branch") or "main"
    data = gh_get(f"/repos/{repo['full_name']}/git/trees/{branch}", {"recursive": "1"})
    if not data:
        return []
    out = []
    for item in data.get("tree", []):
        if item.get("type") != "blob":
            continue
        p = str(item.get("path", ""))
        low = p.lower()
        if low.endswith(DATA_EXTENSIONS) and any(k in low for k in ("tick", "xau", "gold", "gc", "mgc", "trade", "quote")):
            out.append(p)
    return out[:100]


def classify(repo: dict, text: str, files: list[str]) -> dict:
    low = ((repo.get("description") or "") + "\n" + text).lower()
    name = repo["full_name"]

    futures = any(k in low for k in ("gold futures", "comex", "cme", "micro gold", "mgc", " gc futures"))
    spot = any(k in low for k in ("xauusd", "xau/usd", "forex gold", "cfd"))
    tick = any(k in low for k in ("tick-by-tick", "tick by tick", "tick data", "ticks", "trades schema", "time & sales", "mbo", "mbp"))
    quotes = any(k in low for k in ("bid ask", "bid/ask", "quotes", "order book", "mbp", "mbo"))
    trades = any(k in low for k in ("trades", "time & sales", "last price", "tick-by-tick"))
    providers = [p for p in ("cme", "comex", "databento", "dukascopy", "histdata", "metatrader", "topstep", "topstepx", "dxfeed", "rithmic", "polygon") if p in low]
    downloadable = bool(files) or any(k in low for k in ("csv", "parquet", "download", "dataset", "historical files"))
    history = any(k in low for k in ("historical", "history", "archive", "years", "from 20", "date range"))

    score = 0
    reasons: list[str] = []
    if futures:
        score += 35; reasons.append("GC/MGC futures relevance")
    if tick:
        score += 30; reasons.append("tick-level language")
    if trades:
        score += 8; reasons.append("trade prints")
    if quotes:
        score += 5; reasons.append("quotes/order book")
    if downloadable:
        score += 18; reasons.append("downloadable/data files")
    if files:
        score += min(20, 4 + 2 * len(files)); reasons.append(f"{len(files)} candidate data files in repo tree")
    if history:
        score += 8; reasons.append("historical coverage")
    if providers:
        score += min(12, 3 * len(providers)); reasons.append("provenance terms: " + ", ".join(providers[:4]))
    if spot and not futures:
        score -= 8; reasons.append("spot/CFD rather than futures")
    if not tick:
        score -= 15; reasons.append("no clear tick-level evidence")

    license_id = (repo.get("license") or {}).get("spdx_id")
    if license_id and license_id != "NOASSERTION":
        score += 4; reasons.append("declared license")

    return {
        "repo": name,
        "url": repo.get("html_url"),
        "description": repo.get("description"),
        "score": score,
        "futures": futures,
        "spot_or_cfd": spot,
        "tick_evidence": tick,
        "trade_prints": trades,
        "quotes_or_book": quotes,
        "providers": providers,
        "candidate_data_files": files,
        "license": license_id,
        "stars": repo.get("stargazers_count", 0),
        "updated_at": repo.get("updated_at"),
        "reasons": reasons,
        "readme_excerpt": re.sub(r"\s+", " ", text).strip()[:1500],
    }


def main() -> None:
    discovered: dict[str, dict] = {}
    search_log = []
    for q in QUERIES:
        try:
            data = gh_get("/search/repositories", {"q": q, "sort": "updated", "order": "desc", "per_page": 12})
            items = (data or {}).get("items", [])
            search_log.append({"query": q, "results": len(items)})
            for item in items:
                discovered[item["full_name"]] = item
        except Exception as exc:
            search_log.append({"query": q, "error": f"{type(exc).__name__}: {exc}"})

    def cheap_score(r: dict) -> tuple[int, int]:
        s = ((r.get("name") or "") + " " + (r.get("description") or "")).lower()
        hits = sum(k in s for k in ("tick", "gold", "xau", "futures", "gc", "mgc", "data"))
        return hits, int(r.get("stargazers_count", 0))

    shortlist = sorted(discovered.values(), key=cheap_score, reverse=True)[:35]
    rows = []
    for repo in shortlist:
        try:
            txt = readme(repo["full_name"])
            files = tree_files(repo)
            rows.append(classify(repo, txt, files))
        except Exception as exc:
            rows.append({
                "repo": repo["full_name"], "url": repo.get("html_url"), "score": -999,
                "error": f"{type(exc).__name__}: {exc}", "candidate_data_files": []
            })

    rows.sort(key=lambda x: (x.get("score", -999), x.get("stars", 0)), reverse=True)
    payload = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "issue": 75,
        "mission": "Find verifiable tick-level Gold data candidates for research backtests.",
        "queries": QUERIES,
        "search_log": search_log,
        "candidates": rows,
        "validation_rule": "A candidate is NOT approved until actual files/data are inspected for symbol semantics, timestamp/timezone, contract/rollover, duplicates/gaps, licensing and reproducible checksums.",
    }
    (OUT / "tick_data_candidates.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = [
        "# FOX-TICK — Gold tick-data scout", "",
        f"Generated: {payload['generated_at']}", "",
        "A high score is only a lead, not an approval.", "",
        "| # | Score | Repository | Futures | Tick evidence | Files | Provenance |",
        "|---:|---:|---|---|---|---:|---|",
    ]
    for i, row in enumerate(rows[:25], 1):
        providers = ", ".join(row.get("providers", [])) or "—"
        lines.append(
            f"| {i} | {row.get('score', -999)} | [{row['repo']}]({row.get('url','')}) | "
            f"{'yes' if row.get('futures') else 'no'} | {'yes' if row.get('tick_evidence') else 'no'} | "
            f"{len(row.get('candidate_data_files', []))} | {providers} |"
        )
    lines += ["", "## Candidate file evidence", ""]
    for row in rows[:15]:
        lines.append(f"### {row['repo']} — score {row.get('score')}")
        lines.append("- " + "; ".join(row.get("reasons", [])))
        files = row.get("candidate_data_files", [])
        if files:
            for p in files[:12]:
                lines.append(f"  - `{p}`")
        else:
            lines.append("  - No candidate data file found in repository tree.")
        lines.append("")
    lines += [
        "## Required validation before adoption", "",
        "1. Confirm actual instrument (GC/MGC futures preferred; XAUUSD is secondary only).",
        "2. Confirm event type: trade/tick vs quote; document whether one tick equals one trade/event.",
        "3. Confirm timezone, exchange session, contract month and rollover method.",
        "4. Measure missing/duplicate timestamps and impossible prices/volumes.",
        "5. Freeze a checksum snapshot before any strategy comparison.",
        "6. Build 50/75/100/250/500/1000-tick bars locally from the same validated raw stream.",
    ]
    report = "\n".join(lines) + "\n"
    (OUT / "tick_data_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
