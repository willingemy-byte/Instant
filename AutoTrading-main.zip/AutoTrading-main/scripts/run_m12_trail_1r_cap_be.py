from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pandas as pd

import run_m10_trailing_initial_risk as b
import run_m10_trailing_initial_risk_fast as f
import run_m11_trail_1p5r_cap_be as m11

OUT = Path("artifacts")
OUT.mkdir(parents=True, exist_ok=True)


def process_minutes_1r_cap_be(pos, mins: pd.DataFrame, trailing: bool):
    """M12: trail 1R behind best favorable price, capped at entry."""
    if pos is None or mins.empty:
        return pos, None

    for ts, bar in mins.iterrows():
        side = int(pos["side"])
        stop = float(pos["active_stop"])
        tp = float(pos["tp"])
        ex = why = None

        if side == 1:
            if bar.Open <= stop:
                ex, why = float(bar.Open), "gap_stop"
            elif bar.Open >= tp:
                ex, why = float(bar.Open), "gap_tp"
            elif bar.Low <= stop and bar.High >= tp:
                ex, why = stop, "both_stop_first"
            elif bar.Low <= stop:
                ex, why = stop, "stop"
            elif bar.High >= tp:
                ex, why = tp, "tp"
        else:
            if bar.Open >= stop:
                ex, why = float(bar.Open), "gap_stop"
            elif bar.Open <= tp:
                ex, why = float(bar.Open), "gap_tp"
            elif bar.High >= stop and bar.Low <= tp:
                ex, why = stop, "both_stop_first"
            elif bar.High >= stop:
                ex, why = stop, "stop"
            elif bar.Low <= tp:
                ex, why = tp, "tp"

        if ex is not None:
            r = ((ex - float(pos["entry"])) / float(pos["risk"])) * side
            return None, {**pos, "exit": ex, "exit_time": ts, "reason": why, "R": r}

        if trailing:
            entry = float(pos["entry"])
            risk = float(pos["risk"])
            if side == 1:
                pos["best_price"] = max(float(pos["best_price"]), float(bar.High))
                candidate = float(pos["best_price"]) - risk
                pos["active_stop"] = max(float(pos["active_stop"]), min(entry, candidate))
            else:
                pos["best_price"] = min(float(pos["best_price"]), float(bar.Low))
                candidate = float(pos["best_price"]) + risk
                pos["active_stop"] = min(float(pos["active_stop"]), max(entry, candidate))

    return pos, None


def main():
    d1 = b.load_1m()
    d5 = b.make_5m(d1)
    snap = OUT / "m12_mgc_5m_from_1m_snapshot.csv"
    d5.to_csv(snap)
    sha = hashlib.sha256(snap.read_bytes()).hexdigest()

    original_process = b.process_minutes
    results = []
    try:
        b.process_minutes = process_minutes_1r_cap_be
        for label, start in b.STARTS.items():
            x1 = d1.loc[start:]
            x5 = d5.loc[start:]
            trades = f.simulate_fast(x1, x5, trailing=True)
            trades.to_csv(OUT / f"m12_trail_1r_cap_be_{label}_trades.csv", index=False)
            met = m11.classify_metrics(trades)
            met.update(window=label, mode="trail_1R_cap_break_even")
            results.append(met)
    finally:
        b.process_minutes = original_process

    payload = {
        "method": "offline research only",
        "instrument": "MGC Micro Gold Futures continuous",
        "signal_timeframe": "5m",
        "management_timeframe": "1m",
        "snapshot_sha256": sha,
        "entry_logic": "same M9b five-wave exhaustion + wave1/wave2 + breakout-close entry",
        "initial_stop": "full five-wave terminal structure extreme",
        "take_profit": "fixed 3R",
        "trailing_rule": {
            "distance": "1R behind best favorable price",
            "never_loosens": True,
            "cap": "break-even / entry price; trailing stop never moves into profit",
            "long": "max(old_stop, min(entry, best_high - 1R))",
            "short": "min(old_stop, max(entry, best_low + 1R))"
        },
        "intraminute_rule": "existing stop/TP checked first; trail updated from completed 1m bar for next minute",
        "results": results
    }
    (OUT / "m12_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = [
        "# M12 — M9b + 1R trailing capped at break-even",
        "",
        f"Snapshot SHA256: `{sha}`",
        "",
        "Signals remain 5m; position management uses underlying 1m bars.",
        "",
        "| Window | Trades | Wins | Losses | BE | WR | Avg R | PF(R) | -1R full | Partial losses | Partial wins | TP 3R |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"
    ]
    for r in results:
        pf = "n/a" if r["profit_factor_R"] is None else f"{r['profit_factor_R']:.3f}"
        lines.append(
            f"| {r['window']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['breakeven']} | "
            f"{r['win_rate_pct']:.2f}% | {r['avg_R']:.3f} | {pf} | {r['full_minus_1R']} | "
            f"{r['partial_losses']} | {r['partial_wins']} | {r['tp_3R']} |"
        )
    lines += [
        "",
        "Rules:",
        "- Same M9b price-action entry and full-structure initial stop.",
        "- Fixed TP remains 3R.",
        "- Trailing stop stays 1R behind the best favorable price.",
        "- It never loosens and never advances beyond entry; once it reaches break-even it stays there.",
        "- Existing stop/TP is evaluated before using each completed 1m bar to update the trail."
    ]
    report = "\n".join(lines) + "\n"
    (OUT / "m12_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
