from __future__ import annotations

import base64
import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path

import requests

TOKEN = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
HEADERS = {
    "Accept": "application/vnd.github+json",
    "X-GitHub-Api-Version": "2022-11-28",
}
if TOKEN:
    HEADERS["Authorization"] = f"Bearer {TOKEN}"

OUT = Path("artifacts")
OUT.mkdir(parents=True, exist_ok=True)

SEARCH_QUERIES = [
    'gold futures OHLCV historical data',
    'GC futures 1 minute data',
    'MGC futures 1 minute OHLCV',
    'COMEX gold historical CSV',
    'CME gold futures dataset',
    'gold futures parquet data',
    'MCP market data gold futures',
    'MCP financial data commodities gold',
]

SEED_REPOS = [
    "axb0306/cme-futures-ohlc",
    "domzack/mgc-ohlcv-data",
    "EricGrill/mcp-market-data",
    "CohenD/fin-data-mcp",
    "goldapi-io/goldapi-mcp-server",
]


def gh_get(url: str, params: dict | None = None):
    if not url.startswith("http"):
        url = "https://api.github.com" + url
    r = requests.get(url, headers=HEADERS, params=params, timeout=30)
    if r.status_code == 404:
        return None
    r.raise_for_status()
    return r.json()


def fetch_repo(full_name: str):
    return gh_get(f"/repos/{full_name}")


def fetch_readme(full_name: str) -> str:
    data = gh_get(f"/repos/{full_name}/readme")
    if not data or not data.get("content"):
        return ""
    try:
        return base64.b64decode(data["content"]).decode("utf-8", errors="replace")
    except Exception:
        return ""


def norm(s: str) -> str:
    return re.sub(r"\s+", " ", s or "").strip()


def classify_and_score(repo: dict, readme: str) -> dict:
    text = (repo.get("description") or "") + "\n" + readme
    low = text.lower()
    full_name = repo["full_name"]

    has_gc = bool(re.search(r"(?<![a-z0-9])gc(?![a-z0-9])", low)) or "gold futures" in low
    has_mgc = bool(re.search(r"(?<![a-z0-9])mgc(?![a-z0-9])", low)) or "micro gold" in low
    has_gld = bool(re.search(r"(?<![a-z0-9])gld(?![a-z0-9])", low))
    has_tick = any(k in low for k in ["tick data", "ticks", "tick-by-tick", "mbp-1", "mbo"])
    has_1m = bool(re.search(r"\b1[ -]?(minute|min|m)\b", low)) or "ohlcv-1m" in low or "1-minute" in low
    has_3m = bool(re.search(r"\b3[ -]?(minute|min|m)\b", low)) or "3-minute" in low
    has_5m = bool(re.search(r"\b5[ -]?(minute|min|m)\b", low)) or "5-minute" in low
    has_files = any(k in low for k in [".csv", "csv file", ".parquet", "jsonl", "ndjson", "download data", "data/by-date"])
    has_history = any(k in low for k in ["historical", "history", "date range", "from 202", "covering", "years of data"])
    provenance_terms = ["databento", "cme", "comex", "topstepx", "exchange", "official", "nasdaq data link", "kibot"]
    provenance = [t for t in provenance_terms if t in low]
    mcp = "model context protocol" in low or " mcp" in low or "mcp server" in low
    yahoo = "yahoo finance" in low or "yfinance" in low
    api_only = mcp and not has_files

    score = 0
    reasons = []
    if has_gc:
        score += 30; reasons.append("GC/gold futures")
    if has_mgc:
        score += 18; reasons.append("MGC")
    if has_tick:
        score += 22; reasons.append("tick-level")
    elif has_1m:
        score += 20; reasons.append("1-minute")
    elif has_3m:
        score += 14; reasons.append("3-minute")
    elif has_5m:
        score += 10; reasons.append("5-minute")
    if has_files:
        score += 15; reasons.append("downloadable files")
    if has_history:
        score += 10; reasons.append("historical coverage")
    if provenance:
        score += min(15, 5 + 3 * len(provenance)); reasons.append("provenance: " + ", ".join(provenance[:3]))
    if repo.get("license") and repo["license"].get("spdx_id") not in (None, "NOASSERTION"):
        score += 6; reasons.append("license declared")
    if mcp:
        score += 4; reasons.append("MCP access")
    if yahoo:
        score -= 8; reasons.append("Yahoo limitations")
    if api_only:
        score -= 8; reasons.append("wrapper/API rather than dataset")
    if has_gld and not has_gc and not has_mgc:
        score -= 12; reasons.append("GLD rather than futures")

    updated = repo.get("updated_at")
    if updated:
        try:
            dt = datetime.fromisoformat(updated.replace("Z", "+00:00"))
            age_days = (datetime.now(timezone.utc) - dt).days
            if age_days <= 90:
                score += 5; reasons.append("recently updated")
        except Exception:
            pass

    granularity = []
    if has_tick: granularity.append("tick")
    if has_1m: granularity.append("1m")
    if has_3m: granularity.append("3m")
    if has_5m: granularity.append("5m")

    date_mentions = sorted(set(re.findall(r"20\d{2}-\d{2}-\d{2}", text)))

    return {
        "repo": full_name,
        "url": repo.get("html_url"),
        "description": repo.get("description"),
        "score": score,
        "type": "dataset" if has_files else ("mcp" if mcp else "repository"),
        "symbols": [x for x, ok in [("GC", has_gc), ("MGC", has_mgc), ("GLD", has_gld)] if ok],
        "granularity": granularity,
        "downloadable_files": has_files,
        "historical": has_history,
        "provenance_terms": provenance,
        "license": (repo.get("license") or {}).get("spdx_id"),
        "stars": repo.get("stargazers_count", 0),
        "updated_at": updated,
        "date_mentions": date_mentions[:12],
        "reasons": reasons,
        "readme_excerpt": norm(readme)[:1000],
    }


def main():
    repos: dict[str, dict] = {}
    search_log = []

    for q in SEARCH_QUERIES:
        try:
            data = gh_get("/search/repositories", params={"q": q, "sort": "updated", "order": "desc", "per_page": 10})
            items = (data or {}).get("items", [])
            search_log.append({"query": q, "count": len(items)})
            for item in items:
                repos[item["full_name"]] = item
        except Exception as e:
            search_log.append({"query": q, "error": str(e)})

    for full_name in SEED_REPOS:
        if full_name not in repos:
            try:
                repo = fetch_repo(full_name)
                if repo:
                    repos[full_name] = repo
            except Exception:
                pass

    # Cheap prefilter before README calls.
    def pre_score(item):
        s = ((item.get("name") or "") + " " + (item.get("description") or "")).lower()
        return sum(k in s for k in ["gold", "futures", "ohlcv", "data", "mcp", "gc", "mgc"])

    shortlist = sorted(repos.values(), key=lambda r: (pre_score(r), r.get("stargazers_count", 0)), reverse=True)[:35]
    candidates = []
    for repo in shortlist:
        try:
            readme = fetch_readme(repo["full_name"])
        except Exception as e:
            readme = f"README fetch failed: {e}"
        candidates.append(classify_and_score(repo, readme))

    candidates.sort(key=lambda x: (x["score"], x["stars"]), reverse=True)

    skilldb_text = ""
    skilldb_path = OUT / "skilldb_search.txt"
    if skilldb_path.exists():
        skilldb_text = skilldb_path.read_text(encoding="utf-8", errors="replace")

    payload = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "mission": "Find reliable historical gold futures data sources for deterministic backtests; research only.",
        "search_log": search_log,
        "candidate_count": len(candidates),
        "candidates": candidates,
    }
    (OUT / "data_scout_candidates.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = [
        "# Gold Data Scout — GitHub/MCP research",
        "",
        f"Generated: {payload['generated_at']}",
        "",
        "## Mission",
        "Find reliable historical GC/MGC data for deterministic backtests. Prefer real datasets over wrappers, 1m/tick granularity, long history, documented provenance, reproducible downloads and clear licensing.",
        "",
        "## SkillDB discovery",
        "SkillDB search was run before repository research. The raw CLI output is preserved in `skilldb_search.txt`.",
        "",
    ]
    if skilldb_text:
        lines += ["```text", skilldb_text[:5000], "```", ""]
    else:
        lines += ["SkillDB CLI returned no captured output; repository research continued independently.", ""]

    lines += [
        "## Ranked candidates",
        "",
        "| # | Score | Repository | Type | Symbols | Granularity | Provenance | License |",
        "|---:|---:|---|---|---|---|---|---|",
    ]
    for i, c in enumerate(candidates[:20], 1):
        prov = ", ".join(c["provenance_terms"][:3]) or "—"
        gran = ", ".join(c["granularity"]) or "—"
        syms = ", ".join(c["symbols"]) or "—"
        lines.append(f"| {i} | {c['score']} | [{c['repo']}]({c['url']}) | {c['type']} | {syms} | {gran} | {prov} | {c['license'] or '—'} |")

    lines += ["", "## Candidate notes", ""]
    for c in candidates[:12]:
        lines += [
            f"### {c['repo']} — score {c['score']}",
            f"- Reasons: {', '.join(c['reasons']) or 'none'}",
            f"- Updated: {c['updated_at'] or 'unknown'}; stars: {c['stars']}",
            f"- Date mentions: {', '.join(c['date_mentions']) or 'none extracted'}",
            f"- Description: {c['description'] or 'none'}",
            "",
        ]

    lines += [
        "## Validation rule before adoption",
        "A candidate is not approved merely because it ranks highly. Before using it in strategy comparisons, verify actual files, symbol/contract semantics, rollover method, timezone/session, missing bars, licensing, and checksum a frozen local snapshot.",
        "",
    ]

    report = "\n".join(lines)
    (OUT / "data_scout_report.md").write_text(report, encoding="utf-8")
    (OUT / "data_scout_summary.md").write_text("\n".join(lines[:35]) + "\n\nFull report is in the workflow artifact.\n", encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
