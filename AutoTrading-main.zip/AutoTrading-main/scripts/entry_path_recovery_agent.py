#!/usr/bin/env python3
"""Bounded technical-recovery worker for ENTRY-PATH V1.

This worker repairs research infrastructure only. It is deliberately forbidden
from changing strategy intent, optimizing trading parameters, loading the blind
holdout, touching UNIVERSAL RANGE, or modifying main directly.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
API_ROOT = "https://api.github.com"
ISSUE_NUMBER = 112
MODEL = os.environ.get("MODEL", "qwen2.5-coder:3b")
OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://127.0.0.1:11434/api/chat")
MAX_ROUNDS = int(os.environ.get("MAX_ROUNDS", "3"))
EVENT_FILE = Path(os.environ.get("ENTRY_PATH_EVENT_FILE", "/tmp/entry-path-event.json"))
LOG_FILE = Path(os.environ.get("ENTRY_PATH_LOG_FILE", "/tmp/entry-path-failure.log"))
REPORT_FILE = Path(os.environ.get("ENTRY_PATH_RECOVERY_REPORT", "/tmp/entry-path-recovery.json"))

ALLOWED_PREFIXES = (
    "entry_path/",
    "tests/",
    "docs/entry-path",
)
ALLOWED_EXACT = {
    "scripts/run_entry_path_v1_campaign.py",
    ".github/workflows/entry-path-v1-campaign.yml",
    "requirements.txt",
    "STATUS.md",
    "WORKPLAN.md",
}
FORBIDDEN_TEXT = ("2026-04-01", "UNIVERSAL RANGE")


def token() -> str:
    return os.environ["GITHUB_TOKEN"]


def repo() -> str:
    return os.environ.get("GITHUB_REPOSITORY", "willingemy-byte/AutoTrading")


def http_json(url: str) -> dict:
    request = Request(
        url,
        headers={
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {token()}",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "AutoTrading-Entry-Path-Recovery",
        },
    )
    try:
        with urlopen(request, timeout=60) as response:
            return json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {exc.code} from {url}: {detail[:2000]}") from exc


def local_json(payload: dict) -> dict:
    request = Request(
        OLLAMA_URL,
        method="POST",
        headers={"Content-Type": "application/json"},
        data=json.dumps(payload).encode("utf-8"),
    )
    with urlopen(request, timeout=900) as response:
        return json.loads(response.read().decode("utf-8"))


def safe_path(raw: str) -> Path:
    normalized = raw.strip().replace("\\", "/")
    if normalized in ALLOWED_EXACT or normalized.startswith(ALLOWED_PREFIXES):
        candidate = (ROOT / normalized).resolve()
        candidate.relative_to(ROOT.resolve())
        return candidate
    raise ValueError(f"Recovery agent attempted disallowed path: {raw}")


def targeted_tests() -> tuple[int, str]:
    completed = subprocess.run(
        [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-p", "test_entry_path*.py", "-v"],
        cwd=ROOT,
        text=True,
        capture_output=True,
        timeout=300,
    )
    output = (completed.stdout + "\n" + completed.stderr).strip()
    return completed.returncode, output[-20000:]


def read_text(path: Path, limit: int = 24000) -> str:
    if not path.exists():
        return ""
    return path.read_text(encoding="utf-8", errors="replace")[:limit]


def repository_context() -> str:
    candidates = [
        "AGENTS.md",
        "WORKPLAN.md",
        "STATUS.md",
        "docs/entry-path-v1-inventory.md",
        "scripts/run_entry_path_v1_campaign.py",
        ".github/workflows/entry-path-v1-campaign.yml",
    ]
    candidates += sorted(str(p.relative_to(ROOT)) for p in (ROOT / "entry_path").glob("*.py"))
    candidates += sorted(str(p.relative_to(ROOT)) for p in (ROOT / "tests").glob("test_entry_path*.py"))
    chunks: list[str] = []
    for relative in candidates:
        text = read_text(ROOT / relative)
        if text:
            chunks.append(f"\n===== {relative} =====\n{text}")
    return "".join(chunks)[:120000]


def issue_context() -> str:
    issue = http_json(f"{API_ROOT}/repos/{repo()}/issues/{ISSUE_NUMBER}")
    return f"{issue.get('title', '')}\n\n{issue.get('body', '')}"


def event_context() -> str:
    return read_text(EVENT_FILE, 12000) or "{}"


def failure_logs() -> str:
    return read_text(LOG_FILE, 30000) or "No workflow logs were available."


def model_call(test_output: str, round_no: int) -> dict:
    system = (
        "You are the bounded ENTRY-PATH V1 technical recovery worker. Repair ONLY technical defects that prevent the existing research campaign from running or persisting its requested artifacts. "
        "Do not alter strategy entry semantics, initial-stop semantics, Topstep rules, +/-7R definitions, dataset provenance, or research conclusions. "
        "Never load/use/analyze data from 2026-04-01 onward. UNIVERSAL RANGE is paused and must not be touched. Never add broker/live-trading connectivity. Never modify main. "
        "Return ONLY JSON with keys summary and files. files maps repository-relative paths to COMPLETE UTF-8 file contents. Keep changes minimal and deterministic."
    )
    user = (
        f"ORCHESTRATION ISSUE:\n{issue_context()}\n\n"
        f"WATCHDOG EVENT:\n{event_context()}\n\n"
        f"FAILED/STALLED RUN LOGS:\n{failure_logs()}\n\n"
        f"TARGETED TEST OUTPUT:\n{test_output}\n\n"
        f"ROUND {round_no}/{MAX_ROUNDS}\n\n"
        f"CURRENT ENTRY-PATH CONTEXT:\n{repository_context()}\n\n"
        "Diagnose the smallest technical fix. If no repository change is justified, return an empty files object and explain why in summary."
    )
    response = local_json({
        "model": MODEL,
        "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
        "stream": False,
        "format": "json",
        "options": {"temperature": 0.05, "num_ctx": 32768, "num_predict": 10000},
    })
    content = response["message"]["content"]
    result = json.loads(content)
    if not isinstance(result.get("files"), dict):
        raise RuntimeError("Recovery model response missing files object")
    return result


def apply_files(files: dict[str, str]) -> list[str]:
    changed: list[str] = []
    for relative, content in files.items():
        if not isinstance(relative, str) or not isinstance(content, str):
            raise ValueError("files must map strings to strings")
        path = safe_path(relative)
        old = path.read_text(encoding="utf-8") if path.exists() else None
        if old != content:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            changed.append(path.relative_to(ROOT).as_posix())
    return changed


def write_report(report: dict) -> None:
    REPORT_FILE.write_text(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def main() -> int:
    report: dict[str, object] = {"model": MODEL, "rounds": [], "changed_files": [], "success": False}
    changed_all: list[str] = []
    code, tests = targeted_tests()
    report["initial_tests"] = {"returncode": code, "output": tests}
    try:
        for round_no in range(1, MAX_ROUNDS + 1):
            result = model_call(tests, round_no)
            changed = apply_files(result["files"])
            changed_all.extend(changed)
            code, tests = targeted_tests()
            report["rounds"].append({
                "round": round_no,
                "summary": str(result.get("summary") or ""),
                "changed": changed,
                "test_returncode": code,
                "test_output": tests,
            })
            if code == 0:
                report["success"] = True
                break
        report["changed_files"] = list(dict.fromkeys(changed_all))
        report["final_tests"] = {"returncode": code, "output": tests}
        write_report(report)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0 if report["success"] else 1
    except Exception as exc:
        report["error"] = f"{type(exc).__name__}: {exc}"
        report["changed_files"] = list(dict.fromkeys(changed_all))
        write_report(report)
        print(json.dumps(report, ensure_ascii=False, indent=2), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
