from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

import run_m10_trailing_initial_risk as b
import run_m13_trail_1p5r_then_3r_tp7 as m13

OUT = Path("artifacts")
OUT.mkdir(parents=True, exist_ok=True)

START_BALANCE = 150_000.0
MLL_DISTANCE = 4_500.0
RISK_DOLLARS = 300.0
CT = "America/Chicago"


def _ct(ts: pd.Timestamp) -> pd.Timestamp:
    if ts.tzinfo is None:
        ts = ts.tz_localize("UTC")
    return ts.tz_convert(CT)


def entry_allowed(ts: pd.Timestamp) -> bool:
    """Topstep regular weekday schedule, conservative no-new-entry after 15:08 CT.

    Sunday opens 17:00 CT. Mon-Thu: open before 15:08 and again from 17:00.
    Friday: open only before 15:08. Saturday closed.
    Holiday early closes are not modeled in M14.
    """
    x = _ct(ts)
    wd = x.weekday()  # Mon=0 ... Sun=6
    hm = x.hour * 60 + x.minute
    if wd == 5:
        return False
    if wd == 6:
        return hm >= 17 * 60
    if wd == 4:
        return hm < 15 * 60 + 8
    return hm < 15 * 60 + 8 or hm >= 17 * 60


def force_flat_now(ts: pd.Timestamp) -> bool:
    x = _ct(ts)
    return x.weekday() <= 4 and x.hour == 15 and x.minute == 10


def session_label(ts: pd.Timestamp) -> str:
    """Topstep trading day: 17:00 CT -> 15:10 CT next calendar day."""
    x = _ct(ts)
    d = x.date()
    if (x.hour, x.minute) >= (17, 0):
        d = (x + pd.Timedelta(days=1)).date()
    return str(d)


def process_minutes_topstep(pos, mins: pd.DataFrame):
    if pos is None or mins.empty:
        return pos, None
    eps = 1e-12
    for ts, bar in mins.iterrows():
        if force_flat_now(ts):
            ex = float(bar.Open)
            side = int(pos["side"])
            r = ((ex - float(pos["entry"])) / float(pos["risk"])) * side
            return None, {**pos, "exit": ex, "exit_time": ts, "reason": "topstep_1510_flat", "R": r}

        side = int(pos["side"])
        stop = float(pos["active_stop"])
        tp = float(pos["tp"])
        ex = why = None
        if side == 1:
            if bar.Open <= stop:
                ex, why = float(bar.Open), "gap_stop"
            elif bar.Open >= tp:
                ex, why = float(bar.Open), "gap_tp"
            elif bar.Low <= stop and bar.High >= tp:
                ex, why = stop, "both_stop_first"
            elif bar.Low <= stop:
                ex, why = stop, "stop"
            elif bar.High >= tp:
                ex, why = tp, "tp7"
        else:
            if bar.Open >= stop:
                ex, why = float(bar.Open), "gap_stop"
            elif bar.Open <= tp:
                ex, why = float(bar.Open), "gap_tp"
            elif bar.High >= stop and bar.Low <= tp:
                ex, why = stop, "both_stop_first"
            elif bar.High >= stop:
                ex, why = stop, "stop"
            elif bar.Low <= tp:
                ex, why = tp, "tp7"
        if ex is not None:
            r = ((ex - float(pos["entry"])) / float(pos["risk"])) * side
            return None, {**pos, "exit": ex, "exit_time": ts, "reason": why, "R": r}

        entry = float(pos["entry"])
        risk = float(pos["risk"])
        if side == 1:
            pos["best_price"] = max(float(pos["best_price"]), float(bar.High))
            if not bool(pos.get("phase2", False)):
                candidate = float(pos["best_price"]) - 1.5 * risk
                pos["active_stop"] = max(float(pos["active_stop"]), min(entry, candidate))
                if float(pos["active_stop"]) >= entry - eps:
                    pos["active_stop"] = entry
                    pos["phase2"] = True
            else:
                candidate = float(pos["best_price"]) - 3.0 * risk
                pos["active_stop"] = max(entry, float(pos["active_stop"]), candidate)
        else:
            pos["best_price"] = min(float(pos["best_price"]), float(bar.Low))
            if not bool(pos.get("phase2", False)):
                candidate = float(pos["best_price"]) + 1.5 * risk
                pos["active_stop"] = min(float(pos["active_stop"]), max(entry, candidate))
                if float(pos["active_stop"]) <= entry + eps:
                    pos["active_stop"] = entry
                    pos["phase2"] = True
            else:
                candidate = float(pos["best_price"]) + 3.0 * risk
                pos["active_stop"] = min(entry, float(pos["active_stop"]), candidate)
    return pos, None


def simulate_topstep_trades(d1: pd.DataFrame, d5: pd.DataFrame) -> pd.DataFrame:
    c5 = d5.Close.to_numpy(float)
    h5 = d5.High.to_numpy(float)
    l5 = d5.Low.to_numpy(float)
    idx5 = d5.index
    pivots = b.raw_pivots(d5)
    by_confirm = {}
    for p in pivots:
        by_confirm.setdefault(p["confirm_i"], []).append(p)

    seq = []
    long_state = short_state = pos = None
    rec = []
    one_ns = pd.Timedelta(nanoseconds=1)

    for i in range(len(d5)):
        close_time = idx5[i] + pd.Timedelta(minutes=5)
        prev_close = idx5[i] if i == 0 else idx5[i - 1] + pd.Timedelta(minutes=5)
        if pos is not None:
            pos, done = process_minutes_topstep(pos, d1.loc[prev_close:close_time - one_ns])
            if done is not None:
                rec.append(done)

        for p in by_confirm.get(i, []):
            if not seq or p["type"] != seq[-1]["type"]:
                seq.append(p.copy())
            else:
                q = seq[-1]
                replace = ((p["type"] == "H" and p["price"] >= q["price"])
                           or (p["type"] == "L" and p["price"] <= q["price"]))
                if replace:
                    seq[-1] = p.copy()
            if len(seq) > 30:
                seq = seq[-30:]

            bf = b.bearish_five(seq)
            if bf is not None:
                long_state = {"phase":"wait_wave1_high","terminal":bf[-1].copy(),"wave1":None,"wave2":None}
            uf = b.bullish_five(seq)
            if uf is not None:
                short_state = {"phase":"wait_wave1_low","terminal":uf[-1].copy(),"wave1":None,"wave2":None}

            if long_state is not None and p["pivot_i"] > long_state["terminal"]["pivot_i"]:
                if long_state["phase"] == "wait_wave1_high" and p["type"] == "H":
                    long_state["wave1"] = p.copy(); long_state["phase"] = "wait_wave2_low"
                elif long_state["phase"] == "wait_wave2_low" and p["type"] == "L":
                    if p["price"] > long_state["terminal"]["price"]:
                        long_state["wave2"] = p.copy(); long_state["phase"] = "armed"
                    else:
                        long_state = None
            if short_state is not None and p["pivot_i"] > short_state["terminal"]["pivot_i"]:
                if short_state["phase"] == "wait_wave1_low" and p["type"] == "L":
                    short_state["wave1"] = p.copy(); short_state["phase"] = "wait_wave2_high"
                elif short_state["phase"] == "wait_wave2_high" and p["type"] == "H":
                    if p["price"] < short_state["terminal"]["price"]:
                        short_state["wave2"] = p.copy(); short_state["phase"] = "armed"
                    else:
                        short_state = None

        if long_state is not None and long_state["phase"] == "armed" and l5[i] <= long_state["terminal"]["price"]:
            long_state = None
        if short_state is not None and short_state["phase"] == "armed" and h5[i] >= short_state["terminal"]["price"]:
            short_state = None

        if pos is None and entry_allowed(close_time):
            if long_state is not None and long_state["phase"] == "armed":
                w1,w2,term = long_state["wave1"],long_state["wave2"],long_state["terminal"]
                if c5[i] > w1["price"] and i > w2["confirm_i"]:
                    entry=float(c5[i]); sl=float(term["price"]); risk=entry-sl
                    if risk > 0:
                        pos={"side":1,"entry":entry,"entry_time":close_time,"risk":risk,"initial_stop":sl,
                             "active_stop":sl,"tp":entry+7*risk,"best_price":entry,"phase2":False,
                             "terminal_time":term["time"],"wave1_time":w1["time"],"wave2_time":w2["time"]}
                        long_state=None
            elif short_state is not None and short_state["phase"] == "armed":
                w1,w2,term = short_state["wave1"],short_state["wave2"],short_state["terminal"]
                if c5[i] < w1["price"] and i > w2["confirm_i"]:
                    entry=float(c5[i]); sl=float(term["price"]); risk=sl-entry
                    if risk > 0:
                        pos={"side":-1,"entry":entry,"entry_time":close_time,"risk":risk,"initial_stop":sl,
                             "active_stop":sl,"tp":entry-7*risk,"best_price":entry,"phase2":False,
                             "terminal_time":term["time"],"wave1_time":w1["time"],"wave2_time":w2["time"]}
                        short_state=None

    if pos is not None:
        pos, done = process_minutes_topstep(pos, d1.loc[idx5[-1] + pd.Timedelta(minutes=5):])
        if done is not None:
            rec.append(done)
    return pd.DataFrame(rec)


def closed_drawdown(dollar_pnl: pd.Series) -> float:
    eq = START_BALANCE + dollar_pnl.cumsum()
    peak = eq.cummax()
    return float((eq - peak).min()) if len(eq) else 0.0


def evaluate_mll(trades: pd.DataFrame, d1: pd.DataFrame) -> dict:
    if trades.empty:
        return {"survived": True, "trades": 0}
    t = trades.sort_values("entry_time").reset_index(drop=True).copy()
    t["session"] = t["entry_time"].map(session_label)

    balance = START_BALANCE
    mll = START_BALANCE - MLL_DISTANCE
    min_headroom = float("inf")
    min_headroom_time = None
    breach = None
    rows = []
    current_session = None

    for j, tr in t.iterrows():
        sess = tr["session"]
        if current_session is not None and sess != current_session:
            mll = min(START_BALANCE, max(mll, balance - MLL_DISTANCE))
        current_session = sess

        entry = float(tr["entry"]); risk = float(tr["risk"]); side = int(tr["side"])
        et = pd.Timestamp(tr["entry_time"]); xt = pd.Timestamp(tr["exit_time"])
        dollars_per_price = RISK_DOLLARS / risk
        mins = d1.loc[et:xt]
        local_min_headroom = float("inf")
        local_min_time = et

        for ts, bar in mins.iterrows():
            if ts == xt and str(tr["reason"]) in {"stop","gap_stop","both_stop_first","topstep_1510_flat"}:
                worst_pnl = float(tr["R"]) * RISK_DOLLARS
            else:
                if side == 1:
                    worst_pnl = (float(bar.Low) - entry) * dollars_per_price
                else:
                    worst_pnl = (entry - float(bar.High)) * dollars_per_price
                if ts == xt:
                    worst_pnl = min(worst_pnl, float(tr["R"]) * RISK_DOLLARS)
            equity_worst = balance + worst_pnl
            headroom = equity_worst - mll
            if headroom < local_min_headroom:
                local_min_headroom = headroom; local_min_time = ts
            if headroom < min_headroom:
                min_headroom = headroom; min_headroom_time = ts
            if equity_worst <= mll and breach is None:
                breach = {"trade_index": int(j), "time": str(ts), "equity": equity_worst, "mll": mll,
                          "headroom": headroom, "entry_time": str(et), "R_at_exit": float(tr["R"])}
                break
        pnl = float(tr["R"]) * RISK_DOLLARS
        if breach is None:
            balance += pnl
        rows.append({"trade":int(j+1),"entry_time":str(et),"exit_time":str(xt),"session":sess,
                     "R":float(tr["R"]),"pnl_dollars":pnl,"balance_after":balance,"mll_before_trade":mll,
                     "min_headroom_trade":local_min_headroom,"min_headroom_time":str(local_min_time),"reason":str(tr["reason"])})
        if breach is not None:
            break

    if breach is None and current_session is not None:
        mll = min(START_BALANCE, max(mll, balance - MLL_DISTANCE))

    ledger = pd.DataFrame(rows)
    return {
        "survived": breach is None,
        "trades": int(len(t)),
        "trades_processed": int(len(rows)),
        "final_balance": float(balance),
        "net_profit": float(balance - START_BALANCE),
        "ending_mll": float(mll),
        "minimum_headroom": float(min_headroom),
        "minimum_headroom_time": str(min_headroom_time),
        "breach": breach,
        "ledger": ledger,
    }


def summarize(trades: pd.DataFrame, risk_eval: dict) -> dict:
    eps=1e-9
    r=trades.R.astype(float)
    wins=int((r>eps).sum()); losses=int((r<-eps).sum()); be=int((r.abs()<=eps).sum())
    return {
        "trades":int(len(trades)),"wins":wins,"losses":losses,"breakeven":be,
        "win_rate_all_pct":float(100*wins/len(trades)) if len(trades) else 0.0,
        "win_rate_ex_be_pct":float(100*wins/(wins+losses)) if wins+losses else 0.0,
        "sum_R":float(r.sum()),"avg_R":float(r.mean()) if len(r) else 0.0,
        "fixed_risk_net_profit":float(r.sum()*RISK_DOLLARS),
        "closed_equity_max_drawdown":closed_drawdown(r*RISK_DOLLARS),
        "topstep_survived":risk_eval["survived"],"minimum_mll_headroom":risk_eval["minimum_headroom"],
        "final_balance":risk_eval["final_balance"],"ending_mll":risk_eval["ending_mll"],
    }


def main():
    d1=b.load_1m(); d5=b.make_5m(d1)
    results=[]
    for label,start in b.STARTS.items():
        x1=d1.loc[start:]; x5=d5.loc[start:]
        trades=simulate_topstep_trades(x1,x5)
        trades.to_csv(OUT/f"m14_topstep_{label}_trades.csv",index=False)
        ev=evaluate_mll(trades,x1)
        ev["ledger"].to_csv(OUT/f"m14_topstep_{label}_ledger.csv",index=False)
        s=summarize(trades,ev); s["window"]=label; results.append(s)

    payload={
      "method":"offline research simulation only",
      "instrument":"MGC continuous research data",
      "starting_balance":START_BALANCE,"fixed_initial_R_dollars":RISK_DOLLARS,
      "topstep_150k_mll_distance":MLL_DISTANCE,
      "mll_model":"real-time unrealized equity breach; EOD MLL=max(previous, EOD balance-4500), capped at 150000",
      "schedule_model":"regular Topstep hours; no entries from 15:08-17:00 CT, forced flat at 15:10 CT; weekend closure; holiday early closes not modeled",
      "position_sizing":"continuous normalized size so initial 1R equals exactly $300; integer MGC contract granularity, commissions and slippage not modeled",
      "results":results,
    }
    (OUT/"m14_results.json").write_text(json.dumps(payload,indent=2),encoding="utf-8")
    lines=["# M14 — Topstep-style 150K survival, M13 logic, $300 initial risk","",
           "Regular Topstep day-trading hours are enforced; holiday early closes are not modeled.","",
           "| Window | Trades | W | L | BE | WR all | WR ex-BE | Net $ | Final balance | Closed DD $ | Min MLL headroom $ | Survived |",
           "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|"]
    for r in results:
        lines.append(f"| {r['window']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['breakeven']} | {r['win_rate_all_pct']:.2f}% | {r['win_rate_ex_be_pct']:.2f}% | {r['fixed_risk_net_profit']:.0f} | {r['final_balance']:.0f} | {r['closed_equity_max_drawdown']:.0f} | {r['minimum_mll_headroom']:.0f} | {r['topstep_survived']} |")
    report="\n".join(lines)+"\n"; (OUT/"m14_report.md").write_text(report,encoding="utf-8"); print(report)

if __name__=="__main__": main()
