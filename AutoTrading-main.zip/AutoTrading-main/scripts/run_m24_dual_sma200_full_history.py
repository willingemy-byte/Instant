from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

import run_m10_trailing_initial_risk as b
import run_m14_topstep_150k_risk300 as m14
import run_m16_eb3_1h_sma50 as m16
import run_m17_eb3_noentry_10_17ct as m17
import run_m20_m17_dynamic20_capped900 as m20
import run_m21_m20_full_mgc_history as m21

OUT = Path("artifacts/m24_dual_sma200")
OUT.mkdir(parents=True, exist_ok=True)


def completed_h1_sma200(d1: pd.DataFrame) -> pd.Series:
    """Latest completed 1h SMA200, indexed by hour close time.

    A 5m entry at t may only use an hourly value whose hour has fully closed
    at or before t. This preserves the no-look-ahead convention used in M15+.
    """
    h1 = d1.resample("1h", label="left", closed="left").agg({
        "Open": "first",
        "High": "max",
        "Low": "min",
        "Close": "last",
        "Volume": "sum",
    }).dropna(subset=["Open", "High", "Low", "Close"])
    sma = h1["Close"].rolling(200, min_periods=200).mean()
    sma.index = sma.index + pd.Timedelta(hours=1)
    sma.name = "sma200_h1"
    return sma.dropna()


def simulate_m24(d1: pd.DataFrame, d5: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """M17 entry/management with dual SMA200 directional confirmation.

    User-requested change only:
    - long: EB3 close > 5m SMA200 AND > latest completed 1h SMA200
    - short: EB3 close < 5m SMA200 AND < latest completed 1h SMA200
    - replaces M17/M16 completed 1h SMA50 with SMA200
    Everything else remains M17/M20 lineage.
    """
    h1_sma = completed_h1_sma200(d1)
    sma5 = d5["Close"].rolling(200, min_periods=200).mean()
    if h1_sma.empty or sma5.dropna().empty:
        return pd.DataFrame(), {}

    pos = None
    rec: list[dict] = []
    idx5 = d5.index
    one_ns = pd.Timedelta(nanoseconds=1)
    counters = {
        "eligible_eb3_candidates": 0,
        "blocked_5m_sma200": 0,
        "blocked_1h_sma200": 0,
        "accepted_entries": 0,
    }

    for i in range(len(d5)):
        close_time = idx5[i] + pd.Timedelta(minutes=5)
        prev_close = idx5[i] if i == 0 else idx5[i - 1] + pd.Timedelta(minutes=5)

        if pos is not None:
            pos, done = m14.process_minutes_topstep(pos, d1.loc[prev_close:close_time - one_ns])
            if done is not None:
                rec.append(done)

        if pos is not None or not m17.entry_allowed_m17(close_time):
            continue

        sig = m16.eb3_signal(d5, i)
        if sig == 0:
            continue

        sma200_5m = float(sma5.iloc[i]) if i < len(sma5) and pd.notna(sma5.iloc[i]) else np.nan
        hist = h1_sma.loc[:close_time]
        if not np.isfinite(sma200_5m) or hist.empty:
            continue
        sma200_h1 = float(hist.iloc[-1])
        entry = float(d5.Close.iloc[i])
        counters["eligible_eb3_candidates"] += 1

        if sig == 1:
            if entry <= sma200_5m:
                counters["blocked_5m_sma200"] += 1
                continue
            if entry <= sma200_h1:
                counters["blocked_1h_sma200"] += 1
                continue
            sl = float(d5.Low.iloc[i])
            risk = entry - sl
            if risk <= 0:
                continue
            pos = {
                "side": 1,
                "entry": entry,
                "entry_time": close_time,
                "risk": risk,
                "initial_stop": sl,
                "active_stop": sl,
                "tp": entry + 7.0 * risk,
                "best_price": entry,
                "phase2": False,
                "sma200_5m": sma200_5m,
                "sma200_h1": sma200_h1,
                "eb3_time": idx5[i],
                "eb3_open": float(d5.Open.iloc[i]),
                "eb3_high": float(d5.High.iloc[i]),
                "eb3_low": float(d5.Low.iloc[i]),
                "eb3_close": entry,
            }
        else:
            if entry >= sma200_5m:
                counters["blocked_5m_sma200"] += 1
                continue
            if entry >= sma200_h1:
                counters["blocked_1h_sma200"] += 1
                continue
            sl = float(d5.High.iloc[i])
            risk = sl - entry
            if risk <= 0:
                continue
            pos = {
                "side": -1,
                "entry": entry,
                "entry_time": close_time,
                "risk": risk,
                "initial_stop": sl,
                "active_stop": sl,
                "tp": entry - 7.0 * risk,
                "best_price": entry,
                "phase2": False,
                "sma200_5m": sma200_5m,
                "sma200_h1": sma200_h1,
                "eb3_time": idx5[i],
                "eb3_open": float(d5.Open.iloc[i]),
                "eb3_high": float(d5.High.iloc[i]),
                "eb3_low": float(d5.Low.iloc[i]),
                "eb3_close": entry,
            }
        counters["accepted_entries"] += 1

    if pos is not None:
        pos, done = m14.process_minutes_topstep(pos, d1.loc[idx5[-1] + pd.Timedelta(minutes=5):])
        if done is not None:
            rec.append(done)

    return pd.DataFrame(rec), counters


def main() -> None:
    d1 = m21.load_full_1m()
    d5 = b.make_5m(d1)
    data_start = str(d1.index.min())
    data_end = str(d1.index.max())
    elapsed_days = float((d1.index.max() - d1.index.min()) / pd.Timedelta(days=1))
    elapsed_years = elapsed_days / 365.2425

    trades, counters = simulate_m24(d1, d5)
    trades.to_csv(OUT / "m24_full_history_trades.csv", index=False)

    ev = m20.evaluate_dynamic20_capped900(trades, d1)
    ledger = ev["ledger"].copy()
    ledger.to_csv(OUT / "m24_full_history_ledger.csv", index=False)

    summary = m20.summarize(trades, ev)
    summary.update({
        "data_start": data_start,
        "data_end": data_end,
        "elapsed_days": elapsed_days,
        "elapsed_years": elapsed_years,
        "longest_loss_streak": m21.longest_loss_streak(trades["R"] if not trades.empty else pd.Series(dtype=float)),
    })
    annual = m21.period_stats(trades, ledger, "year")
    quarterly = m21.period_stats(trades, ledger, "quarter")

    payload = {
        "method": "offline research simulation only",
        "baseline": "M17 strategy logic + M20 dynamic 20% MLL-headroom sizing capped at $900",
        "user_requested_change": {
            "5m_filter": "long close > current 5m SMA200; short close < current 5m SMA200",
            "1h_filter": "replace completed 1h SMA50 with latest completed 1h SMA200",
            "both_required": True,
            "lookahead": "forbidden; 1h SMA uses completed hourly bars only",
        },
        "unchanged": [
            "5m EB3 direct entry: current body engulfs previous 3 bodies",
            "initial stop at EB3 wick extreme",
            "TP 7R",
            "M13 management: 1.5R-behind-best phase 1 to BE, then 3R-behind-best with BE floor",
            "M17 no new entries weekdays 10:00-17:00 CT; existing positions continue; forced-flat rule unchanged",
            "M20 risk = min($900, 20% of realized balance minus current MLL)",
        ],
        "data_start": data_start,
        "data_end": data_end,
        "elapsed_years": elapsed_years,
        "entry_filter_counters": counters,
        "summary": summary,
        "annual": annual,
        "quarterly": quarterly,
        "caveats": [
            "continuous normalized sizing; integer MGC contract granularity not modeled",
            "commissions and slippage not modeled",
            "holiday early closes not modeled",
            "continuous research series uses source-defined rollover",
        ],
    }
    (OUT / "m24_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    s = summary
    lines = [
        "# M24 — M20/M21 + dual SMA200 trend filter",
        "",
        f"Data: {data_start} -> {data_end} (~{elapsed_years:.2f} years)",
        "",
        "Only requested strategy change: require 5m close and latest completed 1h trend to agree with SMA200.",
        "The old completed 1h SMA50 filter is replaced by completed 1h SMA200.",
        "",
        "| Trades | W | L | BE | WR ex-BE | Avg R | Net $ | Final balance | Avg risk $ | Min risk $ | Max risk $ | Trades at $900 | Min MLL headroom $ | Loss streak | Survived |",
        "|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|",
        f"| {s['trades']} | {s['wins']} | {s['losses']} | {s['breakeven']} | {s['win_rate_ex_be_pct']:.2f}% | {s['avg_R']:.3f} | {s['net_profit']:.0f} | {s['final_balance']:.0f} | {s['average_risk_dollars']:.0f} | {s['minimum_risk_dollars']:.0f} | {s['maximum_risk_dollars']:.0f} | {s['cap_hit_trades']} | {s['minimum_mll_headroom']:.0f} | {s['longest_loss_streak']} | {s['topstep_survived']} |",
        "",
        "## Entry filter counts",
        "",
        f"- Eligible EB3 candidates while flat/in-session: {counters.get('eligible_eb3_candidates', 0)}",
        f"- Blocked first by 5m SMA200: {counters.get('blocked_5m_sma200', 0)}",
        f"- Passed 5m but blocked by 1h SMA200: {counters.get('blocked_1h_sma200', 0)}",
        f"- Accepted entries: {counters.get('accepted_entries', 0)}",
        "",
        "## By calendar year",
        "",
        "| Year | Trades | W | L | BE | WR ex-BE | Avg R | Sum R | Net $ | Avg risk $ | Loss streak |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in annual:
        lines.append(
            f"| {r['period']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['breakeven']} | "
            f"{r['win_rate_ex_be_pct']:.2f}% | {r['avg_R']:.3f} | {r['sum_R']:.1f} | "
            f"{r['net_profit_dollars']:.0f} | {r['average_risk_dollars']:.0f} | {r['longest_loss_streak']} |"
        )

    lines += [
        "",
        "## By quarter",
        "",
        "| Quarter | Trades | WR ex-BE | Avg R | Sum R | Net $ | Avg risk $ | Loss streak |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in quarterly:
        lines.append(
            f"| {r['period']} | {r['trades']} | {r['win_rate_ex_be_pct']:.2f}% | {r['avg_R']:.3f} | "
            f"{r['sum_R']:.1f} | {r['net_profit_dollars']:.0f} | {r['average_risk_dollars']:.0f} | {r['longest_loss_streak']} |"
        )

    report = "\n".join(lines) + "\n"
    (OUT / "m24_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
