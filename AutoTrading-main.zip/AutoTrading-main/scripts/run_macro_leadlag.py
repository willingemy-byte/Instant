from __future__ import annotations

import io
import json
import math
import re
import urllib.request
from pathlib import Path
from datetime import datetime, timezone

import numpy as np
import pandas as pd
import yfinance as yf

OUT = Path("artifacts/macro_agent")
OUT.mkdir(parents=True, exist_ok=True)
START = "2020-01-01"
END = None
LAGS = list(range(-26, 27))


def fetch_fred(series_id: str) -> pd.Series:
    url = f"https://fred.stlouisfed.org/graph/fredgraph.csv?id={series_id}"
    x = pd.read_csv(url)
    x.columns = [str(c).strip() for c in x.columns]
    date_col = x.columns[0]
    val_col = x.columns[1]
    x[date_col] = pd.to_datetime(x[date_col], errors="coerce")
    x[val_col] = pd.to_numeric(x[val_col], errors="coerce")
    s = x.dropna().set_index(date_col)[val_col].sort_index()
    return s.loc[pd.Timestamp(START):].rename(series_id)


def fetch_boc(series_id: str) -> pd.Series:
    url = f"https://www.bankofcanada.ca/valet/observations/{series_id}/json?start_date={START}"
    req = urllib.request.Request(url, headers={"User-Agent": "AutoTrading-Macro-Agent"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        data = json.load(resp)
    rows = []
    for obs in data.get("observations", []):
        try:
            rows.append((pd.Timestamp(obs["d"]), float(obs[series_id]["v"])))
        except Exception:
            continue
    if not rows:
        raise RuntimeError(f"No BoC observations for {series_id}")
    return pd.Series(dict(rows)).sort_index().rename(series_id)


def _parse_ecb_periods(values: pd.Series) -> pd.Series:
    """Parse ordinary ECB dates plus ISO-week labels such as 2023-W01."""
    raw = values.astype(str).str.strip()
    dt = pd.to_datetime(raw, errors="coerce", utc=True)
    missing = dt.isna()
    if missing.any():
        for idx, text in raw.loc[missing].items():
            m = re.match(r"^(\d{4})-?W(\d{1,2})(?:-(\d))?$", text)
            if not m:
                continue
            year = int(m.group(1)); week = int(m.group(2)); day = int(m.group(3) or 5)
            try:
                dt.loc[idx] = pd.Timestamp.fromisocalendar(year, week, day).tz_localize("UTC")
            except Exception:
                continue
    return dt


def fetch_ecb(series_key: str) -> pd.Series:
    url = f"https://data-api.ecb.europa.eu/service/data/ILM/{series_key}?startPeriod={START}&format=csvdata"
    req = urllib.request.Request(url, headers={"User-Agent": "AutoTrading-Macro-Agent", "Accept": "text/csv"})
    with urllib.request.urlopen(req, timeout=45) as resp:
        raw = resp.read()
    x = pd.read_csv(io.BytesIO(raw))
    cols = {str(c).upper(): c for c in x.columns}
    tcol = cols.get("TIME_PERIOD")
    vcol = cols.get("OBS_VALUE")
    if tcol is None or vcol is None:
        raise RuntimeError(f"ECB CSV missing expected columns: {list(x.columns)[:20]}")
    dt = _parse_ecb_periods(x[tcol])
    vv = pd.to_numeric(x[vcol], errors="coerce")
    good = dt.notna() & vv.notna()
    s = pd.Series(vv.loc[good].to_numpy(), index=pd.DatetimeIndex(dt.loc[good])).sort_index()
    s = s[~s.index.duplicated(keep="last")]
    if s.empty:
        sample = [str(v) for v in x[tcol].head(8).tolist()]
        raise RuntimeError(f"ECB series parsed to zero valid dated observations; sample TIME_PERIOD={sample}")
    return s.rename("ECB_MONPOL_SECURITIES")


def fetch_market(ticker: str, name: str) -> pd.Series:
    x = yf.download(ticker, start=START, end=END, progress=False, auto_adjust=False, threads=False)
    if x.empty:
        raise RuntimeError(f"No market data for {ticker}")
    if isinstance(x.columns, pd.MultiIndex):
        close = x["Close"][ticker] if ticker in x["Close"].columns else x["Close"].iloc[:, 0]
    else:
        close = x["Close"]
    close.index = pd.to_datetime(close.index).tz_localize(None)
    return pd.to_numeric(close, errors="coerce").dropna().rename(name)


def weekly_last(s: pd.Series) -> pd.Series:
    vals = pd.to_numeric(pd.Series(s.to_numpy()), errors="coerce").to_numpy()
    idx = pd.to_datetime(s.index, errors="coerce", utc=True)
    good = (~pd.isna(idx)) & (~pd.isna(vals))
    if not bool(np.any(good)):
        raise RuntimeError(f"Series {s.name} has no valid dated numeric observations")
    clean_idx = pd.DatetimeIndex(idx[good]).tz_convert(None)
    clean = pd.Series(vals[good], index=clean_idx, name=s.name)
    clean = clean[~clean.index.duplicated(keep="last")].sort_index()
    return clean.resample("W-FRI").last().dropna()


def corr_pair(x: pd.Series, y: pd.Series, method: str) -> tuple[float, int]:
    z = pd.concat([x, y], axis=1).dropna()
    n = len(z)
    if n < 20:
        return float("nan"), n
    return float(z.iloc[:, 0].corr(z.iloc[:, 1], method=method)), n


def lead_lag(feature: pd.Series, market_ret: pd.Series, feature_name: str, market_name: str) -> list[dict]:
    out = []
    for lag in LAGS:
        target = market_ret.shift(-lag)
        p, n = corr_pair(feature, target, "pearson")
        s, _ = corr_pair(feature, target, "spearman")
        out.append({
            "feature": feature_name,
            "market": market_name,
            "lag_weeks": lag,
            "meaning": "positive=macro leads market; negative=market leads macro",
            "pearson": p,
            "spearman": s,
            "n": n,
        })
    return out


def safe_float(x):
    try:
        if x is None or not math.isfinite(float(x)):
            return None
        return float(x)
    except Exception:
        return None


def main() -> None:
    errors = []
    raw = {}
    fetchers = {
        "FED_TREAST": lambda: fetch_fred("TREAST"),
        "FED_WALCL": lambda: fetch_fred("WALCL"),
        "BOC_GOC_BONDS": lambda: fetch_boc("V36613"),
        "ECB_MONPOL_SECURITIES": lambda: fetch_ecb("W.U2.C.A070100.U2.EUR"),
        "DXY": lambda: fetch_market("DX-Y.NYB", "DXY"),
        "GOLD": lambda: fetch_market("GC=F", "GOLD"),
        "WTI": lambda: fetch_market("CL=F", "WTI"),
        "BRENT": lambda: fetch_market("BZ=F", "BRENT"),
    }
    for name, fn in fetchers.items():
        try:
            raw[name] = fn()
        except Exception as exc:
            errors.append({"series": name, "error": str(exc)})

    if "DXY" not in raw or "GOLD" not in raw:
        raise RuntimeError(f"Market data unavailable: {errors}")

    weekly_levels = {}
    for name, series in raw.items():
        try:
            weekly_levels[name] = weekly_last(series)
        except Exception as exc:
            errors.append({"series": name, "error": f"weekly normalization: {exc}"})

    if "DXY" not in weekly_levels or "GOLD" not in weekly_levels:
        raise RuntimeError(f"Market weekly normalization failed: {errors}")

    frame = pd.concat(weekly_levels.values(), axis=1).sort_index()
    frame.columns = list(weekly_levels.keys())
    frame.to_csv(OUT / "macro_weekly_levels.csv")

    features = {}
    for name in ("FED_TREAST", "FED_WALCL", "BOC_GOC_BONDS", "ECB_MONPOL_SECURITIES"):
        if name not in frame.columns:
            continue
        base = frame[name]
        available = base.shift(1)
        features[f"{name}_DIFF_AVAIL"] = available.diff()
        features[f"{name}_PCT_AVAIL"] = available.pct_change(fill_method=None)

    markets = {
        "DXY_RET": frame["DXY"].pct_change(fill_method=None),
        "GOLD_RET": frame["GOLD"].pct_change(fill_method=None),
    }
    if "WTI" in frame.columns:
        markets["WTI_RET"] = frame["WTI"].pct_change(fill_method=None)
    if "BRENT" in frame.columns:
        markets["BRENT_RET"] = frame["BRENT"].pct_change(fill_method=None)

    panel = pd.concat({**features, **markets}, axis=1)
    panel.to_csv(OUT / "macro_weekly_transforms.csv")

    rows = []
    for fname, feat in features.items():
        for mname, mret in markets.items():
            rows.extend(lead_lag(feat, mret, fname, mname))
    corr = pd.DataFrame(rows)
    corr.to_csv(OUT / "macro_leadlag_all.csv", index=False)

    ranked = corr[corr["n"] >= 40].copy()
    ranked["abs_score"] = ranked[["pearson", "spearman"]].abs().mean(axis=1)
    ranked = ranked.sort_values("abs_score", ascending=False)
    ranked.head(100).to_csv(OUT / "macro_leadlag_ranked.csv", index=False)

    yearly = []
    for year in range(2023, 2027):
        mask = panel.index.year == year
        sub = panel.loc[mask]
        for fname in features:
            for mname in markets:
                p, n = corr_pair(sub[fname], sub[mname], "pearson")
                s, _ = corr_pair(sub[fname], sub[mname], "spearman")
                yearly.append({"year": year, "feature": fname, "market": mname, "pearson": p, "spearman": s, "n": n})
    pd.DataFrame(yearly).to_csv(OUT / "macro_sameweek_by_year.csv", index=False)

    top = []
    for _, r in ranked.head(20).iterrows():
        top.append({
            "feature": r["feature"], "market": r["market"], "lag_weeks": int(r["lag_weeks"]),
            "pearson": safe_float(r["pearson"]), "spearman": safe_float(r["spearman"]), "n": int(r["n"]),
            "abs_score": safe_float(r["abs_score"]),
        })

    payload = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "start": START,
        "series_loaded": sorted(weekly_levels.keys()),
        "errors": errors,
        "release_handling": "central-bank weekly levels shifted one week before change calculation to reduce publication look-ahead risk",
        "lag_definition": "positive lag means macro feature precedes market weekly return by that many weeks",
        "top_diagnostic_relationships": top,
        "warning": "exploratory correlations are hypothesis generators, not proof of predictive causality; multiple-testing and regime instability can produce false positives",
    }
    (OUT / "macro_leadlag_summary.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = [
        "# Macro lead/lag prototype",
        "",
        f"Generated: {payload['generated_at']}",
        "",
        "Central-bank data are conservatively shifted one weekly bucket before transforms to reduce publication look-ahead.",
        "Positive lag = macro feature at t compared with market return at t + lag weeks.",
        "",
        f"Loaded: {', '.join(payload['series_loaded'])}",
    ]
    if errors:
        lines += ["", "## Fetch/normalization errors"] + [f"- {e['series']}: {e['error']}" for e in errors]
    lines += ["", "## Strongest exploratory relationships (NOT causal proof)", "", "| Feature | Market | Lead weeks | Pearson | Spearman | N |", "|---|---|---:|---:|---:|---:|"]
    for r in top:
        lines.append(f"| {r['feature']} | {r['market']} | {r['lag_weeks']} | {r['pearson'] if r['pearson'] is not None else 'NA'} | {r['spearman'] if r['spearman'] is not None else 'NA'} | {r['n']} |")
    lines += [
        "",
        "## Interpretation gate",
        "",
        "Do not promote any relationship into the trading strategy from this table alone. Next gate: multiple-testing correction, stability by year/regime, and out-of-sample validation on unseen dates.",
    ]
    (OUT / "macro_leadlag_report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print((OUT / "macro_leadlag_report.md").read_text(encoding="utf-8"))


if __name__ == "__main__":
    main()
