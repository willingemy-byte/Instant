#!/usr/bin/env python3
"""Fetch recent COMEX Gold futures (Yahoo symbol GC=F) 5-minute bars for research.

This script uses Yahoo's public chart endpoint, writes a normalized UTC OHLCV CSV,
and validates chronology and OHLC consistency. It never places orders or connects
to a brokerage account.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request, urlopen

DEFAULT_URL = (
    "https://query1.finance.yahoo.com/v8/finance/chart/{symbol}"
    "?range={range_}&interval=5m&includePrePost=true&events=div%2Csplits"
)


def fetch_chart(symbol: str = "GC=F", range_: str = "60d") -> dict:
    url = DEFAULT_URL.format(symbol=quote(symbol, safe=""), range_=range_)
    req = Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/131 Safari/537.36",
            "Accept": "application/json,text/plain,*/*",
        },
    )
    with urlopen(req, timeout=30) as response:
        return json.loads(response.read().decode("utf-8"))


def normalize(payload: dict) -> tuple[list[dict[str, object]], dict[str, object]]:
    chart = payload.get("chart") or {}
    if chart.get("error"):
        raise RuntimeError(f"Yahoo error: {chart['error']}")
    results = chart.get("result") or []
    if not results:
        raise RuntimeError("Yahoo returned no chart result for GC=F")
    result = results[0]
    timestamps = result.get("timestamp") or []
    indicators = result.get("indicators") or {}
    quotes = indicators.get("quote") or []
    if not timestamps or not quotes:
        raise RuntimeError("Yahoo returned no intraday 5-minute bars for GC=F")
    quote_data = quotes[0]
    opens = quote_data.get("open") or []
    highs = quote_data.get("high") or []
    lows = quote_data.get("low") or []
    closes = quote_data.get("close") or []
    volumes = quote_data.get("volume") or []
    lengths = {len(timestamps), len(opens), len(highs), len(lows), len(closes), len(volumes)}
    if len(lengths) != 1:
        raise RuntimeError(f"Yahoo arrays have inconsistent lengths: {sorted(lengths)}")

    rows: list[dict[str, object]] = []
    seen: set[int] = set()
    for ts, o, h, l, c, v in zip(timestamps, opens, highs, lows, closes, volumes):
        if None in (ts, o, h, l, c):
            continue
        ts = int(ts)
        if ts in seen:
            continue
        seen.add(ts)
        o, h, l, c = map(float, (o, h, l, c))
        if h < max(o, l, c) or l > min(o, h, c):
            raise RuntimeError(f"Invalid OHLC at {ts}: {(o, h, l, c)}")
        rows.append(
            {
                "datetime": datetime.fromtimestamp(ts, tz=timezone.utc).isoformat(),
                "open": o,
                "high": h,
                "low": l,
                "close": c,
                "volume": 0 if v is None else int(v),
            }
        )
    rows.sort(key=lambda row: str(row["datetime"]))
    if len(rows) < 1000:
        raise RuntimeError(f"Too few usable 5-minute bars: {len(rows)}")

    meta = result.get("meta") or {}
    report = {
        "source": "Yahoo Finance chart API",
        "symbol_requested": "GC=F",
        "symbol_returned": meta.get("symbol"),
        "exchange": meta.get("exchangeName"),
        "exchange_timezone": meta.get("exchangeTimezoneName"),
        "interval": "5m",
        "rows": len(rows),
        "first_bar_utc": rows[0]["datetime"],
        "last_bar_utc": rows[-1]["datetime"],
        "currency": meta.get("currency"),
        "instrument_type": meta.get("instrumentType"),
    }
    return rows, report


def write_csv(rows: list[dict[str, object]], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["datetime", "open", "high", "low", "close", "volume"])
        writer.writeheader()
        writer.writerows(rows)
    temp.replace(path)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="data/gc_yahoo_5m_60d.csv")
    parser.add_argument("--report", default="data/gc_yahoo_5m_60d.meta.json")
    parser.add_argument("--range", dest="range_", default="60d")
    args = parser.parse_args()

    try:
        rows, report = normalize(fetch_chart(range_=args.range_))
        output = Path(args.output)
        report_path = Path(args.report)
        write_csv(rows, output)
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        print(json.dumps(report, indent=2, sort_keys=True))
        return 0
    except Exception as exc:
        print(f"DATA_FETCH_FAILED: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
