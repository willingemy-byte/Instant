#!/usr/bin/env python3
from __future__ import annotations

import base64
import json
import os
import re
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

ACTIVE = {"queued", "in_progress", "waiting", "requested", "pending"}
QUEUE = {"queued", "waiting", "requested", "pending"}
ACTIONABLE = {
    "FAILED": "price_action_failure",
    "STALLED_QUEUE": "price_action_stalled",
    "STALLED_RUN": "price_action_stalled",
    "STALLED_NO_RUN": "price_action_stalled",
    "STALLED_NO_WORKFLOW": "price_action_stalled",
    "INTEGRITY_ERROR": "price_action_integrity_error",
    "COMPLETE": "price_action_complete",
}


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def parse_dt(value: str | None) -> datetime | None:
    if not value:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def request(method: str, url: str, token: str, payload: dict[str, Any] | None = None, allow_404: bool = False) -> Any:
    body = None if payload is None else json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        method=method,
        headers={
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {token}",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "AutoTrading-Price-Action-Watchdog-v2",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            raw = response.read()
            return json.loads(raw) if raw else None
    except urllib.error.HTTPError as exc:
        if allow_404 and exc.code == 404:
            return None
        detail = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"GitHub API {method} {url} -> HTTP {exc.code}: {detail[:1200]}") from exc


def load_project(path: str, project_id: str) -> dict[str, Any]:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    for project in payload.get("projects", []):
        if project.get("id") == project_id:
            return dict(project)
    raise KeyError(project_id)


def branch_info(api: str, repo: str, token: str, branch: str) -> tuple[str | None, datetime | None, str | None]:
    b = urllib.parse.quote(branch, safe="")
    payload = request("GET", f"{api}/repos/{repo}/branches/{b}", token)
    commit = (payload or {}).get("commit") or {}
    nested = commit.get("commit") or {}
    stamp = ((nested.get("committer") or {}).get("date") or (nested.get("author") or {}).get("date"))
    tree_sha = ((nested.get("tree") or {}).get("sha"))
    return commit.get("sha"), parse_dt(stamp), tree_sha


def tree_paths(api: str, repo: str, token: str, tree_sha: str | None) -> tuple[str, ...]:
    if not tree_sha:
        return ()
    payload = request("GET", f"{api}/repos/{repo}/git/trees/{tree_sha}?recursive=1", token)
    return tuple(str(x.get("path")) for x in (payload or {}).get("tree", []) if x.get("path"))


def latest_run(api: str, repo: str, token: str, branch: str, workflow_name: str, workflow_path: str) -> tuple[dict[str, Any] | None, bool]:
    b = urllib.parse.quote(branch, safe="")
    payload = request("GET", f"{api}/repos/{repo}/actions/runs?branch={b}&per_page=100", token)
    wanted = workflow_path if workflow_path.startswith(".github/workflows/") else f".github/workflows/{workflow_path}"
    matches = []
    for raw in (payload or {}).get("workflow_runs", []):
        path = str(raw.get("path") or "")
        name = str(raw.get("name") or "")
        if name == workflow_name or path == wanted or path.endswith("/" + workflow_path):
            matches.append(raw)
    return (matches[0], True) if matches else (None, False)


def accounted_timeframes(paths: tuple[str, ...], current_root: str, expected: list[str]) -> tuple[list[str], list[str], list[str]]:
    root = current_root.rstrip("/") + "/"
    scoped = [p for p in paths if p.startswith(root)]
    complete: list[str] = []
    unavailable: list[str] = []
    for tf in expected:
        token = tf.lower()
        data_prefix = (root + f"timeframe={tf}/").lower()
        status_path = (root + f"timeframe-status/{tf}.json").lower()
        if any(p.lower().startswith(data_prefix) for p in scoped):
            complete.append(tf)
        elif any(p.lower() == status_path for p in scoped):
            unavailable.append(tf)
    missing = [tf for tf in expected if tf not in complete and tf not in unavailable]
    return complete, unavailable, missing


def integrity(paths: tuple[str, ...], cfg: dict[str, Any]) -> dict[str, Any]:
    current_root = str(cfg["current_root"]).rstrip("/")
    site_root = str(cfg["site_root"]).rstrip("/")
    current = [p for p in paths if p == current_root or p.startswith(current_root + "/")]
    site = [p for p in paths if p == site_root or p.startswith(site_root + "/")]
    expected = list(cfg.get("timeframes") or [])
    complete, unavailable, missing = accounted_timeframes(paths, current_root, expected)
    manifests = [p for p in current if "manifest" in p.rsplit("/", 1)[-1].lower() and p.endswith(".json")]
    hashes = [p for p in current if any(k in p.rsplit("/", 1)[-1].lower() for k in ("hash", "checksum"))]
    checkpoints = [p for p in current if "checkpoint" in p.rsplit("/", 1)[-1].lower()]
    errors: list[str] = []
    if not current:
        errors.append("current artifact root missing")
    if not site:
        errors.append("site-ready root missing")
    if current and not manifests:
        errors.append("manifest missing")
    if current and not hashes:
        errors.append("hash/checksum evidence missing")
    if current and not checkpoints:
        errors.append("checkpoint evidence missing")
    if missing:
        errors.append("unaccounted timeframes: " + ", ".join(missing))
    return {
        "current_exists": bool(current),
        "site_exists": bool(site),
        "completed_timeframes": complete,
        "unavailable_timeframes": unavailable,
        "missing_timeframes": missing,
        "errors": errors,
    }


def classify(run: dict[str, Any] | None, workflow_seen: bool, branch_updated: datetime | None, report: dict[str, Any], cfg: dict[str, Any]) -> str:
    now = utcnow()
    idle = timedelta(minutes=int(os.getenv("IDLE_MINUTES", str(cfg.get("idle_minutes", 15)))))
    queue_stall = timedelta(minutes=int(os.getenv("QUEUE_STALL_MINUTES", str(cfg.get("queue_stall_minutes", 30)))))
    run_timeout = timedelta(minutes=int(os.getenv("RUN_TIMEOUT_MINUTES", str(cfg.get("run_timeout_minutes", 360)))))
    if run:
        status = str(run.get("status") or "")
        conclusion = run.get("conclusion")
        created = parse_dt(run.get("created_at")) or now
        if status in ACTIVE:
            age = now - created
            if status in QUEUE and age >= queue_stall:
                return "STALLED_QUEUE"
            if status == "in_progress" and age >= run_timeout:
                return "STALLED_RUN"
            return "RUNNING"
        if status == "completed":
            if conclusion != "success":
                return "FAILED"
            return "COMPLETE" if not report["errors"] else "INTEGRITY_ERROR"
        return "FAILED"
    if report["current_exists"] and not report["errors"]:
        return "COMPLETE"
    stale = branch_updated is None or now - branch_updated >= idle
    if stale and not workflow_seen:
        return "STALLED_NO_WORKFLOW"
    if stale:
        return "STALLED_NO_RUN"
    return "SETUP_PENDING" if not workflow_seen else "WAITING_FOR_RUN"


def dispatch_payload(state: str, cfg: dict[str, Any], branch_sha: str | None, run: dict[str, Any] | None, report: dict[str, Any]) -> dict[str, Any]:
    payload = {
        "priority": cfg["name"],
        "state": state,
        "priority_branch": cfg["branch"],
        "workflow": cfg["workflow"],
        "issue": cfg["issue"],
        "run_id": run.get("id") if run else None,
        "branch_sha": branch_sha,
        "missing_timeframes": report["missing_timeframes"],
        "integrity_errors": report["errors"],
        "context": {
            "completed_timeframes": report["completed_timeframes"],
            "unavailable_timeframes": report["unavailable_timeframes"],
            "current_root": cfg["current_root"],
            "site_root": cfg["site_root"],
            "guardrails": cfg.get("guardrails", {}),
            "source": "price-action-watchdog-v2",
        },
    }
    if len(payload) > 10:
        raise AssertionError("repository_dispatch client_payload must have <=10 top-level properties")
    return payload


def marker(state: str, branch_sha: str | None, run: dict[str, Any] | None) -> str:
    run_id = run.get("id") if run else "none"
    return f"<!-- AUTOTRADING_PRICE_ACTION_WATCHDOG_V2:{state}:{branch_sha or 'unknown'}:{run_id} -->"


def already_posted(api: str, repo: str, token: str, issue: int, mark: str) -> bool:
    comments = request("GET", f"{api}/repos/{repo}/issues/{issue}/comments?per_page=100", token)
    return any(mark in str(c.get("body") or "") for c in comments or [])


def main() -> int:
    repo = os.environ["GITHUB_REPOSITORY"]
    token = os.environ["GITHUB_TOKEN"]
    api = os.environ.get("GITHUB_API_URL", "https://api.github.com")
    cfg = load_project(os.environ.get("WATCHDOG_REGISTRY", ".github/watchdog-registry.json"), os.environ.get("WATCHDOG_PROJECT", "price-action-v1"))
    dry_run = os.environ.get("WATCHDOG_DRY_RUN", "0").lower() in {"1", "true", "yes"}

    branch_sha, branch_updated, tree_sha = branch_info(api, repo, token, cfg["branch"])
    paths = tree_paths(api, repo, token, tree_sha)
    run, workflow_seen = latest_run(api, repo, token, cfg["branch"], cfg["workflow_name"], cfg["workflow"])
    report = integrity(paths, cfg)
    state = classify(run, workflow_seen, branch_updated, report, cfg)
    summary = {
        "state": state,
        "branch": cfg["branch"],
        "branch_sha": branch_sha,
        "workflow_seen": workflow_seen,
        "run_id": run.get("id") if run else None,
        "run_status": run.get("status") if run else None,
        "run_conclusion": run.get("conclusion") if run else None,
        **report,
        "dry_run": dry_run,
    }
    print(json.dumps(summary, indent=2, sort_keys=True))

    action = ACTIONABLE.get(state)
    if not action:
        return 0
    payload = dispatch_payload(state, cfg, branch_sha, run, report)
    mark = marker(state, branch_sha, run)
    if dry_run:
        print(json.dumps({"would_dispatch": action, "client_payload": payload}, indent=2, sort_keys=True))
        return 0
    issue = int(cfg["issue"])
    if already_posted(api, repo, token, issue, mark):
        print(f"already emitted: {mark}")
        return 0
    body = (
        f"{mark}\nPRICE ACTION V1 watchdog v2: **{state}**\n\n"
        f"- branch: `{cfg['branch']}` @ `{branch_sha or 'unknown'}`\n"
        f"- workflow seen: `{workflow_seen}`\n"
        f"- completed: `{', '.join(report['completed_timeframes']) or 'none'}`\n"
        f"- unavailable with explicit status: `{', '.join(report['unavailable_timeframes']) or 'none'}`\n"
        f"- missing: `{', '.join(report['missing_timeframes']) or 'none'}`\n"
        f"- integrity: `{' ; '.join(report['errors']) or 'OK'}`\n\n"
        "Recovery preserves validated artifacts and does not alter scientific semantics or the reserved Site branch."
    )
    request("POST", f"{api}/repos/{repo}/issues/{issue}/comments", token, {"body": body})
    request("POST", f"{api}/repos/{repo}/dispatches", token, {"event_type": action, "client_payload": payload})
    print(f"emitted {action}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
