#!/usr/bin/env python3
"""Estimate, then optionally download, GC one-minute bars from Databento.

The command is deliberately safe by default: without ``--download`` it only
asks Databento for a price estimate. A download additionally requires an
explicit maximum accepted cost.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Sequence


DATASET = "GLBX.MDP3"
SYMBOL = "GC.v.0"
SCHEMA = "ohlcv-1m"
STYPE_IN = "continuous"
DEFAULT_DAYS = 60
DEFAULT_OUTPUT = Path("data/raw/gc_1m.csv")


class UserError(RuntimeError):
    """A safe, user-actionable command error."""


@dataclass(frozen=True)
class DateRange:
    start: date
    end: date

    def __post_init__(self) -> None:
        if self.end <= self.start:
            raise UserError("--end must be later than --start")

    @property
    def days(self) -> int:
        return (self.end - self.start).days


def iso_date(value: str) -> date:
    try:
        return date.fromisoformat(value)
    except ValueError as exc:
        raise argparse.ArgumentTypeError(
            f"invalid date {value!r}; expected YYYY-MM-DD"
        ) from exc


def nonnegative_decimal(value: str) -> Decimal:
    try:
        parsed = Decimal(value)
    except InvalidOperation as exc:
        raise argparse.ArgumentTypeError("expected a decimal amount") from exc
    if not parsed.is_finite() or parsed < 0:
        raise argparse.ArgumentTypeError("amount must be finite and non-negative")
    return parsed


def default_range(today: date | None = None) -> DateRange:
    end = today or datetime.now(timezone.utc).date()
    return DateRange(start=end - timedelta(days=DEFAULT_DAYS), end=end)


def build_parser(today: date | None = None) -> argparse.ArgumentParser:
    dates = default_range(today)
    parser = argparse.ArgumentParser(
        description=(
            "Estimate the Databento cost for GC.v.0 one-minute bars. "
            "Nothing is downloaded unless --download is supplied."
        )
    )
    parser.add_argument("--start", type=iso_date, default=dates.start)
    parser.add_argument("--end", type=iso_date, default=dates.end)
    parser.add_argument(
        "--download",
        action="store_true",
        help="download only after estimation and the maximum-cost gate",
    )
    parser.add_argument(
        "--max-cost-usd",
        type=nonnegative_decimal,
        help="required with --download; abort if the estimate is higher",
    )
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument(
        "--overwrite",
        action="store_true",
        help="replace an existing output file",
    )
    return parser


def request_parameters(dates: DateRange) -> dict[str, Any]:
    return {
        "dataset": DATASET,
        "symbols": SYMBOL,
        "stype_in": STYPE_IN,
        "schema": SCHEMA,
        "start": dates.start.isoformat(),
        "end": dates.end.isoformat(),
    }


def estimate_cost(client: Any, request: dict[str, Any]) -> Decimal:
    cost = client.metadata.get_cost(**request)
    try:
        result = Decimal(str(cost))
    except InvalidOperation as exc:
        raise UserError(f"Databento returned an invalid cost: {cost!r}") from exc
    if not result.is_finite() or result < 0:
        raise UserError(f"Databento returned an invalid cost: {cost!r}")
    return result


def metadata_path(output: Path) -> Path:
    return output.with_suffix(output.suffix + ".metadata.json")


def download_csv(
    client: Any,
    request: dict[str, Any],
    output: Path,
    *,
    overwrite: bool,
) -> None:
    sidecar = metadata_path(output)
    if not overwrite and (output.exists() or sidecar.exists()):
        raise UserError(
            f"output already exists: {output} (use --overwrite to replace it)"
        )

    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + ".part")
    if temporary.exists():
        temporary.unlink()

    try:
        store = client.timeseries.get_range(**request)
        store.to_csv(
            temporary,
            pretty_ts=True,
            pretty_px=True,
            map_symbols=True,
        )
        if not temporary.exists() or temporary.stat().st_size == 0:
            raise UserError("Databento produced an empty CSV")
        temporary.replace(output)
    finally:
        if temporary.exists():
            temporary.unlink()


def execute(args: argparse.Namespace, client: Any) -> dict[str, Any]:
    dates = DateRange(args.start, args.end)
    request = request_parameters(dates)
    cost = estimate_cost(client, request)

    result: dict[str, Any] = {
        "mode": "estimate",
        "request": request,
        "range_days": dates.days,
        "estimated_cost_usd": str(cost),
        "downloaded": False,
    }

    if not args.download:
        return result
    if args.max_cost_usd is None:
        raise UserError("--download requires --max-cost-usd")
    if cost > args.max_cost_usd:
        raise UserError(
            f"estimated cost ${cost} exceeds --max-cost-usd ${args.max_cost_usd}"
        )

    output = args.output.resolve()
    download_csv(client, request, output, overwrite=args.overwrite)
    sidecar = metadata_path(output)
    result.update(
        {
            "mode": "download",
            "downloaded": True,
            "output": str(output),
            "metadata": str(sidecar),
            "downloaded_at_utc": datetime.now(timezone.utc).isoformat(),
            "max_cost_usd": str(args.max_cost_usd),
        }
    )
    sidecar.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


def create_client() -> Any:
    api_key = os.environ.get("DATABENTO_API_KEY")
    if not api_key:
        raise UserError(
            "DATABENTO_API_KEY is missing; create a Databento key and store it "
            "as an environment secret, never in GitHub or chat"
        )
    try:
        import databento as db
    except ModuleNotFoundError as exc:
        raise UserError(
            "Databento client is not installed; run: "
            "python -m pip install -r requirements-data.txt"
        ) from exc
    return db.Historical(api_key)


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        result = execute(args, create_client())
    except UserError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
