from __future__ import annotations

import json
from pathlib import Path

import run_m10_trailing_initial_risk as b
import run_m14_topstep_150k_risk300 as m14
import run_m17_eb3_noentry_10_17ct as m17

OUT = Path("artifacts")
OUT.mkdir(parents=True, exist_ok=True)

RISK_DOLLARS = 400.0


def main():
    # M18 changes exactly one M17 parameter: normalized dollar risk per 1R.
    m14.RISK_DOLLARS = RISK_DOLLARS

    d1 = b.load_1m()
    d5 = b.make_5m(d1)

    results = []
    for label, start in b.STARTS.items():
        x1 = d1.loc[start:]
        x5 = d5.loc[start:]
        t = m17.simulate_m17(x1, x5)
        t.to_csv(OUT / f"m18_topstep_{label}_trades.csv", index=False)
        risk_eval = m14.evaluate_mll(t, x1)
        risk_eval["ledger"].to_csv(OUT / f"m18_topstep_{label}_ledger.csv", index=False)
        s = m14.summarize(t, risk_eval)
        s["window"] = label
        results.append(s)

    payload = {
        "method": "offline research only",
        "baseline": "M17",
        "only_change": "$400 normalized risk per 1R instead of $300",
        "starting_balance": m14.START_BALANCE,
        "risk_dollars_per_trade": RISK_DOLLARS,
        "mll_distance": m14.MLL_DISTANCE,
        "entry": "M17 unchanged: 5m EB3 + completed 1h SMA50; no new weekday entries 10:00-17:00 CT",
        "management": "M17 unchanged: EB3 wick initial stop; TP7R; 1.5R trail to BE then 3R trail with BE floor; forced flat 15:10 CT",
        "results": results,
    }
    (OUT / "m18_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = [
        "# M18 — M17 at $400 risk per 1R",
        "",
        "Only change vs M17: normalized risk per trade = $400 instead of $300.",
        "",
        "| Window | Trades | W | L | BE | WR ex-BE | Avg R | Net $ | Closed DD $ | Min MLL headroom $ | Survived |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|",
    ]
    for r in results:
        lines.append(
            f"| {r['window']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['breakeven']} | "
            f"{r['win_rate_ex_be_pct']:.2f}% | {r['avg_R']:.3f} | {r['fixed_risk_net_profit']:.0f} | "
            f"{r['closed_equity_max_drawdown']:.0f} | {r['minimum_mll_headroom']:.0f} | {r['topstep_survived']} |"
        )
    report = "\n".join(lines) + "\n"
    (OUT / "m18_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
