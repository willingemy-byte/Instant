from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pandas as pd

import run_m10_trailing_initial_risk as b

OUT = Path("artifacts")
OUT.mkdir(parents=True, exist_ok=True)


def process_minutes_m13(pos, mins: pd.DataFrame):
    """M13 position management on completed 1m bars.

    Phase 1: trail 1.5R behind best favorable price until stop reaches entry.
    Phase 2: never below break-even, then trail 3R behind best favorable price.
    Fixed take-profit = 7R.
    Existing stop/TP is checked before updating from each completed minute.
    """
    if pos is None or mins.empty:
        return pos, None

    eps = 1e-12
    for ts, bar in mins.iterrows():
        side = int(pos["side"])
        stop = float(pos["active_stop"])
        tp = float(pos["tp"])
        ex = why = None

        if side == 1:
            if bar.Open <= stop:
                ex, why = float(bar.Open), "gap_stop"
            elif bar.Open >= tp:
                ex, why = float(bar.Open), "gap_tp"
            elif bar.Low <= stop and bar.High >= tp:
                ex, why = stop, "both_stop_first"
            elif bar.Low <= stop:
                ex, why = stop, "stop"
            elif bar.High >= tp:
                ex, why = tp, "tp7"
        else:
            if bar.Open >= stop:
                ex, why = float(bar.Open), "gap_stop"
            elif bar.Open <= tp:
                ex, why = float(bar.Open), "gap_tp"
            elif bar.High >= stop and bar.Low <= tp:
                ex, why = stop, "both_stop_first"
            elif bar.High >= stop:
                ex, why = stop, "stop"
            elif bar.Low <= tp:
                ex, why = tp, "tp7"

        if ex is not None:
            r = ((ex - float(pos["entry"])) / float(pos["risk"])) * side
            rec = {**pos, "exit": ex, "exit_time": ts, "reason": why, "R": r}
            return None, rec

        entry = float(pos["entry"])
        risk = float(pos["risk"])

        if side == 1:
            pos["best_price"] = max(float(pos["best_price"]), float(bar.High))
            if not bool(pos.get("phase2", False)):
                candidate = float(pos["best_price"]) - 1.5 * risk
                pos["active_stop"] = max(float(pos["active_stop"]), min(entry, candidate))
                if float(pos["active_stop"]) >= entry - eps:
                    pos["active_stop"] = entry
                    pos["phase2"] = True
            else:
                candidate = float(pos["best_price"]) - 3.0 * risk
                pos["active_stop"] = max(entry, float(pos["active_stop"]), candidate)
        else:
            pos["best_price"] = min(float(pos["best_price"]), float(bar.Low))
            if not bool(pos.get("phase2", False)):
                candidate = float(pos["best_price"]) + 1.5 * risk
                pos["active_stop"] = min(float(pos["active_stop"]), max(entry, candidate))
                if float(pos["active_stop"]) <= entry + eps:
                    pos["active_stop"] = entry
                    pos["phase2"] = True
            else:
                candidate = float(pos["best_price"]) + 3.0 * risk
                pos["active_stop"] = min(entry, float(pos["active_stop"]), candidate)

    return pos, None


def simulate_m13(d1: pd.DataFrame, d5: pd.DataFrame) -> pd.DataFrame:
    c5 = d5.Close.to_numpy(float)
    h5 = d5.High.to_numpy(float)
    l5 = d5.Low.to_numpy(float)
    idx5 = d5.index

    pivots = b.raw_pivots(d5)
    by_confirm = {}
    for p in pivots:
        by_confirm.setdefault(p["confirm_i"], []).append(p)

    seq = []
    long_state = None
    short_state = None
    pos = None
    rec = []
    one_ns = pd.Timedelta(nanoseconds=1)

    for i in range(len(d5)):
        close_time = idx5[i] + pd.Timedelta(minutes=5)
        prev_close = idx5[i] if i == 0 else idx5[i - 1] + pd.Timedelta(minutes=5)

        if pos is not None:
            mins = d1.loc[prev_close:close_time - one_ns]
            pos, done = process_minutes_m13(pos, mins)
            if done is not None:
                rec.append(done)

        for p in by_confirm.get(i, []):
            if not seq or p["type"] != seq[-1]["type"]:
                seq.append(p.copy())
            else:
                q = seq[-1]
                replace = (
                    (p["type"] == "H" and p["price"] >= q["price"])
                    or (p["type"] == "L" and p["price"] <= q["price"])
                )
                if replace:
                    seq[-1] = p.copy()
            if len(seq) > 30:
                seq = seq[-30:]

            bf = b.bearish_five(seq)
            if bf is not None:
                long_state = {
                    "phase": "wait_wave1_high",
                    "terminal": bf[-1].copy(),
                    "wave1": None,
                    "wave2": None,
                }

            uf = b.bullish_five(seq)
            if uf is not None:
                short_state = {
                    "phase": "wait_wave1_low",
                    "terminal": uf[-1].copy(),
                    "wave1": None,
                    "wave2": None,
                }

            if long_state is not None and p["pivot_i"] > long_state["terminal"]["pivot_i"]:
                if long_state["phase"] == "wait_wave1_high" and p["type"] == "H":
                    long_state["wave1"] = p.copy()
                    long_state["phase"] = "wait_wave2_low"
                elif long_state["phase"] == "wait_wave2_low" and p["type"] == "L":
                    if p["price"] > long_state["terminal"]["price"]:
                        long_state["wave2"] = p.copy()
                        long_state["phase"] = "armed"
                    else:
                        long_state = None

            if short_state is not None and p["pivot_i"] > short_state["terminal"]["pivot_i"]:
                if short_state["phase"] == "wait_wave1_low" and p["type"] == "L":
                    short_state["wave1"] = p.copy()
                    short_state["phase"] = "wait_wave2_high"
                elif short_state["phase"] == "wait_wave2_high" and p["type"] == "H":
                    if p["price"] < short_state["terminal"]["price"]:
                        short_state["wave2"] = p.copy()
                        short_state["phase"] = "armed"
                    else:
                        short_state = None

        if long_state is not None and long_state["phase"] == "armed" and l5[i] <= long_state["terminal"]["price"]:
            long_state = None
        if short_state is not None and short_state["phase"] == "armed" and h5[i] >= short_state["terminal"]["price"]:
            short_state = None

        if pos is None:
            if long_state is not None and long_state["phase"] == "armed":
                w1, w2, term = long_state["wave1"], long_state["wave2"], long_state["terminal"]
                if c5[i] > w1["price"] and i > w2["confirm_i"]:
                    entry = float(c5[i])
                    sl = float(term["price"])
                    risk = entry - sl
                    if risk > 0:
                        pos = {
                            "side": 1,
                            "entry": entry,
                            "entry_time": close_time,
                            "risk": risk,
                            "initial_stop": sl,
                            "active_stop": sl,
                            "tp": entry + 7.0 * risk,
                            "best_price": entry,
                            "phase2": False,
                            "terminal_time": term["time"],
                            "wave1_time": w1["time"],
                            "wave2_time": w2["time"],
                        }
                        long_state = None
            elif short_state is not None and short_state["phase"] == "armed":
                w1, w2, term = short_state["wave1"], short_state["wave2"], short_state["terminal"]
                if c5[i] < w1["price"] and i > w2["confirm_i"]:
                    entry = float(c5[i])
                    sl = float(term["price"])
                    risk = sl - entry
                    if risk > 0:
                        pos = {
                            "side": -1,
                            "entry": entry,
                            "entry_time": close_time,
                            "risk": risk,
                            "initial_stop": sl,
                            "active_stop": sl,
                            "tp": entry - 7.0 * risk,
                            "best_price": entry,
                            "phase2": False,
                            "terminal_time": term["time"],
                            "wave1_time": w1["time"],
                            "wave2_time": w2["time"],
                        }
                        short_state = None

    if pos is not None:
        start = idx5[-1] + pd.Timedelta(minutes=5)
        pos, done = process_minutes_m13(pos, d1.loc[start:])
        if done is not None:
            rec.append(done)

    return pd.DataFrame(rec)


def metrics(t: pd.DataFrame):
    if t.empty:
        return {"trades": 0}

    eps = 1e-9
    r = t["R"].astype(float)
    wins = r > eps
    losses = r < -eps
    be = r.abs() <= eps
    gp = r[wins].sum()
    gl = -r[losses].sum()

    return {
        "trades": int(len(t)),
        "wins": int(wins.sum()),
        "losses": int(losses.sum()),
        "breakeven": int(be.sum()),
        "win_rate_pct": float(100.0 * wins.mean()),
        "avg_R": float(r.mean()),
        "profit_factor_R": float(gp / gl) if gl > 0 else None,
        "median_R": float(r.median()),
        "full_minus_1R": int((r <= -0.999).sum()),
        "partial_losses": int(((r < -eps) & (r > -0.999)).sum()),
        "partial_wins": int(((r > eps) & (r < 6.999)).sum()),
        "tp_7R": int((r >= 6.999).sum()),
        "wins_ge_1R": int((r >= 1.0).sum()),
        "wins_ge_3R": int((r >= 3.0).sum()),
        "wins_ge_5R": int((r >= 5.0).sum()),
        "max_R": float(r.max()),
    }


def main():
    d1 = b.load_1m()
    d5 = b.make_5m(d1)

    snap = OUT / "m13_mgc_5m_from_1m_snapshot.csv"
    d5.to_csv(snap)
    sha = hashlib.sha256(snap.read_bytes()).hexdigest()

    results = []
    for label, start in b.STARTS.items():
        x1 = d1.loc[start:]
        x5 = d5.loc[start:]
        t = simulate_m13(x1, x5)
        t.to_csv(OUT / f"m13_{label}_trades.csv", index=False)
        m = metrics(t)
        m.update(window=label)
        results.append(m)

    payload = {
        "method": "offline research only",
        "instrument": "MGC Micro Gold Futures continuous",
        "signal_timeframe": "5m",
        "management_timeframe": "1m",
        "snapshot_sha256": sha,
        "entry_logic": "same M9b five-wave exhaustion + wave1/wave2 + breakout-close entry",
        "initial_stop": "full five-wave terminal structure extreme",
        "take_profit": "fixed 7R",
        "trailing_rule": {
            "phase1": "1.5R behind best favorable price until stop reaches break-even",
            "phase2": "once break-even is reached, stop never returns below entry and trails 3R behind best favorable price",
            "long_phase2": "max(entry, old_stop, best_high - 3R)",
            "short_phase2": "min(entry, old_stop, best_low + 3R)",
        },
        "intraminute_rule": "existing stop/TP checked first; trail updated from completed 1m bar for next minute",
        "results": results,
    }
    (OUT / "m13_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = [
        "# M13 — 1.5R to BE, then 3R trail, TP 7R",
        "",
        f"Snapshot SHA256: `{sha}`",
        "",
        "Signals remain 5m; position management uses underlying 1m bars.",
        "",
        "| Window | Trades | Wins | Losses | BE | WR | Avg R | PF(R) | -1R full | Partial losses | Partial wins | TP 7R | >=3R wins | Max R |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in results:
        pf = "n/a" if r.get("profit_factor_R") is None else f"{r['profit_factor_R']:.3f}"
        lines.append(
            f"| {r['window']} | {r['trades']} | {r['wins']} | {r['losses']} | {r['breakeven']} | "
            f"{r['win_rate_pct']:.2f}% | {r['avg_R']:.3f} | {pf} | {r['full_minus_1R']} | "
            f"{r['partial_losses']} | {r['partial_wins']} | {r['tp_7R']} | {r['wins_ge_3R']} | {r['max_R']:.3f} |"
        )
    lines += [
        "",
        "Rules:",
        "- Same M9b price-action entry and full-structure initial stop.",
        "- TP = 7R.",
        "- Phase 1 trail = 1.5R behind best favorable price until break-even.",
        "- Phase 2 trail = 3R behind best favorable price, with break-even as the hard floor/ceiling.",
        "- Existing stop/TP is evaluated before using each completed 1m bar to update the trail.",
    ]
    report = "\n".join(lines) + "\n"
    (OUT / "m13_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
