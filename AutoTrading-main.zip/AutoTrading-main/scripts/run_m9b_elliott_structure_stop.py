from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pandas as pd

import run_m9_elliott_5wave_12break as m9

OUT = Path("artifacts")
OUT.mkdir(parents=True, exist_ok=True)


def simulate(d: pd.DataFrame) -> pd.DataFrame:
    O = d.Open.to_numpy(float)
    H = d.High.to_numpy(float)
    L = d.Low.to_numpy(float)
    C = d.Close.to_numpy(float)
    idx = d.index

    pivots = m9.raw_pivots(d)
    by_confirm = {}
    for p in pivots:
        by_confirm.setdefault(p["confirm_i"], []).append(p)

    swing_seq = []
    long_state = None
    short_state = None
    pos = None
    records = []

    for i in range(len(d)):
        if pos is not None and i > pos["entry_i"]:
            side, sl, tp = pos["side"], pos["sl"], pos["tp"]
            ex = why = None
            if side == 1:
                if O[i] <= sl:
                    ex, why = O[i], "gap_sl"
                elif O[i] >= tp:
                    ex, why = O[i], "gap_tp"
                elif L[i] <= sl and H[i] >= tp:
                    ex, why = sl, "both_stop_first"
                elif L[i] <= sl:
                    ex, why = sl, "sl"
                elif H[i] >= tp:
                    ex, why = tp, "tp"
            else:
                if O[i] >= sl:
                    ex, why = O[i], "gap_sl"
                elif O[i] <= tp:
                    ex, why = O[i], "gap_tp"
                elif H[i] >= sl and L[i] <= tp:
                    ex, why = sl, "both_stop_first"
                elif H[i] >= sl:
                    ex, why = sl, "sl"
                elif L[i] <= tp:
                    ex, why = tp, "tp"
            if ex is not None:
                r = ((ex - pos["entry"]) / pos["risk"]) * side
                records.append({**pos, "exit": ex, "exit_time": idx[i], "exit_i": i, "reason": why, "R": r})
                pos = None

        for p in by_confirm.get(i, []):
            if not swing_seq or p["type"] != swing_seq[-1]["type"]:
                swing_seq.append(p.copy())
            else:
                prev = swing_seq[-1]
                replace = (p["type"] == "H" and p["price"] >= prev["price"]) or (
                    p["type"] == "L" and p["price"] <= prev["price"]
                )
                if replace:
                    swing_seq[-1] = p.copy()
            if len(swing_seq) > 30:
                swing_seq = swing_seq[-30:]

            bf = m9.bearish_five(swing_seq)
            if bf is not None:
                long_state = {
                    "phase": "wait_wave1_high",
                    "five": [x.copy() for x in bf],
                    "terminal": bf[-1].copy(),
                    "wave1": None,
                    "wave2": None,
                }

            uf = m9.bullish_five(swing_seq)
            if uf is not None:
                short_state = {
                    "phase": "wait_wave1_low",
                    "five": [x.copy() for x in uf],
                    "terminal": uf[-1].copy(),
                    "wave1": None,
                    "wave2": None,
                }

            if long_state is not None:
                term = long_state["terminal"]
                if p["pivot_i"] > term["pivot_i"]:
                    if long_state["phase"] == "wait_wave1_high" and p["type"] == "H":
                        long_state["wave1"] = p.copy()
                        long_state["phase"] = "wait_wave2_low"
                    elif long_state["phase"] == "wait_wave2_low" and p["type"] == "L":
                        if p["price"] > term["price"]:
                            long_state["wave2"] = p.copy()
                            long_state["phase"] = "armed"
                        else:
                            long_state = None

            if short_state is not None:
                term = short_state["terminal"]
                if p["pivot_i"] > term["pivot_i"]:
                    if short_state["phase"] == "wait_wave1_low" and p["type"] == "L":
                        short_state["wave1"] = p.copy()
                        short_state["phase"] = "wait_wave2_high"
                    elif short_state["phase"] == "wait_wave2_high" and p["type"] == "H":
                        if p["price"] < term["price"]:
                            short_state["wave2"] = p.copy()
                            short_state["phase"] = "armed"
                        else:
                            short_state = None

        if long_state is not None and long_state["phase"] == "armed" and L[i] <= long_state["terminal"]["price"]:
            long_state = None
        if short_state is not None and short_state["phase"] == "armed" and H[i] >= short_state["terminal"]["price"]:
            short_state = None

        if pos is None:
            if long_state is not None and long_state["phase"] == "armed":
                w1 = long_state["wave1"]
                w2 = long_state["wave2"]
                term = long_state["terminal"]
                if C[i] > w1["price"] and i > w2["confirm_i"]:
                    entry = C[i]
                    # M9b change: stop at the extreme wick of the entire completed five-wave structure.
                    sl = term["price"]
                    risk = entry - sl
                    if risk > 0:
                        pos = {
                            "side": 1,
                            "entry": entry,
                            "entry_time": idx[i],
                            "entry_i": i,
                            "sl": sl,
                            "tp": entry + 3.0 * risk,
                            "risk": risk,
                            "five_terminal_time": term["time"],
                            "five_terminal_price": term["price"],
                            "wave1_time": w1["time"],
                            "wave1_price": w1["price"],
                            "wave2_time": w2["time"],
                            "wave2_price": w2["price"],
                        }
                        long_state = None
            elif short_state is not None and short_state["phase"] == "armed":
                w1 = short_state["wave1"]
                w2 = short_state["wave2"]
                term = short_state["terminal"]
                if C[i] < w1["price"] and i > w2["confirm_i"]:
                    entry = C[i]
                    # M9b change: stop at the extreme wick of the entire completed five-wave structure.
                    sl = term["price"]
                    risk = sl - entry
                    if risk > 0:
                        pos = {
                            "side": -1,
                            "entry": entry,
                            "entry_time": idx[i],
                            "entry_i": i,
                            "sl": sl,
                            "tp": entry - 3.0 * risk,
                            "risk": risk,
                            "five_terminal_time": term["time"],
                            "five_terminal_price": term["price"],
                            "wave1_time": w1["time"],
                            "wave1_price": w1["price"],
                            "wave2_time": w2["time"],
                            "wave2_price": w2["price"],
                        }
                        short_state = None

    return pd.DataFrame(records)


def main():
    d = m9.load_data()
    snap = OUT / "m9b_mgc_5m_snapshot.csv"
    d.to_csv(snap)
    sha = hashlib.sha256(snap.read_bytes()).hexdigest()
    results = []

    for label, start in m9.STARTS.items():
        x = d.loc[d.index >= start].copy()
        t = m9.add_excursions(x, simulate(x))
        t.to_csv(OUT / f"m9b_{label}_trades.csv", index=False)
        met = m9.metrics(t)
        met["window"] = label
        results.append(met)

    payload = {
        "method": "offline research replay only",
        "instrument": "MGC Micro Gold Futures continuous",
        "timeframe": "5m",
        "snapshot_sha256": sha,
        "strategy": "M9b Elliott-inspired five-wave exhaustion + wave1/wave2 + close beyond wave1 + full-structure stop",
        "rules": {
            "entry": "same as M9",
            "stop_long": "terminal low wick of the completed bearish five-wave structure",
            "stop_short": "terminal high wick of the completed bullish five-wave structure",
            "take_profit": "3R from the wider full-structure stop distance",
            "session_filter": None,
        },
        "results": results,
    }
    (OUT / "m9b_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = [
        "# M9b — Elliott-inspired 5-wave + 1/2 breakout, full-structure stop",
        "",
        f"Snapshot SHA256: `{sha}`",
        "",
        "| Window | Trades | Wins | Losses | WR | Avg R | PF(R) | Loss MFE→TP mean |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in results:
        lines.append(
            f"| {r['window']} | {r['trades']} | {r['wins']} | {r['losses']} | "
            f"{r['win_rate_pct']:.2f}% | {r['avg_R']:.3f} | "
            f"{r['profit_factor_R'] if r['profit_factor_R'] is not None else 'n/a'} | "
            f"{r.get('loss_mfe_tp_mean') if r.get('loss_mfe_tp_mean') is not None else 'n/a'} |"
        )
    lines += [
        "",
        "Rules:",
        "- Same M9 causal five-wave exhaustion and wave1/wave2 breakout logic.",
        "- Entry remains the 5m close beyond wave1 after wave2 is confirmed.",
        "- Stop is now at the terminal extreme wick of the entire completed five-wave structure, not wave2.",
        "- TP remains exactly 3R, therefore moves farther away when the structural stop is wider.",
        "- No RSI, moving average, engulfing, break-even or session filter.",
    ]
    report = "\n".join(lines) + "\n"
    (OUT / "m9b_report.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
