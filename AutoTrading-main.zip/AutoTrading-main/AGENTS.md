# AutoTrading — Protocole durable pour Codex

Ces règles s'appliquent à tout agent qui travaille dans ce dépôt.

## Avant de travailler

1. Lire `WORKPLAN.md`.
2. Lire `STATUS.md`.
3. Lire au moins les 20 dernières lignes de `WORKLOG.jsonl`.
4. Vérifier `git status` et `git log -1 --oneline`.
5. Nommer un seul objectif, un payoff vérifiable et un identifiant de run.
6. Écrire un événement `start` avant toute recherche ou opération longue.

## Pendant le travail

- Écrire un événement après chaque action matérielle : lecture structurante, décision, modification, test, erreur ou blocage.
- Ne jamais dépasser 5 minutes ou 3 appels d'outil sans checkpoint durable.
- Avant un appel réseau, navigateur, TradingView ou authentification potentiellement long, enregistrer l'action qui va commencer et la condition d'arrêt.
- Si un blocage dure plus de 2 minutes, écrire un événement `block`, créer un commit `wip:` et s'arrêter avec une demande précise.
- Chaque événement doit contenir des faits reprenables : action, résultat, fichiers, tests, blocage et prochaine action exacte.
- Ne pas enregistrer de mot de passe, jeton, cookie, clé API, donnée personnelle sensible ou secret de dépôt.
- Ne pas prétendre enregistrer le raisonnement interne privé. Écrire plutôt un résumé opérationnel explicite de la décision et de ses preuves.

Exemple :

```bash
python scripts/worklog.py checkpoint \
  --run-id tvcontrol-audit \
  --step "Auditer l'intégration TradingView" \
  --payoff "Tableau de capacités vérifiées" \
  --summary "Le dépôt A expose les commandes B et C." \
  --action "Lecture du README et du code d'entrée" \
  --result "Injection Pine confirmée; authentification locale requise" \
  --file docs/tvcontrol-audit.md \
  --test "Liens et commandes vérifiés" \
  --next "Tester l'installation minimale" \
  --commit --push
```

## À chaque fin d'étape

1. Exécuter les tests pertinents.
2. Écrire `checkpoint`, `block` ou `finish`.
3. Inclure les fichiers de l'étape avec `--file`.
4. Utiliser `--commit --push` pour rendre le checkpoint visible sur GitHub.
5. Rapporter le SHA complet et sa version courte.
6. Ne commencer l'étape suivante qu'après l'existence du payoff.

Si le push est impossible, conserver le commit local, rapporter immédiatement son SHA et inscrire le blocage dans le journal.
