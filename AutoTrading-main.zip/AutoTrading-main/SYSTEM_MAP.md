# AUTO TRADING — carte globale du système

> **Dépôt :** `willingemy-byte/AutoTrading`  
> **Rôle de ce document :** point d’entrée pour comprendre comment les branches actives s’emboîtent.  
> **Règle :** chaque branche active conserve son propre `BRANCH_SYSTEM_MAP.md` avec les détails locaux.

## Vue globale

```mermaid
flowchart LR
    subgraph SOURCES[Sources de données]
        A[MGC historique 1 minute]
        B[GC trade ticks]
    end

    subgraph SCIENCE[Branches scientifiques]
        C[research/entry-path-v1\nParcours post-entrée]
        D[research/price-action-v1\nStructure multi-timeframe minute]
        E[research/price-action-tick-v1\n25t → familles tick → parcours tick]
    end

    subgraph FEEDS[Feeds de consultation]
        F[Entry-Path current/site]
        G[Price Action minute current/site]
        H[Tick site feed]
    end

    subgraph SITE[Couche Site]
        I[site/entry-path-dashboard-v1]
        J[Manifest de routage]
        K[Dashboard]
        L[ChatGPT Site publié]
    end

    A --> C
    A --> D
    B --> E

    C --> F
    D --> G
    E --> H

    F --> I
    G --> I
    H --> I
    I --> J
    J --> K
    K --> L
```

## Les quatre territoires actifs

### `research/entry-path-v1`

**Question à laquelle cette branche répond :**
> Après une entrée historique donnée, avec son stop initial original, quel chemin le prix a-t-il réellement parcouru ?

Entrées principales :
- entrées historiques des stratégies;
- stop initial original;
- historique MGC minute.

Sorties principales :
- `R_PATH`;
- `EXTREMA_PATH`;
- first-passage;
- MFE / MAE;
- terminal +7R / -7R / force-flat / fin de données;
- feed `results/entry-path-v1/current/site/`.

Détails locaux : `research/entry-path-v1/BRANCH_SYSTEM_MAP.md`.

---

### `research/price-action-v1`

**Question à laquelle cette branche répond :**
> Quelle était la structure déterministe du marché, indépendamment des stratégies ?

Entrée principale :
- historique MGC 1 minute qualifié et épinglé.

Transformation :
- 1W, 1D, 4H, 2H, 1H, 15m, 5m, 3m, 1m;
- HH / HL / LH / LL;
- impulsions / retracements / waves;
- ranges bullish/bearish;
- position 0–100 %;
- changements de structure et breaks.

Sortie :
- `results/price-action-v1/current/`;
- feed léger `results/price-action-v1/current/site/`.

Détails locaux : `research/price-action-v1/BRANCH_SYSTEM_MAP.md`.

---

### `research/price-action-tick-v1`

**Question à laquelle cette branche répond :**
> Que révèle la chronologie tick lorsqu’on observe le marché à travers différentes tailles de barres en nombre de trades ?

Chaîne canonique :

```mermaid
flowchart LR
    A[Raw ordered trade ticks] --> B[25t canonique]
    B --> C[50t]
    B --> D[75t]
    B --> E[100t]
    B --> F[...]
    B --> G[2000t]
    C --> H[Analyses tick]
    D --> H
    E --> H
    F --> H
    G --> H
```

Règle importante :
- les barres minute ne sont jamais reconstruites depuis les ticks;
- le 25t sert de couche canonique intermédiaire;
- les familles supérieures sont dérivées du 25t;
- si une grosse barre crée une ambiguïté, on descend vers une résolution plus fine, puis vers le raw si nécessaire.

Détails locaux : `research/price-action-tick-v1/BRANCH_SYSTEM_MAP.md`.

---

### `site/entry-path-dashboard-v1`

**Question à laquelle cette branche répond :**
> Comment consulter les résultats scientifiques sans recalculer la science ?

Cette branche :
- lit les feeds scientifiques;
- maintient un manifest de routage léger;
- charge les données lourdes à la demande;
- sert l’interface de comparaison, drill-down, santé et Price Action;
- ne modifie jamais les branches scientifiques.

Détails locaux : `site/entry-path-dashboard-v1/BRANCH_SYSTEM_MAP.md`.

## Flux complet d’une donnée

```mermaid
flowchart TD
    A[Source brute] --> B[Branche scientifique]
    B --> C[Artifact déterministe]
    C --> D[Validation / hashes / manifest]
    D --> E[current/site]
    E --> F[Miroir léger branche Site]
    F --> G[site_manifest.json]
    G --> H[Interface]
    H --> I[Publication ChatGPT Site]
```

## Où chercher selon le problème

| Ce que tu cherches | Branche à ouvrir |
|---|---|
| entrée, stop original, R_PATH, EXTREMA, MFE, MAE | `research/entry-path-v1` |
| HH/HL/LH/LL, range, wave, structure minute | `research/price-action-v1` |
| 25t, familles tick, ambiguïtés tick, parcours tick | `research/price-action-tick-v1` |
| manifest, dashboard, chargement mobile, publication | `site/entry-path-dashboard-v1` |
| vue d’ensemble | `main/SYSTEM_MAP.md` |

## Garde-fous globaux

- GitHub et les artifacts validés restent la source de vérité.
- Ne pas recalculer un artifact valide si ses inputs/hashes sont inchangés.
- Les branches scientifiques restent séparées.
- Le Site est une couche de lecture uniquement.
- Le Site ne doit jamais fabriquer une métrique scientifique.
- Les données lourdes doivent être chargées à la demande.
- Le holdout reste séparé tant qu’il n’est pas explicitement ouvert.
- Les changements de schéma doivent être versionnés et documentés.
- Une publication live est distincte d’un simple build GitHub.

## Documentation obligatoire par branche

Chaque branche active doit maintenir un `BRANCH_SYSTEM_MAP.md` contenant au minimum :

1. son rôle;
2. ses entrées;
3. ses transformations;
4. ses sorties/artifacts;
5. ses dépendances;
6. ses garde-fous;
7. où chercher les fichiers importants;
8. un schéma visuel simple avec flèches lorsque pertinent.

Quand l’architecture change, **la carte doit être mise à jour dans le même changement** afin que le prochain agent puisse reprendre sans reconstruire le système de mémoire.
