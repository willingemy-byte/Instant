# AutoTrading — WORK PLAN

## Objectif mesurable

Déterminer si les règles d'entrée et de sortie sont rentables sur le contrat à terme Gold `GC`, en chandelles de 5 minutes, sur environ 60 jours.

## Portée actuelle

- Backtest de recherche seulement, directement dans TradingView ou hors ligne selon les barres déjà accessibles.
- Utiliser uniquement les barres GC déjà accessibles gratuitement pour le peaufinage initial d'environ 60 jours.
- Aucun achat de données et aucun compte de fournisseur à créer pour cette étape.
- Aucun ordre réel et aucune connexion à un compte de courtage.
- Aucune connexion à un compte TradingView n'est requise si le Strategy Tester invité suffit.
- TradingView automatisé en continu et Alibaba Cloud sont reportés à la phase de déploiement.

## Étapes et payoff

| Étape | Travail | Payoff vérifiable | État |
|---|---|---|---|
| 1 | Fixer la fenêtre de test | GC 5 minutes, environ 60 jours de barres déjà accessibles, sans achat | **Corrigé** |
| 2 | Charger les données disponibles | Fenêtre réellement couverte et nombre de barres rapportés | **Chart visible; Strategy Tester invité bloqué** |
| 3 | Figeler les règles | Spécification non ambiguë de l'entrée, du stop, de la sortie et des cas intrabar | **Baseline et variante sans horaire créés** |
| 4 | Construire le moteur | Backtest déterministe avec tests automatisés et frais configurables | À faire |
| 5 | Exécuter et comparer | Win rate, profit factor, expectancy, drawdown et comparaison aux résultats ~57 % / ~25 % | À faire |
| 6 | Conclure | Décision: rejeter, modifier ou passer à une validation plus longue | À faire |

## Décision de données actuelle

Le peaufinage se fait avec les données GC 5 minutes déjà accessibles, sur un maximum visé d'environ 60 jours. Il n'exige pas 5, 10 ou 20 ans d'historique et ne justifie aucun achat.

Le téléchargeur Databento déjà écrit demeure dormant comme solution éventuelle de validation indépendante. Il ne fait plus partie du chemin actif et aucun compte Databento ne doit être créé maintenant.

## Prochaine action exacte

Ouvrir une session gratuite TradingView existante dans le navigateur contrôlé, puis charger `strategies/manus_v1_executable.pine` sur `GC1!` 5 minutes. Si aucune connexion n'est possible, obtenir un CSV gratuit réel avant de prétendre avoir testé 60 jours.

## Règle de reprise

Après chaque étape ou au maximum après trois opérations matérielles, mettre à jour `STATUS.md` et `WORKLOG.jsonl`, puis publier un commit GitHub.
